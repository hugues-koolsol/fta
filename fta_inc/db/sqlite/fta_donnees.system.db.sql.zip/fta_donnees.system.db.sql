/*



  =========================================================================
  Pour la table tbl_cibles il y a 3 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_cibles`( `chi_id_cible`, `chp_nom_cible`, `chp_dossier_cible`, `chp_commentaire_cible`) VALUES
('1','fta','fta','la racine');
/*



  =========================================================================
  Pour la table tbl_dossiers il y a 5 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_dossiers`( `chi_id_dossier`, `chx_cible_dossier`, `chp_nom_dossier`) VALUES
('1','1','/'),
('2','1','/fta_inc/db/sqlite'),
('3','1','/fta_inc/sql');
/*



  =========================================================================
  Pour la table tbl_sources il y a 9 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_sources`( `chi_id_source`, `chx_cible_id_source`, `chp_nom_source`, `chp_commentaire_source`, `chx_dossier_id_source`, `chp_rev_source`, `chp_genere_source`, `chp_type_source`) VALUES
('1','1','index.html',NULL,'1','html(
   (doctype),
   #(
     ===============================================================================================================
     exemple de programme html simple avec une redirection 
     Il y a un outil qui génère un fichier rev  à partir d''un fichier html
     Il y a un outil qui génère un fichier html à partir d''un fichier rev
     ===============================================================================================================
   ),
   head(
      meta( ( ''http-equiv'' , "refresh" ) , ( ''content'' , "300; url=''./fta_www/''" )),
      meta( ( ''charset'' , "utf-8" )),
      title( ''exemple de page html''),
      meta( ( ''name'' , "viewport" ) , ( ''content'' , "width=device-width, initial-scale=1" )),
      #(
        définition du css racine pour utilisation du css principal plus bas
      ),
      style( ( ''type'' , "text/css" ) , ''
            :root{ 
--yyvtrg:40px; 
--yyvtrt:12px; /* taille de référence du texte */ 
--yyvtrp:2px; /* taille de référence du espaces ( padding ) */ 
--yyvtrb:1px; /* taille de référence des bordures */ 
--yyvtrm:1px; /* taille de référence dus marges */ 
--yyvhmb:22px; /* hauteur minimales des boutons */ 
--yyvhal:14px; /* hauteur de ligne */ 
--yyvhmd:35px; /* hauteur du menu à défilement */ 
--yyvhgb:32px; /* hauteur des grands boutons ( quitter et index ) */ 
--yyvhmc:24px; /* hauteur minimale de conteneur ( div ) */ 
}''),
      #( Le css root étant défini plus haut, on peut utiliser le fichier 6.css ),
      link( ( ''rel'' , "stylesheet" ) , ( ''as'' , "style" ) , ( ''type'' , "text/css" ) , ( ''href'' , "fta_www/6.css" ))
   ),
   body(
      #( redirection vers la page d''accueil ),
      h1( ''racine de l\''application''),
      p(
         ( ''style'' , "text-align:center;font-size:1.3rem;"),
         ( ''id'' , "phrase"),
         ''Dans'',
         b( span( ( ''id'' , "decompte" ) , ''300'' )),
         ''secondes, vous serez'',
         b( ''redirigé automatiquement''),
         br(),
         ''vers la la page principale de l\''application''
      ),
      div( ( ''style'' , "text-align:center;" ) , a( ( ''class'' , "yyinfo yytbgrand" ) , ( ''style'' , "max-width: fit-content;" ) , ( ''href'' , "fta_www/" ) , ''y aller maintenant'' )),
      div( ( ''style'' , "text-align:center;" ) , a( ( ''class'' , "yyinfo yytbgrand" ) , ( ''style'' , "max-width: fit-content;" ) , ( ''href'' , "tictactoe.html" ) , ''aller sur tictactoe'' )),
      javascriptDansHtml(
         ( ''type'' , "text/javascript"),
         source(
            #(
              =============================================================================================
              programme javascript d''affichage de décompte 
              =============================================================================================
            ),
            declare( decompte , 300),
            declare( a , appelf( element(document) , nomf(getElementsByTagName) , p( ''meta'' ) )),
            choix(
               si(
                  condition( et( a , sup( a.length , 0 ) )),
                  alors(
                     boucle(
                        initialisation( declare( i , 0 )),
                        condition( inf( i , a.length )),
                        increment(i++),
                        faire(
                           choix(
                              si(
                                 condition(
                                    et(
                                       appelf( element(a[i]) , nomf(getAttribute) , p( ''http-equiv'' )),
                                       egal( appelf( element(a[i]) , nomf(getAttribute) , p( ''http-equiv'' ) ) , "refresh"),
                                       appelf( element(a[i]) , nomf(getAttribute) , p( ''content'' ))
                                    )
                                 ),
                                 alors(
                                    declare( contenu , appelf( element(a[i]) , nomf(getAttribute) , p( ''content'' ) )),
                                    #( content="300; url=''./fta_www/''" ),
                                    choix(
                                       si(
                                          condition(
                                             supeg( appelf( element(contenu) , nomf(indexOf) , p( '';'' ) ) , 0)
                                          ),
                                          alors(
                                             declare(
                                                temps_en_secondes,
                                                appelf(
                                                   element(contenu),
                                                   nomf(substr),
                                                   p(0),
                                                   p( appelf( element(contenu) , nomf(indexOf) , p( '';'' ) ))
                                                )
                                             ),
                                             choix(
                                                si(
                                                   condition(
                                                      et(
                                                         non( appelf( nomf(isNaN) , p(temps_en_secondes) )),
                                                         non(
                                                            appelf(
                                                               nomf(isNaN),
                                                               p( appelf( nomf(parseFloat) , p(temps_en_secondes) ))
                                                            )
                                                         )
                                                      )
                                                   ),
                                                   alors(
                                                      affecte( decompte , appelf( nomf(parseInt) , p(temps_en_secondes) , p(10) )),
                                                      affecte(
                                                         appelf( element(document) , nomf(getElementById) , p( ''phrase'' ) , prop(innerHTML)),
                                                         concat(
                                                            ''Dans <b><span id="decompte">'',
                                                            temps_en_secondes,
                                                            ''</span></b> secondes, vous serez '',
                                                            ''<b>redirigé automatiquement</b> '',
                                                            ''<br />'',
                                                            ''vers la la page principale de l\''application''
                                                         )
                                                      ),
                                                      break()
                                                   )
                                                )
                                             )
                                          )
                                       )
                                    )
                                 )
                              )
                           )
                        )
                     )
                  )
               )
            ),
            fonction(
               definition( nom(maj_decompte)),
               contenu(
                  postdec(decompte),
                  affecte( appelf( element(document) , nomf(getElementById) , p( ''decompte'' ) , prop(innerHTML) ) , decompte),
                  appelf( nomf(setTimeout) , p(maj_decompte) , p(1000))
               )
            ),
            appelf( nomf(setTimeout) , p(maj_decompte) , p(1000)),
            fonction( definition( nom(f) , argument(x) ) , contenu( retourner(x) )),
            declare( a , defTab( p( ''x'' ) , p( ''y'' ) )),
            declare(
               test,
               tableau(
                  nomt(a),
                  p(
                     virgule( appelf( nomf(f) , p(0) ) , appelf( nomf(f) , p(1) ))
                  )
               )
            ),
            #( ci dessous test retourne y ! ),
            appelf( element(console) , nomf(log) , p(test))
         )
      )
   )
)','<!DOCTYPE html>
<html>
    <!-- 
      =============================================================================================================
      exemple de programme html simple avec une redirection 
      Il y a un outil qui génère un fichier rev  à partir d''un fichier html
      Il y a un outil qui génère un fichier html à partir d''un fichier rev
      =============================================================================================================
    -->
    <head>
        <meta http-equiv="refresh" content="300; url=''./fta_www/''" />
        <meta charset="utf-8" />
        <title>exemple de page html</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- 
          définition du css racine pour utilisation du css principal plus bas
        -->
        <style type="text/css">
            :root{ 
--yyvtrg:40px; 
--yyvtrt:12px; /* taille de référence du texte */ 
--yyvtrp:2px; /* taille de référence du espaces ( padding ) */ 
--yyvtrb:1px; /* taille de référence des bordures */ 
--yyvtrm:1px; /* taille de référence dus marges */ 
--yyvhmb:22px; /* hauteur minimales des boutons */ 
--yyvhal:14px; /* hauteur de ligne */ 
--yyvhmd:35px; /* hauteur du menu à défilement */ 
--yyvhgb:32px; /* hauteur des grands boutons ( quitter et index ) */ 
--yyvhmc:24px; /* hauteur minimale de conteneur ( div ) */ 
}</style>
        <!-- Le css root étant défini plus haut, on peut utiliser le fichier 6.css -->
        <link rel="stylesheet" as="style" type="text/css" href="fta_www/6.css" />
    </head>
    <body>
        <!-- redirection vers la page d''accueil -->
        <h1>racine de l''application</h1>
        <p style="text-align:center;font-size:1.3rem;" id="phrase">Dans
            <b>
                <span id="decompte">300</span>
            </b>secondes, vous serez
            <b>redirigé automatiquement</b>
            <br />vers la la page principale de l''application
        </p>
        <div style="text-align:center;">
            <a class="yyinfo yytbgrand" style="max-width: fit-content;" href="fta_www/">y aller maintenant</a>
        </div>
        <div style="text-align:center;">
            <a class="yyinfo yytbgrand" style="max-width: fit-content;" href="tictactoe.html">aller sur tictactoe</a>
        </div>
<script type="text/javascript">
//<![CDATA[
//<source_javascript_rev>
/*
  =====================================================================================================================
  programme javascript d''affichage de décompte 
  =====================================================================================================================
*/
var decompte=300;
var a=document.getElementsByTagName( ''meta'' );
if(a && a.length > 0){
    for( var i=0 ; i < a.length ; i++ ){
        if(a[i].getAttribute( ''http-equiv'' ) && a[i].getAttribute( ''http-equiv'' ) == "refresh" && a[i].getAttribute( ''content'' )){
            var contenu=a[i].getAttribute( ''content'' );
            /* content="300; url=''./fta_www/''" */
            if(contenu.indexOf( '';'' ) >= 0){
                var temps_en_secondes=contenu.substr( 0 , contenu.indexOf( '';'' ) );
                if(!isNaN( temps_en_secondes ) && !isNaN( parseFloat( temps_en_secondes ) )){
                    decompte=parseInt( temps_en_secondes , 10 );
                    document.getElementById( ''phrase'' ).innerHTML=''Dans <b><span id="decompte">'' + temps_en_secondes + ''</span></b> secondes, vous serez '' + ''<b>redirigé automatiquement</b> '' + ''<br />'' + ''vers la la page principale de l\''application'';
                    break;
                }
            }
        }
    }
}
function maj_decompte(){
    decompte--;
    document.getElementById( ''decompte'' ).innerHTML=decompte;
    setTimeout( maj_decompte , 1000 );
}
setTimeout( maj_decompte , 1000 );
function f( x ){
    return x;
}
var a=[''x'',''y''];
var test=a[f( 0 ),f( 1 )];
/* ci dessous test retourne y ! */
console.log( test );
//</source_javascript_rev>
//]]>
</script>

    </body>
</html>','normal'),
('5','1','tictactoe.html',NULL,'1','html(
   (doctype),
   ( ''lang'' , "fr"),
   doctype(),
   head(
      #(
        Il y a un outil qui génère un fichier rev  à partir d''un fichier html
        Il y a un outil qui génère un fichier html à partir d''un fichier rev
      ),
      meta( ( ''charset'' , "utf-8" )),
      meta( ( ''name'' , "viewport" ) , ( ''content'' , "width=device-width, initial-scale=1" )),
      meta( ( ''name'' , "description" ) , ( ''content'' , "tictactoe" )),
      title( ''tictactoe''),
      #(
        =========================================================================================================
        le css principal utilise des variables qu''il faut déclarer 
        =========================================================================================================
      ),
      style( ( ''type'' , "text/css" ) , ''
            :root{ 
--yyvtrg:40px; 
--yyvtrt:12px; /* taille de référence du texte */ 
--yyvtrp:2px; /* taille de référence du espaces ( padding ) */ 
--yyvtrb:1px; /* taille de référence des bordures */ 
--yyvtrm:1px; /* taille de référence dus marges */ 
--yyvhmb:22px; /* hauteur minimales des boutons */ 
--yyvhal:14px; /* hauteur de ligne */ 
--yyvhmd:35px; /* hauteur du menu à défilement */ 
--yyvhgb:32px; /* hauteur des grands boutons ( quitter et index ) */ 
--yyvhmc:24px; /* hauteur minimale de conteneur ( div ) */ 
}

h1{text-align:center;} 
#t1{  width:70vmin;  height:70vmin;  margin: 0 auto 0 auto; } 
#t1 td {  width:33%;  text-align:center;  font-size:10vw;  cursor:pointer; } 
h1{  border:0;  margin:0;  height:10vmin; } 
#numero_de_joueur{  font-size:1.8em;  color:red; text-align:center; } 
@keyframes acsb1 { 
   0% { transform: translateY(0)    } 
  25% { transform: translateY(15px) } 
  50% { transform: translateY(-15px)} 
  75% { transform: translateY(15px) } 
 100% { transform: translateY(0)  }
} 
.csb1 { 
  animation: acsb1 0.25s; animation-iteration-count: 3;
}
.csb2 { 
  color: blue!important;
  background: yellow;
  animation: acsb1 0.25s; animation-iteration-count: 3;
}''),
      #(
        =========================================================================================================
        on peut utiliser le css principal 
        =========================================================================================================
      ),
      link( ( ''rel'' , "stylesheet" ) , ( ''as'' , "style" ) , ( ''type'' , "text/css" ) , ( ''href'' , "fta_www/6.css" )),
      style( ( ''type'' , "text/css" ) , ''
tbody tr:nth-child(2n) {
 background-color: revert;
}'')
   ),
   body(
      h1( ''tictactoe'' , a( ( ''href'' , "." ) , ''page d\''accueil'' )),
      div( ( ''id'' , "numero_de_joueur" ) , ( ''class'' , "" )),
      table(
         ( ''border'' , "1"),
         ( ''id'' , "t1"),
         tbody(
            tr( td( ( ''id'' , "0" ) , ''&nbsp;'' ) , td( ( ''id'' , "1" ) , ''&nbsp;'' ) , td( ( ''id'' , "2" ) , ''&nbsp;'' )),
            tr( td( ( ''id'' , "3" ) , ''&nbsp;'' ) , td( ( ''id'' , "4" ) , ''&nbsp;'' ) , td( ( ''id'' , "5" ) , ''&nbsp;'' )),
            tr( td( ( ''id'' , "6" ) , ''&nbsp;'' ) , td( ( ''id'' , "7" ) , ''&nbsp;'' ) , td( ( ''id'' , "8" ) , ''&nbsp;'' ))
         )
      ),
      javascriptDansHtml(
         ( ''type'' , "text/javascript"),
         source(
            directive( "use strict"),
            #(
              =============================================================================================
            ),
            declare( numero_de_joueur , ''x''),
            declare( termine , false),
            declare( message1 , '' clique sur une case ''),
            #(
              =============================================================================================
            ),
            fonction(
               definition( nom(verifie_gagnant1) , argument(nj)),
               contenu(
                  declare( i , 0),
                  boucle(
                     initialisation( affecte( i , 0 )),
                     condition( inf( i , 3 )),
                     increment(i++),
                     faire(
                        choix(
                           si(
                              condition(
                                 et(
                                    egalstricte(
                                       appelf(
                                          element(document),
                                          nomf(getElementById),
                                          p( plus( mult( i , 3 ) , 0 )),
                                          prop(innerHTML)
                                       ),
                                       nj
                                    ),
                                    egalstricte(
                                       appelf(
                                          element(document),
                                          nomf(getElementById),
                                          p( plus( mult( i , 3 ) , 1 )),
                                          prop(innerHTML)
                                       ),
                                       nj
                                    ),
                                    egalstricte(
                                       appelf(
                                          element(document),
                                          nomf(getElementById),
                                          p( plus( mult( i , 3 ) , 2 )),
                                          prop(innerHTML)
                                       ),
                                       nj
                                    )
                                 )
                              ),
                              alors( retourner(1))
                           )
                        )
                     )
                  ),
                  declare( i , 0),
                  boucle(
                     initialisation( affecte( i , 0 )),
                     condition( inf( i , 3 )),
                     increment(i++),
                     faire(
                        choix(
                           si(
                              condition(
                                 et(
                                    egalstricte(
                                       appelf( element(document) , nomf(getElementById) , p( plus( i , 0 ) ) , prop(innerHTML)),
                                       nj
                                    ),
                                    egalstricte(
                                       appelf( element(document) , nomf(getElementById) , p( plus( i , 3 ) ) , prop(innerHTML)),
                                       nj
                                    ),
                                    egalstricte(
                                       appelf( element(document) , nomf(getElementById) , p( plus( i , 6 ) ) , prop(innerHTML)),
                                       nj
                                    )
                                 )
                              ),
                              alors( retourner(1))
                           )
                        )
                     )
                  ),
                  choix(
                     si(
                        condition(
                           et(
                              egalstricte( appelf( element(document) , nomf(getElementById) , p(0) , prop(innerHTML) ) , nj),
                              egalstricte( appelf( element(document) , nomf(getElementById) , p(4) , prop(innerHTML) ) , nj),
                              egalstricte( appelf( element(document) , nomf(getElementById) , p(8) , prop(innerHTML) ) , nj)
                           )
                        ),
                        alors( retourner(1))
                     )
                  ),
                  choix(
                     si(
                        condition(
                           et(
                              egalstricte( appelf( element(document) , nomf(getElementById) , p(6) , prop(innerHTML) ) , nj),
                              egalstricte( appelf( element(document) , nomf(getElementById) , p(4) , prop(innerHTML) ) , nj),
                              egalstricte( appelf( element(document) , nomf(getElementById) , p(2) , prop(innerHTML) ) , nj)
                           )
                        ),
                        alors( retourner(1))
                     )
                  ),
                  #( egalite ),
                  declare( case_vide_trouve , false),
                  declare(
                     lst,
                     appelf(
                        element( appelf( element(document) , nomf(getElementById) , p( ''t1'' ) )),
                        nomf(getElementsByTagName),
                        p( ''td'')
                     )
                  ),
                  declare( i , 0),
                  boucle(
                     initialisation( affecte( i , 0 )),
                     condition( inf( i , lst.length )),
                     increment(i++),
                     faire(
                        choix(
                           si( condition( egalstricte( lst[i].innerHTML , ''&nbsp;'' ) ) , alors( affecte( case_vide_trouve , true ) ))
                        )
                     )
                  ),
                  choix(
                     si(
                        condition( egalstricte( case_vide_trouve , false )),
                        alors(
                           retourner(0),
                           #( egalite )
                        )
                     )
                  ),
                  retourner(2)
               )
            ),
            #(
              =============================================================================================
            ),
            fonction(
               definition( nom(recommencer)),
               contenu(
                  affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , ''csb1''),
                  declare(
                     lst,
                     appelf(
                        element( appelf( element(document) , nomf(getElementById) , p( ''t1'' ) )),
                        nomf(getElementsByTagName),
                        p( ''td'')
                     )
                  ),
                  declare( i , 0),
                  boucle( initialisation( affecte( i , 0 ) ) , condition( inf( i , lst.length ) ) , increment(i++) , faire( affecte( lst[i].innerHTML , ''&nbsp;'' ) )),
                  affecte( numero_de_joueur , ''x''),
                  affecte( termine , false),
                  affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(innerHTML) ) , plus( numero_de_joueur , message1 )),
                  appelf(
                     nomf(setTimeout),
                     p(
                        appelf(
                           nomf(function),
                           contenu(
                              affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , '''')
                           ),
                           p()
                        )
                     ),
                     p(250)
                  )
               )
            ),
            #(
              =============================================================================================
            ),
            fonction(
               definition( nom(monClick) , argument(e)),
               contenu(
                  choix(
                     si( condition( egalstricte( termine , true ) ) , alors( revenir() ))
                  ),
                  choix(
                     si(
                        condition( ou( egalstricte( e.target.innerHTML , ''x'' ) , egalstricte( e.target.innerHTML , ''o'' ) )),
                        alors( revenir())
                     )
                  ),
                  affecte( e.target.innerHTML , numero_de_joueur),
                  declare( a_gagne , appelf( nomf(verifie_gagnant1) , p(numero_de_joueur) )),
                  choix(
                     si(
                        condition( egalstricte( a_gagne , 1 )),
                        alors(
                           declare( t , concat( numero_de_joueur , '' a gagné !'' )),
                           affectop( ''+='' , t , '' <button type="button" onclick="recommencer()">recommencer</button>''),
                           affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(innerHTML) ) , t),
                           affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , ''csb2''),
                           affecte( termine , true),
                           appelf(
                              nomf(setTimeout),
                              p(
                                 appelf(
                                    nomf(function),
                                    contenu(
                                       affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , '''')
                                    ),
                                    p()
                                 )
                              ),
                              p(1250)
                           )
                        )
                     ),
                     sinonsi(
                        condition( egalstricte( a_gagne , 2 )),
                        alors(
                           affecte(
                              numero_de_joueur,
                              testEnLigne( condition( egalstricte( numero_de_joueur , ''o'' ) ) , siVrai( ''x'' ) , siFaux( ''o'' ))
                           ),
                           affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(innerHTML) ) , plus( numero_de_joueur , message1 )),
                           affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , ''csb1''),
                           appelf(
                              nomf(setTimeout),
                              p(
                                 appelf(
                                    nomf(function),
                                    contenu(
                                       affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , '''')
                                    ),
                                    p()
                                 )
                              ),
                              p(250)
                           )
                        )
                     ),
                     sinonsi(
                        condition( egalstricte( a_gagne , 0 )),
                        alors(
                           declare( t , '' égalité ! ''),
                           affectop( ''+='' , t , '' <button type="button" onclick="recommencer()">recommencer</button>''),
                           affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(innerHTML) ) , t),
                           affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , ''csb1''),
                           affecte( termine , true),
                           appelf(
                              nomf(setTimeout),
                              p(
                                 appelf(
                                    nomf(function),
                                    contenu(
                                       affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , '''')
                                    ),
                                    p()
                                 )
                              ),
                              p(1250)
                           )
                        )
                     )
                  )
               )
            ),
            #(
              =============================================================================================
            ),
            fonction(
               definition( nom(init)),
               contenu(
                  declare(
                     lst,
                     appelf(
                        element( appelf( element(document) , nomf(getElementById) , p( ''t1'' ) )),
                        nomf(getElementsByTagName),
                        p( ''td'')
                     )
                  ),
                  declare( i , 0),
                  boucle(
                     initialisation( affecte( i , 0 )),
                     condition( inf( i , lst.length )),
                     increment(i++),
                     faire( appelf( element(lst[i]) , nomf(addEventListener) , p( ''click'' ) , p(monClick) ))
                  ),
                  affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(innerHTML) ) , plus( numero_de_joueur , message1 )),
                  affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , ''csb1''),
                  appelf(
                     nomf(setTimeout),
                     p(
                        appelf(
                           nomf(function),
                           contenu(
                              affecte( appelf( element(document) , nomf(getElementById) , p( ''numero_de_joueur'' ) , prop(className) ) , '''')
                           ),
                           p()
                        )
                     ),
                     p(1250)
                  )
               )
            ),
            #(
              =============================================================================================
            ),
            appelf(
               element(window),
               nomf(addEventListener),
               p( ''load''),
               p(
                  appelf(
                     nomf(function),
                     contenu(
                        #( quand tout est chargé, on initialise le jeu ),
                        appelf( nomf(init) , p())
                     ),
                     p()
                  )
               )
            )
         )
      )
   )
)','<!DOCTYPE html>
<html lang="fr">
    <doctype></doctype>
    <head>
        <!-- 
          Il y a un outil qui génère un fichier rev  à partir d''un fichier html
          Il y a un outil qui génère un fichier html à partir d''un fichier rev
        -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="tictactoe" />
        <title>tictactoe</title>
        <!-- 
          =====================================================================================================
          le css principal utilise des variables qu''il faut déclarer 
          =====================================================================================================
        -->
        <style type="text/css">
            :root{ 
--yyvtrg:40px; 
--yyvtrt:12px; /* taille de référence du texte */ 
--yyvtrp:2px; /* taille de référence du espaces ( padding ) */ 
--yyvtrb:1px; /* taille de référence des bordures */ 
--yyvtrm:1px; /* taille de référence dus marges */ 
--yyvhmb:22px; /* hauteur minimales des boutons */ 
--yyvhal:14px; /* hauteur de ligne */ 
--yyvhmd:35px; /* hauteur du menu à défilement */ 
--yyvhgb:32px; /* hauteur des grands boutons ( quitter et index ) */ 
--yyvhmc:24px; /* hauteur minimale de conteneur ( div ) */ 
}

h1{text-align:center;} 
#t1{  width:70vmin;  height:70vmin;  margin: 0 auto 0 auto; } 
#t1 td {  width:33%;  text-align:center;  font-size:10vw;  cursor:pointer; } 
h1{  border:0;  margin:0;  height:10vmin; } 
#numero_de_joueur{  font-size:1.8em;  color:red; text-align:center; } 
@keyframes acsb1 { 
   0% { transform: translateY(0)    } 
  25% { transform: translateY(15px) } 
  50% { transform: translateY(-15px)} 
  75% { transform: translateY(15px) } 
 100% { transform: translateY(0)  }
} 
.csb1 { 
  animation: acsb1 0.25s; animation-iteration-count: 3;
}
.csb2 { 
  color: blue!important;
  background: yellow;
  animation: acsb1 0.25s; animation-iteration-count: 3;
}</style>
        <!-- 
          =====================================================================================================
          on peut utiliser le css principal 
          =====================================================================================================
        -->
        <link rel="stylesheet" as="style" type="text/css" href="fta_www/6.css" />
        <style type="text/css">
tbody tr:nth-child(2n) {
 background-color: revert;
}</style>
    </head>
    <body>
        <h1>tictactoe
            <a href=".">page d''accueil</a></h1>
        <div id="numero_de_joueur" class=""></div>
        <table border="1" id="t1">
            <tbody>
                <tr>
                    <td id="0">&nbsp;</td>
                    <td id="1">&nbsp;</td>
                    <td id="2">&nbsp;</td>
                </tr>
                <tr>
                    <td id="3">&nbsp;</td>
                    <td id="4">&nbsp;</td>
                    <td id="5">&nbsp;</td>
                </tr>
                <tr>
                    <td id="6">&nbsp;</td>
                    <td id="7">&nbsp;</td>
                    <td id="8">&nbsp;</td>
                </tr>
            </tbody>
        </table>
<script type="text/javascript">
//<![CDATA[
//<source_javascript_rev>
"use strict";
/*
  =====================================================================================================================
*/
var numero_de_joueur=''x'';
var termine=false;
var message1='' clique sur une case '';
/*
  =====================================================================================================================
*/
function verifie_gagnant1( nj ){
    var i=0;
    for( i=0 ; i < 3 ; i++ ){
        if(document.getElementById( i * 3 + 0 ).innerHTML === nj
               && document.getElementById( i * 3 + 1 ).innerHTML === nj
               && document.getElementById( i * 3 + 2 ).innerHTML === nj
        ){
            return 1;
        }
    }
    var i=0;
    for( i=0 ; i < 3 ; i++ ){
        if(document.getElementById( i + 0 ).innerHTML === nj
               && document.getElementById( i + 3 ).innerHTML === nj
               && document.getElementById( i + 6 ).innerHTML === nj
        ){
            return 1;
        }
    }
    if(document.getElementById( 0 ).innerHTML === nj
           && document.getElementById( 4 ).innerHTML === nj
           && document.getElementById( 8 ).innerHTML === nj
    ){
        return 1;
    }
    if(document.getElementById( 6 ).innerHTML === nj
           && document.getElementById( 4 ).innerHTML === nj
           && document.getElementById( 2 ).innerHTML === nj
    ){
        return 1;
    }
    /* egalite */
    var case_vide_trouve=false;
    var lst=document.getElementById( ''t1'' ).getElementsByTagName( ''td'' );
    var i=0;
    for( i=0 ; i < lst.length ; i++ ){
        if(lst[i].innerHTML === ''&nbsp;''){
            case_vide_trouve=true;
        }
    }
    if(case_vide_trouve === false){
        return 0;
        /* egalite */
    }
    return 2;
}
/*
  =====================================================================================================================
*/
function recommencer(){
    document.getElementById( ''numero_de_joueur'' ).className=''csb1'';
    var lst=document.getElementById( ''t1'' ).getElementsByTagName( ''td'' );
    var i=0;
    for( i=0 ; i < lst.length ; i++ ){
        lst[i].innerHTML=''&nbsp;'';
    }
    numero_de_joueur=''x'';
    termine=false;
    document.getElementById( ''numero_de_joueur'' ).innerHTML=numero_de_joueur + message1;
    setTimeout( function(){
            document.getElementById( ''numero_de_joueur'' ).className='''';
        } , 250 );
}
/*
  =====================================================================================================================
*/
function monClick( e ){
    if(termine === true){
        return;
    }
    if(e.target.innerHTML === ''x'' || e.target.innerHTML === ''o''){
        return;
    }
    e.target.innerHTML=numero_de_joueur;
    var a_gagne=verifie_gagnant1( numero_de_joueur );
    if(a_gagne === 1){
        var t=numero_de_joueur + '' a gagné !'';
        t+='' <button type="button" onclick="recommencer()">recommencer</button>'';
        document.getElementById( ''numero_de_joueur'' ).innerHTML=t;
        document.getElementById( ''numero_de_joueur'' ).className=''csb2'';
        termine=true;
        setTimeout( function(){
                document.getElementById( ''numero_de_joueur'' ).className='''';
            } , 1250 );
    }else if(a_gagne === 2){
        numero_de_joueur=numero_de_joueur === ''o'' ? ( ''x'' ) : ( ''o'' );
        document.getElementById( ''numero_de_joueur'' ).innerHTML=numero_de_joueur + message1;
        document.getElementById( ''numero_de_joueur'' ).className=''csb1'';
        setTimeout( function(){
                document.getElementById( ''numero_de_joueur'' ).className='''';
            } , 250 );
    }else if(a_gagne === 0){
        var t='' égalité ! '';
        t+='' <button type="button" onclick="recommencer()">recommencer</button>'';
        document.getElementById( ''numero_de_joueur'' ).innerHTML=t;
        document.getElementById( ''numero_de_joueur'' ).className=''csb1'';
        termine=true;
        setTimeout( function(){
                document.getElementById( ''numero_de_joueur'' ).className='''';
            } , 1250 );
    }
}
/*
  =====================================================================================================================
*/
function init(){
    var lst=document.getElementById( ''t1'' ).getElementsByTagName( ''td'' );
    var i=0;
    for( i=0 ; i < lst.length ; i++ ){
        lst[i].addEventListener( ''click'' , monClick );
    }
    document.getElementById( ''numero_de_joueur'' ).innerHTML=numero_de_joueur + message1;
    document.getElementById( ''numero_de_joueur'' ).className=''csb1'';
    setTimeout( function(){
            document.getElementById( ''numero_de_joueur'' ).className='''';
        } , 1250 );
}
/*
  =====================================================================================================================
*/
window.addEventListener( ''load'' , function(){
        /* quand tout est chargé, on initialise le jeu */
        init();
    } );
//</source_javascript_rev>
//]]>
</script>

    </body>
</html>','normal'),
('6','1','index.php',NULL,'1','php(
   #(  exemple de programme très simple en php : on a déjà écrit cette page en html ),
   appelf( nomf(require_once) , p( ''index.html'' )),
   html_dans_php(
      #( fin de fichier )
   )
)','<?php
/*  exemple de programme très simple en php : on a déjà écrit cette page en html */
require_once(''index.html'');
?>
<!-- fin de fichier -->','normal'),
('7','1','bidon.js',NULL,'1','#(
  ce js ne sert que pour mes tests 
  
  Il y a un outil qui génère un fichier rev à partir d''un fichier js
  Il y a un outil qui génère un fichier js  à partir d''un fichier rev
),
declare( a , `
// la variable a çi dessus contient un source js
// ce source est encadré pas des apostrophes inversés ( accents graves )
var bidon=1;
`)','/*
  ce js ne sert que pour mes tests 
  
  Il y a un outil qui génère un fichier rev à partir d''un fichier js
  Il y a un outil qui génère un fichier js  à partir d''un fichier rev
*/
var a=`
// la variable a çi dessus contient un source js
// ce source est encadré pas des apostrophes inversés ( accents graves )
var bidon=1;
`;','normal'),
('8','1','exemple.sql',NULL,'1','
sélectionner(
   valeurs(
      ''exemple de commande sql'',
      ''Il y a un outil qui génère un fichier rev à partir d\''un fichier sql'',
      ''Il y a un outil qui génère un fichier sql à partir d\''un fichier rev'',
      champ(`client`,`id`),
      champ(`client`,`nom`),
      champ(`commande`,`id`),
      champ(`commande`,`produit`),
      champ(`commande`,`id_client`),
   )
   ,provenance(
      table_reference(source(nom_de_la_table(client,alias(client)))),
      jointure_gauche(
         source(nom_de_la_table(commande,alias(commande))
         ),contrainte(egal(champ(`commande`,`id_client`) , champ(`client`,`id`)))),
   )
   ,conditions(
      egal(champ(`client`,`id_client`) , 1),
   )
),','SELECT 
''exemple de commande sql'' , ''Il y a un outil qui génère un fichier rev à partir d''''un fichier sql'' , ''Il y a un outil qui génère un fichier sql à partir d''''un fichier rev'' , `client`.`id` , `client`.`nom` , 
`commande`.`id` , `commande`.`produit` , `commande`.`id_client`
 FROM client client
 LEFT JOIN commande commande ON `commande`.`id_client` = `client`.`id`

WHERE `client`.`id_client` = 1;','normal'),
('9','1','test.css',NULL,'1','#(mon css),
at( nomr( ''-ms-viewport'' ) , d( p( ''width'' ) , v( ''device-width'' ) )),
regle( selecteur( ''*,*::before,*::after'' ) , d( p( ''box-sizing'' ) , v( ''border-box'' ) )),
regle(
   selecteur( ''html''),
   #(fond),
   d( p( ''background'' ) , v( ''linear-gradient(to bottom, #ECEFF1 0%, #DBDEE0 100%)'' )),
   #(hauteur),
   d( p( ''min-height'' ) , v( ''100%'' ))
),
at(
   nomr( ''media''),
   params( ''print''),
   regle( selecteur( ''a[href]:after'' ) , d( p( ''content'' ) , v( ''none'' ) )),
   at( nomr( ''page'' ) , d( p( ''size'' ) , v( ''auto'' ) ) , d( p( ''margin-bottom'' ) , v( ''0'' ) ))
)','/*mon css*/
@-ms-viewport{width:device-width;}
*,*::before,*::after{box-sizing:border-box;}
html{
   /*fond*/
   background:linear-gradient(to bottom, #ECEFF1 0%, #DBDEE0 100%);
   /*hauteur*/
   min-height:100%;
}
@media print{a[href]:after{content:none;}@page{size:auto;margin-bottom:0;}}','normal');
/*



  =========================================================================
  Pour la table tbl_utilisateurs il y a 1 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_utilisateurs`( `chi_id_utilisateur`, `chp_nom_de_connexion_utilisateur`, `chp_mot_de_passe_utilisateur`, `chp_parametres_utilisateur`, `chp_commentaire_utilisateur`) VALUES
('1','admin','$2y$13$511GXb2mv6/lIM8yBiyGte7CNn.rMaTvD0aPNW6BF/GYlmv946RVK','{"zz_sources_l1.php":{"nombre_de_lignes":20},"zz_taches_l1.php":{"nombre_de_lignes":20},"zz_revs_l1.php":{"nombre_de_lignes":30},"zz_cibles_l1.php":{"nombre_de_lignes":30}}','mdp = admin');
/*



  =========================================================================
  Pour la table tbl_bdds il y a 2 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_bdds`(`chi_id_basedd`, `chx_dossier_id_basedd`, `chx_cible_id_basedd`, `chp_nom_basedd`, `chp_commentaire_basedd`, `chp_rev_basedd`) VALUES
('1','2','1','system.db','test de base virtuelle','#(
  =====================================================================================================================
  table tbl_cibles
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_cibles''),
      (nom_long_de_la_table , ''liste des systèmes cibles''),
      (nom_court_de_la_table , ''une cible''),
      (nom_bref_de_la_table , ''cible''),
      (transform_table_sur_svg , transform(translate(-69 , -131)))
   ),
   nom_de_la_table(''tbl_cibles''),
   fields(
      #(),
      field(nom_du_champ(chi_id_cible) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_cible'') , (nom_long_du_champ , ''identifiant unique de la cible'') , (nom_court_du_champ , ''identifiant cible'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_cible) , type(TEXT) , non_nulle() , meta((champ , ''chp_nom_cible'') , (nom_long_du_champ , ''nom de la cible'') , (nom_court_du_champ , ''nom cible'') , (nom_bref_du_champ , ''nom'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_dossier_cible) , type(CHARACTER , 3) , meta((champ , ''chp_dossier_cible'') , (nom_long_du_champ , ''à faire chp_dossier_cible'') , (nom_court_du_champ , ''à faire chp_dossier_cible'') , (nom_bref_du_champ , ''à faire chp_dossier_cible'') , (typologie , ''cho''))),
      field(nom_du_champ(chp_commentaire_cible) , type(TEXT) , meta((champ , ''chp_commentaire_cible'') , (nom_long_du_champ , ''à faire chp_commentaire_cible'') , (nom_court_du_champ , ''à faire chp_commentaire_cible'') , (nom_bref_du_champ , ''à faire chp_commentaire_cible'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_cibles'') , unique() , index_name(''idx_dossier_cible'') , fields(''chp_dossier_cible'') , meta((index , ''idx_dossier_cible'') , (__xme , ''à faire idx_dossier_cible''))),
#(
  =====================================================================================================================
  table tbl_dossiers
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_dossiers''),
      (nom_long_de_la_table , ''liste des dossiers sur disque''),
      (nom_court_de_la_table , ''un dossier''),
      (nom_bref_de_la_table , ''dossiers''),
      (transform_table_sur_svg , transform(translate(309 , -24)))
   ),
   nom_de_la_table(''tbl_dossiers''),
   fields(
      #(),
      field(nom_du_champ(chi_id_dossier) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_dossier'') , (nom_long_du_champ , ''à faire chi_id_dossier'') , (nom_court_du_champ , ''à faire chi_id_dossier'') , (nom_bref_du_champ , ''à faire chi_id_dossier'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_cible_dossier) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_dossier'') , (nom_long_du_champ , ''à faire chx_cible_dossier'') , (nom_court_du_champ , ''à faire chx_cible_dossier'') , (nom_bref_du_champ , ''à faire chx_cible_dossier'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_nom_dossier) , type(CHARACTER , 256) , meta((champ , ''chp_nom_dossier'') , (nom_long_du_champ , ''à faire chp_nom_dossier'') , (nom_court_du_champ , ''à faire chp_nom_dossier'') , (nom_bref_du_champ , ''à faire chp_nom_dossier'') , (typologie , ''cho'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_dossiers'') , unique() , index_name(''idx_cible_et_nom'') , fields(''chx_cible_dossier'' , ''chp_nom_dossier'') , meta((index , ''idx_cible_et_nom'') , (__xme , ''à faire idx_cible_et_nom''))),
#(
  =====================================================================================================================
  table tbl_sources
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_sources''),
      (nom_long_de_la_table , ''liste des programmes sources''),
      (nom_court_de_la_table , ''le source''),
      (nom_bref_de_la_table , ''sources''),
      (transform_table_sur_svg , transform(translate(454 , -74)))
   ),
   nom_de_la_table(''tbl_sources''),
   fields(
      #(),
      field(nom_du_champ(chi_id_source) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_source'') , (nom_long_du_champ , ''à faire chi_id_source'') , (nom_court_du_champ , ''à faire chi_id_source'') , (nom_bref_du_champ , ''à faire chi_id_source'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_cible_id_source) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_id_source'') , (nom_long_du_champ , ''à faire chx_cible_id_source'') , (nom_court_du_champ , ''à faire chx_cible_id_source'') , (nom_bref_du_champ , ''à faire chx_cible_id_source'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_nom_source) , type(CHARACTER , 256) , non_nulle() , valeur_par_defaut('''') , meta((champ , ''chp_nom_source'') , (nom_long_du_champ , ''à faire chp_nom_source'') , (nom_court_du_champ , ''à faire chp_nom_source'') , (nom_bref_du_champ , ''à faire chp_nom_source'') , (typologie , ''cho''))),
      field(nom_du_champ(chp_commentaire_source) , type(TEXT) , meta((champ , ''chp_commentaire_source'') , (nom_long_du_champ , ''à faire chp_commentaire_source'') , (nom_court_du_champ , ''à faire chp_commentaire_source'') , (nom_bref_du_champ , ''à faire chp_commentaire_source'') , (typologie , ''cht''))),
      field(nom_du_champ(chx_dossier_id_source) , type(INTEGER) , references(''tbl_dossiers'' , ''chi_id_dossier'') , meta((champ , ''chx_dossier_id_source'') , (nom_long_du_champ , ''à faire chx_dossier_id_source'') , (nom_court_du_champ , ''à faire chx_dossier_id_source'') , (nom_bref_du_champ , ''à faire chx_dossier_id_source'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_rev_source) , type(TEXT) , meta((champ , ''chp_rev_source'') , (nom_long_du_champ , ''à faire chp_rev_source'') , (nom_court_du_champ , ''à faire chp_rev_source'') , (nom_bref_du_champ , ''à faire chp_rev_source'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_genere_source) , type(TEXT) , meta((champ , ''chp_genere_source'') , (nom_long_du_champ , ''à faire chp_genere_source'') , (nom_court_du_champ , ''à faire chp_genere_source'') , (nom_bref_du_champ , ''à faire chp_genere_source'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_type_source) , type(TEXT) , non_nulle() , valeur_par_defaut(''normal'') , meta((champ , ''chp_type_source'') , (nom_long_du_champ , ''à faire chp_type_source'') , (nom_court_du_champ , ''à faire chp_type_source'') , (nom_bref_du_champ , ''à faire chp_type_source'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_sources'') , unique() , index_name(''idx_nom_et_dossier'') , fields(''chx_dossier_id_source'' , ''chp_nom_source'') , meta((index , ''idx_nom_et_dossier'') , (__xme , ''à faire idx_nom_et_dossier''))),
#(
  =====================================================================================================================
  table tbl_utilisateurs
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_utilisateurs''),
      (nom_long_de_la_table , ''liste des utilisateurs''),
      (nom_court_de_la_table , ''un utilisateur''),
      (nom_bref_de_la_table , ''utilisateurs''),
      (transform_table_sur_svg , transform(translate(-70 , 248)))
   ),
   nom_de_la_table(''tbl_utilisateurs''),
   fields(
      #(),
      field(nom_du_champ(chi_id_utilisateur) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_utilisateur'') , (nom_long_du_champ , ''à faire chi_id_utilisateur'') , (nom_court_du_champ , ''à faire chi_id_utilisateur'') , (nom_bref_du_champ , ''à faire chi_id_utilisateur'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_de_connexion_utilisateur) , type(TEXT) , meta((champ , ''chp_nom_de_connexion_utilisateur'') , (nom_long_du_champ , ''à faire chp_nom_de_connexion_utilisateur'') , (nom_court_du_champ , ''à faire chp_nom_de_connexion_utilisateur'') , (nom_bref_du_champ , ''à faire chp_nom_de_connexion_utilisateur'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_mot_de_passe_utilisateur) , type(TEXT) , meta((champ , ''chp_mot_de_passe_utilisateur'') , (nom_long_du_champ , ''à faire chp_mot_de_passe_utilisateur'') , (nom_court_du_champ , ''à faire chp_mot_de_passe_utilisateur'') , (nom_bref_du_champ , ''à faire chp_mot_de_passe_utilisateur'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_parametres_utilisateur) , type(TEXT) , meta((champ , ''chp_parametres_utilisateur'') , (nom_long_du_champ , ''à faire chp_parametres_utilisateur'') , (nom_court_du_champ , ''à faire chp_parametres_utilisateur'') , (nom_bref_du_champ , ''à faire chp_parametres_utilisateur'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_commentaire_utilisateur) , type(TEXT) , meta((champ , ''chp_commentaire_utilisateur'') , (nom_long_du_champ , ''à faire chp_commentaire_utilisateur'') , (nom_court_du_champ , ''à faire chp_commentaire_utilisateur'') , (nom_bref_du_champ , ''à faire chp_commentaire_utilisateur'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_utilisateurs'') , unique() , index_name(''idxNomUtilisateur'') , fields(''chp_nom_de_connexion_utilisateur'') , meta((index , ''idxNomUtilisateur'') , (__xme , ''à faire idxNomUtilisateur''))),
#(
  =====================================================================================================================
  table tbl_taches
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_taches''),
      (nom_long_de_la_table , ''liste des tâches à réaliser''),
      (nom_court_de_la_table , ''une tâche''),
      (nom_bref_de_la_table , ''taches''),
      (transform_table_sur_svg , transform(translate(201 , 286)))
   ),
   nom_de_la_table(''tbl_taches''),
   fields(
      #(),
      field(nom_du_champ(chi_id_tache) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_tache'') , (nom_long_du_champ , ''à faire chi_id_tache'') , (nom_court_du_champ , ''à faire chi_id_tache'') , (nom_bref_du_champ , ''à faire chi_id_tache'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_utilisateur_tache) , type(INTEGER) , non_nulle() , references(''tbl_utilisateurs'' , ''chi_id_utilisateur'') , meta((champ , ''chx_utilisateur_tache'') , (nom_long_du_champ , ''à faire chx_utilisateur_tache'') , (nom_court_du_champ , ''à faire chx_utilisateur_tache'') , (nom_bref_du_champ , ''à faire chx_utilisateur_tache'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_texte_tache) , type(TEXT) , non_nulle() , meta((champ , ''chp_texte_tache'') , (nom_long_du_champ , ''à faire chp_texte_tache'') , (nom_court_du_champ , ''à faire chp_texte_tache'') , (nom_bref_du_champ , ''à faire chp_texte_tache'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_priorite_tache) , type(INTEGER) , meta((champ , ''chp_priorite_tache'') , (nom_long_du_champ , ''à faire chp_priorite_tache'') , (nom_court_du_champ , ''à faire chp_priorite_tache'') , (nom_bref_du_champ , ''à faire chp_priorite_tache'') , (typologie , ''che'')))
   )
),
#(
  =====================================================================================================================
  table tbl_revs
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_revs''),
      (nom_long_de_la_table , ''à faire tbl_revs''),
      (nom_court_de_la_table , ''à faire tbl_revs''),
      (nom_bref_de_la_table , ''à faire tbl_revs''),
      (transform_table_sur_svg , transform(translate(643 , -132)))
   ),
   nom_de_la_table(''tbl_revs''),
   fields(
      #(),
      field(nom_du_champ(chi_id_rev) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_rev'') , (nom_long_du_champ , ''à faire chi_id_rev'') , (nom_court_du_champ , ''à faire chi_id_rev'') , (nom_bref_du_champ , ''à faire chi_id_rev'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_cible_rev) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_rev'') , (nom_long_du_champ , ''à faire chx_cible_rev'') , (nom_court_du_champ , ''à faire chx_cible_rev'') , (nom_bref_du_champ , ''à faire chx_cible_rev'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_provenance_rev) , type(CHARACTER , 32) , meta((champ , ''chp_provenance_rev'') , (nom_long_du_champ , ''à faire chp_provenance_rev'') , (nom_court_du_champ , ''à faire chp_provenance_rev'') , (nom_bref_du_champ , ''à faire chp_provenance_rev'') , (typologie , ''cho''))),
      field(nom_du_champ(chx_source_rev) , type(INTEGER) , meta((champ , ''chx_source_rev'') , (nom_long_du_champ , ''à faire chx_source_rev'') , (nom_court_du_champ , ''à faire chx_source_rev'') , (nom_bref_du_champ , ''à faire chx_source_rev'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_id_rev) , type(INTEGER) , meta((champ , ''chp_id_rev'') , (nom_long_du_champ , ''à faire chp_id_rev'') , (nom_court_du_champ , ''à faire chp_id_rev'') , (nom_bref_du_champ , ''à faire chp_id_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_valeur_rev) , type(TEXT) , meta((champ , ''chp_valeur_rev'') , (nom_long_du_champ , ''à faire chp_valeur_rev'') , (nom_court_du_champ , ''à faire chp_valeur_rev'') , (nom_bref_du_champ , ''à faire chp_valeur_rev'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_type_rev) , type(CHARACTER , 4) , meta((champ , ''chp_type_rev'') , (nom_long_du_champ , ''à faire chp_type_rev'') , (nom_court_du_champ , ''à faire chp_type_rev'') , (nom_bref_du_champ , ''à faire chp_type_rev'') , (typologie , ''cho''))),
      field(nom_du_champ(chp_niveau_rev) , type(INTEGER) , meta((champ , ''chp_niveau_rev'') , (nom_long_du_champ , ''à faire chp_niveau_rev'') , (nom_court_du_champ , ''à faire chp_niveau_rev'') , (nom_bref_du_champ , ''à faire chp_niveau_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_quotee_rev) , type(INTEGER) , meta((champ , ''chp_quotee_rev'') , (nom_long_du_champ , ''à faire chp_quotee_rev'') , (nom_court_du_champ , ''à faire chp_quotee_rev'') , (nom_bref_du_champ , ''à faire chp_quotee_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_premier_rev) , type(INTEGER) , meta((champ , ''chp_pos_premier_rev'') , (nom_long_du_champ , ''à faire chp_pos_premier_rev'') , (nom_court_du_champ , ''à faire chp_pos_premier_rev'') , (nom_bref_du_champ , ''à faire chp_pos_premier_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_dernier_rev) , type(INTEGER) , meta((champ , ''chp_pos_dernier_rev'') , (nom_long_du_champ , ''à faire chp_pos_dernier_rev'') , (nom_court_du_champ , ''à faire chp_pos_dernier_rev'') , (nom_bref_du_champ , ''à faire chp_pos_dernier_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_parent_rev) , type(INTEGER) , meta((champ , ''chp_parent_rev'') , (nom_long_du_champ , ''à faire chp_parent_rev'') , (nom_court_du_champ , ''à faire chp_parent_rev'') , (nom_bref_du_champ , ''à faire chp_parent_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_nbr_enfants_rev) , type(INTEGER) , meta((champ , ''chp_nbr_enfants_rev'') , (nom_long_du_champ , ''à faire chp_nbr_enfants_rev'') , (nom_court_du_champ , ''à faire chp_nbr_enfants_rev'') , (nom_bref_du_champ , ''à faire chp_nbr_enfants_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_num_enfant_rev) , type(INTEGER) , meta((champ , ''chp_num_enfant_rev'') , (nom_long_du_champ , ''à faire chp_num_enfant_rev'') , (nom_court_du_champ , ''à faire chp_num_enfant_rev'') , (nom_bref_du_champ , ''à faire chp_num_enfant_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_profondeur_rev) , type(INTEGER) , meta((champ , ''chp_profondeur_rev'') , (nom_long_du_champ , ''à faire chp_profondeur_rev'') , (nom_court_du_champ , ''à faire chp_profondeur_rev'') , (nom_bref_du_champ , ''à faire chp_profondeur_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_ouver_parenthese_rev) , type(INTEGER) , meta((champ , ''chp_pos_ouver_parenthese_rev'') , (nom_long_du_champ , ''à faire chp_pos_ouver_parenthese_rev'') , (nom_court_du_champ , ''à faire chp_pos_ouver_parenthese_rev'') , (nom_bref_du_champ , ''à faire chp_pos_ouver_parenthese_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_fermer_parenthese_rev) , type(INTEGER) , meta((champ , ''chp_pos_fermer_parenthese_rev'') , (nom_long_du_champ , ''à faire chp_pos_fermer_parenthese_rev'') , (nom_court_du_champ , ''à faire chp_pos_fermer_parenthese_rev'') , (nom_bref_du_champ , ''à faire chp_pos_fermer_parenthese_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_commentaire_rev) , type(TEXT) , meta((champ , ''chp_commentaire_rev'') , (nom_long_du_champ , ''à faire chp_commentaire_rev'') , (nom_court_du_champ , ''à faire chp_commentaire_rev'') , (nom_bref_du_champ , ''à faire chp_commentaire_rev'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_revs'') , unique() , index_name(''idx_ligne_rev'') , fields(''chx_cible_rev'' , ''chp_provenance_rev'' , ''chx_source_rev'' , ''chp_id_rev'') , meta((index , ''idx_ligne_rev'') , (__xme , ''à faire idx_ligne_rev''))),
#(
  =====================================================================================================================
  table tbl_bdds
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_bdds''),
      (nom_long_de_la_table , ''liste des bases de données''),
      (nom_court_de_la_table , ''une base''),
      (nom_bref_de_la_table , ''bases''),
      (transform_table_sur_svg , transform(translate(450 , 129)))
   ),
   nom_de_la_table(''tbl_bdds''),
   fields(
      #(),
      field(nom_du_champ(chi_id_basedd) , type(INTEGER) , primary_key() , auto_increment() , meta((champ , ''chi_id_basedd'') , (nom_long_du_champ , ''à faire chi_id_basedd'') , (nom_court_du_champ , ''à faire chi_id_basedd'') , (nom_bref_du_champ , ''à faire chi_id_basedd'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_dossier_id_basedd) , type(INTEGER) , references(''tbl_dossiers'' , ''chi_id_dossier'') , meta((champ , ''chx_dossier_id_basedd'') , (nom_long_du_champ , ''à faire chx_dossier_id_basedd'') , (nom_court_du_champ , ''à faire chx_dossier_id_basedd'') , (nom_bref_du_champ , ''à faire chx_dossier_id_basedd'') , (typologie , ''chx''))),
      field(nom_du_champ(chx_cible_id_basedd) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_id_basedd'') , (nom_long_du_champ , ''à faire chx_cible_id_basedd'') , (nom_court_du_champ , ''à faire chx_cible_id_basedd'') , (nom_bref_du_champ , ''à faire chx_cible_id_basedd'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_nom_basedd) , type(TEXT) , non_nulle() , valeur_par_defaut('''') , meta((champ , ''chp_nom_basedd'') , (nom_long_du_champ , ''à faire chp_nom_basedd'') , (nom_court_du_champ , ''à faire chp_nom_basedd'') , (nom_bref_du_champ , ''à faire chp_nom_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_rev_basedd) , type(TEXT) , meta((champ , ''chp_rev_basedd'') , (nom_long_du_champ , ''à faire chp_rev_basedd'') , (nom_court_du_champ , ''à faire chp_rev_basedd'') , (nom_bref_du_champ , ''à faire chp_rev_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_commentaire_basedd) , type(TEXT) , meta((champ , ''chp_commentaire_basedd'') , (nom_long_du_champ , ''à faire chp_commentaire_basedd'') , (nom_court_du_champ , ''à faire chp_commentaire_basedd'') , (nom_bref_du_champ , ''à faire chp_commentaire_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_genere_basedd) , type(TEXT) , meta((champ , ''chp_genere_basedd'') , (nom_long_du_champ , ''à faire chp_genere_basedd'') , (nom_court_du_champ , ''à faire chp_genere_basedd'') , (nom_bref_du_champ , ''à faire chp_genere_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_rev_travail_basedd) , type(TEXT) , meta((champ , ''chp_rev_travail_basedd'') , (nom_long_du_champ , ''à faire chp_rev_travail_basedd'') , (nom_court_du_champ , ''à faire chp_rev_travail_basedd'') , (nom_bref_du_champ , ''à faire chp_rev_travail_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_fournisseur_basedd) , type(TEXT) , valeur_par_defaut(''sqlite'') , meta((champ , ''chp_fournisseur_basedd'') , (nom_long_du_champ , ''à faire chp_fournisseur_basedd'') , (nom_court_du_champ , ''à faire chp_fournisseur_basedd'') , (nom_bref_du_champ , ''à faire chp_fournisseur_basedd'') , (typologie , ''cht'')))
   )
),
#(
  =====================================================================================================================
  table tbl_requetes
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_requetes''),
      (nom_long_de_la_table , ''liste des requêtes''),
      (nom_court_de_la_table , ''une requête''),
      (nom_bref_de_la_table , ''requêtes''),
      (transform_table_sur_svg , transform(translate(115 , 69)))
   ),
   nom_de_la_table(''tbl_requetes''),
   fields(
      #(),
      field(nom_du_champ(chi_id_requete) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_requete'') , (nom_long_du_champ , ''identifiant unique de la requête'') , (nom_court_du_champ , ''id unique'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(
         nom_du_champ(chx_cible_requete),
         type(INTEGER),
         non_nulle(),
         valeur_par_defaut(1),
         references(''tbl_cibles'' , ''chi_id_cible''),
         meta((champ , ''chx_cible_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''chi''))
      ),
      field(nom_du_champ(chp_type_requete) , type(VARCHAR , 64) , valeur_par_defaut(''selectionner'') , meta((champ , ''chp_type_requete'') , (nom_long_du_champ , ''type de la requête sql'') , (nom_court_du_champ , ''type requete'') , (nom_bref_du_champ , ''type'') , (typologie , ''chi''))),
      field(nom_du_champ(cht_rev_requete) , type(TEXT) , meta((champ , ''cht_rev_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_sql_requete) , type(TEXT) , meta((champ , ''cht_sql_requete'') , (nom_long_du_champ , ''requete au format sql'') , (nom_court_du_champ , ''format sql'') , (nom_bref_du_champ , ''sql'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_php_requete) , type(TEXT) , meta((champ , ''cht_php_requete'') , (nom_long_du_champ , ''requete au format php'') , (nom_court_du_champ , ''format php'') , (nom_bref_du_champ , ''php'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_commentaire_requete) , type(TEXT) , meta((champ , ''cht_commentaire_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_matrice_requete) , type(TEXT) , meta((champ , ''cht_matrice_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''cht'')))
   )
),
#(
  =====================================================================================================================
  table tbl_tests
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_tests''),
      (nom_long_de_la_table , ''liste d\''enregistrements \\ de test''),
      (nom_court_de_la_table , ''un test''),
      (nom_bref_de_la_table , ''test''),
      (transform_table_sur_svg , transform(translate(645 , 268)))
   ),
   nom_de_la_table(''tbl_tests''),
   fields(
      #(),
      field(
         nom_du_champ(chx_test_parent_test),
         type(INTEGER),
         non_nulle(),
         valeur_par_defaut(0),
         references(''tbl_tests'' , ''chi_id_test''),
         meta((champ , ''chx_test_parent_test'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''chi''))
      ),
      field(nom_du_champ(chi_id_test) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_test'') , (nom_long_du_champ , ''identifiant unique \'' du \\ test'') , (nom_court_du_champ , ''id du test'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_test) , type(VARCHAR , 64) , non_nulle() , valeur_par_defaut('''') , meta((champ , ''chp_nom_test'') , (nom_long_du_champ , ''nom du test'') , (nom_court_du_champ , ''nom test'') , (nom_bref_du_champ , ''nom'') , (typologie , ''chp''))),
      field(nom_du_champ(chp_texte1_test) , type(VARCHAR , 32) , valeur_par_defaut(''hello world'') , meta((champ , ''chp_texte1_test'') , (nom_long_du_champ , ''test'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''chp'')))
   )
)'),
('9','2','1','test.db','test de base virtuelle','#(
  =====================================================================================================================
  table tbl_a
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_a''),
      (nom_long_de_la_table , ''long table a''),
      (nom_court_de_la_table , ''court tbl_a''),
      (nom_bref_de_la_table , ''bref tbl_a''),
      (transform_table_sur_svg , transform(translate(-52 , -188)))
   ),
   nom_de_la_table(''tbl_a''),
   fields(
      #(),
      field(nom_du_champ(chi_id_a) , type(INTEGER , 20) , primary_key() , meta((champ , ''chi_id_a'') , (nom_long_du_champ , ''identifiant unique'') , (nom_court_du_champ , ''id aaa'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_a) , type(STRING) , meta((champ , ''chp_nom_a'') , (nom_long_du_champ , ''à faire chp_nom_cible'') , (nom_court_du_champ , ''à faire chp_nom_cible'') , (nom_bref_du_champ , ''à faire chp_nom_cible'') , (typologie , ''cht''))),
      field(nom_du_champ(chx_a_a) , type(INTEGER) , non_nulle() , references(''tbl_a'' , ''chi_id_a'') , meta((champ , ''chx_a_a'') , (nom_long_du_champ , ''à faire chx_a_a'') , (nom_court_du_champ , ''à faire chx_a_a'') , (nom_bref_du_champ , ''à faire chx_a_a'') , (typologie , ''chx''))),
      field(nom_du_champ(chx_a2_a) , type(INTEGER) , non_nulle() , references(''tbl_a'' , ''chx_a_a'') , meta((champ , ''chx_a2_a'') , (nom_long_du_champ , ''à faire chx_a2_a'') , (nom_court_du_champ , ''à faire chx_a2_a'') , (nom_bref_du_champ , ''à faire chx_a2_a'') , (typologie , ''chx'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_a'') , unique() , index_name(''idx_nom_a'') , fields(''chp_nom_a'' , ''chx_a_a'') , meta((index , ''idx_nom_a'') , (message , ''bla''))),
#(
  =====================================================================================================================
  table tbl_b
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_b''),
      (nom_long_de_la_table , ''à faire tbl_b''),
      (nom_court_de_la_table , ''à faire tbl_b''),
      (nom_bref_de_la_table , ''à faire tbl_b''),
      (transform_table_sur_svg , transform(translate(0 , 0)))
   ),
   nom_de_la_table(''tbl_b''),
   fields(
      #(),
      field(nom_du_champ(chi_id_b) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_b'') , (nom_long_du_champ , ''identifiant unique'') , (nom_court_du_champ , ''id bbb'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_b) , type(STRING) , valeur_par_defaut(''toto'') , meta((champ , ''chp_nom_b'') , (nom_long_du_champ , ''à faire chp_nom_b'') , (nom_court_du_champ , ''à faire chp_nom_b'') , (nom_bref_du_champ , ''à faire chp_nom_b'') , (typologie , ''cht''))),
      field(nom_du_champ(chx_a_b) , type(INTEGER) , non_nulle() , references(''tbl_a'' , ''chi_id_a'') , meta((champ , ''chx_a_b'') , (nom_long_du_champ , ''à faire'') , (nom_court_du_champ , ''à faire'') , (nom_bref_du_champ , ''id'') , (typologie , ''chx''))),
      field(nom_du_champ(cht_t_b) , type(CHARACTER) , meta((champ , ''cht_t_b'') , (nom_long_du_champ , ''à faire cht_t_b'') , (nom_court_du_champ , ''à faire cht_t_b'') , (nom_bref_du_champ , ''à faire cht_t_b'') , (typologie , ''cht'')))
   )
)');
/*



  =========================================================================
  Pour la table tbl_requetes il y a 67 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_requetes`( `chi_id_requete`, `chx_cible_requete`, `chp_type_requete`, `cht_rev_requete`, `cht_sql_requete`, `cht_php_requete`, `cht_commentaire_requete`, `cht_matrice_requete`) VALUES
('1','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_utilisateur` ) , champ( `T0` , `chp_mot_de_passe_utilisateur` ) , champ( `T0` , `chp_parametres_utilisateur` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_utilisateurs , alias(T0) , base(b1) ))
      )
   ),
   conditions( egal( champ( `T0` , `chp_nom_de_connexion_utilisateur` ) , :nom_de_connexion )),
   complements( limité_à( quantité(1) , début(0) ))
)','SELECT 
`T0`.`chi_id_utilisateur` , `T0`.`chp_mot_de_passe_utilisateur` , `T0`.`chp_parametres_utilisateur`
 FROM b1.tbl_utilisateurs T0
WHERE `T0`.`chp_nom_de_connexion_utilisateur` = :nom_de_connexion  
LIMIT 1 OFFSET 0 ;','function sql_1($par){
    $champs0=''
      `T0`.`chi_id_utilisateur` , `T0`.`chp_mot_de_passe_utilisateur` , `T0`.`chp_parametres_utilisateur`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_utilisateurs T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `T0`.`chp_nom_de_connexion_utilisateur` = ''.sq1($par[''nom_de_connexion'']).''''.PHP_EOL;
    $sql0.=$where0;
    $order0='''';
    $sql0.=$order0;
    $plage0=''
        LIMIT 1 OFFSET 0 '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_utilisateur'' => $tab0[0],
                ''T0.chp_mot_de_passe_utilisateur'' => $tab0[1],
                ''T0.chp_parametres_utilisateur'' => $tab0[2],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,35,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,35,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,14,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_utilisateur","c",3,2,66,83,5,0,2,0,56,35,""],[8,"champ","f",2,0,90,94,4,2,2,1,95,11,""],[9,"T0","c",3,2,98,99,8,0,1,0,95,10,""],[10,"chp_mot_de_passe_utilisateur","c",3,2,105,132,8,0,2,0,95,35,""],[11,"champ","f",2,0,139,143,4,2,3,1,144,35,""],[12,"T0","c",3,2,147,148,11,0,1,0,144,13,""],[13,"chp_parametres_utilisateur","c",3,2,154,179,11,0,2,0,144,35,""],[14,"provenance","f",1,0,189,198,1,1,3,5,199,23,""],[15,"table_reference","f",2,0,207,221,14,1,1,4,222,35,""],[16,"source","f",3,0,233,238,15,1,1,3,239,35,""],[17,"nom_de_la_table","f",4,0,241,255,16,3,1,2,256,35,""],[18,"tbl_utilisateurs","c",5,0,258,273,17,0,1,0,0,19,""],[19,"alias","f",5,0,277,281,17,1,2,1,282,21,""],[20,"T0","c",6,0,283,284,19,0,1,0,282,35,""],[21,"base","f",5,0,289,292,17,1,3,1,293,35,""],[22,"b1","c",6,0,294,295,21,0,1,0,293,35,""],[23,"conditions","f",1,0,318,327,1,1,4,3,328,29,""],[24,"egal","f",2,0,330,333,23,2,1,2,334,35,""],[25,"champ","f",3,0,336,340,24,2,1,1,341,28,""],[26,"T0","c",4,2,344,345,25,0,1,0,341,27,""],[27,"chp_nom_de_connexion_utilisateur","c",4,2,351,382,25,0,2,0,341,35,""],[28,":nom_de_connexion","c",3,0,389,405,24,0,2,0,0,35,""],[29,"complements","f",1,0,414,424,1,1,5,3,425,35,""],[30,"limit\u00e9_\u00e0","f",2,0,427,434,29,2,1,2,435,35,""],[31,"quantit\u00e9","f",3,0,437,444,30,1,1,1,445,33,""],[32,"1","c",4,0,446,446,31,0,1,0,445,35,""],[33,"d\u00e9but","f",3,0,451,455,30,1,2,1,456,35,""],[34,"0","c",4,0,457,457,33,0,1,0,456,35,""]]'),
('2','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_requete`),
      champ( `T0` , `chp_type_requete`),
      champ( `T0` , `cht_rev_requete`),
      champ( `T0` , `cht_sql_requete`),
      champ( `T0` , `cht_php_requete`),
      champ( `T0` , `cht_commentaire_requete`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et(
         egal( champ( `T0` , `chx_cible_requete` ) , :T0_chx_cible_requete),
         egal( champ( `T0` , `chi_id_requete` ) , :T0_chi_id_requete),
         comme( champ( `T0` , `chp_type_requete` ) , :T0_chp_type_requete),
         comme( champ( `T0` , `cht_rev_requete` ) , :T0_cht_rev_requete)
      )
   ),
   complements(
      trier_par( ( champ( `T0` , `chi_id_requete` ) , décroissant() )),
      limité_à( quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , 
`T0`.`cht_commentaire_requete`
 FROM b1.tbl_requetes T0
WHERE (`T0`.`chx_cible_requete` = :T0_chx_cible_requete
   AND `T0`.`chi_id_requete` = :T0_chi_id_requete
   AND `T0`.`chp_type_requete` LIKE :T0_chp_type_requete
   AND `T0`.`cht_rev_requete` LIKE :T0_cht_rev_requete) 
ORDER BY `T0`.`chi_id_requete` DESC  
LIMIT :quantitee OFFSET :debut ;','function sql_2($par){
    $champs0=''
      `T0`.`chi_id_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , 
      `T0`.`cht_commentaire_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    if(($par[''T0_chx_cible_requete''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_requete`'',$par[''T0_chx_cible_requete'']);
    }
    if(($par[''T0_chi_id_requete''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_requete`'',$par[''T0_chi_id_requete'']);
    }
    if(($par[''T0_chp_type_requete''] !== '''')){
        $where0.='' AND `T0`.`chp_type_requete` LIKE ''.sq1($par[''T0_chp_type_requete'']).''''.PHP_EOL;
    }
    if(($par[''T0_cht_rev_requete''] !== '''')){
        $where0.='' AND `T0`.`cht_rev_requete` LIKE ''.sq1($par[''T0_cht_rev_requete'']).''''.PHP_EOL;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_requete` DESC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_requete'' => $tab0[0],
                ''T0.chp_type_requete'' => $tab0[1],
                ''T0.cht_rev_requete'' => $tab0[2],
                ''T0.cht_sql_requete'' => $tab0[3],
                ''T0.cht_php_requete'' => $tab0[4],
                ''T0.cht_commentaire_requete'' => $tab0[5],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => __xsu       ,
           __xva  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => __xer ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','requêtes','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,66,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,66,""],[4,"valeurs","f",1,0,42,48,1,6,2,2,49,23,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_requete","c",3,2,72,85,5,0,2,0,62,66,""],[8,"champ","f",2,0,96,100,4,2,2,1,101,11,""],[9,"T0","c",3,2,104,105,8,0,1,0,101,10,""],[10,"chp_type_requete","c",3,2,111,126,8,0,2,0,101,66,""],[11,"champ","f",2,0,137,141,4,2,3,1,142,14,""],[12,"T0","c",3,2,145,146,11,0,1,0,142,13,""],[13,"cht_rev_requete","c",3,2,152,166,11,0,2,0,142,66,""],[14,"champ","f",2,0,177,181,4,2,4,1,182,17,""],[15,"T0","c",3,2,185,186,14,0,1,0,182,16,""],[16,"cht_sql_requete","c",3,2,192,206,14,0,2,0,182,66,""],[17,"champ","f",2,0,217,221,4,2,5,1,222,20,""],[18,"T0","c",3,2,225,226,17,0,1,0,222,19,""],[19,"cht_php_requete","c",3,2,232,246,17,0,2,0,222,66,""],[20,"champ","f",2,0,257,261,4,2,6,1,262,66,""],[21,"T0","c",3,2,265,266,20,0,1,0,262,22,""],[22,"cht_commentaire_requete","c",3,2,272,294,20,0,2,0,262,66,""],[23,"provenance","f",1,0,307,316,1,1,3,5,317,32,""],[24,"table_reference","f",2,0,325,339,23,1,1,4,340,66,""],[25,"source","f",3,0,351,356,24,1,1,3,357,66,""],[26,"nom_de_la_table","f",4,0,359,373,25,3,1,2,374,66,""],[27,"tbl_requetes","c",5,0,376,387,26,0,1,0,0,28,""],[28,"alias","f",5,0,391,395,26,1,2,1,396,30,""],[29,"T0","c",6,0,397,398,28,0,1,0,396,66,""],[30,"base","f",5,0,403,406,26,1,3,1,407,66,""],[31,"b1","c",6,0,408,409,30,0,1,0,407,66,""],[32,"conditions","f",1,0,432,441,1,1,4,4,442,54,""],[33,"et","f",2,0,450,451,32,4,1,3,452,66,""],[34,"egal","f",3,0,463,466,33,2,1,2,467,39,""],[35,"champ","f",4,0,469,473,34,2,1,1,474,38,""],[36,"T0","c",5,2,477,478,35,0,1,0,474,37,""],[37,"chx_cible_requete","c",5,2,484,500,35,0,2,0,474,66,""],[38,":T0_chx_cible_requete","c",4,0,507,527,34,0,2,0,474,66,""],[39,"egal","f",3,0,540,543,33,2,2,2,544,44,""],[40,"champ","f",4,0,546,550,39,2,1,1,551,43,""],[41,"T0","c",5,2,554,555,40,0,1,0,551,42,""],[42,"chi_id_requete","c",5,2,561,574,40,0,2,0,551,66,""],[43,":T0_chi_id_requete","c",4,0,581,598,39,0,2,0,551,66,""],[44,"comme","f",3,0,611,615,33,2,3,2,616,49,""],[45,"champ","f",4,0,618,622,44,2,1,1,623,48,""],[46,"T0","c",5,2,626,627,45,0,1,0,623,47,""],[47,"chp_type_requete","c",5,2,633,648,45,0,2,0,623,66,""],[48,":T0_chp_type_requete","c",4,0,655,674,44,0,2,0,623,66,""],[49,"comme","f",3,0,687,691,33,2,4,2,692,66,""],[50,"champ","f",4,0,694,698,49,2,1,1,699,53,""],[51,"T0","c",5,2,702,703,50,0,1,0,699,52,""],[52,"cht_rev_requete","c",5,2,709,723,50,0,2,0,699,66,""],[53,":T0_cht_rev_requete","c",4,0,730,748,49,0,2,0,699,66,""],[54,"complements","f",1,0,768,778,1,2,5,4,779,66,""],[55,"trier_par","f",2,0,787,795,54,1,1,3,796,61,""],[56,"","f",3,0,787,795,55,2,1,2,798,66,""],[57,"champ","f",4,0,800,804,56,2,1,1,805,60,""],[58,"T0","c",5,2,808,809,57,0,1,0,805,59,""],[59,"chi_id_requete","c",5,2,815,828,57,0,2,0,805,66,""],[60,"d\u00e9croissant","f",4,0,835,845,56,0,2,0,846,66,""],[61,"limit\u00e9_\u00e0","f",2,0,859,866,54,2,2,2,867,66,""],[62,"quantit\u00e9","f",3,0,869,876,61,1,1,1,877,64,""],[63,":quantitee","c",4,0,878,887,62,0,1,0,877,66,""],[64,"d\u00e9but","f",3,0,892,896,61,1,2,1,897,66,""],[65,":debut","c",4,0,898,903,64,0,1,0,897,66,""]]'),
('3','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chi_id_requete` ) , :n_chi_id_requete )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , base(b1) ))
      )
   ),
   conditions(
      et(
         egal( champ( `chi_id_requete` ) , :c_chi_id_requete),
         egal( champ( `chx_cible_requete` ) , :c_chx_cible_requete)
      )
   )
)','UPDATE b1.tbl_requetes SET `chi_id_requete` = :n_chi_id_requete
WHERE (`chi_id_requete` = :c_chi_id_requete
   AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_3($par){
    $texte_sql_3=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.PHP_EOL;

    if($par[''n_chi_id_requete'']==='''' || $par[''n_chi_id_requete'']===NULL ){
        $texte_sql_3.=''    `chi_id_requete` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_3.=''    `chi_id_requete` = ''.sq0($par[''n_chi_id_requete'']).'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.PHP_EOL;
    $texte_sql_3.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_3 = <pre>'' . $texte_sql_3 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_3);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_3()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','changer le numéro d''une requête','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,26,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,26,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,26,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chi_id_requete","c",4,2,64,77,6,0,1,0,61,26,""],[8,":n_chi_id_requete","c",3,0,84,100,5,0,2,0,0,26,""],[9,"provenance","f",1,0,109,118,1,1,3,5,119,16,""],[10,"table_reference","f",2,0,127,141,9,1,1,4,142,26,""],[11,"source","f",3,0,153,158,10,1,1,3,159,26,""],[12,"nom_de_la_table","f",4,0,161,175,11,2,1,2,176,26,""],[13,"tbl_requetes","c",5,0,178,189,12,0,1,0,0,14,""],[14,"base","f",5,0,193,196,12,1,2,1,197,26,""],[15,"b1","c",6,0,198,199,14,0,1,0,197,26,""],[16,"conditions","f",1,0,222,231,1,1,4,4,232,26,""],[17,"et","f",2,0,240,241,16,2,1,3,242,26,""],[18,"egal","f",3,0,253,256,17,2,1,2,257,22,""],[19,"champ","f",4,0,259,263,18,1,1,1,264,21,""],[20,"chi_id_requete","c",5,2,267,280,19,0,1,0,264,26,""],[21,":c_chi_id_requete","c",4,0,287,303,18,0,2,0,264,26,""],[22,"egal","f",3,0,316,319,17,2,2,2,320,26,""],[23,"champ","f",4,0,322,326,22,1,1,1,327,25,""],[24,"chx_cible_requete","c",5,2,330,346,23,0,1,0,327,26,""],[25,":c_chx_cible_requete","c",4,0,353,372,22,0,2,0,327,26,""]]'),
('4','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_requete` ) , :chi_id_requete ) , egal( champ( `chx_cible_requete` ) , :chx_cible_requete ))
   )
)','DELETE FROM b1.tbl_requetes
WHERE (`chi_id_requete` = :chi_id_requete
   AND `chx_cible_requete` = :chx_cible_requete) ;','function sql_4($par){
    $texte_sql_4=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes
          WHERE (`chi_id_requete` = ''.sq1($par[''chi_id_requete'']).'' AND `chx_cible_requete` = ''.sq1($par[''chx_cible_requete'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_4 = <pre>'' . $texte_sql_4 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_4);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_4()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,21,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,21,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,21,""],[6,"source","f",3,0,83,88,5,1,1,3,89,21,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,21,""],[8,"tbl_requetes","c",5,0,108,119,7,0,1,0,0,9,""],[9,"base","f",5,0,123,126,7,1,2,1,127,21,""],[10,"b1","c",6,0,128,129,9,0,1,0,127,21,""],[11,"conditions","f",1,0,152,161,1,1,3,4,162,21,""],[12,"et","f",2,0,170,171,11,2,1,3,172,21,""],[13,"egal","f",3,0,174,177,12,2,1,2,178,17,""],[14,"champ","f",4,0,180,184,13,1,1,1,185,16,""],[15,"chi_id_requete","c",5,2,188,201,14,0,1,0,185,21,""],[16,":chi_id_requete","c",4,0,208,222,13,0,2,0,0,21,""],[17,"egal","f",3,0,228,231,12,2,2,2,232,21,""],[18,"champ","f",4,0,234,238,17,1,1,1,239,20,""],[19,"chx_cible_requete","c",5,2,242,258,18,0,1,0,239,21,""],[20,":chx_cible_requete","c",4,0,265,282,17,0,2,0,0,21,""]]'),
('5','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_revs , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chx_cible_rev` ) , :chx_cible_rev ) , egal( champ( `chp_provenance_rev` ) , :chp_provenance_rev ) , egal( champ( `chx_source_rev` ) , :chx_source_rev ))
   )
)','DELETE FROM b1.tbl_revs
WHERE (`chx_cible_rev` = :chx_cible_rev
   AND `chp_provenance_rev` = :chp_provenance_rev
   AND `chx_source_rev` = :chx_source_rev) ;','function sql_5($par){
    $texte_sql_5=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_revs
          WHERE (`chx_cible_rev` = ''.sq1($par[''chx_cible_rev'']).'' AND `chp_provenance_rev` = ''.sq1($par[''chp_provenance_rev'']).'' AND `chx_source_rev` = ''.sq1($par[''chx_source_rev'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_5 = <pre>'' . $texte_sql_5 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_5);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_5()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','rev par cible, provenance et source','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,25,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,25,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,25,""],[6,"source","f",3,0,83,88,5,1,1,3,89,25,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,25,""],[8,"tbl_revs","c",5,0,108,115,7,0,1,0,0,9,""],[9,"base","f",5,0,119,122,7,1,2,1,123,25,""],[10,"b1","c",6,0,124,125,9,0,1,0,123,25,""],[11,"conditions","f",1,0,148,157,1,1,3,4,158,25,""],[12,"et","f",2,0,166,167,11,3,1,3,168,25,""],[13,"egal","f",3,0,170,173,12,2,1,2,174,17,""],[14,"champ","f",4,0,176,180,13,1,1,1,181,16,""],[15,"chx_cible_rev","c",5,2,184,196,14,0,1,0,181,25,""],[16,":chx_cible_rev","c",4,0,203,216,13,0,2,0,0,25,""],[17,"egal","f",3,0,222,225,12,2,2,2,226,21,""],[18,"champ","f",4,0,228,232,17,1,1,1,233,20,""],[19,"chp_provenance_rev","c",5,2,236,253,18,0,1,0,233,25,""],[20,":chp_provenance_rev","c",4,0,260,278,17,0,2,0,0,25,""],[21,"egal","f",3,0,284,287,12,2,3,2,288,25,""],[22,"champ","f",4,0,290,294,21,1,1,1,295,24,""],[23,"chx_source_rev","c",5,2,298,311,22,0,1,0,295,25,""],[24,":chx_source_rev","c",4,0,318,332,21,0,2,0,0,25,""]]'),
('6','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_requete` ) , champ( `T0` , `cht_sql_requete` ) , champ( `T0` , `cht_php_requete` ) , champ( `T0` , `cht_matrice_requete` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chx_cible_requete` ) , :T0_chx_cible_requete ))
   ),
   complements( trier_par( (champ( `T0` , `chi_id_requete` ) , croissant()) ))
)','SELECT 
`T0`.`chi_id_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , `T0`.`cht_matrice_requete`
 FROM b1.tbl_requetes T0
WHERE (`T0`.`chx_cible_requete` = :T0_chx_cible_requete) 
ORDER BY `T0`.`chi_id_requete` ASC;','function sql_6($par){
    $champs0=''
      `T0`.`chi_id_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , `T0`.`cht_matrice_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_requete`'',$par[''T0_chx_cible_requete'']);
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_requete` ASC'';
    $sql0.=$order0;
    /* ATTENTION : pas de limites */
    $plage0='''';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_requete'' => $tab0[0],
                ''T0.cht_sql_requete'' => $tab0[1],
                ''T0.cht_php_requete'' => $tab0[2],
                ''T0.cht_matrice_requete'' => $tab0[3],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,40,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,40,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,17,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_requete","c",3,2,66,79,5,0,2,0,56,40,""],[8,"champ","f",2,0,86,90,4,2,2,1,91,11,""],[9,"T0","c",3,2,94,95,8,0,1,0,91,10,""],[10,"cht_sql_requete","c",3,2,101,115,8,0,2,0,91,40,""],[11,"champ","f",2,0,122,126,4,2,3,1,127,14,""],[12,"T0","c",3,2,130,131,11,0,1,0,127,13,""],[13,"cht_php_requete","c",3,2,137,151,11,0,2,0,127,40,""],[14,"champ","f",2,0,158,162,4,2,4,1,163,40,""],[15,"T0","c",3,2,166,167,14,0,1,0,163,16,""],[16,"cht_matrice_requete","c",3,2,173,191,14,0,2,0,163,40,""],[17,"provenance","f",1,0,201,210,1,1,3,5,211,26,""],[18,"table_reference","f",2,0,219,233,17,1,1,4,234,40,""],[19,"source","f",3,0,245,250,18,1,1,3,251,40,""],[20,"nom_de_la_table","f",4,0,253,267,19,3,1,2,268,40,""],[21,"tbl_requetes","c",5,0,270,281,20,0,1,0,0,22,""],[22,"alias","f",5,0,285,289,20,1,2,1,290,24,""],[23,"T0","c",6,0,291,292,22,0,1,0,290,40,""],[24,"base","f",5,0,297,300,20,1,3,1,301,40,""],[25,"b1","c",6,0,302,303,24,0,1,0,301,40,""],[26,"conditions","f",1,0,326,335,1,1,4,4,336,33,""],[27,"et","f",2,0,344,345,26,1,1,3,346,40,""],[28,"egal","f",3,0,348,351,27,2,1,2,352,40,""],[29,"champ","f",4,0,354,358,28,2,1,1,359,32,""],[30,"T0","c",5,2,362,363,29,0,1,0,359,31,""],[31,"chx_cible_requete","c",5,2,369,385,29,0,2,0,359,40,""],[32,":T0_chx_cible_requete","c",4,0,392,412,28,0,2,0,0,40,""],[33,"complements","f",1,0,426,436,1,1,5,4,437,40,""],[34,"trier_par","f",2,0,439,447,33,1,1,3,448,40,""],[35,"","f",3,0,439,447,34,2,1,2,450,40,""],[36,"champ","f",4,0,451,455,35,2,1,1,456,39,""],[37,"T0","c",5,2,459,460,36,0,1,0,456,38,""],[38,"chi_id_requete","c",5,2,466,479,36,0,2,0,456,40,""],[39,"croissant","f",4,0,486,494,35,0,2,0,495,40,""]]'),
('7','1','insert','insérer(
   base_de_reference(1),
   valeurs(
      affecte( champ( `chx_cible_requete` ) , :chx_cible_requete),
      affecte( champ( `chp_type_requete` ) , :chp_type_requete),
      affecte( champ( `cht_rev_requete` ) , :cht_rev_requete),
      affecte( champ( `cht_sql_requete` ) , :cht_sql_requete),
      affecte( champ( `cht_php_requete` ) , :cht_php_requete),
      affecte( champ( `cht_commentaire_requete` ) , :cht_commentaire_requete)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , base(b1) ))
      )
   )
)','INSERT INTO b1.`tbl_requetes`(
    `chx_cible_requete` , 
    `chp_type_requete` , 
    `cht_rev_requete` , 
    `cht_sql_requete` , 
    `cht_php_requete` , 
    `cht_commentaire_requete`
) VALUES (
    :chx_cible_requete , 
    :chp_type_requete , 
    :cht_rev_requete , 
    :cht_sql_requete , 
    :cht_php_requete , 
    :cht_commentaire_requete
);','function sql_7($par){
    $texte_sql_7=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes`(
         `chx_cible_requete` , 
         `chp_type_requete` , 
         `cht_rev_requete` , 
         `cht_sql_requete` , 
         `cht_php_requete` , 
         `cht_commentaire_requete`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_type_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_rev_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_sql_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_php_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_commentaire_requete'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_7.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_7 = <pre>'' . $texte_sql_7 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_7);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_7()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,36,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,36,""],[4,"valeurs","f",1,0,37,43,1,6,2,3,44,29,""],[5,"affecte","f",2,0,52,58,4,2,1,2,59,9,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,8,""],[7,"chx_cible_requete","c",4,2,69,85,6,0,1,0,66,36,""],[8,":chx_cible_requete","c",3,0,92,109,5,0,2,0,66,36,""],[9,"affecte","f",2,0,119,125,4,2,2,2,126,13,""],[10,"champ","f",3,0,128,132,9,1,1,1,133,12,""],[11,"chp_type_requete","c",4,2,136,151,10,0,1,0,133,36,""],[12,":chp_type_requete","c",3,0,158,174,9,0,2,0,133,36,""],[13,"affecte","f",2,0,184,190,4,2,3,2,191,17,""],[14,"champ","f",3,0,193,197,13,1,1,1,198,16,""],[15,"cht_rev_requete","c",4,2,201,215,14,0,1,0,198,36,""],[16,":cht_rev_requete","c",3,0,222,237,13,0,2,0,198,36,""],[17,"affecte","f",2,0,247,253,4,2,4,2,254,21,""],[18,"champ","f",3,0,256,260,17,1,1,1,261,20,""],[19,"cht_sql_requete","c",4,2,264,278,18,0,1,0,261,36,""],[20,":cht_sql_requete","c",3,0,285,300,17,0,2,0,261,36,""],[21,"affecte","f",2,0,310,316,4,2,5,2,317,25,""],[22,"champ","f",3,0,319,323,21,1,1,1,324,24,""],[23,"cht_php_requete","c",4,2,327,341,22,0,1,0,324,36,""],[24,":cht_php_requete","c",3,0,348,363,21,0,2,0,324,36,""],[25,"affecte","f",2,0,373,379,4,2,6,2,380,36,""],[26,"champ","f",3,0,382,386,25,1,1,1,387,28,""],[27,"cht_commentaire_requete","c",4,2,390,412,26,0,1,0,387,36,""],[28,":cht_commentaire_requete","c",3,0,419,442,25,0,2,0,387,36,""],[29,"provenance","f",1,0,454,463,1,1,3,5,464,36,""],[30,"table_reference","f",2,0,472,486,29,1,1,4,487,36,""],[31,"source","f",3,0,498,503,30,1,1,3,504,36,""],[32,"nom_de_la_table","f",4,0,506,520,31,2,1,2,521,36,""],[33,"tbl_requetes","c",5,0,523,534,32,0,1,0,0,34,""],[34,"base","f",5,0,538,541,32,1,2,1,542,36,""],[35,"b1","c",6,0,543,544,34,0,1,0,542,36,""]]'),
('8','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chx_source_rev` ) , :n_chx_source_rev )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_revs , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chx_cible_rev` ) , :c_chx_cible_rev ) , egal( champ( `chp_provenance_rev` ) , :c_chp_provenance_rev ) , egal( champ( `chx_source_rev` ) , :c_chx_source_rev ))
   )
)','UPDATE b1.tbl_revs SET `chx_source_rev` = :n_chx_source_rev
WHERE (`chx_cible_rev` = :c_chx_cible_rev
   AND `chp_provenance_rev` = :c_chp_provenance_rev
   AND `chx_source_rev` = :c_chx_source_rev) ;','function sql_8($par){
    $texte_sql_8=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_revs` SET ''.PHP_EOL;

    if($par[''n_chx_source_rev'']==='''' || $par[''n_chx_source_rev'']===NULL ){
        $texte_sql_8.=''    `chx_source_rev` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_8.=''    `chx_source_rev` = ''.sq0($par[''n_chx_source_rev'']).'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chx_cible_rev` = ''.sq1($par[''c_chx_cible_rev'']).''''.PHP_EOL;
    $where0.='' AND `chp_provenance_rev` = ''.sq1($par[''c_chp_provenance_rev'']).''''.PHP_EOL;
    $where0.='' AND `chx_source_rev` = ''.sq1($par[''c_chx_source_rev'']).''''.PHP_EOL;
    $texte_sql_8.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_8 = <pre>'' . $texte_sql_8 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_8);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_8()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,30,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,30,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,30,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chx_source_rev","c",4,2,64,77,6,0,1,0,61,30,""],[8,":n_chx_source_rev","c",3,0,84,100,5,0,2,0,0,30,""],[9,"provenance","f",1,0,109,118,1,1,3,5,119,16,""],[10,"table_reference","f",2,0,127,141,9,1,1,4,142,30,""],[11,"source","f",3,0,153,158,10,1,1,3,159,30,""],[12,"nom_de_la_table","f",4,0,161,175,11,2,1,2,176,30,""],[13,"tbl_revs","c",5,0,178,185,12,0,1,0,0,14,""],[14,"base","f",5,0,189,192,12,1,2,1,193,30,""],[15,"b1","c",6,0,194,195,14,0,1,0,193,30,""],[16,"conditions","f",1,0,218,227,1,1,4,4,228,30,""],[17,"et","f",2,0,236,237,16,3,1,3,238,30,""],[18,"egal","f",3,0,240,243,17,2,1,2,244,22,""],[19,"champ","f",4,0,246,250,18,1,1,1,251,21,""],[20,"chx_cible_rev","c",5,2,254,266,19,0,1,0,251,30,""],[21,":c_chx_cible_rev","c",4,0,273,288,18,0,2,0,0,30,""],[22,"egal","f",3,0,294,297,17,2,2,2,298,26,""],[23,"champ","f",4,0,300,304,22,1,1,1,305,25,""],[24,"chp_provenance_rev","c",5,2,308,325,23,0,1,0,305,30,""],[25,":c_chp_provenance_rev","c",4,0,332,352,22,0,2,0,0,30,""],[26,"egal","f",3,0,358,361,17,2,3,2,362,30,""],[27,"champ","f",4,0,364,368,26,1,1,1,369,29,""],[28,"chx_source_rev","c",5,2,372,385,27,0,1,0,369,30,""],[29,":c_chx_source_rev","c",4,0,392,408,26,0,2,0,0,30,""]]'),
('9','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte( champ( `chp_type_requete` ) , :n_chp_type_requete),
      affecte( champ( `cht_rev_requete` ) , :n_cht_rev_requete),
      affecte( champ( `cht_sql_requete` ) , :n_cht_sql_requete),
      affecte( champ( `cht_php_requete` ) , :n_cht_php_requete),
      affecte( champ( `cht_matrice_requete` ) , :n_cht_matrice_requete),
      affecte( champ( `cht_commentaire_requete` ) , :n_cht_commentaire_requete)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_requete` ) , :c_chi_id_requete ) , egal( champ( `chx_cible_requete` ) , :c_chx_cible_requete ))
   )
)','UPDATE b1.tbl_requetes SET `chp_type_requete` = :n_chp_type_requete , `cht_rev_requete` = :n_cht_rev_requete , `cht_sql_requete` = :n_cht_sql_requete , `cht_php_requete` = :n_cht_php_requete , `cht_matrice_requete` = :n_cht_matrice_requete , `cht_commentaire_requete` = :n_cht_commentaire_requete
WHERE (`chi_id_requete` = :c_chi_id_requete
   AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_9($par){
    $texte_sql_9=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.PHP_EOL;

    if($par[''n_chp_type_requete'']==='''' || $par[''n_chp_type_requete'']===NULL ){
        $texte_sql_9.=''    `chp_type_requete` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_9.=''    `chp_type_requete` = \''''.sq0($par[''n_chp_type_requete'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_cht_rev_requete'']==='''' || $par[''n_cht_rev_requete'']===NULL ){
        $texte_sql_9.=''    `cht_rev_requete` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_9.=''    `cht_rev_requete` = \''''.sq0($par[''n_cht_rev_requete'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_cht_sql_requete'']==='''' || $par[''n_cht_sql_requete'']===NULL ){
        $texte_sql_9.=''    `cht_sql_requete` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_9.=''    `cht_sql_requete` = \''''.sq0($par[''n_cht_sql_requete'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_cht_php_requete'']==='''' || $par[''n_cht_php_requete'']===NULL ){
        $texte_sql_9.=''    `cht_php_requete` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_9.=''    `cht_php_requete` = \''''.sq0($par[''n_cht_php_requete'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_cht_matrice_requete'']==='''' || $par[''n_cht_matrice_requete'']===NULL ){
        $texte_sql_9.=''    `cht_matrice_requete` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_9.=''    `cht_matrice_requete` = \''''.sq0($par[''n_cht_matrice_requete'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_cht_commentaire_requete'']==='''' || $par[''n_cht_commentaire_requete'']===NULL ){
        $texte_sql_9.=''    `cht_commentaire_requete` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_9.=''    `cht_commentaire_requete` = \''''.sq0($par[''n_cht_commentaire_requete'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.PHP_EOL;
    $texte_sql_9.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_9 = <pre>'' . $texte_sql_9 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_9);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_9()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','maj d''une requête','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,46,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,46,""],[4,"valeurs","f",1,0,38,44,1,6,2,3,45,29,""],[5,"affecte","f",2,0,53,59,4,2,1,2,60,9,""],[6,"champ","f",3,0,62,66,5,1,1,1,67,8,""],[7,"chp_type_requete","c",4,2,70,85,6,0,1,0,67,46,""],[8,":n_chp_type_requete","c",3,0,92,110,5,0,2,0,67,46,""],[9,"affecte","f",2,0,120,126,4,2,2,2,127,13,""],[10,"champ","f",3,0,129,133,9,1,1,1,134,12,""],[11,"cht_rev_requete","c",4,2,137,151,10,0,1,0,134,46,""],[12,":n_cht_rev_requete","c",3,0,158,175,9,0,2,0,134,46,""],[13,"affecte","f",2,0,185,191,4,2,3,2,192,17,""],[14,"champ","f",3,0,194,198,13,1,1,1,199,16,""],[15,"cht_sql_requete","c",4,2,202,216,14,0,1,0,199,46,""],[16,":n_cht_sql_requete","c",3,0,223,240,13,0,2,0,199,46,""],[17,"affecte","f",2,0,250,256,4,2,4,2,257,21,""],[18,"champ","f",3,0,259,263,17,1,1,1,264,20,""],[19,"cht_php_requete","c",4,2,267,281,18,0,1,0,264,46,""],[20,":n_cht_php_requete","c",3,0,288,305,17,0,2,0,264,46,""],[21,"affecte","f",2,0,315,321,4,2,5,2,322,25,""],[22,"champ","f",3,0,324,328,21,1,1,1,329,24,""],[23,"cht_matrice_requete","c",4,2,332,350,22,0,1,0,329,46,""],[24,":n_cht_matrice_requete","c",3,0,357,378,21,0,2,0,329,46,""],[25,"affecte","f",2,0,388,394,4,2,6,2,395,46,""],[26,"champ","f",3,0,397,401,25,1,1,1,402,28,""],[27,"cht_commentaire_requete","c",4,2,405,427,26,0,1,0,402,46,""],[28,":n_cht_commentaire_requete","c",3,0,434,459,25,0,2,0,402,46,""],[29,"provenance","f",1,0,471,480,1,1,3,5,481,36,""],[30,"table_reference","f",2,0,489,503,29,1,1,4,504,46,""],[31,"source","f",3,0,515,520,30,1,1,3,521,46,""],[32,"nom_de_la_table","f",4,0,523,537,31,2,1,2,538,46,""],[33,"tbl_requetes","c",5,0,540,551,32,0,1,0,0,34,""],[34,"base","f",5,0,555,558,32,1,2,1,559,46,""],[35,"b1","c",6,0,560,561,34,0,1,0,559,46,""],[36,"conditions","f",1,0,584,593,1,1,4,4,594,46,""],[37,"et","f",2,0,602,603,36,2,1,3,604,46,""],[38,"egal","f",3,0,606,609,37,2,1,2,610,42,""],[39,"champ","f",4,0,612,616,38,1,1,1,617,41,""],[40,"chi_id_requete","c",5,2,620,633,39,0,1,0,617,46,""],[41,":c_chi_id_requete","c",4,0,640,656,38,0,2,0,0,46,""],[42,"egal","f",3,0,662,665,37,2,2,2,666,46,""],[43,"champ","f",4,0,668,672,42,1,1,1,673,45,""],[44,"chx_cible_requete","c",5,2,676,692,43,0,1,0,673,46,""],[45,":c_chx_cible_requete","c",4,0,699,718,42,0,2,0,0,46,""]]'),
('10','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_rev_travail_basedd` ) , :n_chp_rev_travail_basedd )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_basedd` ) , :c_chi_id_basedd ) , egal( champ( `chx_cible_id_basedd` ) , :c_chx_cible_id_basedd ))
   )
)','UPDATE b1.tbl_bdds SET `chp_rev_travail_basedd` = :n_chp_rev_travail_basedd
WHERE (`chi_id_basedd` = :c_chi_id_basedd
   AND `chx_cible_id_basedd` = :c_chx_cible_id_basedd) ;','function sql_10($par){
    $texte_sql_10=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_bdds` SET ''.PHP_EOL;

    if($par[''n_chp_rev_travail_basedd'']==='''' || $par[''n_chp_rev_travail_basedd'']===NULL ){
        $texte_sql_10.=''    `chp_rev_travail_basedd` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_10.=''    `chp_rev_travail_basedd` = \''''.sq0($par[''n_chp_rev_travail_basedd'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_basedd` = ''.sq1($par[''c_chi_id_basedd'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_id_basedd` = ''.sq1($par[''c_chx_cible_id_basedd'']).''''.PHP_EOL;
    $texte_sql_10.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_10 = <pre>'' . $texte_sql_10 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_10);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_10()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,26,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,26,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,26,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_rev_travail_basedd","c",4,2,64,85,6,0,1,0,61,26,""],[8,":n_chp_rev_travail_basedd","c",3,0,92,116,5,0,2,0,0,26,""],[9,"provenance","f",1,0,125,134,1,1,3,5,135,16,""],[10,"table_reference","f",2,0,143,157,9,1,1,4,158,26,""],[11,"source","f",3,0,169,174,10,1,1,3,175,26,""],[12,"nom_de_la_table","f",4,0,177,191,11,2,1,2,192,26,""],[13,"tbl_bdds","c",5,0,194,201,12,0,1,0,0,14,""],[14,"base","f",5,0,205,208,12,1,2,1,209,26,""],[15,"b1","c",6,0,210,211,14,0,1,0,209,26,""],[16,"conditions","f",1,0,234,243,1,1,4,4,244,26,""],[17,"et","f",2,0,252,253,16,2,1,3,254,26,""],[18,"egal","f",3,0,256,259,17,2,1,2,260,22,""],[19,"champ","f",4,0,262,266,18,1,1,1,267,21,""],[20,"chi_id_basedd","c",5,2,270,282,19,0,1,0,267,26,""],[21,":c_chi_id_basedd","c",4,0,289,304,18,0,2,0,0,26,""],[22,"egal","f",3,0,310,313,17,2,2,2,314,26,""],[23,"champ","f",4,0,316,320,22,1,1,1,321,25,""],[24,"chx_cible_id_basedd","c",5,2,324,342,23,0,1,0,321,26,""],[25,":c_chx_cible_id_basedd","c",4,0,349,370,22,0,2,0,0,26,""]]'),
('11','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_basedd` ) , champ( `T0` , `chp_nom_basedd` ) , champ( `T0` , `chp_rev_travail_basedd` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et(
         #(),
         dans( champ( `T0` , `chi_id_basedd` ) , (:les_id_des_bases)),
         egal( champ( `T0` , `chx_cible_id_basedd` ) , :chx_cible_id_basedd)
      )
   )
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_travail_basedd`
 FROM b1.tbl_bdds T0
WHERE ( /* */ `T0`.`chi_id_basedd` IN (:les_id_des_bases)
   AND `T0`.`chx_cible_id_basedd` = :chx_cible_id_basedd);','function sql_11($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_travail_basedd`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `T0`.`chi_id_basedd` IN (''.sq0($par[''les_id_des_bases'']).'')''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chp_nom_basedd'' => $tab0[1],
                ''T0.chp_rev_travail_basedd'' => $tab0[2],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,37,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,37,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,14,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_basedd","c",3,2,66,78,5,0,2,0,56,37,""],[8,"champ","f",2,0,85,89,4,2,2,1,90,11,""],[9,"T0","c",3,2,93,94,8,0,1,0,90,10,""],[10,"chp_nom_basedd","c",3,2,100,113,8,0,2,0,90,37,""],[11,"champ","f",2,0,120,124,4,2,3,1,125,37,""],[12,"T0","c",3,2,128,129,11,0,1,0,125,13,""],[13,"chp_rev_travail_basedd","c",3,2,135,156,11,0,2,0,125,37,""],[14,"provenance","f",1,0,166,175,1,1,3,5,176,23,""],[15,"table_reference","f",2,0,184,198,14,1,1,4,199,37,""],[16,"source","f",3,0,210,215,15,1,1,3,216,37,""],[17,"nom_de_la_table","f",4,0,218,232,16,3,1,2,233,37,""],[18,"tbl_bdds","c",5,0,235,242,17,0,1,0,0,19,""],[19,"alias","f",5,0,246,250,17,1,2,1,251,21,""],[20,"T0","c",6,0,252,253,19,0,1,0,251,37,""],[21,"base","f",5,0,258,261,17,1,3,1,262,37,""],[22,"b1","c",6,0,263,264,21,0,1,0,262,37,""],[23,"conditions","f",1,0,287,296,1,1,4,4,297,37,""],[24,"et","f",2,0,305,306,23,3,1,3,307,37,""],[25,"#","f",3,0,318,318,24,0,1,0,319,26,""],[26,"dans","f",3,0,332,335,24,2,2,2,336,32,""],[27,"champ","f",4,0,338,342,26,2,1,1,343,30,""],[28,"T0","c",5,2,346,347,27,0,1,0,343,29,""],[29,"chi_id_basedd","c",5,2,353,365,27,0,2,0,343,37,""],[30,"","f",4,0,353,365,26,1,2,1,372,37,""],[31,":les_id_des_bases","c",5,0,373,389,30,0,1,0,372,37,""],[32,"egal","f",3,0,403,406,24,2,3,2,407,37,""],[33,"champ","f",4,0,409,413,32,2,1,1,414,36,""],[34,"T0","c",5,2,417,418,33,0,1,0,414,35,""],[35,"chx_cible_id_basedd","c",5,2,424,442,33,0,2,0,414,37,""],[36,":chx_cible_id_basedd","c",4,0,449,468,32,0,2,0,414,37,""]]'),
('12','1','insert','insérer(
   base_de_reference(1),
   valeurs(
      affecte( champ( `chx_cible_rev` ) , :chx_cible_rev),
      affecte( champ( `chp_provenance_rev` ) , :chp_provenance_rev),
      affecte( champ( `chx_source_rev` ) , :chx_source_rev),
      affecte( champ( `chp_id_rev` ) , :chp_id_rev),
      affecte( champ( `chp_valeur_rev` ) , :chp_valeur_rev),
      affecte( champ( `chp_type_rev` ) , :chp_type_rev),
      affecte( champ( `chp_niveau_rev` ) , :chp_niveau_rev),
      affecte( champ( `chp_quotee_rev` ) , :chp_quotee_rev),
      affecte( champ( `chp_pos_premier_rev` ) , :chp_pos_premier_rev),
      affecte( champ( `chp_pos_dernier_rev` ) , :chp_pos_dernier_rev),
      affecte( champ( `chp_parent_rev` ) , :chp_parent_rev),
      affecte( champ( `chp_nbr_enfants_rev` ) , :chp_nbr_enfants_rev),
      affecte( champ( `chp_num_enfant_rev` ) , :chp_num_enfant_rev),
      affecte( champ( `chp_profondeur_rev` ) , :chp_profondeur_rev),
      affecte( champ( `chp_pos_ouver_parenthese_rev` ) , :chp_pos_ouver_parenthese_rev),
      affecte( champ( `chp_pos_fermer_parenthese_rev` ) , :chp_pos_fermer_parenthese_rev),
      affecte( champ( `chp_commentaire_rev` ) , :chp_commentaire_rev)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_revs , base(b1) ))
      )
   )
)','INSERT INTO b1.`tbl_revs`(
    `chx_cible_rev` , 
    `chp_provenance_rev` , 
    `chx_source_rev` , 
    `chp_id_rev` , 
    `chp_valeur_rev` , 
    `chp_type_rev` , 
    `chp_niveau_rev` , 
    `chp_quotee_rev` , 
    `chp_pos_premier_rev` , 
    `chp_pos_dernier_rev` , 
    `chp_parent_rev` , 
    `chp_nbr_enfants_rev` , 
    `chp_num_enfant_rev` , 
    `chp_profondeur_rev` , 
    `chp_pos_ouver_parenthese_rev` , 
    `chp_pos_fermer_parenthese_rev` , 
    `chp_commentaire_rev`
) VALUES (
    :chx_cible_rev , 
    :chp_provenance_rev , 
    :chx_source_rev , 
    :chp_id_rev , 
    :chp_valeur_rev , 
    :chp_type_rev , 
    :chp_niveau_rev , 
    :chp_quotee_rev , 
    :chp_pos_premier_rev , 
    :chp_pos_dernier_rev , 
    :chp_parent_rev , 
    :chp_nbr_enfants_rev , 
    :chp_num_enfant_rev , 
    :chp_profondeur_rev , 
    :chp_pos_ouver_parenthese_rev , 
    :chp_pos_fermer_parenthese_rev , 
    :chp_commentaire_rev
);','function sql_12($par){
    $texte_sql_12=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_revs`(
         `chx_cible_rev` , 
         `chp_provenance_rev` , 
         `chx_source_rev` , 
         `chp_id_rev` , 
         `chp_valeur_rev` , 
         `chp_type_rev` , 
         `chp_niveau_rev` , 
         `chp_quotee_rev` , 
         `chp_pos_premier_rev` , 
         `chp_pos_dernier_rev` , 
         `chp_parent_rev` , 
         `chp_nbr_enfants_rev` , 
         `chp_num_enfant_rev` , 
         `chp_profondeur_rev` , 
         `chp_pos_ouver_parenthese_rev` , 
         `chp_pos_fermer_parenthese_rev` , 
         `chp_commentaire_rev`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_provenance_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_source_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_id_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_valeur_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_type_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_niveau_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_quotee_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_premier_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_dernier_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_parent_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nbr_enfants_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_num_enfant_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_profondeur_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_ouver_parenthese_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_fermer_parenthese_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_rev'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_12.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_12 = <pre>'' . $texte_sql_12 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_12);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_12()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,80,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,80,""],[4,"valeurs","f",1,0,37,43,1,17,2,3,44,73,""],[5,"affecte","f",2,0,52,58,4,2,1,2,59,9,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,8,""],[7,"chx_cible_rev","c",4,2,69,81,6,0,1,0,66,80,""],[8,":chx_cible_rev","c",3,0,88,101,5,0,2,0,66,80,""],[9,"affecte","f",2,0,111,117,4,2,2,2,118,13,""],[10,"champ","f",3,0,120,124,9,1,1,1,125,12,""],[11,"chp_provenance_rev","c",4,2,128,145,10,0,1,0,125,80,""],[12,":chp_provenance_rev","c",3,0,152,170,9,0,2,0,125,80,""],[13,"affecte","f",2,0,180,186,4,2,3,2,187,17,""],[14,"champ","f",3,0,189,193,13,1,1,1,194,16,""],[15,"chx_source_rev","c",4,2,197,210,14,0,1,0,194,80,""],[16,":chx_source_rev","c",3,0,217,231,13,0,2,0,194,80,""],[17,"affecte","f",2,0,241,247,4,2,4,2,248,21,""],[18,"champ","f",3,0,250,254,17,1,1,1,255,20,""],[19,"chp_id_rev","c",4,2,258,267,18,0,1,0,255,80,""],[20,":chp_id_rev","c",3,0,274,284,17,0,2,0,255,80,""],[21,"affecte","f",2,0,294,300,4,2,5,2,301,25,""],[22,"champ","f",3,0,303,307,21,1,1,1,308,24,""],[23,"chp_valeur_rev","c",4,2,311,324,22,0,1,0,308,80,""],[24,":chp_valeur_rev","c",3,0,331,345,21,0,2,0,308,80,""],[25,"affecte","f",2,0,355,361,4,2,6,2,362,29,""],[26,"champ","f",3,0,364,368,25,1,1,1,369,28,""],[27,"chp_type_rev","c",4,2,372,383,26,0,1,0,369,80,""],[28,":chp_type_rev","c",3,0,390,402,25,0,2,0,369,80,""],[29,"affecte","f",2,0,412,418,4,2,7,2,419,33,""],[30,"champ","f",3,0,421,425,29,1,1,1,426,32,""],[31,"chp_niveau_rev","c",4,2,429,442,30,0,1,0,426,80,""],[32,":chp_niveau_rev","c",3,0,449,463,29,0,2,0,426,80,""],[33,"affecte","f",2,0,473,479,4,2,8,2,480,37,""],[34,"champ","f",3,0,482,486,33,1,1,1,487,36,""],[35,"chp_quotee_rev","c",4,2,490,503,34,0,1,0,487,80,""],[36,":chp_quotee_rev","c",3,0,510,524,33,0,2,0,487,80,""],[37,"affecte","f",2,0,534,540,4,2,9,2,541,41,""],[38,"champ","f",3,0,543,547,37,1,1,1,548,40,""],[39,"chp_pos_premier_rev","c",4,2,551,569,38,0,1,0,548,80,""],[40,":chp_pos_premier_rev","c",3,0,576,595,37,0,2,0,548,80,""],[41,"affecte","f",2,0,605,611,4,2,10,2,612,45,""],[42,"champ","f",3,0,614,618,41,1,1,1,619,44,""],[43,"chp_pos_dernier_rev","c",4,2,622,640,42,0,1,0,619,80,""],[44,":chp_pos_dernier_rev","c",3,0,647,666,41,0,2,0,619,80,""],[45,"affecte","f",2,0,676,682,4,2,11,2,683,49,""],[46,"champ","f",3,0,685,689,45,1,1,1,690,48,""],[47,"chp_parent_rev","c",4,2,693,706,46,0,1,0,690,80,""],[48,":chp_parent_rev","c",3,0,713,727,45,0,2,0,690,80,""],[49,"affecte","f",2,0,737,743,4,2,12,2,744,53,""],[50,"champ","f",3,0,746,750,49,1,1,1,751,52,""],[51,"chp_nbr_enfants_rev","c",4,2,754,772,50,0,1,0,751,80,""],[52,":chp_nbr_enfants_rev","c",3,0,779,798,49,0,2,0,751,80,""],[53,"affecte","f",2,0,808,814,4,2,13,2,815,57,""],[54,"champ","f",3,0,817,821,53,1,1,1,822,56,""],[55,"chp_num_enfant_rev","c",4,2,825,842,54,0,1,0,822,80,""],[56,":chp_num_enfant_rev","c",3,0,849,867,53,0,2,0,822,80,""],[57,"affecte","f",2,0,877,883,4,2,14,2,884,61,""],[58,"champ","f",3,0,886,890,57,1,1,1,891,60,""],[59,"chp_profondeur_rev","c",4,2,894,911,58,0,1,0,891,80,""],[60,":chp_profondeur_rev","c",3,0,918,936,57,0,2,0,891,80,""],[61,"affecte","f",2,0,946,952,4,2,15,2,953,65,""],[62,"champ","f",3,0,955,959,61,1,1,1,960,64,""],[63,"chp_pos_ouver_parenthese_rev","c",4,2,963,990,62,0,1,0,960,80,""],[64,":chp_pos_ouver_parenthese_rev","c",3,0,997,1025,61,0,2,0,960,80,""],[65,"affecte","f",2,0,1035,1041,4,2,16,2,1042,69,""],[66,"champ","f",3,0,1044,1048,65,1,1,1,1049,68,""],[67,"chp_pos_fermer_parenthese_rev","c",4,2,1052,1080,66,0,1,0,1049,80,""],[68,":chp_pos_fermer_parenthese_rev","c",3,0,1087,1116,65,0,2,0,1049,80,""],[69,"affecte","f",2,0,1126,1132,4,2,17,2,1133,80,""],[70,"champ","f",3,0,1135,1139,69,1,1,1,1140,72,""],[71,"chp_commentaire_rev","c",4,2,1143,1161,70,0,1,0,1140,80,""],[72,":chp_commentaire_rev","c",3,0,1168,1187,69,0,2,0,1140,80,""],[73,"provenance","f",1,0,1199,1208,1,1,3,5,1209,80,""],[74,"table_reference","f",2,0,1217,1231,73,1,1,4,1232,80,""],[75,"source","f",3,0,1243,1248,74,1,1,3,1249,80,""],[76,"nom_de_la_table","f",4,0,1251,1265,75,2,1,2,1266,80,""],[77,"tbl_revs","c",5,0,1268,1275,76,0,1,0,0,78,""],[78,"base","f",5,0,1279,1282,76,1,2,1,1283,80,""],[79,"b1","c",6,0,1284,1285,78,0,1,0,1283,80,""]]'),
('13','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_rev`),
      champ( `T0` , `chp_provenance_rev`),
      champ( `T0` , `chx_source_rev`),
      champ( `T1` , `chp_nom_source`),
      champ( `T0` , `chp_valeur_rev`),
      champ( `T0` , `chp_type_rev`),
      champ( `T0` , `chp_niveau_rev`),
      champ( `T0` , `chp_pos_premier_rev`),
      champ( `T0` , `chp_commentaire_rev`),
      champ( `T2` , `chp_type_requete`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_revs , alias(T0) , base(b1) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_sources , alias(T1) , base(b1) )),
         contrainte( egal( champ( T1 , chi_id_source ) , champ( T0 , chx_source_rev ) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_requetes , alias(T2) , base(b1) )),
         contrainte( egal( champ( T2 , chi_id_requete ) , champ( T0 , chx_source_rev ) ))
      )
   ),
   conditions(
      et(
         egal( champ( `T0` , `chx_cible_rev` ) , :T0_chx_cible_rev),
         comme( champ( `T0` , `chp_provenance_rev` ) , :T0_chp_provenance_rev),
         egal( champ( `T0` , `chx_source_rev` ) , :T0_chx_source_rev),
         comme( champ( `T1` , `chp_nom_source` ) , :T1_chp_nom_source1),
         pas_comme( champ( `T1` , `chp_nom_source` ) , :T1_chp_nom_source2),
         comme( champ( `T0` , `chp_valeur_rev` ) , :T0_chp_valeur_rev),
         comme( champ( `T0` , `chp_commentaire_rev` ) , :T0_chp_commentaire_rev),
         egal( champ( `T0` , `chi_id_rev` ) , :T0_chi_id_rev)
      )
   ),
   complements(
      trier_par( ( champ( `T0` , `chp_provenance_rev` ) , croissant() ) , ( champ( `T0` , `chx_source_rev` ) , croissant() )),
      limité_à( quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_rev` , `T0`.`chp_provenance_rev` , `T0`.`chx_source_rev` , `T1`.`chp_nom_source` , `T0`.`chp_valeur_rev` , 
`T0`.`chp_type_rev` , `T0`.`chp_niveau_rev` , `T0`.`chp_pos_premier_rev` , `T0`.`chp_commentaire_rev` , `T2`.`chp_type_requete`
 FROM b1.tbl_revs T0
 LEFT JOIN b1.tbl_sources T1 ON T1.chi_id_source = T0.chx_source_rev

 LEFT JOIN b1.tbl_requetes T2 ON T2.chi_id_requete = T0.chx_source_rev

WHERE (`T0`.`chx_cible_rev` = :T0_chx_cible_rev
   AND `T0`.`chp_provenance_rev` LIKE :T0_chp_provenance_rev
   AND `T0`.`chx_source_rev` = :T0_chx_source_rev
   AND `T1`.`chp_nom_source` LIKE :T1_chp_nom_source1
   AND `T1`.`chp_nom_source` NOT LIKE :T1_chp_nom_source2
   AND `T0`.`chp_valeur_rev` LIKE :T0_chp_valeur_rev
   AND `T0`.`chp_commentaire_rev` LIKE :T0_chp_commentaire_rev
   AND `T0`.`chi_id_rev` = :T0_chi_id_rev) 
ORDER BY `T0`.`chp_provenance_rev` ASC, `T0`.`chx_source_rev` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_13($par){
    $champs0=''
      `T0`.`chi_id_rev` , `T0`.`chp_provenance_rev` , `T0`.`chx_source_rev` , `T1`.`chp_nom_source` , `T0`.`chp_valeur_rev` , 
      `T0`.`chp_type_rev` , `T0`.`chp_niveau_rev` , `T0`.`chp_pos_premier_rev` , `T0`.`chp_commentaire_rev` , `T2`.`chp_type_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_revs T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T1 ON T1.chi_id_source = T0.chx_source_rev

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T2 ON T2.chi_id_requete = T0.chx_source_rev
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    if(($par[''T0_chx_cible_rev''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_rev`'',$par[''T0_chx_cible_rev'']);
    }
    if(($par[''T0_chp_provenance_rev''] !== '''')){
        $where0.='' AND `T0`.`chp_provenance_rev` LIKE ''.sq1($par[''T0_chp_provenance_rev'']).''''.PHP_EOL;
    }
    if(($par[''T0_chx_source_rev''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_source_rev`'',$par[''T0_chx_source_rev'']);
    }
    if(($par[''T1_chp_nom_source1''] !== '''')){
        $where0.='' AND `T1`.`chp_nom_source` LIKE ''.sq1($par[''T1_chp_nom_source1'']).''''.PHP_EOL;
    }
    if(($par[''T1_chp_nom_source2''] !== '''')){
        $where0.='' AND `T1`.`chp_nom_source` NOT LIKE ''.sq1($par[''T1_chp_nom_source2'']).''''.PHP_EOL;
    }
    if(($par[''T0_chp_valeur_rev''] !== '''')){
        $where0.='' AND `T0`.`chp_valeur_rev` LIKE ''.sq1($par[''T0_chp_valeur_rev'']).''''.PHP_EOL;
    }
    if(($par[''T0_chp_commentaire_rev''] !== '''')){
        $where0.='' AND `T0`.`chp_commentaire_rev` LIKE ''.sq1($par[''T0_chp_commentaire_rev'']).''''.PHP_EOL;
    }
    if(($par[''T0_chi_id_rev''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_rev`'',$par[''T0_chi_id_rev'']);
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_provenance_rev` ASC, `T0`.`chx_source_rev` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_rev'' => $tab0[0],
                ''T0.chp_provenance_rev'' => $tab0[1],
                ''T0.chx_source_rev'' => $tab0[2],
                ''T1.chp_nom_source'' => $tab0[3],
                ''T0.chp_valeur_rev'' => $tab0[4],
                ''T0.chp_type_rev'' => $tab0[5],
                ''T0.chp_niveau_rev'' => $tab0[6],
                ''T0.chp_pos_premier_rev'' => $tab0[7],
                ''T0.chp_commentaire_rev'' => $tab0[8],
                ''T2.chp_type_requete'' => $tab0[9],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => __xsu       ,
           __xva  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => __xer ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','revs','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,135,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,135,""],[4,"valeurs","f",1,0,42,48,1,10,2,2,49,35,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_rev","c",3,2,72,81,5,0,2,0,62,135,""],[8,"champ","f",2,0,92,96,4,2,2,1,97,11,""],[9,"T0","c",3,2,100,101,8,0,1,0,97,10,""],[10,"chp_provenance_rev","c",3,2,107,124,8,0,2,0,97,135,""],[11,"champ","f",2,0,135,139,4,2,3,1,140,14,""],[12,"T0","c",3,2,143,144,11,0,1,0,140,13,""],[13,"chx_source_rev","c",3,2,150,163,11,0,2,0,140,135,""],[14,"champ","f",2,0,174,178,4,2,4,1,179,17,""],[15,"T1","c",3,2,182,183,14,0,1,0,179,16,""],[16,"chp_nom_source","c",3,2,189,202,14,0,2,0,179,135,""],[17,"champ","f",2,0,213,217,4,2,5,1,218,20,""],[18,"T0","c",3,2,221,222,17,0,1,0,218,19,""],[19,"chp_valeur_rev","c",3,2,228,241,17,0,2,0,218,135,""],[20,"champ","f",2,0,252,256,4,2,6,1,257,23,""],[21,"T0","c",3,2,260,261,20,0,1,0,257,22,""],[22,"chp_type_rev","c",3,2,267,278,20,0,2,0,257,135,""],[23,"champ","f",2,0,289,293,4,2,7,1,294,26,""],[24,"T0","c",3,2,297,298,23,0,1,0,294,25,""],[25,"chp_niveau_rev","c",3,2,304,317,23,0,2,0,294,135,""],[26,"champ","f",2,0,328,332,4,2,8,1,333,29,""],[27,"T0","c",3,2,336,337,26,0,1,0,333,28,""],[28,"chp_pos_premier_rev","c",3,2,343,361,26,0,2,0,333,135,""],[29,"champ","f",2,0,372,376,4,2,9,1,377,32,""],[30,"T0","c",3,2,380,381,29,0,1,0,377,31,""],[31,"chp_commentaire_rev","c",3,2,387,405,29,0,2,0,377,135,""],[32,"champ","f",2,0,416,420,4,2,10,1,421,135,""],[33,"T2","c",3,2,424,425,32,0,1,0,421,34,""],[34,"chp_type_requete","c",3,2,431,446,32,0,2,0,421,135,""],[35,"provenance","f",1,0,459,468,1,3,3,5,469,76,""],[36,"table_reference","f",2,0,477,491,35,1,1,4,492,44,""],[37,"source","f",3,0,503,508,36,1,1,3,509,135,""],[38,"nom_de_la_table","f",4,0,511,525,37,3,1,2,526,135,""],[39,"tbl_revs","c",5,0,528,535,38,0,1,0,0,40,""],[40,"alias","f",5,0,539,543,38,1,2,1,544,42,""],[41,"T0","c",6,0,545,546,40,0,1,0,544,135,""],[42,"base","f",5,0,551,554,38,1,3,1,555,135,""],[43,"b1","c",6,0,556,557,42,0,1,0,555,135,""],[44,"jointure_gauche","f",2,0,578,592,35,2,2,4,593,60,""],[45,"source","f",3,0,604,609,44,1,1,3,610,52,""],[46,"nom_de_la_table","f",4,0,612,626,45,3,1,2,627,135,""],[47,"tbl_sources","c",5,0,629,639,46,0,1,0,0,48,""],[48,"alias","f",5,0,643,647,46,1,2,1,648,50,""],[49,"T1","c",6,0,649,650,48,0,1,0,648,135,""],[50,"base","f",5,0,655,658,46,1,3,1,659,135,""],[51,"b1","c",6,0,660,661,50,0,1,0,659,135,""],[52,"contrainte","f",3,0,677,686,44,1,2,3,687,135,""],[53,"egal","f",4,0,689,692,52,2,1,2,693,135,""],[54,"champ","f",5,0,695,699,53,2,1,1,700,57,""],[55,"T1","c",6,0,702,703,54,0,1,0,0,56,""],[56,"chi_id_source","c",6,0,707,719,54,0,2,0,0,135,""],[57,"champ","f",5,0,725,729,53,2,2,1,730,135,""],[58,"T0","c",6,0,732,733,57,0,1,0,0,59,""],[59,"chx_source_rev","c",6,0,737,750,57,0,2,0,0,135,""],[60,"jointure_gauche","f",2,0,772,786,35,2,3,4,787,135,""],[61,"source","f",3,0,798,803,60,1,1,3,804,68,""],[62,"nom_de_la_table","f",4,0,806,820,61,3,1,2,821,135,""],[63,"tbl_requetes","c",5,0,823,834,62,0,1,0,0,64,""],[64,"alias","f",5,0,838,842,62,1,2,1,843,66,""],[65,"T2","c",6,0,844,845,64,0,1,0,843,135,""],[66,"base","f",5,0,850,853,62,1,3,1,854,135,""],[67,"b1","c",6,0,855,856,66,0,1,0,854,135,""],[68,"contrainte","f",3,0,872,881,60,1,2,3,882,135,""],[69,"egal","f",4,0,884,887,68,2,1,2,888,135,""],[70,"champ","f",5,0,890,894,69,2,1,1,895,73,""],[71,"T2","c",6,0,897,898,70,0,1,0,0,72,""],[72,"chi_id_requete","c",6,0,902,915,70,0,2,0,0,135,""],[73,"champ","f",5,0,921,925,69,2,2,1,926,135,""],[74,"T0","c",6,0,928,929,73,0,1,0,0,75,""],[75,"chx_source_rev","c",6,0,933,946,73,0,2,0,0,135,""],[76,"conditions","f",1,0,970,979,1,1,4,4,980,118,""],[77,"et","f",2,0,988,989,76,8,1,3,990,135,""],[78,"egal","f",3,0,1001,1004,77,2,1,2,1005,83,""],[79,"champ","f",4,0,1007,1011,78,2,1,1,1012,82,""],[80,"T0","c",5,2,1015,1016,79,0,1,0,1012,81,""],[81,"chx_cible_rev","c",5,2,1022,1034,79,0,2,0,1012,135,""],[82,":T0_chx_cible_rev","c",4,0,1041,1057,78,0,2,0,1012,135,""],[83,"comme","f",3,0,1070,1074,77,2,2,2,1075,88,""],[84,"champ","f",4,0,1077,1081,83,2,1,1,1082,87,""],[85,"T0","c",5,2,1085,1086,84,0,1,0,1082,86,""],[86,"chp_provenance_rev","c",5,2,1092,1109,84,0,2,0,1082,135,""],[87,":T0_chp_provenance_rev","c",4,0,1116,1137,83,0,2,0,1082,135,""],[88,"egal","f",3,0,1150,1153,77,2,3,2,1154,93,""],[89,"champ","f",4,0,1156,1160,88,2,1,1,1161,92,""],[90,"T0","c",5,2,1164,1165,89,0,1,0,1161,91,""],[91,"chx_source_rev","c",5,2,1171,1184,89,0,2,0,1161,135,""],[92,":T0_chx_source_rev","c",4,0,1191,1208,88,0,2,0,1161,135,""],[93,"comme","f",3,0,1221,1225,77,2,4,2,1226,98,""],[94,"champ","f",4,0,1228,1232,93,2,1,1,1233,97,""],[95,"T1","c",5,2,1236,1237,94,0,1,0,1233,96,""],[96,"chp_nom_source","c",5,2,1243,1256,94,0,2,0,1233,135,""],[97,":T1_chp_nom_source1","c",4,0,1263,1281,93,0,2,0,1233,135,""],[98,"pas_comme","f",3,0,1294,1302,77,2,5,2,1303,103,""],[99,"champ","f",4,0,1305,1309,98,2,1,1,1310,102,""],[100,"T1","c",5,2,1313,1314,99,0,1,0,1310,101,""],[101,"chp_nom_source","c",5,2,1320,1333,99,0,2,0,1310,135,""],[102,":T1_chp_nom_source2","c",4,0,1340,1358,98,0,2,0,1310,135,""],[103,"comme","f",3,0,1371,1375,77,2,6,2,1376,108,""],[104,"champ","f",4,0,1378,1382,103,2,1,1,1383,107,""],[105,"T0","c",5,2,1386,1387,104,0,1,0,1383,106,""],[106,"chp_valeur_rev","c",5,2,1393,1406,104,0,2,0,1383,135,""],[107,":T0_chp_valeur_rev","c",4,0,1413,1430,103,0,2,0,1383,135,""],[108,"comme","f",3,0,1443,1447,77,2,7,2,1448,113,""],[109,"champ","f",4,0,1450,1454,108,2,1,1,1455,112,""],[110,"T0","c",5,2,1458,1459,109,0,1,0,1455,111,""],[111,"chp_commentaire_rev","c",5,2,1465,1483,109,0,2,0,1455,135,""],[112,":T0_chp_commentaire_rev","c",4,0,1490,1512,108,0,2,0,1455,135,""],[113,"egal","f",3,0,1525,1528,77,2,8,2,1529,135,""],[114,"champ","f",4,0,1531,1535,113,2,1,1,1536,117,""],[115,"T0","c",5,2,1539,1540,114,0,1,0,1536,116,""],[116,"chi_id_rev","c",5,2,1546,1555,114,0,2,0,1536,135,""],[117,":T0_chi_id_rev","c",4,0,1562,1575,113,0,2,0,1536,135,""],[118,"complements","f",1,0,1595,1605,1,2,5,4,1606,135,""],[119,"trier_par","f",2,0,1614,1622,118,2,1,3,1623,130,""],[120,"","f",3,0,1614,1622,119,2,1,2,1625,125,""],[121,"champ","f",4,0,1627,1631,120,2,1,1,1632,124,""],[122,"T0","c",5,2,1635,1636,121,0,1,0,1632,123,""],[123,"chp_provenance_rev","c",5,2,1642,1659,121,0,2,0,1632,135,""],[124,"croissant","f",4,0,1666,1674,120,0,2,0,1675,135,""],[125,"","f",3,0,1666,1674,119,2,2,2,1682,135,""],[126,"champ","f",4,0,1684,1688,125,2,1,1,1689,129,""],[127,"T0","c",5,2,1692,1693,126,0,1,0,1689,128,""],[128,"chx_source_rev","c",5,2,1699,1712,126,0,2,0,1689,135,""],[129,"croissant","f",4,0,1719,1727,125,0,2,0,1728,135,""],[130,"limit\u00e9_\u00e0","f",2,0,1741,1748,118,2,2,2,1749,135,""],[131,"quantit\u00e9","f",3,0,1751,1758,130,1,1,1,1759,133,""],[132,":quantitee","c",4,0,1760,1769,131,0,1,0,1759,135,""],[133,"d\u00e9but","f",3,0,1774,1778,130,1,2,1,1779,135,""],[134,":debut","c",4,0,1780,1785,133,0,1,0,1779,135,""]]'),
('14','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_revs , base(b1) ))
      )
   ),
   conditions( egal( champ( `chx_cible_rev` ) , :chx_cible_rev ))
)','DELETE FROM b1.tbl_revs
WHERE `chx_cible_rev` = :chx_cible_rev ;','function sql_14($par){
    $texte_sql_14=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_revs
          WHERE `chx_cible_rev` = ''.sq1($par[''chx_cible_rev'']).'' ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_14 = <pre>'' . $texte_sql_14 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_14);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_14()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','rev par cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,16,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,16,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,16,""],[6,"source","f",3,0,83,88,5,1,1,3,89,16,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,16,""],[8,"tbl_revs","c",5,0,108,115,7,0,1,0,0,9,""],[9,"base","f",5,0,119,122,7,1,2,1,123,16,""],[10,"b1","c",6,0,124,125,9,0,1,0,123,16,""],[11,"conditions","f",1,0,148,157,1,1,3,3,158,16,""],[12,"egal","f",2,0,160,163,11,2,1,2,164,16,""],[13,"champ","f",3,0,166,170,12,1,1,1,171,15,""],[14,"chx_cible_rev","c",4,2,174,186,13,0,1,0,171,16,""],[15,":chx_cible_rev","c",3,0,193,206,12,0,2,0,0,16,""]]'),
('15','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_basedd` ) , champ( `T0` , `chp_nom_basedd` ) , champ( `T0` , `chp_commentaire_basedd` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et(
         #(),
         egal( champ( `T0` , `chx_cible_id_basedd` ) , :T0_chx_cible_id_basedd),
         egal( champ( `T0` , `chi_id_basedd` ) , :T0_chi_id_basedd),
         comme( champ( `T0` , `chp_nom_basedd` ) , :T0_chp_nom_basedd)
      )
   ),
   complements(
      trier_par( ( champ( `T0` , `chi_id_basedd` ) , croissant() )),
      limité_à( quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_commentaire_basedd`
 FROM b1.tbl_bdds T0
WHERE ( /* */ `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd
   AND `T0`.`chi_id_basedd` = :T0_chi_id_basedd
   AND `T0`.`chp_nom_basedd` LIKE :T0_chp_nom_basedd) 
ORDER BY `T0`.`chi_id_basedd` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_15($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_commentaire_basedd`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    if(($par[''T0_chx_cible_id_basedd''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    }
    if(($par[''T0_chi_id_basedd''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_basedd`'',$par[''T0_chi_id_basedd'']);
    }
    if(($par[''T0_chp_nom_basedd''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_basedd` LIKE ''.sq1($par[''T0_chp_nom_basedd'']).''''.PHP_EOL;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_basedd` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chp_nom_basedd'' => $tab0[1],
                ''T0.chp_commentaire_basedd'' => $tab0[2],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => __xsu       ,
           __xva  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => __xer ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','bdd','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,53,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,53,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,14,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_basedd","c",3,2,66,78,5,0,2,0,56,53,""],[8,"champ","f",2,0,85,89,4,2,2,1,90,11,""],[9,"T0","c",3,2,93,94,8,0,1,0,90,10,""],[10,"chp_nom_basedd","c",3,2,100,113,8,0,2,0,90,53,""],[11,"champ","f",2,0,120,124,4,2,3,1,125,53,""],[12,"T0","c",3,2,128,129,11,0,1,0,125,13,""],[13,"chp_commentaire_basedd","c",3,2,135,156,11,0,2,0,125,53,""],[14,"provenance","f",1,0,166,175,1,1,3,5,176,23,""],[15,"table_reference","f",2,0,184,198,14,1,1,4,199,53,""],[16,"source","f",3,0,210,215,15,1,1,3,216,53,""],[17,"nom_de_la_table","f",4,0,218,232,16,3,1,2,233,53,""],[18,"tbl_bdds","c",5,0,235,242,17,0,1,0,0,19,""],[19,"alias","f",5,0,246,250,17,1,2,1,251,21,""],[20,"T0","c",6,0,252,253,19,0,1,0,251,53,""],[21,"base","f",5,0,258,261,17,1,3,1,262,53,""],[22,"b1","c",6,0,263,264,21,0,1,0,262,53,""],[23,"conditions","f",1,0,287,296,1,1,4,4,297,41,""],[24,"et","f",2,0,305,306,23,4,1,3,307,53,""],[25,"#","f",3,0,318,318,24,0,1,0,319,26,""],[26,"egal","f",3,0,332,335,24,2,2,2,336,31,""],[27,"champ","f",4,0,338,342,26,2,1,1,343,30,""],[28,"T0","c",5,2,346,347,27,0,1,0,343,29,""],[29,"chx_cible_id_basedd","c",5,2,353,371,27,0,2,0,343,53,""],[30,":T0_chx_cible_id_basedd","c",4,0,378,400,26,0,2,0,343,53,""],[31,"egal","f",3,0,413,416,24,2,3,2,417,36,""],[32,"champ","f",4,0,419,423,31,2,1,1,424,35,""],[33,"T0","c",5,2,427,428,32,0,1,0,424,34,""],[34,"chi_id_basedd","c",5,2,434,446,32,0,2,0,424,53,""],[35,":T0_chi_id_basedd","c",4,0,453,469,31,0,2,0,424,53,""],[36,"comme","f",3,0,482,486,24,2,4,2,487,53,""],[37,"champ","f",4,0,489,493,36,2,1,1,494,40,""],[38,"T0","c",5,2,497,498,37,0,1,0,494,39,""],[39,"chp_nom_basedd","c",5,2,504,517,37,0,2,0,494,53,""],[40,":T0_chp_nom_basedd","c",4,0,524,541,36,0,2,0,494,53,""],[41,"complements","f",1,0,561,571,1,2,5,4,572,53,""],[42,"trier_par","f",2,0,580,588,41,1,1,3,589,48,""],[43,"","f",3,0,580,588,42,2,1,2,591,53,""],[44,"champ","f",4,0,593,597,43,2,1,1,598,47,""],[45,"T0","c",5,2,601,602,44,0,1,0,598,46,""],[46,"chi_id_basedd","c",5,2,608,620,44,0,2,0,598,53,""],[47,"croissant","f",4,0,627,635,43,0,2,0,636,53,""],[48,"limit\u00e9_\u00e0","f",2,0,649,656,41,2,2,2,657,53,""],[49,"quantit\u00e9","f",3,0,659,666,48,1,1,1,667,51,""],[50,":quantitee","c",4,0,668,677,49,0,1,0,667,53,""],[51,"d\u00e9but","f",3,0,682,686,48,1,2,1,687,53,""],[52,":debut","c",4,0,688,693,51,0,1,0,687,53,""]]'),
('16','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte( champ( `chx_dossier_id_basedd` ) , :n_chx_dossier_id_basedd),
      affecte( champ( `chp_nom_basedd` ) , :n_chp_nom_basedd),
      affecte( champ( `chp_rev_basedd` ) , :n_chp_rev_basedd),
      affecte( champ( `chp_commentaire_basedd` ) , :n_chp_commentaire_basedd),
      affecte( champ( `chp_genere_basedd` ) , :n_chp_genere_basedd),
      affecte( champ( `chp_rev_travail_basedd` ) , :n_chp_rev_travail_basedd),
      affecte( champ( `chp_fournisseur_basedd` ) , :n_chp_fournisseur_basedd)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_basedd` ) , :c_chi_id_basedd ) , egal( champ( `chx_cible_id_basedd` ) , :c_chx_cible_id_basedd ))
   )
)','UPDATE b1.tbl_bdds SET `chx_dossier_id_basedd` = :n_chx_dossier_id_basedd , `chp_nom_basedd` = :n_chp_nom_basedd , `chp_rev_basedd` = :n_chp_rev_basedd , `chp_commentaire_basedd` = :n_chp_commentaire_basedd , `chp_genere_basedd` = :n_chp_genere_basedd , `chp_rev_travail_basedd` = :n_chp_rev_travail_basedd , `chp_fournisseur_basedd` = :n_chp_fournisseur_basedd
WHERE (`chi_id_basedd` = :c_chi_id_basedd
   AND `chx_cible_id_basedd` = :c_chx_cible_id_basedd) ;','function sql_16($par){
    $texte_sql_16=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_bdds` SET ''.PHP_EOL;

    if($par[''n_chx_dossier_id_basedd'']==='''' || $par[''n_chx_dossier_id_basedd'']===NULL ){
        $texte_sql_16.=''    `chx_dossier_id_basedd` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_16.=''    `chx_dossier_id_basedd` = ''.sq0($par[''n_chx_dossier_id_basedd'']).'' , ''.PHP_EOL;
    }
    if($par[''n_chp_nom_basedd'']==='''' || $par[''n_chp_nom_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_nom_basedd` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_16.=''    `chp_nom_basedd` = \''''.sq0($par[''n_chp_nom_basedd'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_rev_basedd'']==='''' || $par[''n_chp_rev_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_rev_basedd` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_16.=''    `chp_rev_basedd` = \''''.sq0($par[''n_chp_rev_basedd'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_commentaire_basedd'']==='''' || $par[''n_chp_commentaire_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_commentaire_basedd` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_16.=''    `chp_commentaire_basedd` = \''''.sq0($par[''n_chp_commentaire_basedd'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_genere_basedd'']==='''' || $par[''n_chp_genere_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_genere_basedd` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_16.=''    `chp_genere_basedd` = \''''.sq0($par[''n_chp_genere_basedd'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_rev_travail_basedd'']==='''' || $par[''n_chp_rev_travail_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_rev_travail_basedd` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_16.=''    `chp_rev_travail_basedd` = \''''.sq0($par[''n_chp_rev_travail_basedd'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_fournisseur_basedd'']==='''' || $par[''n_chp_fournisseur_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_fournisseur_basedd` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_16.=''    `chp_fournisseur_basedd` = \''''.sq0($par[''n_chp_fournisseur_basedd'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_basedd` = ''.sq1($par[''c_chi_id_basedd'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_id_basedd` = ''.sq1($par[''c_chx_cible_id_basedd'']).''''.PHP_EOL;
    $texte_sql_16.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_16 = <pre>'' . $texte_sql_16 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_16);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_16()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,50,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,50,""],[4,"valeurs","f",1,0,38,44,1,7,2,3,45,33,""],[5,"affecte","f",2,0,53,59,4,2,1,2,60,9,""],[6,"champ","f",3,0,62,66,5,1,1,1,67,8,""],[7,"chx_dossier_id_basedd","c",4,2,70,90,6,0,1,0,67,50,""],[8,":n_chx_dossier_id_basedd","c",3,0,97,120,5,0,2,0,67,50,""],[9,"affecte","f",2,0,130,136,4,2,2,2,137,13,""],[10,"champ","f",3,0,139,143,9,1,1,1,144,12,""],[11,"chp_nom_basedd","c",4,2,147,160,10,0,1,0,144,50,""],[12,":n_chp_nom_basedd","c",3,0,167,183,9,0,2,0,144,50,""],[13,"affecte","f",2,0,193,199,4,2,3,2,200,17,""],[14,"champ","f",3,0,202,206,13,1,1,1,207,16,""],[15,"chp_rev_basedd","c",4,2,210,223,14,0,1,0,207,50,""],[16,":n_chp_rev_basedd","c",3,0,230,246,13,0,2,0,207,50,""],[17,"affecte","f",2,0,256,262,4,2,4,2,263,21,""],[18,"champ","f",3,0,265,269,17,1,1,1,270,20,""],[19,"chp_commentaire_basedd","c",4,2,273,294,18,0,1,0,270,50,""],[20,":n_chp_commentaire_basedd","c",3,0,301,325,17,0,2,0,270,50,""],[21,"affecte","f",2,0,335,341,4,2,5,2,342,25,""],[22,"champ","f",3,0,344,348,21,1,1,1,349,24,""],[23,"chp_genere_basedd","c",4,2,352,368,22,0,1,0,349,50,""],[24,":n_chp_genere_basedd","c",3,0,375,394,21,0,2,0,349,50,""],[25,"affecte","f",2,0,404,410,4,2,6,2,411,29,""],[26,"champ","f",3,0,413,417,25,1,1,1,418,28,""],[27,"chp_rev_travail_basedd","c",4,2,421,442,26,0,1,0,418,50,""],[28,":n_chp_rev_travail_basedd","c",3,0,449,473,25,0,2,0,418,50,""],[29,"affecte","f",2,0,483,489,4,2,7,2,490,50,""],[30,"champ","f",3,0,492,496,29,1,1,1,497,32,""],[31,"chp_fournisseur_basedd","c",4,2,500,521,30,0,1,0,497,50,""],[32,":n_chp_fournisseur_basedd","c",3,0,528,552,29,0,2,0,497,50,""],[33,"provenance","f",1,0,564,573,1,1,3,5,574,40,""],[34,"table_reference","f",2,0,582,596,33,1,1,4,597,50,""],[35,"source","f",3,0,608,613,34,1,1,3,614,50,""],[36,"nom_de_la_table","f",4,0,616,630,35,2,1,2,631,50,""],[37,"tbl_bdds","c",5,0,633,640,36,0,1,0,0,38,""],[38,"base","f",5,0,644,647,36,1,2,1,648,50,""],[39,"b1","c",6,0,649,650,38,0,1,0,648,50,""],[40,"conditions","f",1,0,673,682,1,1,4,4,683,50,""],[41,"et","f",2,0,691,692,40,2,1,3,693,50,""],[42,"egal","f",3,0,695,698,41,2,1,2,699,46,""],[43,"champ","f",4,0,701,705,42,1,1,1,706,45,""],[44,"chi_id_basedd","c",5,2,709,721,43,0,1,0,706,50,""],[45,":c_chi_id_basedd","c",4,0,728,743,42,0,2,0,0,50,""],[46,"egal","f",3,0,749,752,41,2,2,2,753,50,""],[47,"champ","f",4,0,755,759,46,1,1,1,760,49,""],[48,"chx_cible_id_basedd","c",5,2,763,781,47,0,1,0,760,50,""],[49,":c_chx_cible_id_basedd","c",4,0,788,809,46,0,2,0,0,50,""]]'),
('17','1','insert','insérer(
   base_de_reference(1),
   valeurs(
      affecte( champ( `chx_dossier_id_basedd` ) , :chx_dossier_id_basedd),
      affecte( champ( `chx_cible_id_basedd` ) , :chx_cible_id_basedd),
      affecte( champ( `chp_nom_basedd` ) , :chp_nom_basedd),
      affecte( champ( `chp_commentaire_basedd` ) , :chp_commentaire_basedd),
      affecte( champ( `chp_fournisseur_basedd` ) , :chp_fournisseur_basedd)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , base(b1) ))
      )
   )
)','INSERT INTO b1.`tbl_bdds`(
    `chx_dossier_id_basedd` , 
    `chx_cible_id_basedd` , 
    `chp_nom_basedd` , 
    `chp_commentaire_basedd` , 
    `chp_fournisseur_basedd`
) VALUES (
    :chx_dossier_id_basedd , 
    :chx_cible_id_basedd , 
    :chp_nom_basedd , 
    :chp_commentaire_basedd , 
    :chp_fournisseur_basedd
);','function sql_17($par){
    $texte_sql_17=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_bdds`(
         `chx_dossier_id_basedd` , 
         `chx_cible_id_basedd` , 
         `chp_nom_basedd` , 
         `chp_commentaire_basedd` , 
         `chp_fournisseur_basedd`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_dossier_id_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_id_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_fournisseur_basedd'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_17.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_17 = <pre>'' . $texte_sql_17 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_17);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_17()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,32,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,32,""],[4,"valeurs","f",1,0,37,43,1,5,2,3,44,25,""],[5,"affecte","f",2,0,52,58,4,2,1,2,59,9,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,8,""],[7,"chx_dossier_id_basedd","c",4,2,69,89,6,0,1,0,66,32,""],[8,":chx_dossier_id_basedd","c",3,0,96,117,5,0,2,0,66,32,""],[9,"affecte","f",2,0,127,133,4,2,2,2,134,13,""],[10,"champ","f",3,0,136,140,9,1,1,1,141,12,""],[11,"chx_cible_id_basedd","c",4,2,144,162,10,0,1,0,141,32,""],[12,":chx_cible_id_basedd","c",3,0,169,188,9,0,2,0,141,32,""],[13,"affecte","f",2,0,198,204,4,2,3,2,205,17,""],[14,"champ","f",3,0,207,211,13,1,1,1,212,16,""],[15,"chp_nom_basedd","c",4,2,215,228,14,0,1,0,212,32,""],[16,":chp_nom_basedd","c",3,0,235,249,13,0,2,0,212,32,""],[17,"affecte","f",2,0,259,265,4,2,4,2,266,21,""],[18,"champ","f",3,0,268,272,17,1,1,1,273,20,""],[19,"chp_commentaire_basedd","c",4,2,276,297,18,0,1,0,273,32,""],[20,":chp_commentaire_basedd","c",3,0,304,326,17,0,2,0,273,32,""],[21,"affecte","f",2,0,336,342,4,2,5,2,343,32,""],[22,"champ","f",3,0,345,349,21,1,1,1,350,24,""],[23,"chp_fournisseur_basedd","c",4,2,353,374,22,0,1,0,350,32,""],[24,":chp_fournisseur_basedd","c",3,0,381,403,21,0,2,0,350,32,""],[25,"provenance","f",1,0,415,424,1,1,3,5,425,32,""],[26,"table_reference","f",2,0,433,447,25,1,1,4,448,32,""],[27,"source","f",3,0,459,464,26,1,1,3,465,32,""],[28,"nom_de_la_table","f",4,0,467,481,27,2,1,2,482,32,""],[29,"tbl_bdds","c",5,0,484,491,28,0,1,0,0,30,""],[30,"base","f",5,0,495,498,28,1,2,1,499,32,""],[31,"b1","c",6,0,500,501,30,0,1,0,499,32,""]]'),
('18','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_basedd` ) , :chi_id_basedd ) , egal( champ( `chx_cible_id_basedd` ) , :chx_cible_id_basedd ))
   )
)','DELETE FROM b1.tbl_bdds
WHERE (`chi_id_basedd` = :chi_id_basedd
   AND `chx_cible_id_basedd` = :chx_cible_id_basedd) ;','function sql_18($par){
    $texte_sql_18=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds
          WHERE (`chi_id_basedd` = ''.sq1($par[''chi_id_basedd'']).'' AND `chx_cible_id_basedd` = ''.sq1($par[''chx_cible_id_basedd'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_18 = <pre>'' . $texte_sql_18 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_18);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_18()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','bdds par id et cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,21,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,21,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,21,""],[6,"source","f",3,0,83,88,5,1,1,3,89,21,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,21,""],[8,"tbl_bdds","c",5,0,108,115,7,0,1,0,0,9,""],[9,"base","f",5,0,119,122,7,1,2,1,123,21,""],[10,"b1","c",6,0,124,125,9,0,1,0,123,21,""],[11,"conditions","f",1,0,148,157,1,1,3,4,158,21,""],[12,"et","f",2,0,166,167,11,2,1,3,168,21,""],[13,"egal","f",3,0,170,173,12,2,1,2,174,17,""],[14,"champ","f",4,0,176,180,13,1,1,1,181,16,""],[15,"chi_id_basedd","c",5,2,184,196,14,0,1,0,181,21,""],[16,":chi_id_basedd","c",4,0,203,216,13,0,2,0,0,21,""],[17,"egal","f",3,0,222,225,12,2,2,2,226,21,""],[18,"champ","f",4,0,228,232,17,1,1,1,233,20,""],[19,"chx_cible_id_basedd","c",5,2,236,254,18,0,1,0,233,21,""],[20,":chx_cible_id_basedd","c",4,0,261,280,17,0,2,0,0,21,""]]'),
('19','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_tache` ) , champ( `T0` , `chp_texte_tache` ) , champ( `T0` , `chp_priorite_tache` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et(
         #(),
         egal( champ( `T0` , `chx_utilisateur_tache` ) , :T0_chx_utilisateur_tache),
         egal( champ( `T0` , `chi_id_tache` ) , :T0_chi_id_tache),
         comme( champ( `T0` , `chp_texte_tache` ) , :T0_chp_texte_tache),
         egal( champ( `T0` , `chp_priorite_tache` ) , :T0_chp_priorite_tache),
         inf( champ( `T0` , `chp_priorite_tache` ) , :T0_chp_priorite_tache2)
      )
   ),
   complements(
      trier_par( ( champ( `T0` , `chp_priorite_tache` ) , croissant() )),
      limité_à( quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
 FROM b1.tbl_taches T0
WHERE ( /* */ `T0`.`chx_utilisateur_tache` = :T0_chx_utilisateur_tache
   AND `T0`.`chi_id_tache` = :T0_chi_id_tache
   AND `T0`.`chp_texte_tache` LIKE :T0_chp_texte_tache
   AND `T0`.`chp_priorite_tache` = :T0_chp_priorite_tache
   AND `T0`.`chp_priorite_tache` < :T0_chp_priorite_tache2) 
ORDER BY `T0`.`chp_priorite_tache` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_19($par){
    $champs0=''
      `T0`.`chi_id_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    if(($par[''T0_chx_utilisateur_tache''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_utilisateur_tache`'',$par[''T0_chx_utilisateur_tache'']);
    }
    if(($par[''T0_chi_id_tache''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_tache`'',$par[''T0_chi_id_tache'']);
    }
    if(($par[''T0_chp_texte_tache''] !== '''')){
        $where0.='' AND `T0`.`chp_texte_tache` LIKE ''.sq1($par[''T0_chp_texte_tache'']).''''.PHP_EOL;
    }
    if(($par[''T0_chp_priorite_tache''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chp_priorite_tache`'',$par[''T0_chp_priorite_tache'']);
    }
    if(($par[''T0_chp_priorite_tache2''] !== '''')){
        $where0.='' AND `T0`.`chp_priorite_tache` < ''.sq1($par[''T0_chp_priorite_tache2'']).''''.PHP_EOL;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_priorite_tache` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_tache'' => $tab0[0],
                ''T0.chp_texte_tache'' => $tab0[1],
                ''T0.chp_priorite_tache'' => $tab0[2],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => __xsu       ,
           __xva  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => __xer ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','tâches','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,63,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,63,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,14,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_tache","c",3,2,66,77,5,0,2,0,56,63,""],[8,"champ","f",2,0,84,88,4,2,2,1,89,11,""],[9,"T0","c",3,2,92,93,8,0,1,0,89,10,""],[10,"chp_texte_tache","c",3,2,99,113,8,0,2,0,89,63,""],[11,"champ","f",2,0,120,124,4,2,3,1,125,63,""],[12,"T0","c",3,2,128,129,11,0,1,0,125,13,""],[13,"chp_priorite_tache","c",3,2,135,152,11,0,2,0,125,63,""],[14,"provenance","f",1,0,162,171,1,1,3,5,172,23,""],[15,"table_reference","f",2,0,180,194,14,1,1,4,195,63,""],[16,"source","f",3,0,206,211,15,1,1,3,212,63,""],[17,"nom_de_la_table","f",4,0,214,228,16,3,1,2,229,63,""],[18,"tbl_taches","c",5,0,231,240,17,0,1,0,0,19,""],[19,"alias","f",5,0,244,248,17,1,2,1,249,21,""],[20,"T0","c",6,0,250,251,19,0,1,0,249,63,""],[21,"base","f",5,0,256,259,17,1,3,1,260,63,""],[22,"b1","c",6,0,261,262,21,0,1,0,260,63,""],[23,"conditions","f",1,0,285,294,1,1,4,4,295,51,""],[24,"et","f",2,0,303,304,23,6,1,3,305,63,""],[25,"#","f",3,0,316,316,24,0,1,0,317,26,""],[26,"egal","f",3,0,330,333,24,2,2,2,334,31,""],[27,"champ","f",4,0,336,340,26,2,1,1,341,30,""],[28,"T0","c",5,2,344,345,27,0,1,0,341,29,""],[29,"chx_utilisateur_tache","c",5,2,351,371,27,0,2,0,341,63,""],[30,":T0_chx_utilisateur_tache","c",4,0,378,402,26,0,2,0,341,63,""],[31,"egal","f",3,0,415,418,24,2,3,2,419,36,""],[32,"champ","f",4,0,421,425,31,2,1,1,426,35,""],[33,"T0","c",5,2,429,430,32,0,1,0,426,34,""],[34,"chi_id_tache","c",5,2,436,447,32,0,2,0,426,63,""],[35,":T0_chi_id_tache","c",4,0,454,469,31,0,2,0,426,63,""],[36,"comme","f",3,0,482,486,24,2,4,2,487,41,""],[37,"champ","f",4,0,489,493,36,2,1,1,494,40,""],[38,"T0","c",5,2,497,498,37,0,1,0,494,39,""],[39,"chp_texte_tache","c",5,2,504,518,37,0,2,0,494,63,""],[40,":T0_chp_texte_tache","c",4,0,525,543,36,0,2,0,494,63,""],[41,"egal","f",3,0,556,559,24,2,5,2,560,46,""],[42,"champ","f",4,0,562,566,41,2,1,1,567,45,""],[43,"T0","c",5,2,570,571,42,0,1,0,567,44,""],[44,"chp_priorite_tache","c",5,2,577,594,42,0,2,0,567,63,""],[45,":T0_chp_priorite_tache","c",4,0,601,622,41,0,2,0,567,63,""],[46,"inf","f",3,0,635,637,24,2,6,2,638,63,""],[47,"champ","f",4,0,640,644,46,2,1,1,645,50,""],[48,"T0","c",5,2,648,649,47,0,1,0,645,49,""],[49,"chp_priorite_tache","c",5,2,655,672,47,0,2,0,645,63,""],[50,":T0_chp_priorite_tache2","c",4,0,679,701,46,0,2,0,645,63,""],[51,"complements","f",1,0,721,731,1,2,5,4,732,63,""],[52,"trier_par","f",2,0,740,748,51,1,1,3,749,58,""],[53,"","f",3,0,740,748,52,2,1,2,751,63,""],[54,"champ","f",4,0,753,757,53,2,1,1,758,57,""],[55,"T0","c",5,2,761,762,54,0,1,0,758,56,""],[56,"chp_priorite_tache","c",5,2,768,785,54,0,2,0,758,63,""],[57,"croissant","f",4,0,792,800,53,0,2,0,801,63,""],[58,"limit\u00e9_\u00e0","f",2,0,814,821,51,2,2,2,822,63,""],[59,"quantit\u00e9","f",3,0,824,831,58,1,1,1,832,61,""],[60,":quantitee","c",4,0,833,842,59,0,1,0,832,63,""],[61,"d\u00e9but","f",3,0,847,851,58,1,2,1,852,63,""],[62,":debut","c",4,0,853,858,61,0,1,0,852,63,""]]'),
('20','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_priorite_tache` ) , moins( chp_priorite_tache , 1 ) )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_tache` ) , :c_chi_id_tache ) , egal( champ( `chx_utilisateur_tache` ) , :c_chx_utilisateur_tache ) , supegal( champ( `chp_priorite_tache` ) , 1 ))
   )
)','UPDATE b1.tbl_taches SET `chp_priorite_tache` = (chp_priorite_tache-1)
WHERE (`chi_id_tache` = :c_chi_id_tache
   AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache
   AND `chp_priorite_tache` >= 1) ;','function sql_20($par){
    $texte_sql_20=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    $texte_sql_20.=''    `chp_priorite_tache` = (chp_priorite_tache-1) ''.PHP_EOL;

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.PHP_EOL;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $where0.='' AND `chp_priorite_tache` >= 1''.PHP_EOL;
    $texte_sql_20.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_20 = <pre>'' . $texte_sql_20 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_20);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_20()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,32,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,11,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,32,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_priorite_tache","c",4,2,64,81,6,0,1,0,61,32,""],[8,"moins","f",3,0,88,92,5,2,2,1,93,32,""],[9,"chp_priorite_tache","c",4,0,95,112,8,0,1,0,0,10,""],[10,"1","c",4,0,116,116,8,0,2,0,0,32,""],[11,"provenance","f",1,0,127,136,1,1,3,5,137,18,""],[12,"table_reference","f",2,0,145,159,11,1,1,4,160,32,""],[13,"source","f",3,0,171,176,12,1,1,3,177,32,""],[14,"nom_de_la_table","f",4,0,179,193,13,2,1,2,194,32,""],[15,"tbl_taches","c",5,0,196,205,14,0,1,0,0,16,""],[16,"base","f",5,0,209,212,14,1,2,1,213,32,""],[17,"b1","c",6,0,214,215,16,0,1,0,213,32,""],[18,"conditions","f",1,0,238,247,1,1,4,4,248,32,""],[19,"et","f",2,0,256,257,18,3,1,3,258,32,""],[20,"egal","f",3,0,260,263,19,2,1,2,264,24,""],[21,"champ","f",4,0,266,270,20,1,1,1,271,23,""],[22,"chi_id_tache","c",5,2,274,285,21,0,1,0,271,32,""],[23,":c_chi_id_tache","c",4,0,292,306,20,0,2,0,0,32,""],[24,"egal","f",3,0,312,315,19,2,2,2,316,28,""],[25,"champ","f",4,0,318,322,24,1,1,1,323,27,""],[26,"chx_utilisateur_tache","c",5,2,326,346,25,0,1,0,323,32,""],[27,":c_chx_utilisateur_tache","c",4,0,353,376,24,0,2,0,0,32,""],[28,"supegal","f",3,0,382,388,19,2,3,2,389,32,""],[29,"champ","f",4,0,391,395,28,1,1,1,396,31,""],[30,"chp_priorite_tache","c",5,2,399,416,29,0,1,0,396,32,""],[31,"1","c",4,0,423,423,28,0,2,0,0,32,""]]'),
('21','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_priorite_tache` ) , plus( chp_priorite_tache , 1 ) )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_tache` ) , :c_chi_id_tache ) , egal( champ( `chx_utilisateur_tache` ) , :c_chx_utilisateur_tache ) , inf( champ( `chp_priorite_tache` ) , 50 ))
   )
)','UPDATE b1.tbl_taches SET `chp_priorite_tache` = (chp_priorite_tache+1)
WHERE (`chi_id_tache` = :c_chi_id_tache
   AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache
   AND `chp_priorite_tache` < 50) ;','function sql_21($par){
    $texte_sql_21=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    $texte_sql_21.=''    `chp_priorite_tache` = (chp_priorite_tache+1) ''.PHP_EOL;

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.PHP_EOL;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $where0.='' AND `chp_priorite_tache` < 50''.PHP_EOL;
    $texte_sql_21.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_21 = <pre>'' . $texte_sql_21 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_21);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_21()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,32,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,11,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,32,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_priorite_tache","c",4,2,64,81,6,0,1,0,61,32,""],[8,"plus","f",3,0,88,91,5,2,2,1,92,32,""],[9,"chp_priorite_tache","c",4,0,94,111,8,0,1,0,0,10,""],[10,"1","c",4,0,115,115,8,0,2,0,0,32,""],[11,"provenance","f",1,0,126,135,1,1,3,5,136,18,""],[12,"table_reference","f",2,0,144,158,11,1,1,4,159,32,""],[13,"source","f",3,0,170,175,12,1,1,3,176,32,""],[14,"nom_de_la_table","f",4,0,178,192,13,2,1,2,193,32,""],[15,"tbl_taches","c",5,0,195,204,14,0,1,0,0,16,""],[16,"base","f",5,0,208,211,14,1,2,1,212,32,""],[17,"b1","c",6,0,213,214,16,0,1,0,212,32,""],[18,"conditions","f",1,0,237,246,1,1,4,4,247,32,""],[19,"et","f",2,0,255,256,18,3,1,3,257,32,""],[20,"egal","f",3,0,259,262,19,2,1,2,263,24,""],[21,"champ","f",4,0,265,269,20,1,1,1,270,23,""],[22,"chi_id_tache","c",5,2,273,284,21,0,1,0,270,32,""],[23,":c_chi_id_tache","c",4,0,291,305,20,0,2,0,0,32,""],[24,"egal","f",3,0,311,314,19,2,2,2,315,28,""],[25,"champ","f",4,0,317,321,24,1,1,1,322,27,""],[26,"chx_utilisateur_tache","c",5,2,325,345,25,0,1,0,322,32,""],[27,":c_chx_utilisateur_tache","c",4,0,352,375,24,0,2,0,0,32,""],[28,"inf","f",3,0,381,383,19,2,3,2,384,32,""],[29,"champ","f",4,0,386,390,28,1,1,1,391,31,""],[30,"chp_priorite_tache","c",5,2,394,411,29,0,1,0,391,32,""],[31,"50","c",4,0,418,419,28,0,2,0,0,32,""]]'),
('22','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_priorite_tache` ) , :n_chp_priorite_tache )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_tache` ) , :c_chi_id_tache ) , egal( champ( `chx_utilisateur_tache` ) , :c_chx_utilisateur_tache ))
   )
)','UPDATE b1.tbl_taches SET `chp_priorite_tache` = :n_chp_priorite_tache
WHERE (`chi_id_tache` = :c_chi_id_tache
   AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache) ;','function sql_22($par){
    $texte_sql_22=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_22.=''    `chp_priorite_tache` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_22.=''    `chp_priorite_tache` = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.PHP_EOL;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $texte_sql_22.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_22 = <pre>'' . $texte_sql_22 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_22);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_22()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,26,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,26,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,26,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_priorite_tache","c",4,2,64,81,6,0,1,0,61,26,""],[8,":n_chp_priorite_tache","c",3,0,88,108,5,0,2,0,0,26,""],[9,"provenance","f",1,0,117,126,1,1,3,5,127,16,""],[10,"table_reference","f",2,0,135,149,9,1,1,4,150,26,""],[11,"source","f",3,0,161,166,10,1,1,3,167,26,""],[12,"nom_de_la_table","f",4,0,169,183,11,2,1,2,184,26,""],[13,"tbl_taches","c",5,0,186,195,12,0,1,0,0,14,""],[14,"base","f",5,0,199,202,12,1,2,1,203,26,""],[15,"b1","c",6,0,204,205,14,0,1,0,203,26,""],[16,"conditions","f",1,0,228,237,1,1,4,4,238,26,""],[17,"et","f",2,0,246,247,16,2,1,3,248,26,""],[18,"egal","f",3,0,250,253,17,2,1,2,254,22,""],[19,"champ","f",4,0,256,260,18,1,1,1,261,21,""],[20,"chi_id_tache","c",5,2,264,275,19,0,1,0,261,26,""],[21,":c_chi_id_tache","c",4,0,282,296,18,0,2,0,0,26,""],[22,"egal","f",3,0,302,305,17,2,2,2,306,26,""],[23,"champ","f",4,0,308,312,22,1,1,1,313,25,""],[24,"chx_utilisateur_tache","c",5,2,316,336,23,0,1,0,313,26,""],[25,":c_chx_utilisateur_tache","c",4,0,343,366,22,0,2,0,0,26,""]]'),
('23','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_priorite_tache` ) , :n_chp_priorite_tache )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et(
         ou( est( champ(chp_priorite_tache) , NULL ) , egal( champ(chp_priorite_tache) , '''' )),
         egal( champ(chx_utilisateur_tache) , :c_chx_utilisateur_tache)
      )
   )
)','UPDATE b1.tbl_taches SET `chp_priorite_tache` = :n_chp_priorite_tache
WHERE ((chp_priorite_tache IS NULL OR chp_priorite_tache = '''')
   AND chx_utilisateur_tache = :c_chx_utilisateur_tache) ;','function sql_23($par){
    $texte_sql_23=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_23.=''    `chp_priorite_tache` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_23.=''    `chp_priorite_tache` = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND (chp_priorite_tache IS NULL OR chp_priorite_tache = \''\'')''.PHP_EOL;
    $where0.='' AND chx_utilisateur_tache = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $texte_sql_23.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_23 = <pre>'' . $texte_sql_23 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_23);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_23()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,31,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,31,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,31,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_priorite_tache","c",4,2,64,81,6,0,1,0,61,31,""],[8,":n_chp_priorite_tache","c",3,0,88,108,5,0,2,0,0,31,""],[9,"provenance","f",1,0,117,126,1,1,3,5,127,16,""],[10,"table_reference","f",2,0,135,149,9,1,1,4,150,31,""],[11,"source","f",3,0,161,166,10,1,1,3,167,31,""],[12,"nom_de_la_table","f",4,0,169,183,11,2,1,2,184,31,""],[13,"tbl_taches","c",5,0,186,195,12,0,1,0,0,14,""],[14,"base","f",5,0,199,202,12,1,2,1,203,31,""],[15,"b1","c",6,0,204,205,14,0,1,0,203,31,""],[16,"conditions","f",1,0,228,237,1,1,4,5,238,31,""],[17,"et","f",2,0,246,247,16,2,1,4,248,31,""],[18,"ou","f",3,0,259,260,17,2,1,3,261,27,""],[19,"est","f",4,0,263,265,18,2,1,2,266,23,""],[20,"champ","f",5,0,268,272,19,1,1,1,273,22,""],[21,"chp_priorite_tache","c",6,0,274,291,20,0,1,0,273,31,""],[22,"NULL","c",5,0,296,299,19,0,2,0,0,31,""],[23,"egal","f",4,0,305,308,18,2,2,2,309,31,""],[24,"champ","f",5,0,311,315,23,1,1,1,316,26,""],[25,"chp_priorite_tache","c",6,0,317,334,24,0,1,0,316,31,""],[26,"","c",5,1,339,339,23,0,2,0,316,31,""],[27,"egal","f",3,0,355,358,17,2,2,2,359,31,""],[28,"champ","f",4,0,361,365,27,1,1,1,366,30,""],[29,"chx_utilisateur_tache","c",5,0,367,387,28,0,1,0,366,31,""],[30,":c_chx_utilisateur_tache","c",4,0,392,415,27,0,2,0,366,31,""]]'),
('24','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_priorite_tache` ) , plus( chp_priorite_tache , 1 ) )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chx_utilisateur_tache` ) , :c_chx_utilisateur_tache ) , inf( champ( `chp_priorite_tache` ) , 50 ))
   )
)','UPDATE b1.tbl_taches SET `chp_priorite_tache` = (chp_priorite_tache+1)
WHERE (`chx_utilisateur_tache` = :c_chx_utilisateur_tache
   AND `chp_priorite_tache` < 50) ;','function sql_24($par){
    $texte_sql_24=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    $texte_sql_24.=''    `chp_priorite_tache` = (chp_priorite_tache+1) ''.PHP_EOL;

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $where0.='' AND `chp_priorite_tache` < 50''.PHP_EOL;
    $texte_sql_24.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_24 = <pre>'' . $texte_sql_24 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_24);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_24()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,28,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,28,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,11,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,28,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_priorite_tache","c",4,2,64,81,6,0,1,0,61,28,""],[8,"plus","f",3,0,88,91,5,2,2,1,92,28,""],[9,"chp_priorite_tache","c",4,0,94,111,8,0,1,0,0,10,""],[10,"1","c",4,0,115,115,8,0,2,0,0,28,""],[11,"provenance","f",1,0,126,135,1,1,3,5,136,18,""],[12,"table_reference","f",2,0,144,158,11,1,1,4,159,28,""],[13,"source","f",3,0,170,175,12,1,1,3,176,28,""],[14,"nom_de_la_table","f",4,0,178,192,13,2,1,2,193,28,""],[15,"tbl_taches","c",5,0,195,204,14,0,1,0,0,16,""],[16,"base","f",5,0,208,211,14,1,2,1,212,28,""],[17,"b1","c",6,0,213,214,16,0,1,0,212,28,""],[18,"conditions","f",1,0,237,246,1,1,4,4,247,28,""],[19,"et","f",2,0,255,256,18,2,1,3,257,28,""],[20,"egal","f",3,0,259,262,19,2,1,2,263,24,""],[21,"champ","f",4,0,265,269,20,1,1,1,270,23,""],[22,"chx_utilisateur_tache","c",5,2,273,293,21,0,1,0,270,28,""],[23,":c_chx_utilisateur_tache","c",4,0,300,323,20,0,2,0,0,28,""],[24,"inf","f",3,0,329,331,19,2,2,2,332,28,""],[25,"champ","f",4,0,334,338,24,1,1,1,339,27,""],[26,"chp_priorite_tache","c",5,2,342,359,25,0,1,0,339,28,""],[27,"50","c",4,0,366,367,24,0,2,0,0,28,""]]'),
('25','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_priorite_tache` ) , moins( chp_priorite_tache , 1 ) )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et(

         egal( champ( `chx_utilisateur_tache` ) , :c_chx_utilisateur_tache),
         inf( champ( `chp_priorite_tache` ) , 50),
         sup( champ( `chp_priorite_tache` ) , 0)
      )
   )
)','UPDATE b1.tbl_taches SET `chp_priorite_tache` = (chp_priorite_tache-1)
WHERE (`chx_utilisateur_tache` = :c_chx_utilisateur_tache
   AND `chp_priorite_tache` < 50
   AND `chp_priorite_tache` > 0) ;','function sql_25($par){
    $texte_sql_25=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    $texte_sql_25.=''    `chp_priorite_tache` = (chp_priorite_tache-1) ''.PHP_EOL;

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $where0.='' AND `chp_priorite_tache` < 50''.PHP_EOL;
    $where0.='' AND `chp_priorite_tache` > 0''.PHP_EOL;
    $texte_sql_25.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_25 = <pre>'' . $texte_sql_25 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_25);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_25()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,32,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,11,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,32,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_priorite_tache","c",4,2,64,81,6,0,1,0,61,32,""],[8,"moins","f",3,0,88,92,5,2,2,1,93,32,""],[9,"chp_priorite_tache","c",4,0,95,112,8,0,1,0,0,10,""],[10,"1","c",4,0,116,116,8,0,2,0,0,32,""],[11,"provenance","f",1,0,127,136,1,1,3,5,137,18,""],[12,"table_reference","f",2,0,145,159,11,1,1,4,160,32,""],[13,"source","f",3,0,171,176,12,1,1,3,177,32,""],[14,"nom_de_la_table","f",4,0,179,193,13,2,1,2,194,32,""],[15,"tbl_taches","c",5,0,196,205,14,0,1,0,0,16,""],[16,"base","f",5,0,209,212,14,1,2,1,213,32,""],[17,"b1","c",6,0,214,215,16,0,1,0,213,32,""],[18,"conditions","f",1,0,238,247,1,1,4,4,248,32,""],[19,"et","f",2,0,256,257,18,3,1,3,258,32,""],[20,"egal","f",3,0,270,273,19,2,1,2,274,24,""],[21,"champ","f",4,0,276,280,20,1,1,1,281,23,""],[22,"chx_utilisateur_tache","c",5,2,284,304,21,0,1,0,281,32,""],[23,":c_chx_utilisateur_tache","c",4,0,311,334,20,0,2,0,281,32,""],[24,"inf","f",3,0,347,349,19,2,2,2,350,28,""],[25,"champ","f",4,0,352,356,24,1,1,1,357,27,""],[26,"chp_priorite_tache","c",5,2,360,377,25,0,1,0,357,32,""],[27,"50","c",4,0,384,385,24,0,2,0,357,32,""],[28,"sup","f",3,0,398,400,19,2,3,2,401,32,""],[29,"champ","f",4,0,403,407,28,1,1,1,408,31,""],[30,"chp_priorite_tache","c",5,2,411,428,29,0,1,0,408,32,""],[31,"0","c",4,0,435,435,28,0,2,0,408,32,""]]'),
('26','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_basedd`),
      champ( `T0` , `chx_dossier_id_basedd`),
      champ( `T0` , `chx_cible_id_basedd`),
      champ( `T0` , `chp_nom_basedd`),
      champ( `T0` , `chp_rev_basedd`),
      champ( `T0` , `chp_commentaire_basedd`),
      champ( `T0` , `chp_genere_basedd`),
      champ( `T0` , `chp_rev_travail_basedd`),
      champ( `T0` , `chp_fournisseur_basedd`),
      champ( `T1` , `chi_id_dossier`),
      champ( `T1` , `chx_cible_dossier`),
      champ( `T1` , `chp_nom_dossier`),
      champ( `T2` , `chi_id_cible`),
      champ( `T2` , `chp_nom_cible`),
      champ( `T2` , `chp_dossier_cible`),
      champ( `T2` , `chp_commentaire_cible`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , alias(T0) , base(b1) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_dossiers , alias(T1) , base(b1) )),
         contrainte( egal( champ( T1 , chi_id_dossier ) , champ( T0 , chx_dossier_id_basedd ) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_cibles , alias(T2) , base(b1) )),
         contrainte( egal( champ( T2 , chi_id_cible ) , champ( T0 , chx_cible_id_basedd ) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_basedd` ) , :T0_chi_id_basedd ) , egal( champ( `T0` , `chx_cible_id_basedd` ) , :T0_chx_cible_id_basedd ))
   )
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
`T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
`T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
`T2`.`chp_commentaire_cible`
 FROM b1.tbl_bdds T0
 LEFT JOIN b1.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

 LEFT JOIN b1.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd

WHERE (`T0`.`chi_id_basedd` = :T0_chi_id_basedd
   AND `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd);','function sql_26($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
      `T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
      `T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
      `T2`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chi_id_basedd`'',$par[''T0_chi_id_basedd'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chx_dossier_id_basedd'' => $tab0[1],
                ''T0.chx_cible_id_basedd'' => $tab0[2],
                ''T0.chp_nom_basedd'' => $tab0[3],
                ''T0.chp_rev_basedd'' => $tab0[4],
                ''T0.chp_commentaire_basedd'' => $tab0[5],
                ''T0.chp_genere_basedd'' => $tab0[6],
                ''T0.chp_rev_travail_basedd'' => $tab0[7],
                ''T0.chp_fournisseur_basedd'' => $tab0[8],
                ''T1.chi_id_dossier'' => $tab0[9],
                ''T1.chx_cible_dossier'' => $tab0[10],
                ''T1.chp_nom_dossier'' => $tab0[11],
                ''T2.chi_id_cible'' => $tab0[12],
                ''T2.chp_nom_cible'' => $tab0[13],
                ''T2.chp_dossier_cible'' => $tab0[14],
                ''T2.chp_commentaire_cible'' => $tab0[15],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','bases par id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,106,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,106,""],[4,"valeurs","f",1,0,42,48,1,16,2,2,49,53,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_basedd","c",3,2,72,84,5,0,2,0,62,106,""],[8,"champ","f",2,0,95,99,4,2,2,1,100,11,""],[9,"T0","c",3,2,103,104,8,0,1,0,100,10,""],[10,"chx_dossier_id_basedd","c",3,2,110,130,8,0,2,0,100,106,""],[11,"champ","f",2,0,141,145,4,2,3,1,146,14,""],[12,"T0","c",3,2,149,150,11,0,1,0,146,13,""],[13,"chx_cible_id_basedd","c",3,2,156,174,11,0,2,0,146,106,""],[14,"champ","f",2,0,185,189,4,2,4,1,190,17,""],[15,"T0","c",3,2,193,194,14,0,1,0,190,16,""],[16,"chp_nom_basedd","c",3,2,200,213,14,0,2,0,190,106,""],[17,"champ","f",2,0,224,228,4,2,5,1,229,20,""],[18,"T0","c",3,2,232,233,17,0,1,0,229,19,""],[19,"chp_rev_basedd","c",3,2,239,252,17,0,2,0,229,106,""],[20,"champ","f",2,0,263,267,4,2,6,1,268,23,""],[21,"T0","c",3,2,271,272,20,0,1,0,268,22,""],[22,"chp_commentaire_basedd","c",3,2,278,299,20,0,2,0,268,106,""],[23,"champ","f",2,0,310,314,4,2,7,1,315,26,""],[24,"T0","c",3,2,318,319,23,0,1,0,315,25,""],[25,"chp_genere_basedd","c",3,2,325,341,23,0,2,0,315,106,""],[26,"champ","f",2,0,352,356,4,2,8,1,357,29,""],[27,"T0","c",3,2,360,361,26,0,1,0,357,28,""],[28,"chp_rev_travail_basedd","c",3,2,367,388,26,0,2,0,357,106,""],[29,"champ","f",2,0,399,403,4,2,9,1,404,32,""],[30,"T0","c",3,2,407,408,29,0,1,0,404,31,""],[31,"chp_fournisseur_basedd","c",3,2,414,435,29,0,2,0,404,106,""],[32,"champ","f",2,0,446,450,4,2,10,1,451,35,""],[33,"T1","c",3,2,454,455,32,0,1,0,451,34,""],[34,"chi_id_dossier","c",3,2,461,474,32,0,2,0,451,106,""],[35,"champ","f",2,0,485,489,4,2,11,1,490,38,""],[36,"T1","c",3,2,493,494,35,0,1,0,490,37,""],[37,"chx_cible_dossier","c",3,2,500,516,35,0,2,0,490,106,""],[38,"champ","f",2,0,527,531,4,2,12,1,532,41,""],[39,"T1","c",3,2,535,536,38,0,1,0,532,40,""],[40,"chp_nom_dossier","c",3,2,542,556,38,0,2,0,532,106,""],[41,"champ","f",2,0,567,571,4,2,13,1,572,44,""],[42,"T2","c",3,2,575,576,41,0,1,0,572,43,""],[43,"chi_id_cible","c",3,2,582,593,41,0,2,0,572,106,""],[44,"champ","f",2,0,604,608,4,2,14,1,609,47,""],[45,"T2","c",3,2,612,613,44,0,1,0,609,46,""],[46,"chp_nom_cible","c",3,2,619,631,44,0,2,0,609,106,""],[47,"champ","f",2,0,642,646,4,2,15,1,647,50,""],[48,"T2","c",3,2,650,651,47,0,1,0,647,49,""],[49,"chp_dossier_cible","c",3,2,657,673,47,0,2,0,647,106,""],[50,"champ","f",2,0,684,688,4,2,16,1,689,106,""],[51,"T2","c",3,2,692,693,50,0,1,0,689,52,""],[52,"chp_commentaire_cible","c",3,2,699,719,50,0,2,0,689,106,""],[53,"provenance","f",1,0,732,741,1,3,3,5,742,94,""],[54,"table_reference","f",2,0,750,764,53,1,1,4,765,62,""],[55,"source","f",3,0,776,781,54,1,1,3,782,106,""],[56,"nom_de_la_table","f",4,0,784,798,55,3,1,2,799,106,""],[57,"tbl_bdds","c",5,0,801,808,56,0,1,0,0,58,""],[58,"alias","f",5,0,812,816,56,1,2,1,817,60,""],[59,"T0","c",6,0,818,819,58,0,1,0,817,106,""],[60,"base","f",5,0,824,827,56,1,3,1,828,106,""],[61,"b1","c",6,0,829,830,60,0,1,0,828,106,""],[62,"jointure_gauche","f",2,0,851,865,53,2,2,4,866,78,""],[63,"source","f",3,0,877,882,62,1,1,3,883,70,""],[64,"nom_de_la_table","f",4,0,885,899,63,3,1,2,900,106,""],[65,"tbl_dossiers","c",5,0,902,913,64,0,1,0,0,66,""],[66,"alias","f",5,0,917,921,64,1,2,1,922,68,""],[67,"T1","c",6,0,923,924,66,0,1,0,922,106,""],[68,"base","f",5,0,929,932,64,1,3,1,933,106,""],[69,"b1","c",6,0,934,935,68,0,1,0,933,106,""],[70,"contrainte","f",3,0,951,960,62,1,2,3,961,106,""],[71,"egal","f",4,0,963,966,70,2,1,2,967,106,""],[72,"champ","f",5,0,969,973,71,2,1,1,974,75,""],[73,"T1","c",6,0,976,977,72,0,1,0,0,74,""],[74,"chi_id_dossier","c",6,0,981,994,72,0,2,0,0,106,""],[75,"champ","f",5,0,1000,1004,71,2,2,1,1005,106,""],[76,"T0","c",6,0,1007,1008,75,0,1,0,0,77,""],[77,"chx_dossier_id_basedd","c",6,0,1012,1032,75,0,2,0,0,106,""],[78,"jointure_gauche","f",2,0,1054,1068,53,2,3,4,1069,106,""],[79,"source","f",3,0,1080,1085,78,1,1,3,1086,86,""],[80,"nom_de_la_table","f",4,0,1088,1102,79,3,1,2,1103,106,""],[81,"tbl_cibles","c",5,0,1105,1114,80,0,1,0,0,82,""],[82,"alias","f",5,0,1118,1122,80,1,2,1,1123,84,""],[83,"T2","c",6,0,1124,1125,82,0,1,0,1123,106,""],[84,"base","f",5,0,1130,1133,80,1,3,1,1134,106,""],[85,"b1","c",6,0,1135,1136,84,0,1,0,1134,106,""],[86,"contrainte","f",3,0,1152,1161,78,1,2,3,1162,106,""],[87,"egal","f",4,0,1164,1167,86,2,1,2,1168,106,""],[88,"champ","f",5,0,1170,1174,87,2,1,1,1175,91,""],[89,"T2","c",6,0,1177,1178,88,0,1,0,0,90,""],[90,"chi_id_cible","c",6,0,1182,1193,88,0,2,0,0,106,""],[91,"champ","f",5,0,1199,1203,87,2,2,1,1204,106,""],[92,"T0","c",6,0,1206,1207,91,0,1,0,0,93,""],[93,"chx_cible_id_basedd","c",6,0,1211,1229,91,0,2,0,0,106,""],[94,"conditions","f",1,0,1253,1262,1,1,4,4,1263,106,""],[95,"et","f",2,0,1271,1272,94,2,1,3,1273,106,""],[96,"egal","f",3,0,1275,1278,95,2,1,2,1279,101,""],[97,"champ","f",4,0,1281,1285,96,2,1,1,1286,100,""],[98,"T0","c",5,2,1289,1290,97,0,1,0,1286,99,""],[99,"chi_id_basedd","c",5,2,1296,1308,97,0,2,0,1286,106,""],[100,":T0_chi_id_basedd","c",4,0,1315,1331,96,0,2,0,0,106,""],[101,"egal","f",3,0,1337,1340,95,2,2,2,1341,106,""],[102,"champ","f",4,0,1343,1347,101,2,1,1,1348,105,""],[103,"T0","c",5,2,1351,1352,102,0,1,0,1348,104,""],[104,"chx_cible_id_basedd","c",5,2,1358,1376,102,0,2,0,1348,106,""],[105,":T0_chx_cible_id_basedd","c",4,0,1383,1405,101,0,2,0,0,106,""]]'),
('27','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_basedd`),
      champ( `T0` , `chx_dossier_id_basedd`),
      champ( `T0` , `chx_cible_id_basedd`),
      champ( `T0` , `chp_nom_basedd`),
      champ( `T0` , `chp_rev_basedd`),
      champ( `T0` , `chp_commentaire_basedd`),
      champ( `T0` , `chp_genere_basedd`),
      champ( `T0` , `chp_rev_travail_basedd`),
      champ( `T0` , `chp_fournisseur_basedd`),
      champ( `T1` , `chi_id_dossier`),
      champ( `T1` , `chx_cible_dossier`),
      champ( `T1` , `chp_nom_dossier`),
      champ( `T2` , `chi_id_cible`),
      champ( `T2` , `chp_nom_cible`),
      champ( `T2` , `chp_dossier_cible`),
      champ( `T2` , `chp_commentaire_cible`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , alias(T0) , base(b1) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_dossiers , alias(T1) , base(b1) )),
         contrainte( egal( champ( T1 , chi_id_dossier ) , champ( T0 , chx_dossier_id_basedd ) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_cibles , alias(T2) , base(b1) )),
         contrainte( egal( champ( T2 , chi_id_cible ) , champ( T0 , chx_cible_id_basedd ) ))
      )
   ),
   conditions( egal( champ( `T0` , `chx_cible_id_basedd` ) , :T0_chx_cible_id_basedd ))
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
`T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
`T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
`T2`.`chp_commentaire_cible`
 FROM b1.tbl_bdds T0
 LEFT JOIN b1.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

 LEFT JOIN b1.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd

WHERE `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd;','function sql_27($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
      `T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
      `T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
      `T2`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chx_dossier_id_basedd'' => $tab0[1],
                ''T0.chx_cible_id_basedd'' => $tab0[2],
                ''T0.chp_nom_basedd'' => $tab0[3],
                ''T0.chp_rev_basedd'' => $tab0[4],
                ''T0.chp_commentaire_basedd'' => $tab0[5],
                ''T0.chp_genere_basedd'' => $tab0[6],
                ''T0.chp_rev_travail_basedd'' => $tab0[7],
                ''T0.chp_fournisseur_basedd'' => $tab0[8],
                ''T1.chi_id_dossier'' => $tab0[9],
                ''T1.chx_cible_dossier'' => $tab0[10],
                ''T1.chp_nom_dossier'' => $tab0[11],
                ''T2.chi_id_cible'' => $tab0[12],
                ''T2.chp_nom_cible'' => $tab0[13],
                ''T2.chp_dossier_cible'' => $tab0[14],
                ''T2.chp_commentaire_cible'' => $tab0[15],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','toutes les bases d''une cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,100,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,100,""],[4,"valeurs","f",1,0,42,48,1,16,2,2,49,53,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_basedd","c",3,2,72,84,5,0,2,0,62,100,""],[8,"champ","f",2,0,95,99,4,2,2,1,100,11,""],[9,"T0","c",3,2,103,104,8,0,1,0,100,10,""],[10,"chx_dossier_id_basedd","c",3,2,110,130,8,0,2,0,100,100,""],[11,"champ","f",2,0,141,145,4,2,3,1,146,14,""],[12,"T0","c",3,2,149,150,11,0,1,0,146,13,""],[13,"chx_cible_id_basedd","c",3,2,156,174,11,0,2,0,146,100,""],[14,"champ","f",2,0,185,189,4,2,4,1,190,17,""],[15,"T0","c",3,2,193,194,14,0,1,0,190,16,""],[16,"chp_nom_basedd","c",3,2,200,213,14,0,2,0,190,100,""],[17,"champ","f",2,0,224,228,4,2,5,1,229,20,""],[18,"T0","c",3,2,232,233,17,0,1,0,229,19,""],[19,"chp_rev_basedd","c",3,2,239,252,17,0,2,0,229,100,""],[20,"champ","f",2,0,263,267,4,2,6,1,268,23,""],[21,"T0","c",3,2,271,272,20,0,1,0,268,22,""],[22,"chp_commentaire_basedd","c",3,2,278,299,20,0,2,0,268,100,""],[23,"champ","f",2,0,310,314,4,2,7,1,315,26,""],[24,"T0","c",3,2,318,319,23,0,1,0,315,25,""],[25,"chp_genere_basedd","c",3,2,325,341,23,0,2,0,315,100,""],[26,"champ","f",2,0,352,356,4,2,8,1,357,29,""],[27,"T0","c",3,2,360,361,26,0,1,0,357,28,""],[28,"chp_rev_travail_basedd","c",3,2,367,388,26,0,2,0,357,100,""],[29,"champ","f",2,0,399,403,4,2,9,1,404,32,""],[30,"T0","c",3,2,407,408,29,0,1,0,404,31,""],[31,"chp_fournisseur_basedd","c",3,2,414,435,29,0,2,0,404,100,""],[32,"champ","f",2,0,446,450,4,2,10,1,451,35,""],[33,"T1","c",3,2,454,455,32,0,1,0,451,34,""],[34,"chi_id_dossier","c",3,2,461,474,32,0,2,0,451,100,""],[35,"champ","f",2,0,485,489,4,2,11,1,490,38,""],[36,"T1","c",3,2,493,494,35,0,1,0,490,37,""],[37,"chx_cible_dossier","c",3,2,500,516,35,0,2,0,490,100,""],[38,"champ","f",2,0,527,531,4,2,12,1,532,41,""],[39,"T1","c",3,2,535,536,38,0,1,0,532,40,""],[40,"chp_nom_dossier","c",3,2,542,556,38,0,2,0,532,100,""],[41,"champ","f",2,0,567,571,4,2,13,1,572,44,""],[42,"T2","c",3,2,575,576,41,0,1,0,572,43,""],[43,"chi_id_cible","c",3,2,582,593,41,0,2,0,572,100,""],[44,"champ","f",2,0,604,608,4,2,14,1,609,47,""],[45,"T2","c",3,2,612,613,44,0,1,0,609,46,""],[46,"chp_nom_cible","c",3,2,619,631,44,0,2,0,609,100,""],[47,"champ","f",2,0,642,646,4,2,15,1,647,50,""],[48,"T2","c",3,2,650,651,47,0,1,0,647,49,""],[49,"chp_dossier_cible","c",3,2,657,673,47,0,2,0,647,100,""],[50,"champ","f",2,0,684,688,4,2,16,1,689,100,""],[51,"T2","c",3,2,692,693,50,0,1,0,689,52,""],[52,"chp_commentaire_cible","c",3,2,699,719,50,0,2,0,689,100,""],[53,"provenance","f",1,0,732,741,1,3,3,5,742,94,""],[54,"table_reference","f",2,0,750,764,53,1,1,4,765,62,""],[55,"source","f",3,0,776,781,54,1,1,3,782,100,""],[56,"nom_de_la_table","f",4,0,784,798,55,3,1,2,799,100,""],[57,"tbl_bdds","c",5,0,801,808,56,0,1,0,0,58,""],[58,"alias","f",5,0,812,816,56,1,2,1,817,60,""],[59,"T0","c",6,0,818,819,58,0,1,0,817,100,""],[60,"base","f",5,0,824,827,56,1,3,1,828,100,""],[61,"b1","c",6,0,829,830,60,0,1,0,828,100,""],[62,"jointure_gauche","f",2,0,851,865,53,2,2,4,866,78,""],[63,"source","f",3,0,877,882,62,1,1,3,883,70,""],[64,"nom_de_la_table","f",4,0,885,899,63,3,1,2,900,100,""],[65,"tbl_dossiers","c",5,0,902,913,64,0,1,0,0,66,""],[66,"alias","f",5,0,917,921,64,1,2,1,922,68,""],[67,"T1","c",6,0,923,924,66,0,1,0,922,100,""],[68,"base","f",5,0,929,932,64,1,3,1,933,100,""],[69,"b1","c",6,0,934,935,68,0,1,0,933,100,""],[70,"contrainte","f",3,0,951,960,62,1,2,3,961,100,""],[71,"egal","f",4,0,963,966,70,2,1,2,967,100,""],[72,"champ","f",5,0,969,973,71,2,1,1,974,75,""],[73,"T1","c",6,0,976,977,72,0,1,0,0,74,""],[74,"chi_id_dossier","c",6,0,981,994,72,0,2,0,0,100,""],[75,"champ","f",5,0,1000,1004,71,2,2,1,1005,100,""],[76,"T0","c",6,0,1007,1008,75,0,1,0,0,77,""],[77,"chx_dossier_id_basedd","c",6,0,1012,1032,75,0,2,0,0,100,""],[78,"jointure_gauche","f",2,0,1054,1068,53,2,3,4,1069,100,""],[79,"source","f",3,0,1080,1085,78,1,1,3,1086,86,""],[80,"nom_de_la_table","f",4,0,1088,1102,79,3,1,2,1103,100,""],[81,"tbl_cibles","c",5,0,1105,1114,80,0,1,0,0,82,""],[82,"alias","f",5,0,1118,1122,80,1,2,1,1123,84,""],[83,"T2","c",6,0,1124,1125,82,0,1,0,1123,100,""],[84,"base","f",5,0,1130,1133,80,1,3,1,1134,100,""],[85,"b1","c",6,0,1135,1136,84,0,1,0,1134,100,""],[86,"contrainte","f",3,0,1152,1161,78,1,2,3,1162,100,""],[87,"egal","f",4,0,1164,1167,86,2,1,2,1168,100,""],[88,"champ","f",5,0,1170,1174,87,2,1,1,1175,91,""],[89,"T2","c",6,0,1177,1178,88,0,1,0,0,90,""],[90,"chi_id_cible","c",6,0,1182,1193,88,0,2,0,0,100,""],[91,"champ","f",5,0,1199,1203,87,2,2,1,1204,100,""],[92,"T0","c",6,0,1206,1207,91,0,1,0,0,93,""],[93,"chx_cible_id_basedd","c",6,0,1211,1229,91,0,2,0,0,100,""],[94,"conditions","f",1,0,1253,1262,1,1,4,3,1263,100,""],[95,"egal","f",2,0,1265,1268,94,2,1,2,1269,100,""],[96,"champ","f",3,0,1271,1275,95,2,1,1,1276,99,""],[97,"T0","c",4,2,1279,1280,96,0,1,0,1276,98,""],[98,"chx_cible_id_basedd","c",4,2,1286,1304,96,0,2,0,1276,100,""],[99,":T0_chx_cible_id_basedd","c",3,0,1311,1333,95,0,2,0,0,100,""]]'),
('28','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_tache` ) , champ( `T0` , `chx_utilisateur_tache` ) , champ( `T0` , `chp_texte_tache` ) , champ( `T0` , `chp_priorite_tache` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_tache` ) , :T0_chi_id_tache ) , egal( champ( `T0` , `chx_utilisateur_tache` ) , :T0_chx_utilisateur_tache ))
   )
)','SELECT 
`T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
 FROM b1.tbl_taches T0
WHERE (`T0`.`chi_id_tache` = :T0_chi_id_tache
   AND `T0`.`chx_utilisateur_tache` = :T0_chx_utilisateur_tache);','function sql_28($par){
    $champs0=''
      `T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chi_id_tache`'',$par[''T0_chi_id_tache'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_utilisateur_tache`'',$par[''T0_chx_utilisateur_tache'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_tache'' => $tab0[0],
                ''T0.chx_utilisateur_tache'' => $tab0[1],
                ''T0.chp_texte_tache'' => $tab0[2],
                ''T0.chp_priorite_tache'' => $tab0[3],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,38,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,38,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,17,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_tache","c",3,2,66,77,5,0,2,0,56,38,""],[8,"champ","f",2,0,84,88,4,2,2,1,89,11,""],[9,"T0","c",3,2,92,93,8,0,1,0,89,10,""],[10,"chx_utilisateur_tache","c",3,2,99,119,8,0,2,0,89,38,""],[11,"champ","f",2,0,126,130,4,2,3,1,131,14,""],[12,"T0","c",3,2,134,135,11,0,1,0,131,13,""],[13,"chp_texte_tache","c",3,2,141,155,11,0,2,0,131,38,""],[14,"champ","f",2,0,162,166,4,2,4,1,167,38,""],[15,"T0","c",3,2,170,171,14,0,1,0,167,16,""],[16,"chp_priorite_tache","c",3,2,177,194,14,0,2,0,167,38,""],[17,"provenance","f",1,0,204,213,1,1,3,5,214,26,""],[18,"table_reference","f",2,0,222,236,17,1,1,4,237,38,""],[19,"source","f",3,0,248,253,18,1,1,3,254,38,""],[20,"nom_de_la_table","f",4,0,256,270,19,3,1,2,271,38,""],[21,"tbl_taches","c",5,0,273,282,20,0,1,0,0,22,""],[22,"alias","f",5,0,286,290,20,1,2,1,291,24,""],[23,"T0","c",6,0,292,293,22,0,1,0,291,38,""],[24,"base","f",5,0,298,301,20,1,3,1,302,38,""],[25,"b1","c",6,0,303,304,24,0,1,0,302,38,""],[26,"conditions","f",1,0,327,336,1,1,4,4,337,38,""],[27,"et","f",2,0,345,346,26,2,1,3,347,38,""],[28,"egal","f",3,0,349,352,27,2,1,2,353,33,""],[29,"champ","f",4,0,355,359,28,2,1,1,360,32,""],[30,"T0","c",5,2,363,364,29,0,1,0,360,31,""],[31,"chi_id_tache","c",5,2,370,381,29,0,2,0,360,38,""],[32,":T0_chi_id_tache","c",4,0,388,403,28,0,2,0,0,38,""],[33,"egal","f",3,0,409,412,27,2,2,2,413,38,""],[34,"champ","f",4,0,415,419,33,2,1,1,420,37,""],[35,"T0","c",5,2,423,424,34,0,1,0,420,36,""],[36,"chx_utilisateur_tache","c",5,2,430,450,34,0,2,0,420,38,""],[37,":T0_chx_utilisateur_tache","c",4,0,457,481,33,0,2,0,0,38,""]]'),
('29','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_texte_tache` ) , :n_chp_texte_tache ) , affecte( champ( `chp_priorite_tache` ) , :n_chp_priorite_tache )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chx_utilisateur_tache` ) , :c_chx_utilisateur_tache ) , egal( champ( `chi_id_tache` ) , :c_chi_id_tache ))
   )
)','UPDATE b1.tbl_taches SET `chp_texte_tache` = :n_chp_texte_tache , `chp_priorite_tache` = :n_chp_priorite_tache
WHERE (`chx_utilisateur_tache` = :c_chx_utilisateur_tache
   AND `chi_id_tache` = :c_chi_id_tache) ;','function sql_29($par){
    $texte_sql_29=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    if($par[''n_chp_texte_tache'']==='''' || $par[''n_chp_texte_tache'']===NULL ){
        $texte_sql_29.=''    `chp_texte_tache` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_29.=''    `chp_texte_tache` = \''''.sq0($par[''n_chp_texte_tache'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_29.=''    `chp_priorite_tache` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_29.=''    `chp_priorite_tache` = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.PHP_EOL;
    $texte_sql_29.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_29 = <pre>'' . $texte_sql_29 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_29);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_29()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','texte et priorité par id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,30,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,30,""],[4,"valeurs","f",1,0,38,44,1,2,2,3,45,13,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,9,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_texte_tache","c",4,2,64,78,6,0,1,0,61,30,""],[8,":n_chp_texte_tache","c",3,0,85,102,5,0,2,0,0,30,""],[9,"affecte","f",2,0,108,114,4,2,2,2,115,30,""],[10,"champ","f",3,0,117,121,9,1,1,1,122,12,""],[11,"chp_priorite_tache","c",4,2,125,142,10,0,1,0,122,30,""],[12,":n_chp_priorite_tache","c",3,0,149,169,9,0,2,0,0,30,""],[13,"provenance","f",1,0,178,187,1,1,3,5,188,20,""],[14,"table_reference","f",2,0,196,210,13,1,1,4,211,30,""],[15,"source","f",3,0,222,227,14,1,1,3,228,30,""],[16,"nom_de_la_table","f",4,0,230,244,15,2,1,2,245,30,""],[17,"tbl_taches","c",5,0,247,256,16,0,1,0,0,18,""],[18,"base","f",5,0,260,263,16,1,2,1,264,30,""],[19,"b1","c",6,0,265,266,18,0,1,0,264,30,""],[20,"conditions","f",1,0,289,298,1,1,4,4,299,30,""],[21,"et","f",2,0,307,308,20,2,1,3,309,30,""],[22,"egal","f",3,0,311,314,21,2,1,2,315,26,""],[23,"champ","f",4,0,317,321,22,1,1,1,322,25,""],[24,"chx_utilisateur_tache","c",5,2,325,345,23,0,1,0,322,30,""],[25,":c_chx_utilisateur_tache","c",4,0,352,375,22,0,2,0,0,30,""],[26,"egal","f",3,0,381,384,21,2,2,2,385,30,""],[27,"champ","f",4,0,387,391,26,1,1,1,392,29,""],[28,"chi_id_tache","c",5,2,395,406,27,0,1,0,392,30,""],[29,":c_chi_id_tache","c",4,0,413,427,26,0,2,0,0,30,""]]'),
('30','1','insert','insérer(
   base_de_reference(1),
   valeurs( affecte( champ( `chx_utilisateur_tache` ) , :chx_utilisateur_tache ) , affecte( champ( `chp_texte_tache` ) , :chp_texte_tache ) , affecte( champ( `chp_priorite_tache` ) , :chp_priorite_tache )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   )
)','INSERT INTO b1.`tbl_taches`(
    `chx_utilisateur_tache` , 
    `chp_texte_tache` , 
    `chp_priorite_tache`
) VALUES (
    :chx_utilisateur_tache , 
    :chp_texte_tache , 
    :chp_priorite_tache
);','function sql_30($par){
    $texte_sql_30=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches`(
         `chx_utilisateur_tache` , 
         `chp_texte_tache` , 
         `chp_priorite_tache`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_utilisateur_tache'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_texte_tache'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_priorite_tache'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_30.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_30 = <pre>'' . $texte_sql_30 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_30);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_30()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,24,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,24,""],[4,"valeurs","f",1,0,37,43,1,3,2,3,44,17,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,9,""],[6,"champ","f",3,0,55,59,5,1,1,1,60,8,""],[7,"chx_utilisateur_tache","c",4,2,63,83,6,0,1,0,60,24,""],[8,":chx_utilisateur_tache","c",3,0,90,111,5,0,2,0,0,24,""],[9,"affecte","f",2,0,117,123,4,2,2,2,124,13,""],[10,"champ","f",3,0,126,130,9,1,1,1,131,12,""],[11,"chp_texte_tache","c",4,2,134,148,10,0,1,0,131,24,""],[12,":chp_texte_tache","c",3,0,155,170,9,0,2,0,0,24,""],[13,"affecte","f",2,0,176,182,4,2,3,2,183,24,""],[14,"champ","f",3,0,185,189,13,1,1,1,190,16,""],[15,"chp_priorite_tache","c",4,2,193,210,14,0,1,0,190,24,""],[16,":chp_priorite_tache","c",3,0,217,235,13,0,2,0,0,24,""],[17,"provenance","f",1,0,244,253,1,1,3,5,254,24,""],[18,"table_reference","f",2,0,262,276,17,1,1,4,277,24,""],[19,"source","f",3,0,288,293,18,1,1,3,294,24,""],[20,"nom_de_la_table","f",4,0,296,310,19,2,1,2,311,24,""],[21,"tbl_taches","c",5,0,313,322,20,0,1,0,0,22,""],[22,"base","f",5,0,326,329,20,1,2,1,330,24,""],[23,"b1","c",6,0,331,332,22,0,1,0,330,24,""]]'),
('31','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_tache` ) , :chi_id_tache ) , egal( champ( `chx_utilisateur_tache` ) , :chx_utilisateur_tache ))
   )
)','DELETE FROM b1.tbl_taches
WHERE (`chi_id_tache` = :chi_id_tache
   AND `chx_utilisateur_tache` = :chx_utilisateur_tache) ;','function sql_31($par){
    $texte_sql_31=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches
          WHERE (`chi_id_tache` = ''.sq1($par[''chi_id_tache'']).'' AND `chx_utilisateur_tache` = ''.sq1($par[''chx_utilisateur_tache'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_31 = <pre>'' . $texte_sql_31 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_31);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_31()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','tâche par id et utilisateur','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,21,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,21,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,21,""],[6,"source","f",3,0,83,88,5,1,1,3,89,21,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,21,""],[8,"tbl_taches","c",5,0,108,117,7,0,1,0,0,9,""],[9,"base","f",5,0,121,124,7,1,2,1,125,21,""],[10,"b1","c",6,0,126,127,9,0,1,0,125,21,""],[11,"conditions","f",1,0,150,159,1,1,3,4,160,21,""],[12,"et","f",2,0,168,169,11,2,1,3,170,21,""],[13,"egal","f",3,0,172,175,12,2,1,2,176,17,""],[14,"champ","f",4,0,178,182,13,1,1,1,183,16,""],[15,"chi_id_tache","c",5,2,186,197,14,0,1,0,183,21,""],[16,":chi_id_tache","c",4,0,204,216,13,0,2,0,0,21,""],[17,"egal","f",3,0,222,225,12,2,2,2,226,21,""],[18,"champ","f",4,0,228,232,17,1,1,1,233,20,""],[19,"chx_utilisateur_tache","c",5,2,236,256,18,0,1,0,233,21,""],[20,":chx_utilisateur_tache","c",4,0,263,284,17,0,2,0,0,21,""]]'),
('32','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_requete`),
      champ( `T0` , `chx_cible_requete`),
      champ( `T0` , `chp_type_requete`),
      champ( `T0` , `cht_rev_requete`),
      champ( `T0` , `cht_sql_requete`),
      champ( `T0` , `cht_php_requete`),
      champ( `T0` , `cht_commentaire_requete`),
      champ( `T0` , `cht_matrice_requete`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_requete` ) , :T0_chi_id_requete ) , egal( champ( `T0` , `chx_cible_requete` ) , :T0_chx_cible_requete ))
   )
)','SELECT 
`T0`.`chi_id_requete` , `T0`.`chx_cible_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , 
`T0`.`cht_php_requete` , `T0`.`cht_commentaire_requete` , `T0`.`cht_matrice_requete`
 FROM b1.tbl_requetes T0
WHERE (`T0`.`chi_id_requete` = :T0_chi_id_requete
   AND `T0`.`chx_cible_requete` = :T0_chx_cible_requete);','function sql_32($par){
    $champs0=''
      `T0`.`chi_id_requete` , `T0`.`chx_cible_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , 
      `T0`.`cht_php_requete` , `T0`.`cht_commentaire_requete` , `T0`.`cht_matrice_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chi_id_requete`'',$par[''T0_chi_id_requete'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_requete`'',$par[''T0_chx_cible_requete'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_requete'' => $tab0[0],
                ''T0.chx_cible_requete'' => $tab0[1],
                ''T0.chp_type_requete'' => $tab0[2],
                ''T0.cht_rev_requete'' => $tab0[3],
                ''T0.cht_sql_requete'' => $tab0[4],
                ''T0.cht_php_requete'' => $tab0[5],
                ''T0.cht_commentaire_requete'' => $tab0[6],
                ''T0.cht_matrice_requete'' => $tab0[7],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','requête par id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,50,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,50,""],[4,"valeurs","f",1,0,42,48,1,8,2,2,49,29,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_requete","c",3,2,72,85,5,0,2,0,62,50,""],[8,"champ","f",2,0,96,100,4,2,2,1,101,11,""],[9,"T0","c",3,2,104,105,8,0,1,0,101,10,""],[10,"chx_cible_requete","c",3,2,111,127,8,0,2,0,101,50,""],[11,"champ","f",2,0,138,142,4,2,3,1,143,14,""],[12,"T0","c",3,2,146,147,11,0,1,0,143,13,""],[13,"chp_type_requete","c",3,2,153,168,11,0,2,0,143,50,""],[14,"champ","f",2,0,179,183,4,2,4,1,184,17,""],[15,"T0","c",3,2,187,188,14,0,1,0,184,16,""],[16,"cht_rev_requete","c",3,2,194,208,14,0,2,0,184,50,""],[17,"champ","f",2,0,219,223,4,2,5,1,224,20,""],[18,"T0","c",3,2,227,228,17,0,1,0,224,19,""],[19,"cht_sql_requete","c",3,2,234,248,17,0,2,0,224,50,""],[20,"champ","f",2,0,259,263,4,2,6,1,264,23,""],[21,"T0","c",3,2,267,268,20,0,1,0,264,22,""],[22,"cht_php_requete","c",3,2,274,288,20,0,2,0,264,50,""],[23,"champ","f",2,0,299,303,4,2,7,1,304,26,""],[24,"T0","c",3,2,307,308,23,0,1,0,304,25,""],[25,"cht_commentaire_requete","c",3,2,314,336,23,0,2,0,304,50,""],[26,"champ","f",2,0,347,351,4,2,8,1,352,50,""],[27,"T0","c",3,2,355,356,26,0,1,0,352,28,""],[28,"cht_matrice_requete","c",3,2,362,380,26,0,2,0,352,50,""],[29,"provenance","f",1,0,393,402,1,1,3,5,403,38,""],[30,"table_reference","f",2,0,411,425,29,1,1,4,426,50,""],[31,"source","f",3,0,437,442,30,1,1,3,443,50,""],[32,"nom_de_la_table","f",4,0,445,459,31,3,1,2,460,50,""],[33,"tbl_requetes","c",5,0,462,473,32,0,1,0,0,34,""],[34,"alias","f",5,0,477,481,32,1,2,1,482,36,""],[35,"T0","c",6,0,483,484,34,0,1,0,482,50,""],[36,"base","f",5,0,489,492,32,1,3,1,493,50,""],[37,"b1","c",6,0,494,495,36,0,1,0,493,50,""],[38,"conditions","f",1,0,518,527,1,1,4,4,528,50,""],[39,"et","f",2,0,536,537,38,2,1,3,538,50,""],[40,"egal","f",3,0,540,543,39,2,1,2,544,45,""],[41,"champ","f",4,0,546,550,40,2,1,1,551,44,""],[42,"T0","c",5,2,554,555,41,0,1,0,551,43,""],[43,"chi_id_requete","c",5,2,561,574,41,0,2,0,551,50,""],[44,":T0_chi_id_requete","c",4,0,581,598,40,0,2,0,0,50,""],[45,"egal","f",3,0,604,607,39,2,2,2,608,50,""],[46,"champ","f",4,0,610,614,45,2,1,1,615,49,""],[47,"T0","c",5,2,618,619,46,0,1,0,615,48,""],[48,"chx_cible_requete","c",5,2,625,641,46,0,2,0,615,50,""],[49,":T0_chx_cible_requete","c",4,0,648,668,45,0,2,0,0,50,""]]'),
('33','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_cible` ) , champ( `T0` , `chp_nom_cible` ) , champ( `T0` , `chp_dossier_cible` ) , champ( `T0` , `chp_commentaire_cible` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_cibles , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_cible` ) , :T0_chi_id_cible ) , comme( champ( `T0` , `chp_nom_cible` ) , :T0_chp_nom_cible ) , comme( champ( `T0` , `chp_dossier_cible` ) , :T0_chp_dossier_cible ) , comme( champ( `T0` , `chp_commentaire_cible` ) , :T0_chp_commentaire_cible ))
   ),
   complements(
      trier_par( ( champ( `T0` , `chi_id_cible` ) , croissant() )),
      limité_à( quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
 FROM b1.tbl_cibles T0
WHERE (`T0`.`chi_id_cible` = :T0_chi_id_cible
   AND `T0`.`chp_nom_cible` LIKE :T0_chp_nom_cible
   AND `T0`.`chp_dossier_cible` LIKE :T0_chp_dossier_cible
   AND `T0`.`chp_commentaire_cible` LIKE :T0_chp_commentaire_cible) 
ORDER BY `T0`.`chi_id_cible` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_33($par){
    $champs0=''
      `T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    if(($par[''T0_chi_id_cible''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_cible`'',$par[''T0_chi_id_cible'']);
    }
    if(($par[''T0_chp_nom_cible''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_cible` LIKE ''.sq1($par[''T0_chp_nom_cible'']).''''.PHP_EOL;
    }
    if(($par[''T0_chp_dossier_cible''] !== '''')){
        $where0.='' AND `T0`.`chp_dossier_cible` LIKE ''.sq1($par[''T0_chp_dossier_cible'']).''''.PHP_EOL;
    }
    if(($par[''T0_chp_commentaire_cible''] !== '''')){
        $where0.='' AND `T0`.`chp_commentaire_cible` LIKE ''.sq1($par[''T0_chp_commentaire_cible'']).''''.PHP_EOL;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_cible` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_cible'' => $tab0[0],
                ''T0.chp_nom_cible'' => $tab0[1],
                ''T0.chp_dossier_cible'' => $tab0[2],
                ''T0.chp_commentaire_cible'' => $tab0[3],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => __xsu       ,
           __xva  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => __xer ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','cibles','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,60,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,60,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,17,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_cible","c",3,2,66,77,5,0,2,0,56,60,""],[8,"champ","f",2,0,84,88,4,2,2,1,89,11,""],[9,"T0","c",3,2,92,93,8,0,1,0,89,10,""],[10,"chp_nom_cible","c",3,2,99,111,8,0,2,0,89,60,""],[11,"champ","f",2,0,118,122,4,2,3,1,123,14,""],[12,"T0","c",3,2,126,127,11,0,1,0,123,13,""],[13,"chp_dossier_cible","c",3,2,133,149,11,0,2,0,123,60,""],[14,"champ","f",2,0,156,160,4,2,4,1,161,60,""],[15,"T0","c",3,2,164,165,14,0,1,0,161,16,""],[16,"chp_commentaire_cible","c",3,2,171,191,14,0,2,0,161,60,""],[17,"provenance","f",1,0,201,210,1,1,3,5,211,26,""],[18,"table_reference","f",2,0,219,233,17,1,1,4,234,60,""],[19,"source","f",3,0,245,250,18,1,1,3,251,60,""],[20,"nom_de_la_table","f",4,0,253,267,19,3,1,2,268,60,""],[21,"tbl_cibles","c",5,0,270,279,20,0,1,0,0,22,""],[22,"alias","f",5,0,283,287,20,1,2,1,288,24,""],[23,"T0","c",6,0,289,290,22,0,1,0,288,60,""],[24,"base","f",5,0,295,298,20,1,3,1,299,60,""],[25,"b1","c",6,0,300,301,24,0,1,0,299,60,""],[26,"conditions","f",1,0,324,333,1,1,4,4,334,48,""],[27,"et","f",2,0,342,343,26,4,1,3,344,60,""],[28,"egal","f",3,0,346,349,27,2,1,2,350,33,""],[29,"champ","f",4,0,352,356,28,2,1,1,357,32,""],[30,"T0","c",5,2,360,361,29,0,1,0,357,31,""],[31,"chi_id_cible","c",5,2,367,378,29,0,2,0,357,60,""],[32,":T0_chi_id_cible","c",4,0,385,400,28,0,2,0,0,60,""],[33,"comme","f",3,0,406,410,27,2,2,2,411,38,""],[34,"champ","f",4,0,413,417,33,2,1,1,418,37,""],[35,"T0","c",5,2,421,422,34,0,1,0,418,36,""],[36,"chp_nom_cible","c",5,2,428,440,34,0,2,0,418,60,""],[37,":T0_chp_nom_cible","c",4,0,447,463,33,0,2,0,0,60,""],[38,"comme","f",3,0,469,473,27,2,3,2,474,43,""],[39,"champ","f",4,0,476,480,38,2,1,1,481,42,""],[40,"T0","c",5,2,484,485,39,0,1,0,481,41,""],[41,"chp_dossier_cible","c",5,2,491,507,39,0,2,0,481,60,""],[42,":T0_chp_dossier_cible","c",4,0,514,534,38,0,2,0,0,60,""],[43,"comme","f",3,0,540,544,27,2,4,2,545,60,""],[44,"champ","f",4,0,547,551,43,2,1,1,552,47,""],[45,"T0","c",5,2,555,556,44,0,1,0,552,46,""],[46,"chp_commentaire_cible","c",5,2,562,582,44,0,2,0,552,60,""],[47,":T0_chp_commentaire_cible","c",4,0,589,613,43,0,2,0,0,60,""],[48,"complements","f",1,0,627,637,1,2,5,4,638,60,""],[49,"trier_par","f",2,0,646,654,48,1,1,3,655,55,""],[50,"","f",3,0,646,654,49,2,1,2,657,60,""],[51,"champ","f",4,0,659,663,50,2,1,1,664,54,""],[52,"T0","c",5,2,667,668,51,0,1,0,664,53,""],[53,"chi_id_cible","c",5,2,674,685,51,0,2,0,664,60,""],[54,"croissant","f",4,0,692,700,50,0,2,0,701,60,""],[55,"limit\u00e9_\u00e0","f",2,0,714,721,48,2,2,2,722,60,""],[56,"quantit\u00e9","f",3,0,724,731,55,1,1,1,732,58,""],[57,":quantitee","c",4,0,733,742,56,0,1,0,732,60,""],[58,"d\u00e9but","f",3,0,747,751,55,1,2,1,752,60,""],[59,":debut","c",4,0,753,758,58,0,1,0,752,60,""]]'),
('34','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_cible` ) , champ( `T0` , `chp_nom_cible` ) , champ( `T0` , `chp_dossier_cible` ) , champ( `T0` , `chp_commentaire_cible` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_cibles , alias(T0) , base(b1) ))
      )
   ),
   conditions( egal( champ( `T0` , `chi_id_cible` ) , :T0_chi_id_cible ))
)','SELECT 
`T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
 FROM b1.tbl_cibles T0
WHERE `T0`.`chi_id_cible` = :T0_chi_id_cible;','function sql_34($par){
    $champs0=''
      `T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chi_id_cible`'',$par[''T0_chi_id_cible'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_cible'' => $tab0[0],
                ''T0.chp_nom_cible'' => $tab0[1],
                ''T0.chp_dossier_cible'' => $tab0[2],
                ''T0.chp_commentaire_cible'' => $tab0[3],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','cible par id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,32,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,32,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,17,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_cible","c",3,2,66,77,5,0,2,0,56,32,""],[8,"champ","f",2,0,84,88,4,2,2,1,89,11,""],[9,"T0","c",3,2,92,93,8,0,1,0,89,10,""],[10,"chp_nom_cible","c",3,2,99,111,8,0,2,0,89,32,""],[11,"champ","f",2,0,118,122,4,2,3,1,123,14,""],[12,"T0","c",3,2,126,127,11,0,1,0,123,13,""],[13,"chp_dossier_cible","c",3,2,133,149,11,0,2,0,123,32,""],[14,"champ","f",2,0,156,160,4,2,4,1,161,32,""],[15,"T0","c",3,2,164,165,14,0,1,0,161,16,""],[16,"chp_commentaire_cible","c",3,2,171,191,14,0,2,0,161,32,""],[17,"provenance","f",1,0,201,210,1,1,3,5,211,26,""],[18,"table_reference","f",2,0,219,233,17,1,1,4,234,32,""],[19,"source","f",3,0,245,250,18,1,1,3,251,32,""],[20,"nom_de_la_table","f",4,0,253,267,19,3,1,2,268,32,""],[21,"tbl_cibles","c",5,0,270,279,20,0,1,0,0,22,""],[22,"alias","f",5,0,283,287,20,1,2,1,288,24,""],[23,"T0","c",6,0,289,290,22,0,1,0,288,32,""],[24,"base","f",5,0,295,298,20,1,3,1,299,32,""],[25,"b1","c",6,0,300,301,24,0,1,0,299,32,""],[26,"conditions","f",1,0,324,333,1,1,4,3,334,32,""],[27,"egal","f",2,0,336,339,26,2,1,2,340,32,""],[28,"champ","f",3,0,342,346,27,2,1,1,347,31,""],[29,"T0","c",4,2,350,351,28,0,1,0,347,30,""],[30,"chi_id_cible","c",4,2,357,368,28,0,2,0,347,32,""],[31,":T0_chi_id_cible","c",3,0,375,390,27,0,2,0,0,32,""]]'),
('35','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `cht_php_requete` ) , :n_cht_php_requete )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_requete` ) , :c_chi_id_requete ) , egal( champ( `chx_cible_requete` ) , :c_chx_cible_requete ))
   )
)','UPDATE b1.tbl_requetes SET `cht_php_requete` = :n_cht_php_requete
WHERE (`chi_id_requete` = :c_chi_id_requete
   AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_35($par){
    $texte_sql_35=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.PHP_EOL;

    if($par[''n_cht_php_requete'']==='''' || $par[''n_cht_php_requete'']===NULL ){
        $texte_sql_35.=''    `cht_php_requete` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_35.=''    `cht_php_requete` = \''''.sq0($par[''n_cht_php_requete'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.PHP_EOL;
    $texte_sql_35.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_35 = <pre>'' . $texte_sql_35 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_35);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_35()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','modifier le php d''une requete après création','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,26,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,26,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,26,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"cht_php_requete","c",4,2,64,78,6,0,1,0,61,26,""],[8,":n_cht_php_requete","c",3,0,85,102,5,0,2,0,0,26,""],[9,"provenance","f",1,0,111,120,1,1,3,5,121,16,""],[10,"table_reference","f",2,0,129,143,9,1,1,4,144,26,""],[11,"source","f",3,0,155,160,10,1,1,3,161,26,""],[12,"nom_de_la_table","f",4,0,163,177,11,2,1,2,178,26,""],[13,"tbl_requetes","c",5,0,180,191,12,0,1,0,0,14,""],[14,"base","f",5,0,195,198,12,1,2,1,199,26,""],[15,"b1","c",6,0,200,201,14,0,1,0,199,26,""],[16,"conditions","f",1,0,224,233,1,1,4,4,234,26,""],[17,"et","f",2,0,242,243,16,2,1,3,244,26,""],[18,"egal","f",3,0,246,249,17,2,1,2,250,22,""],[19,"champ","f",4,0,252,256,18,1,1,1,257,21,""],[20,"chi_id_requete","c",5,2,260,273,19,0,1,0,257,26,""],[21,":c_chi_id_requete","c",4,0,280,296,18,0,2,0,0,26,""],[22,"egal","f",3,0,302,305,17,2,2,2,306,26,""],[23,"champ","f",4,0,308,312,22,1,1,1,313,25,""],[24,"chx_cible_requete","c",5,2,316,332,23,0,1,0,313,26,""],[25,":c_chx_cible_requete","c",4,0,339,358,22,0,2,0,0,26,""]]'),
('36','1','insert','insérer(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_nom_cible` ) , :chp_nom_cible ) , affecte( champ( `chp_dossier_cible` ) , :chp_dossier_cible ) , affecte( champ( `chp_commentaire_cible` ) , :chp_commentaire_cible )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_cibles , base(b1) ))
      )
   )
)','INSERT INTO b1.`tbl_cibles`(
    `chp_nom_cible` , 
    `chp_dossier_cible` , 
    `chp_commentaire_cible`
) VALUES (
    :chp_nom_cible , 
    :chp_dossier_cible , 
    :chp_commentaire_cible
);','function sql_36($par){
    $texte_sql_36=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_cibles`(
         `chp_nom_cible` , 
         `chp_dossier_cible` , 
         `chp_commentaire_cible`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_cible'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_dossier_cible'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_cible'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_36.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_36 = <pre>'' . $texte_sql_36 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_36);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_36()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,24,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,24,""],[4,"valeurs","f",1,0,37,43,1,3,2,3,44,17,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,9,""],[6,"champ","f",3,0,55,59,5,1,1,1,60,8,""],[7,"chp_nom_cible","c",4,2,63,75,6,0,1,0,60,24,""],[8,":chp_nom_cible","c",3,0,82,95,5,0,2,0,0,24,""],[9,"affecte","f",2,0,101,107,4,2,2,2,108,13,""],[10,"champ","f",3,0,110,114,9,1,1,1,115,12,""],[11,"chp_dossier_cible","c",4,2,118,134,10,0,1,0,115,24,""],[12,":chp_dossier_cible","c",3,0,141,158,9,0,2,0,0,24,""],[13,"affecte","f",2,0,164,170,4,2,3,2,171,24,""],[14,"champ","f",3,0,173,177,13,1,1,1,178,16,""],[15,"chp_commentaire_cible","c",4,2,181,201,14,0,1,0,178,24,""],[16,":chp_commentaire_cible","c",3,0,208,229,13,0,2,0,0,24,""],[17,"provenance","f",1,0,238,247,1,1,3,5,248,24,""],[18,"table_reference","f",2,0,256,270,17,1,1,4,271,24,""],[19,"source","f",3,0,282,287,18,1,1,3,288,24,""],[20,"nom_de_la_table","f",4,0,290,304,19,2,1,2,305,24,""],[21,"tbl_cibles","c",5,0,307,316,20,0,1,0,0,22,""],[22,"base","f",5,0,320,323,20,1,2,1,324,24,""],[23,"b1","c",6,0,325,326,22,0,1,0,324,24,""]]'),
('37','1','insert','insérer(
   base_de_reference(1),
   valeurs( affecte( champ( `chx_cible_dossier` ) , :chx_cible_dossier ) , affecte( champ( `chp_nom_dossier` ) , :chp_nom_dossier )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , base(b1) ))
      )
   )
)','INSERT INTO b1.`tbl_dossiers`(
    `chx_cible_dossier` , 
    `chp_nom_dossier`
) VALUES (
    :chx_cible_dossier , 
    :chp_nom_dossier
);','function sql_37($par){
    $texte_sql_37=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_dossiers`(
         `chx_cible_dossier` , 
         `chp_nom_dossier`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_dossier'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_dossier'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_37.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_37 = <pre>'' . $texte_sql_37 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_37);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_37()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,20,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,20,""],[4,"valeurs","f",1,0,37,43,1,2,2,3,44,13,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,9,""],[6,"champ","f",3,0,55,59,5,1,1,1,60,8,""],[7,"chx_cible_dossier","c",4,2,63,79,6,0,1,0,60,20,""],[8,":chx_cible_dossier","c",3,0,86,103,5,0,2,0,0,20,""],[9,"affecte","f",2,0,109,115,4,2,2,2,116,20,""],[10,"champ","f",3,0,118,122,9,1,1,1,123,12,""],[11,"chp_nom_dossier","c",4,2,126,140,10,0,1,0,123,20,""],[12,":chp_nom_dossier","c",3,0,147,162,9,0,2,0,0,20,""],[13,"provenance","f",1,0,171,180,1,1,3,5,181,20,""],[14,"table_reference","f",2,0,189,203,13,1,1,4,204,20,""],[15,"source","f",3,0,215,220,14,1,1,3,221,20,""],[16,"nom_de_la_table","f",4,0,223,237,15,2,1,2,238,20,""],[17,"tbl_dossiers","c",5,0,240,251,16,0,1,0,0,18,""],[18,"base","f",5,0,255,258,16,1,2,1,259,20,""],[19,"b1","c",6,0,260,261,18,0,1,0,259,20,""]]'),
('38','1','requete_manuelle','requete_manuelle(base_de_reference(1)
   
   transaction()
)','    BEGIN TRANSACTION;
    ','function sql_38($par){
    $texte_sql_38=''
          BEGIN TRANSACTION;
          
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_38 = <pre>'' . $texte_sql_38 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_38);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_38()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"requete_manuelle","f",0,0,0,15,0,2,1,2,16,5,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,5,""],[4,"transaction","f",1,0,45,55,1,0,2,0,56,5,""]]'),
('39','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_source` ) , :chi_id_source ) , egal( champ( `chx_cible_id_source` ) , :chx_cible_id_source ))
   )
)','DELETE FROM b1.tbl_sources
WHERE (`chi_id_source` = :chi_id_source
   AND `chx_cible_id_source` = :chx_cible_id_source) ;','function sql_39($par){
    $texte_sql_39=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources
          WHERE (`chi_id_source` = ''.sq1($par[''chi_id_source'']).'' AND `chx_cible_id_source` = ''.sq1($par[''chx_cible_id_source'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_39 = <pre>'' . $texte_sql_39 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_39);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_39()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','source par id et cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,21,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,21,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,21,""],[6,"source","f",3,0,83,88,5,1,1,3,89,21,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,21,""],[8,"tbl_sources","c",5,0,108,118,7,0,1,0,0,9,""],[9,"base","f",5,0,122,125,7,1,2,1,126,21,""],[10,"b1","c",6,0,127,128,9,0,1,0,126,21,""],[11,"conditions","f",1,0,151,160,1,1,3,4,161,21,""],[12,"et","f",2,0,169,170,11,2,1,3,171,21,""],[13,"egal","f",3,0,173,176,12,2,1,2,177,17,""],[14,"champ","f",4,0,179,183,13,1,1,1,184,16,""],[15,"chi_id_source","c",5,2,187,199,14,0,1,0,184,21,""],[16,":chi_id_source","c",4,0,206,219,13,0,2,0,0,21,""],[17,"egal","f",3,0,225,228,12,2,2,2,229,21,""],[18,"champ","f",4,0,231,235,17,1,1,1,236,20,""],[19,"chx_cible_id_source","c",5,2,239,257,18,0,1,0,236,21,""],[20,":chx_cible_id_source","c",4,0,264,283,17,0,2,0,0,21,""]]'),
('40','1','requete_manuelle','requete_manuelle(base_de_reference(1)
   rollback()
)','    ROLLBACK;','function sql_40($par){
    $texte_sql_40=''
          ROLLBACK;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_40 = <pre>'' . $texte_sql_40 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_40);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_40()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"requete_manuelle","f",0,0,0,15,0,2,1,2,16,5,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,5,""],[4,"rollback","f",1,0,41,48,1,0,2,0,49,5,""]]'),
('41','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , base(b1) ))
      )
   ),
   conditions( egal( champ( `chx_cible_id_source` ) , :chx_cible_id_source ))
)','DELETE FROM b1.tbl_sources
WHERE `chx_cible_id_source` = :chx_cible_id_source ;','function sql_41($par){
    $texte_sql_41=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources
          WHERE `chx_cible_id_source` = ''.sq1($par[''chx_cible_id_source'']).'' ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_41 = <pre>'' . $texte_sql_41 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_41);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_41()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','sources par cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,16,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,16,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,16,""],[6,"source","f",3,0,83,88,5,1,1,3,89,16,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,16,""],[8,"tbl_sources","c",5,0,108,118,7,0,1,0,0,9,""],[9,"base","f",5,0,122,125,7,1,2,1,126,16,""],[10,"b1","c",6,0,127,128,9,0,1,0,126,16,""],[11,"conditions","f",1,0,151,160,1,1,3,3,161,16,""],[12,"egal","f",2,0,163,166,11,2,1,2,167,16,""],[13,"champ","f",3,0,169,173,12,1,1,1,174,15,""],[14,"chx_cible_id_source","c",4,2,177,195,13,0,1,0,174,16,""],[15,":chx_cible_id_source","c",3,0,202,221,12,0,2,0,0,16,""]]'),
('42','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chx_cible_requete` ) , :chx_cible_requete ))
   )
)','DELETE FROM b1.tbl_requetes
WHERE (`chx_cible_requete` = :chx_cible_requete) ;','function sql_42($par){
    $texte_sql_42=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes
          WHERE (`chx_cible_requete` = ''.sq1($par[''chx_cible_requete'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_42 = <pre>'' . $texte_sql_42 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_42);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_42()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','requêtes par cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,17,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,17,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,17,""],[6,"source","f",3,0,83,88,5,1,1,3,89,17,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,17,""],[8,"tbl_requetes","c",5,0,108,119,7,0,1,0,0,9,""],[9,"base","f",5,0,123,126,7,1,2,1,127,17,""],[10,"b1","c",6,0,128,129,9,0,1,0,127,17,""],[11,"conditions","f",1,0,152,161,1,1,3,4,162,17,""],[12,"et","f",2,0,170,171,11,1,1,3,172,17,""],[13,"egal","f",3,0,174,177,12,2,1,2,178,17,""],[14,"champ","f",4,0,180,184,13,1,1,1,185,16,""],[15,"chx_cible_requete","c",5,2,188,204,14,0,1,0,185,17,""],[16,":chx_cible_requete","c",4,0,211,228,13,0,2,0,0,17,""]]'),
('43','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chx_cible_id_basedd` ) , :chx_cible_id_basedd ))
   )
)','DELETE FROM b1.tbl_bdds
WHERE (`chx_cible_id_basedd` = :chx_cible_id_basedd) ;','function sql_43($par){
    $texte_sql_43=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds
          WHERE (`chx_cible_id_basedd` = ''.sq1($par[''chx_cible_id_basedd'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_43 = <pre>'' . $texte_sql_43 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_43);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_43()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','bases par cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,17,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,17,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,17,""],[6,"source","f",3,0,83,88,5,1,1,3,89,17,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,17,""],[8,"tbl_bdds","c",5,0,108,115,7,0,1,0,0,9,""],[9,"base","f",5,0,119,122,7,1,2,1,123,17,""],[10,"b1","c",6,0,124,125,9,0,1,0,123,17,""],[11,"conditions","f",1,0,148,157,1,1,3,4,158,17,""],[12,"et","f",2,0,166,167,11,1,1,3,168,17,""],[13,"egal","f",3,0,170,173,12,2,1,2,174,17,""],[14,"champ","f",4,0,176,180,13,1,1,1,181,16,""],[15,"chx_cible_id_basedd","c",5,2,184,202,14,0,1,0,181,17,""],[16,":chx_cible_id_basedd","c",4,0,209,228,13,0,2,0,0,17,""]]'),
('44','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chx_cible_dossier` ) , :chx_cible_dossier ))
   )
)','DELETE FROM b1.tbl_dossiers
WHERE (`chx_cible_dossier` = :chx_cible_dossier) ;','function sql_44($par){
    $texte_sql_44=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers
          WHERE (`chx_cible_dossier` = ''.sq1($par[''chx_cible_dossier'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_44 = <pre>'' . $texte_sql_44 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_44);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_44()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','dossiers d''une cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,17,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,17,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,17,""],[6,"source","f",3,0,83,88,5,1,1,3,89,17,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,17,""],[8,"tbl_dossiers","c",5,0,108,119,7,0,1,0,0,9,""],[9,"base","f",5,0,123,126,7,1,2,1,127,17,""],[10,"b1","c",6,0,128,129,9,0,1,0,127,17,""],[11,"conditions","f",1,0,152,161,1,1,3,4,162,17,""],[12,"et","f",2,0,170,171,11,1,1,3,172,17,""],[13,"egal","f",3,0,174,177,12,2,1,2,178,17,""],[14,"champ","f",4,0,180,184,13,1,1,1,185,16,""],[15,"chx_cible_dossier","c",5,2,188,204,14,0,1,0,185,17,""],[16,":chx_cible_dossier","c",4,0,211,228,13,0,2,0,0,17,""]]'),
('45','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_cibles , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_cible` ) , :chi_id_cible ))
   )
)','DELETE FROM b1.tbl_cibles
WHERE (`chi_id_cible` = :chi_id_cible) ;','function sql_45($par){
    $texte_sql_45=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles
          WHERE (`chi_id_cible` = ''.sq1($par[''chi_id_cible'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_45 = <pre>'' . $texte_sql_45 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_45);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_45()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','cible par id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,17,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,17,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,17,""],[6,"source","f",3,0,83,88,5,1,1,3,89,17,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,17,""],[8,"tbl_cibles","c",5,0,108,117,7,0,1,0,0,9,""],[9,"base","f",5,0,121,124,7,1,2,1,125,17,""],[10,"b1","c",6,0,126,127,9,0,1,0,125,17,""],[11,"conditions","f",1,0,150,159,1,1,3,4,160,17,""],[12,"et","f",2,0,168,169,11,1,1,3,170,17,""],[13,"egal","f",3,0,172,175,12,2,1,2,176,17,""],[14,"champ","f",4,0,178,182,13,1,1,1,183,16,""],[15,"chi_id_cible","c",5,2,186,197,14,0,1,0,183,17,""],[16,":chi_id_cible","c",4,0,204,216,13,0,2,0,0,17,""]]'),
('46','1','requete_manuelle','requete_manuelle(base_de_reference(1) , commit())','    COMMIT;','function sql_46($par){
    $texte_sql_46=''
          COMMIT;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_46 = <pre>'' . $texte_sql_46 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_46);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_46()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"requete_manuelle","f",0,0,0,15,0,2,1,2,16,5,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,5,""],[4,"commit","f",1,0,40,45,1,0,2,0,46,5,""]]'),
('47','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_commentaire_cible` ) , :n_chp_commentaire_cible )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_cibles , base(b1) ))
      )
   ),
   conditions( egal( champ( `chi_id_cible` ) , 1 ))
)','UPDATE b1.tbl_cibles SET `chp_commentaire_cible` = :n_chp_commentaire_cible
WHERE `chi_id_cible` = 1 ;','function sql_47($par){
    $texte_sql_47=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_cibles` SET ''.PHP_EOL;

    if($par[''n_chp_commentaire_cible'']==='''' || $par[''n_chp_commentaire_cible'']===NULL ){
        $texte_sql_47.=''    `chp_commentaire_cible` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_47.=''    `chp_commentaire_cible` = \''''.sq0($par[''n_chp_commentaire_cible'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_cible` = 1''.PHP_EOL;
    $texte_sql_47.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_47 = <pre>'' . $texte_sql_47 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_47);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_47()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,21,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,21,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,21,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_commentaire_cible","c",4,2,64,84,6,0,1,0,61,21,""],[8,":n_chp_commentaire_cible","c",3,0,91,114,5,0,2,0,0,21,""],[9,"provenance","f",1,0,123,132,1,1,3,5,133,16,""],[10,"table_reference","f",2,0,141,155,9,1,1,4,156,21,""],[11,"source","f",3,0,167,172,10,1,1,3,173,21,""],[12,"nom_de_la_table","f",4,0,175,189,11,2,1,2,190,21,""],[13,"tbl_cibles","c",5,0,192,201,12,0,1,0,0,14,""],[14,"base","f",5,0,205,208,12,1,2,1,209,21,""],[15,"b1","c",6,0,210,211,14,0,1,0,209,21,""],[16,"conditions","f",1,0,234,243,1,1,4,3,244,21,""],[17,"egal","f",2,0,246,249,16,2,1,2,250,21,""],[18,"champ","f",3,0,252,256,17,1,1,1,257,20,""],[19,"chi_id_cible","c",4,2,260,271,18,0,1,0,257,21,""],[20,"1","c",3,0,278,278,17,0,2,0,0,21,""]]'),
('48','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_nom_cible` ) , :n_chp_nom_cible ) , affecte( champ( `chp_dossier_cible` ) , :n_chp_dossier_cible ) , affecte( champ( `chp_commentaire_cible` ) , :n_chp_commentaire_cible )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_cibles , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_cible` ) , :c_chi_id_cible ))
   )
)','UPDATE b1.tbl_cibles SET `chp_nom_cible` = :n_chp_nom_cible , `chp_dossier_cible` = :n_chp_dossier_cible , `chp_commentaire_cible` = :n_chp_commentaire_cible
WHERE (`chi_id_cible` = :c_chi_id_cible) ;','function sql_48($par){
    $texte_sql_48=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_cibles` SET ''.PHP_EOL;

    if($par[''n_chp_nom_cible'']==='''' || $par[''n_chp_nom_cible'']===NULL ){
        $texte_sql_48.=''    `chp_nom_cible` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_48.=''    `chp_nom_cible` = \''''.sq0($par[''n_chp_nom_cible'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_dossier_cible'']==='''' || $par[''n_chp_dossier_cible'']===NULL ){
        $texte_sql_48.=''    `chp_dossier_cible` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_48.=''    `chp_dossier_cible` = \''''.sq0($par[''n_chp_dossier_cible'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_commentaire_cible'']==='''' || $par[''n_chp_commentaire_cible'']===NULL ){
        $texte_sql_48.=''    `chp_commentaire_cible` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_48.=''    `chp_commentaire_cible` = \''''.sq0($par[''n_chp_commentaire_cible'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_cible` = ''.sq1($par[''c_chi_id_cible'']).''''.PHP_EOL;
    $texte_sql_48.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_48 = <pre>'' . $texte_sql_48 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_48);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_48()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,30,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,30,""],[4,"valeurs","f",1,0,38,44,1,3,2,3,45,17,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,9,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_nom_cible","c",4,2,64,76,6,0,1,0,61,30,""],[8,":n_chp_nom_cible","c",3,0,83,98,5,0,2,0,0,30,""],[9,"affecte","f",2,0,104,110,4,2,2,2,111,13,""],[10,"champ","f",3,0,113,117,9,1,1,1,118,12,""],[11,"chp_dossier_cible","c",4,2,121,137,10,0,1,0,118,30,""],[12,":n_chp_dossier_cible","c",3,0,144,163,9,0,2,0,0,30,""],[13,"affecte","f",2,0,169,175,4,2,3,2,176,30,""],[14,"champ","f",3,0,178,182,13,1,1,1,183,16,""],[15,"chp_commentaire_cible","c",4,2,186,206,14,0,1,0,183,30,""],[16,":n_chp_commentaire_cible","c",3,0,213,236,13,0,2,0,0,30,""],[17,"provenance","f",1,0,245,254,1,1,3,5,255,24,""],[18,"table_reference","f",2,0,263,277,17,1,1,4,278,30,""],[19,"source","f",3,0,289,294,18,1,1,3,295,30,""],[20,"nom_de_la_table","f",4,0,297,311,19,2,1,2,312,30,""],[21,"tbl_cibles","c",5,0,314,323,20,0,1,0,0,22,""],[22,"base","f",5,0,327,330,20,1,2,1,331,30,""],[23,"b1","c",6,0,332,333,22,0,1,0,331,30,""],[24,"conditions","f",1,0,356,365,1,1,4,4,366,30,""],[25,"et","f",2,0,374,375,24,1,1,3,376,30,""],[26,"egal","f",3,0,378,381,25,2,1,2,382,30,""],[27,"champ","f",4,0,384,388,26,1,1,1,389,29,""],[28,"chi_id_cible","c",5,2,392,403,27,0,1,0,389,30,""],[29,":c_chi_id_cible","c",4,0,410,424,26,0,2,0,0,30,""]]'),
('49','1','select','sélectionner(
   base_de_reference(1),
   valeurs( compter( tous_les_champs() )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_basedd` ) , :T0_chi_id_basedd ) , egal( champ( `T0` , `chx_cible_id_basedd` ) , :T0_chx_cible_id_basedd ))
   )
)','SELECT 
count( * )
 FROM b1.tbl_bdds T0
WHERE (`T0`.`chi_id_basedd` = :T0_chi_id_basedd
   AND `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd);','function sql_49($par){
    $champs0=''
      count( * )
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chi_id_basedd`'',$par[''T0_chi_id_basedd'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''0'' => $tab0[0],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','comptage des bases d''un correspondants à des id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,28,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,28,""],[4,"valeurs","f",1,0,42,48,1,1,2,2,49,7,""],[5,"compter","f",2,0,51,57,4,1,1,1,58,28,""],[6,"tous_les_champs","f",3,0,60,74,5,0,1,0,75,28,""],[7,"provenance","f",1,0,85,94,1,1,3,5,95,16,""],[8,"table_reference","f",2,0,103,117,7,1,1,4,118,28,""],[9,"source","f",3,0,129,134,8,1,1,3,135,28,""],[10,"nom_de_la_table","f",4,0,137,151,9,3,1,2,152,28,""],[11,"tbl_bdds","c",5,0,154,161,10,0,1,0,0,12,""],[12,"alias","f",5,0,165,169,10,1,2,1,170,14,""],[13,"T0","c",6,0,171,172,12,0,1,0,170,28,""],[14,"base","f",5,0,177,180,10,1,3,1,181,28,""],[15,"b1","c",6,0,182,183,14,0,1,0,181,28,""],[16,"conditions","f",1,0,206,215,1,1,4,4,216,28,""],[17,"et","f",2,0,224,225,16,2,1,3,226,28,""],[18,"egal","f",3,0,228,231,17,2,1,2,232,23,""],[19,"champ","f",4,0,234,238,18,2,1,1,239,22,""],[20,"T0","c",5,2,242,243,19,0,1,0,239,21,""],[21,"chi_id_basedd","c",5,2,249,261,19,0,2,0,239,28,""],[22,":T0_chi_id_basedd","c",4,0,268,284,18,0,2,0,0,28,""],[23,"egal","f",3,0,290,293,17,2,2,2,294,28,""],[24,"champ","f",4,0,296,300,23,2,1,1,301,27,""],[25,"T0","c",5,2,304,305,24,0,1,0,301,26,""],[26,"chx_cible_id_basedd","c",5,2,311,329,24,0,2,0,301,28,""],[27,":T0_chx_cible_id_basedd","c",4,0,336,358,23,0,2,0,0,28,""]]'),
('50','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_dossier`),
      champ( `T0` , `chx_cible_dossier`),
      champ( `T0` , `chp_nom_dossier`),
      champ( `T1` , `chi_id_cible`),
      champ( `T1` , `chp_nom_cible`),
      champ( `T1` , `chp_dossier_cible`),
      champ( `T1` , `chp_commentaire_cible`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , alias(T0) , base(b1) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_cibles , alias(T1) , base(b1) )),
         contrainte( egal( champ( T1 , chi_id_cible ) , champ( T0 , chx_cible_dossier ) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_dossier` ) , :T0_chi_id_dossier ) , egal( champ( `T0` , `chx_cible_dossier` ) , :T0_chx_cible_dossier ))
   )
)','SELECT 
`T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
`T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible`
 FROM b1.tbl_dossiers T0
 LEFT JOIN b1.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_dossier

WHERE (`T0`.`chi_id_dossier` = :T0_chi_id_dossier
   AND `T0`.`chx_cible_dossier` = :T0_chx_cible_dossier);','function sql_50($par){
    $champs0=''
      `T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
      `T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_dossier
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chi_id_dossier`'',$par[''T0_chi_id_dossier'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_dossier'' => $tab0[0],
                ''T0.chx_cible_dossier'' => $tab0[1],
                ''T0.chp_nom_dossier'' => $tab0[2],
                ''T1.chi_id_cible'' => $tab0[3],
                ''T1.chp_nom_cible'' => $tab0[4],
                ''T1.chp_dossier_cible'' => $tab0[5],
                ''T1.chp_commentaire_cible'' => $tab0[6],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','dossier par id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,63,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,63,""],[4,"valeurs","f",1,0,42,48,1,7,2,2,49,26,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_dossier","c",3,2,72,85,5,0,2,0,62,63,""],[8,"champ","f",2,0,96,100,4,2,2,1,101,11,""],[9,"T0","c",3,2,104,105,8,0,1,0,101,10,""],[10,"chx_cible_dossier","c",3,2,111,127,8,0,2,0,101,63,""],[11,"champ","f",2,0,138,142,4,2,3,1,143,14,""],[12,"T0","c",3,2,146,147,11,0,1,0,143,13,""],[13,"chp_nom_dossier","c",3,2,153,167,11,0,2,0,143,63,""],[14,"champ","f",2,0,178,182,4,2,4,1,183,17,""],[15,"T1","c",3,2,186,187,14,0,1,0,183,16,""],[16,"chi_id_cible","c",3,2,193,204,14,0,2,0,183,63,""],[17,"champ","f",2,0,215,219,4,2,5,1,220,20,""],[18,"T1","c",3,2,223,224,17,0,1,0,220,19,""],[19,"chp_nom_cible","c",3,2,230,242,17,0,2,0,220,63,""],[20,"champ","f",2,0,253,257,4,2,6,1,258,23,""],[21,"T1","c",3,2,261,262,20,0,1,0,258,22,""],[22,"chp_dossier_cible","c",3,2,268,284,20,0,2,0,258,63,""],[23,"champ","f",2,0,295,299,4,2,7,1,300,63,""],[24,"T1","c",3,2,303,304,23,0,1,0,300,25,""],[25,"chp_commentaire_cible","c",3,2,310,330,23,0,2,0,300,63,""],[26,"provenance","f",1,0,343,352,1,2,3,5,353,51,""],[27,"table_reference","f",2,0,361,375,26,1,1,4,376,35,""],[28,"source","f",3,0,387,392,27,1,1,3,393,63,""],[29,"nom_de_la_table","f",4,0,395,409,28,3,1,2,410,63,""],[30,"tbl_dossiers","c",5,0,412,423,29,0,1,0,0,31,""],[31,"alias","f",5,0,427,431,29,1,2,1,432,33,""],[32,"T0","c",6,0,433,434,31,0,1,0,432,63,""],[33,"base","f",5,0,439,442,29,1,3,1,443,63,""],[34,"b1","c",6,0,444,445,33,0,1,0,443,63,""],[35,"jointure_gauche","f",2,0,466,480,26,2,2,4,481,63,""],[36,"source","f",3,0,492,497,35,1,1,3,498,43,""],[37,"nom_de_la_table","f",4,0,500,514,36,3,1,2,515,63,""],[38,"tbl_cibles","c",5,0,517,526,37,0,1,0,0,39,""],[39,"alias","f",5,0,530,534,37,1,2,1,535,41,""],[40,"T1","c",6,0,536,537,39,0,1,0,535,63,""],[41,"base","f",5,0,542,545,37,1,3,1,546,63,""],[42,"b1","c",6,0,547,548,41,0,1,0,546,63,""],[43,"contrainte","f",3,0,564,573,35,1,2,3,574,63,""],[44,"egal","f",4,0,576,579,43,2,1,2,580,63,""],[45,"champ","f",5,0,582,586,44,2,1,1,587,48,""],[46,"T1","c",6,0,589,590,45,0,1,0,0,47,""],[47,"chi_id_cible","c",6,0,594,605,45,0,2,0,0,63,""],[48,"champ","f",5,0,611,615,44,2,2,1,616,63,""],[49,"T0","c",6,0,618,619,48,0,1,0,0,50,""],[50,"chx_cible_dossier","c",6,0,623,639,48,0,2,0,0,63,""],[51,"conditions","f",1,0,663,672,1,1,4,4,673,63,""],[52,"et","f",2,0,681,682,51,2,1,3,683,63,""],[53,"egal","f",3,0,685,688,52,2,1,2,689,58,""],[54,"champ","f",4,0,691,695,53,2,1,1,696,57,""],[55,"T0","c",5,2,699,700,54,0,1,0,696,56,""],[56,"chi_id_dossier","c",5,2,706,719,54,0,2,0,696,63,""],[57,":T0_chi_id_dossier","c",4,0,726,743,53,0,2,0,0,63,""],[58,"egal","f",3,0,749,752,52,2,2,2,753,63,""],[59,"champ","f",4,0,755,759,58,2,1,1,760,62,""],[60,"T0","c",5,2,763,764,59,0,1,0,760,61,""],[61,"chx_cible_dossier","c",5,2,770,786,59,0,2,0,760,63,""],[62,":T0_chx_cible_dossier","c",4,0,793,813,58,0,2,0,0,63,""]]'),
('51','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_dossier` ) , champ( `T0` , `chx_cible_dossier` ) , champ( `T0` , `chp_nom_dossier` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chx_cible_dossier` ) , :T0_chx_cible_dossier ))
   )
)','SELECT 
`T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier`
 FROM b1.tbl_dossiers T0
WHERE (`T0`.`chx_cible_dossier` = :T0_chx_cible_dossier);','function sql_51($par){
    $champs0=''
      `T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_dossier'' => $tab0[0],
                ''T0.chx_cible_dossier'' => $tab0[1],
                ''T0.chp_nom_dossier'' => $tab0[2],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','tous les dossiers d''une cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,30,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,30,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,14,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_dossier","c",3,2,66,79,5,0,2,0,56,30,""],[8,"champ","f",2,0,86,90,4,2,2,1,91,11,""],[9,"T0","c",3,2,94,95,8,0,1,0,91,10,""],[10,"chx_cible_dossier","c",3,2,101,117,8,0,2,0,91,30,""],[11,"champ","f",2,0,124,128,4,2,3,1,129,30,""],[12,"T0","c",3,2,132,133,11,0,1,0,129,13,""],[13,"chp_nom_dossier","c",3,2,139,153,11,0,2,0,129,30,""],[14,"provenance","f",1,0,163,172,1,1,3,5,173,23,""],[15,"table_reference","f",2,0,181,195,14,1,1,4,196,30,""],[16,"source","f",3,0,207,212,15,1,1,3,213,30,""],[17,"nom_de_la_table","f",4,0,215,229,16,3,1,2,230,30,""],[18,"tbl_dossiers","c",5,0,232,243,17,0,1,0,0,19,""],[19,"alias","f",5,0,247,251,17,1,2,1,252,21,""],[20,"T0","c",6,0,253,254,19,0,1,0,252,30,""],[21,"base","f",5,0,259,262,17,1,3,1,263,30,""],[22,"b1","c",6,0,264,265,21,0,1,0,263,30,""],[23,"conditions","f",1,0,288,297,1,1,4,4,298,30,""],[24,"et","f",2,0,306,307,23,1,1,3,308,30,""],[25,"egal","f",3,0,310,313,24,2,1,2,314,30,""],[26,"champ","f",4,0,316,320,25,2,1,1,321,29,""],[27,"T0","c",5,2,324,325,26,0,1,0,321,28,""],[28,"chx_cible_dossier","c",5,2,331,347,26,0,2,0,321,30,""],[29,":T0_chx_cible_dossier","c",4,0,354,374,25,0,2,0,0,30,""]]'),
('52','1','insert','insérer(
   base_de_reference(1),
   valeurs( affecte( champ( `chx_cible_dossier` ) , :chx_cible_dossier ) , affecte( champ( `chp_nom_dossier` ) , :chp_nom_dossier )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , base(b1) ))
      )
   ),
   complements( ignorer())
)','INSERT  OR IGNORE INTO b1.`tbl_dossiers`(
    `chx_cible_dossier` , 
    `chp_nom_dossier`
) VALUES (
    :chx_cible_dossier , 
    :chp_nom_dossier
);','function sql_52($par){
    $texte_sql_52=''
      INSERT  OR IGNORE  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_dossiers`(
         `chx_cible_dossier` , 
         `chp_nom_dossier`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_dossier'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_dossier'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_52.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_52 = <pre>'' . $texte_sql_52 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_52);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_52()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,4,1,6,7,22,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,22,""],[4,"valeurs","f",1,0,37,43,1,2,2,3,44,13,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,9,""],[6,"champ","f",3,0,55,59,5,1,1,1,60,8,""],[7,"chx_cible_dossier","c",4,2,63,79,6,0,1,0,60,22,""],[8,":chx_cible_dossier","c",3,0,86,103,5,0,2,0,0,22,""],[9,"affecte","f",2,0,109,115,4,2,2,2,116,22,""],[10,"champ","f",3,0,118,122,9,1,1,1,123,12,""],[11,"chp_nom_dossier","c",4,2,126,140,10,0,1,0,123,22,""],[12,":chp_nom_dossier","c",3,0,147,162,9,0,2,0,0,22,""],[13,"provenance","f",1,0,171,180,1,1,3,5,181,20,""],[14,"table_reference","f",2,0,189,203,13,1,1,4,204,22,""],[15,"source","f",3,0,215,220,14,1,1,3,221,22,""],[16,"nom_de_la_table","f",4,0,223,237,15,2,1,2,238,22,""],[17,"tbl_dossiers","c",5,0,240,251,16,0,1,0,0,18,""],[18,"base","f",5,0,255,258,16,1,2,1,259,22,""],[19,"b1","c",6,0,260,261,18,0,1,0,259,22,""],[20,"complements","f",1,0,284,294,1,1,4,1,295,22,""],[21,"ignorer","f",2,0,297,303,20,0,1,0,304,22,""]]'),
('53','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_dossier` ) , champ( `T0` , `chp_nom_dossier` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_dossier` ) , :T0_chi_id_dossier ) , egal( champ( `T0` , `chx_cible_dossier` ) , :T0_chx_cible_dossier ) , comme( champ( `T0` , `chp_nom_dossier` ) , :T0_chp_nom_dossier ))
   ),
   complements(
      trier_par( ( champ( `T0` , `chp_nom_dossier` ) , croissant() ) , ( champ( `T0` , `chi_id_dossier` ) , décroissant() )),
      limité_à( quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_dossier` , `T0`.`chp_nom_dossier`
 FROM b1.tbl_dossiers T0
WHERE (`T0`.`chi_id_dossier` = :T0_chi_id_dossier
   AND `T0`.`chx_cible_dossier` = :T0_chx_cible_dossier
   AND `T0`.`chp_nom_dossier` LIKE :T0_chp_nom_dossier) 
ORDER BY `T0`.`chp_nom_dossier` ASC, `T0`.`chi_id_dossier` DESC  
LIMIT :quantitee OFFSET :debut ;','function sql_53($par){
    $champs0=''
      `T0`.`chi_id_dossier` , `T0`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    if(($par[''T0_chi_id_dossier''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_dossier`'',$par[''T0_chi_id_dossier'']);
    }
    if(($par[''T0_chx_cible_dossier''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    }
    if(($par[''T0_chp_nom_dossier''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_dossier` LIKE ''.sq1($par[''T0_chp_nom_dossier'']).''''.PHP_EOL;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_nom_dossier` ASC, `T0`.`chi_id_dossier` DESC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_dossier'' => $tab0[0],
                ''T0.chp_nom_dossier'' => $tab0[1],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => __xsu       ,
           __xva  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => __xer ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','dossiers','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,54,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,54,""],[4,"valeurs","f",1,0,42,48,1,2,2,2,49,11,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_dossier","c",3,2,66,79,5,0,2,0,56,54,""],[8,"champ","f",2,0,86,90,4,2,2,1,91,54,""],[9,"T0","c",3,2,94,95,8,0,1,0,91,10,""],[10,"chp_nom_dossier","c",3,2,101,115,8,0,2,0,91,54,""],[11,"provenance","f",1,0,125,134,1,1,3,5,135,20,""],[12,"table_reference","f",2,0,143,157,11,1,1,4,158,54,""],[13,"source","f",3,0,169,174,12,1,1,3,175,54,""],[14,"nom_de_la_table","f",4,0,177,191,13,3,1,2,192,54,""],[15,"tbl_dossiers","c",5,0,194,205,14,0,1,0,0,16,""],[16,"alias","f",5,0,209,213,14,1,2,1,214,18,""],[17,"T0","c",6,0,215,216,16,0,1,0,214,54,""],[18,"base","f",5,0,221,224,14,1,3,1,225,54,""],[19,"b1","c",6,0,226,227,18,0,1,0,225,54,""],[20,"conditions","f",1,0,250,259,1,1,4,4,260,37,""],[21,"et","f",2,0,268,269,20,3,1,3,270,54,""],[22,"egal","f",3,0,272,275,21,2,1,2,276,27,""],[23,"champ","f",4,0,278,282,22,2,1,1,283,26,""],[24,"T0","c",5,2,286,287,23,0,1,0,283,25,""],[25,"chi_id_dossier","c",5,2,293,306,23,0,2,0,283,54,""],[26,":T0_chi_id_dossier","c",4,0,313,330,22,0,2,0,0,54,""],[27,"egal","f",3,0,336,339,21,2,2,2,340,32,""],[28,"champ","f",4,0,342,346,27,2,1,1,347,31,""],[29,"T0","c",5,2,350,351,28,0,1,0,347,30,""],[30,"chx_cible_dossier","c",5,2,357,373,28,0,2,0,347,54,""],[31,":T0_chx_cible_dossier","c",4,0,380,400,27,0,2,0,0,54,""],[32,"comme","f",3,0,406,410,21,2,3,2,411,54,""],[33,"champ","f",4,0,413,417,32,2,1,1,418,36,""],[34,"T0","c",5,2,421,422,33,0,1,0,418,35,""],[35,"chp_nom_dossier","c",5,2,428,442,33,0,2,0,418,54,""],[36,":T0_chp_nom_dossier","c",4,0,449,467,32,0,2,0,0,54,""],[37,"complements","f",1,0,481,491,1,2,5,4,492,54,""],[38,"trier_par","f",2,0,500,508,37,2,1,3,509,49,""],[39,"","f",3,0,500,508,38,2,1,2,511,44,""],[40,"champ","f",4,0,513,517,39,2,1,1,518,43,""],[41,"T0","c",5,2,521,522,40,0,1,0,518,42,""],[42,"chp_nom_dossier","c",5,2,528,542,40,0,2,0,518,54,""],[43,"croissant","f",4,0,549,557,39,0,2,0,558,54,""],[44,"","f",3,0,549,557,38,2,2,2,565,54,""],[45,"champ","f",4,0,567,571,44,2,1,1,572,48,""],[46,"T0","c",5,2,575,576,45,0,1,0,572,47,""],[47,"chi_id_dossier","c",5,2,582,595,45,0,2,0,572,54,""],[48,"d\u00e9croissant","f",4,0,602,612,44,0,2,0,613,54,""],[49,"limit\u00e9_\u00e0","f",2,0,626,633,37,2,2,2,634,54,""],[50,"quantit\u00e9","f",3,0,636,643,49,1,1,1,644,52,""],[51,":quantitee","c",4,0,645,654,50,0,1,0,644,54,""],[52,"d\u00e9but","f",3,0,659,663,49,1,2,1,664,54,""],[53,":debut","c",4,0,665,670,52,0,1,0,664,54,""]]'),
('54','1','insert','insérer(
   base_de_reference(1),
   valeurs(
      affecte( champ( `chx_cible_id_source` ) , :chx_cible_id_source),
      affecte( champ( `chp_nom_source` ) , :chp_nom_source),
      affecte( champ( `chp_commentaire_source` ) , :chp_commentaire_source),
      affecte( champ( `chx_dossier_id_source` ) , :chx_dossier_id_source),
      affecte( champ( `chp_rev_source` ) , :chp_rev_source),
      affecte( champ( `chp_genere_source` ) , :chp_genere_source),
      affecte( champ( `chp_type_source` ) , :chp_type_source)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , base(b1) ))
      )
   )
)','INSERT INTO b1.`tbl_sources`(
    `chx_cible_id_source` , 
    `chp_nom_source` , 
    `chp_commentaire_source` , 
    `chx_dossier_id_source` , 
    `chp_rev_source` , 
    `chp_genere_source` , 
    `chp_type_source`
) VALUES (
    :chx_cible_id_source , 
    :chp_nom_source , 
    :chp_commentaire_source , 
    :chx_dossier_id_source , 
    :chp_rev_source , 
    :chp_genere_source , 
    :chp_type_source
);','function sql_54($par){
    $texte_sql_54=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_sources`(
         `chx_cible_id_source` , 
         `chp_nom_source` , 
         `chp_commentaire_source` , 
         `chx_dossier_id_source` , 
         `chp_rev_source` , 
         `chp_genere_source` , 
         `chp_type_source`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_id_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_dossier_id_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_rev_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_genere_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_type_source'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_54.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_54 = <pre>'' . $texte_sql_54 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_54);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => __xer, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_54()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => __xsu,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,40,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,4,""],[3,"1","c",2,0,30,30,2,0,1,0,29,40,""],[4,"valeurs","f",1,0,37,43,1,7,2,3,44,33,""],[5,"affecte","f",2,0,52,58,4,2,1,2,59,9,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,8,""],[7,"chx_cible_id_source","c",4,2,69,87,6,0,1,0,66,40,""],[8,":chx_cible_id_source","c",3,0,94,113,5,0,2,0,66,40,""],[9,"affecte","f",2,0,123,129,4,2,2,2,130,13,""],[10,"champ","f",3,0,132,136,9,1,1,1,137,12,""],[11,"chp_nom_source","c",4,2,140,153,10,0,1,0,137,40,""],[12,":chp_nom_source","c",3,0,160,174,9,0,2,0,137,40,""],[13,"affecte","f",2,0,184,190,4,2,3,2,191,17,""],[14,"champ","f",3,0,193,197,13,1,1,1,198,16,""],[15,"chp_commentaire_source","c",4,2,201,222,14,0,1,0,198,40,""],[16,":chp_commentaire_source","c",3,0,229,251,13,0,2,0,198,40,""],[17,"affecte","f",2,0,261,267,4,2,4,2,268,21,""],[18,"champ","f",3,0,270,274,17,1,1,1,275,20,""],[19,"chx_dossier_id_source","c",4,2,278,298,18,0,1,0,275,40,""],[20,":chx_dossier_id_source","c",3,0,305,326,17,0,2,0,275,40,""],[21,"affecte","f",2,0,336,342,4,2,5,2,343,25,""],[22,"champ","f",3,0,345,349,21,1,1,1,350,24,""],[23,"chp_rev_source","c",4,2,353,366,22,0,1,0,350,40,""],[24,":chp_rev_source","c",3,0,373,387,21,0,2,0,350,40,""],[25,"affecte","f",2,0,397,403,4,2,6,2,404,29,""],[26,"champ","f",3,0,406,410,25,1,1,1,411,28,""],[27,"chp_genere_source","c",4,2,414,430,26,0,1,0,411,40,""],[28,":chp_genere_source","c",3,0,437,454,25,0,2,0,411,40,""],[29,"affecte","f",2,0,464,470,4,2,7,2,471,40,""],[30,"champ","f",3,0,473,477,29,1,1,1,478,32,""],[31,"chp_type_source","c",4,2,481,495,30,0,1,0,478,40,""],[32,":chp_type_source","c",3,0,502,517,29,0,2,0,478,40,""],[33,"provenance","f",1,0,529,538,1,1,3,5,539,40,""],[34,"table_reference","f",2,0,547,561,33,1,1,4,562,40,""],[35,"source","f",3,0,573,578,34,1,1,3,579,40,""],[36,"nom_de_la_table","f",4,0,581,595,35,2,1,2,596,40,""],[37,"tbl_sources","c",5,0,598,608,36,0,1,0,0,38,""],[38,"base","f",5,0,612,615,36,1,2,1,616,40,""],[39,"b1","c",6,0,617,618,38,0,1,0,616,40,""]]'),
('55','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chx_cible_dossier` ) , :n_chx_cible_dossier ) , affecte( champ( `chp_nom_dossier` ) , :n_chp_nom_dossier )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_dossier` ) , :c_chi_id_dossier ) , egal( champ( `chx_cible_dossier` ) , :c_chx_cible_dossier ))
   )
)','UPDATE b1.tbl_dossiers SET `chx_cible_dossier` = :n_chx_cible_dossier , `chp_nom_dossier` = :n_chp_nom_dossier
WHERE (`chi_id_dossier` = :c_chi_id_dossier
   AND `chx_cible_dossier` = :c_chx_cible_dossier) ;','function sql_55($par){
    $texte_sql_55=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_dossiers` SET ''.PHP_EOL;

    if($par[''n_chx_cible_dossier'']==='''' || $par[''n_chx_cible_dossier'']===NULL ){
        $texte_sql_55.=''    `chx_cible_dossier` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_55.=''    `chx_cible_dossier` = ''.sq0($par[''n_chx_cible_dossier'']).'' , ''.PHP_EOL;
    }
    if($par[''n_chp_nom_dossier'']==='''' || $par[''n_chp_nom_dossier'']===NULL ){
        $texte_sql_55.=''    `chp_nom_dossier` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_55.=''    `chp_nom_dossier` = \''''.sq0($par[''n_chp_nom_dossier'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_dossier` = ''.sq1($par[''c_chi_id_dossier'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_dossier` = ''.sq1($par[''c_chx_cible_dossier'']).''''.PHP_EOL;
    $texte_sql_55.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_55 = <pre>'' . $texte_sql_55 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_55);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_55()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,30,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,30,""],[4,"valeurs","f",1,0,38,44,1,2,2,3,45,13,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,9,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chx_cible_dossier","c",4,2,64,80,6,0,1,0,61,30,""],[8,":n_chx_cible_dossier","c",3,0,87,106,5,0,2,0,0,30,""],[9,"affecte","f",2,0,112,118,4,2,2,2,119,30,""],[10,"champ","f",3,0,121,125,9,1,1,1,126,12,""],[11,"chp_nom_dossier","c",4,2,129,143,10,0,1,0,126,30,""],[12,":n_chp_nom_dossier","c",3,0,150,167,9,0,2,0,0,30,""],[13,"provenance","f",1,0,176,185,1,1,3,5,186,20,""],[14,"table_reference","f",2,0,194,208,13,1,1,4,209,30,""],[15,"source","f",3,0,220,225,14,1,1,3,226,30,""],[16,"nom_de_la_table","f",4,0,228,242,15,2,1,2,243,30,""],[17,"tbl_dossiers","c",5,0,245,256,16,0,1,0,0,18,""],[18,"base","f",5,0,260,263,16,1,2,1,264,30,""],[19,"b1","c",6,0,265,266,18,0,1,0,264,30,""],[20,"conditions","f",1,0,289,298,1,1,4,4,299,30,""],[21,"et","f",2,0,307,308,20,2,1,3,309,30,""],[22,"egal","f",3,0,311,314,21,2,1,2,315,26,""],[23,"champ","f",4,0,317,321,22,1,1,1,322,25,""],[24,"chi_id_dossier","c",5,2,325,338,23,0,1,0,322,30,""],[25,":c_chi_id_dossier","c",4,0,345,361,22,0,2,0,0,30,""],[26,"egal","f",3,0,367,370,21,2,2,2,371,30,""],[27,"champ","f",4,0,373,377,26,1,1,1,378,29,""],[28,"chx_cible_dossier","c",5,2,381,397,27,0,1,0,378,30,""],[29,":c_chx_cible_dossier","c",4,0,404,423,26,0,2,0,0,30,""]]'),
('56','1','select','sélectionner(
   base_de_reference(1),
   valeurs( compter( tous_les_champs() )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chx_cible_id_source` ) , :T0_chx_cible_id_source ) , egal( champ( `T0` , `chx_dossier_id_source` ) , :T0_chx_dossier_id_source ))
   )
)','SELECT 
count( * )
 FROM b1.tbl_sources T0
WHERE (`T0`.`chx_cible_id_source` = :T0_chx_cible_id_source
   AND `T0`.`chx_dossier_id_source` = :T0_chx_dossier_id_source);','function sql_56($par){
    $champs0=''
      count( * )
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_source`'',$par[''T0_chx_dossier_id_source'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''0'' => $tab0[0],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','comptage des sources d''un dossier','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,28,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,28,""],[4,"valeurs","f",1,0,42,48,1,1,2,2,49,7,""],[5,"compter","f",2,0,51,57,4,1,1,1,58,28,""],[6,"tous_les_champs","f",3,0,60,74,5,0,1,0,75,28,""],[7,"provenance","f",1,0,85,94,1,1,3,5,95,16,""],[8,"table_reference","f",2,0,103,117,7,1,1,4,118,28,""],[9,"source","f",3,0,129,134,8,1,1,3,135,28,""],[10,"nom_de_la_table","f",4,0,137,151,9,3,1,2,152,28,""],[11,"tbl_sources","c",5,0,154,164,10,0,1,0,0,12,""],[12,"alias","f",5,0,168,172,10,1,2,1,173,14,""],[13,"T0","c",6,0,174,175,12,0,1,0,173,28,""],[14,"base","f",5,0,180,183,10,1,3,1,184,28,""],[15,"b1","c",6,0,185,186,14,0,1,0,184,28,""],[16,"conditions","f",1,0,209,218,1,1,4,4,219,28,""],[17,"et","f",2,0,227,228,16,2,1,3,229,28,""],[18,"egal","f",3,0,231,234,17,2,1,2,235,23,""],[19,"champ","f",4,0,237,241,18,2,1,1,242,22,""],[20,"T0","c",5,2,245,246,19,0,1,0,242,21,""],[21,"chx_cible_id_source","c",5,2,252,270,19,0,2,0,242,28,""],[22,":T0_chx_cible_id_source","c",4,0,277,299,18,0,2,0,0,28,""],[23,"egal","f",3,0,305,308,17,2,2,2,309,28,""],[24,"champ","f",4,0,311,315,23,2,1,1,316,27,""],[25,"T0","c",5,2,319,320,24,0,1,0,316,26,""],[26,"chx_dossier_id_source","c",5,2,326,346,24,0,2,0,316,28,""],[27,":T0_chx_dossier_id_source","c",4,0,353,377,23,0,2,0,0,28,""]]'),
('57','1','select','sélectionner(
   base_de_reference(1),
   valeurs( compter( tous_les_champs() )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_bdds , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chx_dossier_id_basedd` ) , :T0_chx_dossier_id_basedd ) , egal( champ( `T0` , `chx_cible_id_basedd` ) , :T0_chx_cible_id_basedd ))
   )
)','SELECT 
count( * )
 FROM b1.tbl_bdds T0
WHERE (`T0`.`chx_dossier_id_basedd` = :T0_chx_dossier_id_basedd
   AND `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd);','function sql_57($par){
    $champs0=''
      count( * )
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_basedd`'',$par[''T0_chx_dossier_id_basedd'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''0'' => $tab0[0],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','comptage des bases rattachées à un dossier','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,28,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,28,""],[4,"valeurs","f",1,0,42,48,1,1,2,2,49,7,""],[5,"compter","f",2,0,51,57,4,1,1,1,58,28,""],[6,"tous_les_champs","f",3,0,60,74,5,0,1,0,75,28,""],[7,"provenance","f",1,0,85,94,1,1,3,5,95,16,""],[8,"table_reference","f",2,0,103,117,7,1,1,4,118,28,""],[9,"source","f",3,0,129,134,8,1,1,3,135,28,""],[10,"nom_de_la_table","f",4,0,137,151,9,3,1,2,152,28,""],[11,"tbl_bdds","c",5,0,154,161,10,0,1,0,0,12,""],[12,"alias","f",5,0,165,169,10,1,2,1,170,14,""],[13,"T0","c",6,0,171,172,12,0,1,0,170,28,""],[14,"base","f",5,0,177,180,10,1,3,1,181,28,""],[15,"b1","c",6,0,182,183,14,0,1,0,181,28,""],[16,"conditions","f",1,0,206,215,1,1,4,4,216,28,""],[17,"et","f",2,0,224,225,16,2,1,3,226,28,""],[18,"egal","f",3,0,228,231,17,2,1,2,232,23,""],[19,"champ","f",4,0,234,238,18,2,1,1,239,22,""],[20,"T0","c",5,2,242,243,19,0,1,0,239,21,""],[21,"chx_dossier_id_basedd","c",5,2,249,269,19,0,2,0,239,28,""],[22,":T0_chx_dossier_id_basedd","c",4,0,276,300,18,0,2,0,0,28,""],[23,"egal","f",3,0,306,309,17,2,2,2,310,28,""],[24,"champ","f",4,0,312,316,23,2,1,1,317,27,""],[25,"T0","c",5,2,320,321,24,0,1,0,317,26,""],[26,"chx_cible_id_basedd","c",5,2,327,345,24,0,2,0,317,28,""],[27,":T0_chx_cible_id_basedd","c",4,0,352,374,23,0,2,0,0,28,""]]'),
('58','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_dossier` ) , :chi_id_dossier ) , egal( champ( `chx_cible_dossier` ) , :chx_cible_dossier ))
   )
)','DELETE FROM b1.tbl_dossiers
WHERE (`chi_id_dossier` = :chi_id_dossier
   AND `chx_cible_dossier` = :chx_cible_dossier) ;','function sql_58($par){
    $texte_sql_58=''
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers
          WHERE (`chi_id_dossier` = ''.sq1($par[''chi_id_dossier'']).'' AND `chx_cible_dossier` = ''.sq1($par[''chx_cible_dossier'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_58 = <pre>'' . $texte_sql_58 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_58);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_58()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','dossier par id et cible','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,21,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,4,""],[3,"1","c",2,0,32,32,2,0,1,0,31,21,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,11,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,21,""],[6,"source","f",3,0,83,88,5,1,1,3,89,21,""],[7,"nom_de_la_table","f",4,0,91,105,6,2,1,2,106,21,""],[8,"tbl_dossiers","c",5,0,108,119,7,0,1,0,0,9,""],[9,"base","f",5,0,123,126,7,1,2,1,127,21,""],[10,"b1","c",6,0,128,129,9,0,1,0,127,21,""],[11,"conditions","f",1,0,152,161,1,1,3,4,162,21,""],[12,"et","f",2,0,170,171,11,2,1,3,172,21,""],[13,"egal","f",3,0,174,177,12,2,1,2,178,17,""],[14,"champ","f",4,0,180,184,13,1,1,1,185,16,""],[15,"chi_id_dossier","c",5,2,188,201,14,0,1,0,185,21,""],[16,":chi_id_dossier","c",4,0,208,222,13,0,2,0,0,21,""],[17,"egal","f",3,0,228,231,12,2,2,2,232,21,""],[18,"champ","f",4,0,234,238,17,1,1,1,239,20,""],[19,"chx_cible_dossier","c",5,2,242,258,18,0,1,0,239,21,""],[20,":chx_cible_dossier","c",4,0,265,282,17,0,2,0,0,21,""]]'),
('59','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chp_nom_source` ) , champ( `T0` , `chi_id_source` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et(
         #(),
         dans( champ( `T0` , `chp_nom_source` ) , (:T0_chp_nom_source)),
         egal( champ( `T0` , `chx_cible_id_source` ) , :T0_chx_cible_id_source),
         egal( champ( `T0` , `chx_dossier_id_source` ) , :T0_chx_dossier_id_source)
      )
   )
)','SELECT 
`T0`.`chp_nom_source` , `T0`.`chi_id_source`
 FROM b1.tbl_sources T0
WHERE ( /* */ `T0`.`chp_nom_source` IN (:T0_chp_nom_source)
   AND `T0`.`chx_cible_id_source` = :T0_chx_cible_id_source
   AND `T0`.`chx_dossier_id_source` = :T0_chx_dossier_id_source);','function sql_59($par){
    $champs0=''
      `T0`.`chp_nom_source` , `T0`.`chi_id_source`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `T0`.`chp_nom_source` IN (''.sq0($par[''T0_chp_nom_source'']).'')''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_source`'',$par[''T0_chx_dossier_id_source'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chp_nom_source'' => $tab0[0],
                ''T0.chi_id_source'' => $tab0[1],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','sources d''un dossier par liste de nom','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,39,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,39,""],[4,"valeurs","f",1,0,42,48,1,2,2,2,49,11,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chp_nom_source","c",3,2,66,79,5,0,2,0,56,39,""],[8,"champ","f",2,0,86,90,4,2,2,1,91,39,""],[9,"T0","c",3,2,94,95,8,0,1,0,91,10,""],[10,"chi_id_source","c",3,2,101,113,8,0,2,0,91,39,""],[11,"provenance","f",1,0,123,132,1,1,3,5,133,20,""],[12,"table_reference","f",2,0,141,155,11,1,1,4,156,39,""],[13,"source","f",3,0,167,172,12,1,1,3,173,39,""],[14,"nom_de_la_table","f",4,0,175,189,13,3,1,2,190,39,""],[15,"tbl_sources","c",5,0,192,202,14,0,1,0,0,16,""],[16,"alias","f",5,0,206,210,14,1,2,1,211,18,""],[17,"T0","c",6,0,212,213,16,0,1,0,211,39,""],[18,"base","f",5,0,218,221,14,1,3,1,222,39,""],[19,"b1","c",6,0,223,224,18,0,1,0,222,39,""],[20,"conditions","f",1,0,247,256,1,1,4,4,257,39,""],[21,"et","f",2,0,265,266,20,4,1,3,267,39,""],[22,"#","f",3,0,278,278,21,0,1,0,279,23,""],[23,"dans","f",3,0,292,295,21,2,2,2,296,29,""],[24,"champ","f",4,0,298,302,23,2,1,1,303,27,""],[25,"T0","c",5,2,306,307,24,0,1,0,303,26,""],[26,"chp_nom_source","c",5,2,313,326,24,0,2,0,303,39,""],[27,"","f",4,0,313,326,23,1,2,1,333,39,""],[28,":T0_chp_nom_source","c",5,0,334,351,27,0,1,0,333,39,""],[29,"egal","f",3,0,365,368,21,2,3,2,369,34,""],[30,"champ","f",4,0,371,375,29,2,1,1,376,33,""],[31,"T0","c",5,2,379,380,30,0,1,0,376,32,""],[32,"chx_cible_id_source","c",5,2,386,404,30,0,2,0,376,39,""],[33,":T0_chx_cible_id_source","c",4,0,411,433,29,0,2,0,376,39,""],[34,"egal","f",3,0,446,449,21,2,4,2,450,39,""],[35,"champ","f",4,0,452,456,34,2,1,1,457,38,""],[36,"T0","c",5,2,460,461,35,0,1,0,457,37,""],[37,"chx_dossier_id_source","c",5,2,467,487,35,0,2,0,457,39,""],[38,":T0_chx_dossier_id_source","c",4,0,494,518,34,0,2,0,457,39,""]]'),
('60','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chp_nom_dossier` ) , champ( `T0` , `chi_id_dossier` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_dossiers , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et(
         #(),
         dans( champ( `T0` , `chp_nom_dossier` ) , (:T0_chp_nom_dossier)),
         egal( champ( `T0` , `chx_cible_dossier` ) , :T0_chx_cible_dossier)
      )
   )
)','SELECT 
`T0`.`chp_nom_dossier` , `T0`.`chi_id_dossier`
 FROM b1.tbl_dossiers T0
WHERE ( /* */ `T0`.`chp_nom_dossier` IN (:T0_chp_nom_dossier)
   AND `T0`.`chx_cible_dossier` = :T0_chx_cible_dossier);','function sql_60($par){
    $champs0=''
      `T0`.`chp_nom_dossier` , `T0`.`chi_id_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `T0`.`chp_nom_dossier` IN (''.sq0($par[''T0_chp_nom_dossier'']).'')''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chp_nom_dossier'' => $tab0[0],
                ''T0.chi_id_dossier'' => $tab0[1],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','dossiers pas liste de noms','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,34,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,34,""],[4,"valeurs","f",1,0,42,48,1,2,2,2,49,11,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chp_nom_dossier","c",3,2,66,80,5,0,2,0,56,34,""],[8,"champ","f",2,0,87,91,4,2,2,1,92,34,""],[9,"T0","c",3,2,95,96,8,0,1,0,92,10,""],[10,"chi_id_dossier","c",3,2,102,115,8,0,2,0,92,34,""],[11,"provenance","f",1,0,125,134,1,1,3,5,135,20,""],[12,"table_reference","f",2,0,143,157,11,1,1,4,158,34,""],[13,"source","f",3,0,169,174,12,1,1,3,175,34,""],[14,"nom_de_la_table","f",4,0,177,191,13,3,1,2,192,34,""],[15,"tbl_dossiers","c",5,0,194,205,14,0,1,0,0,16,""],[16,"alias","f",5,0,209,213,14,1,2,1,214,18,""],[17,"T0","c",6,0,215,216,16,0,1,0,214,34,""],[18,"base","f",5,0,221,224,14,1,3,1,225,34,""],[19,"b1","c",6,0,226,227,18,0,1,0,225,34,""],[20,"conditions","f",1,0,250,259,1,1,4,4,260,34,""],[21,"et","f",2,0,268,269,20,3,1,3,270,34,""],[22,"#","f",3,0,281,281,21,0,1,0,282,23,""],[23,"dans","f",3,0,295,298,21,2,2,2,299,29,""],[24,"champ","f",4,0,301,305,23,2,1,1,306,27,""],[25,"T0","c",5,2,309,310,24,0,1,0,306,26,""],[26,"chp_nom_dossier","c",5,2,316,330,24,0,2,0,306,34,""],[27,"","f",4,0,316,330,23,1,2,1,337,34,""],[28,":T0_chp_nom_dossier","c",5,0,338,356,27,0,1,0,337,34,""],[29,"egal","f",3,0,370,373,21,2,3,2,374,34,""],[30,"champ","f",4,0,376,380,29,2,1,1,381,33,""],[31,"T0","c",5,2,384,385,30,0,1,0,381,32,""],[32,"chx_cible_dossier","c",5,2,391,407,30,0,2,0,381,34,""],[33,":T0_chx_cible_dossier","c",4,0,414,434,29,0,2,0,381,34,""]]'),
('61','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_source`),
      champ( `T0` , `chx_cible_id_source`),
      champ( `T0` , `chp_nom_source`),
      champ( `T0` , `chp_commentaire_source`),
      champ( `T0` , `chx_dossier_id_source`),
      champ( `T0` , `chp_rev_source`),
      champ( `T0` , `chp_genere_source`),
      champ( `T0` , `chp_type_source`),
      champ( `T1` , `chi_id_cible`),
      champ( `T1` , `chp_nom_cible`),
      champ( `T1` , `chp_dossier_cible`),
      champ( `T1` , `chp_commentaire_cible`),
      champ( `T2` , `chi_id_dossier`),
      champ( `T2` , `chx_cible_dossier`),
      champ( `T2` , `chp_nom_dossier`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , alias(T0) , base(b1) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_cibles , alias(T1) , base(b1) )),
         contrainte( egal( champ( T1 , chi_id_cible ) , champ( T0 , chx_cible_id_source ) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_dossiers , alias(T2) , base(b1) )),
         contrainte( egal( champ( T2 , chi_id_dossier ) , champ( T0 , chx_dossier_id_source ) ))
      )
   ),
   conditions(
      et(
         egal( champ( `T0` , `chx_cible_id_source` ) , :T0_chx_cible_id_source),
         egal( champ( `T0` , `chi_id_source` ) , :T0_chi_id_source),
         comme( champ( `T0` , `chp_nom_source` ) , :T0_chp_nom_source),
         comme( champ( `T0` , `chp_type_source` ) , :T0_chp_type_source),
         comme( champ( `T2` , `chp_nom_dossier` ) , :T2_chp_nom_dossier),
         egal( champ( `T0` , `chx_dossier_id_source` ) , :T0_chx_dossier_id_source)
      )
   ),
   complements(
      trier_par( ( champ( `T0` , `chp_nom_source` ) , croissant() )),
      limité_à( quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
`T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
`T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
 FROM b1.tbl_sources T0
 LEFT JOIN b1.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

 LEFT JOIN b1.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source

WHERE (`T0`.`chx_cible_id_source` = :T0_chx_cible_id_source
   AND `T0`.`chi_id_source` = :T0_chi_id_source
   AND `T0`.`chp_nom_source` LIKE :T0_chp_nom_source
   AND `T0`.`chp_type_source` LIKE :T0_chp_type_source
   AND `T2`.`chp_nom_dossier` LIKE :T2_chp_nom_dossier
   AND `T0`.`chx_dossier_id_source` = :T0_chx_dossier_id_source) 
ORDER BY `T0`.`chp_nom_source` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_61($par){
    $champs0=''
      `T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
      `T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
      `T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    if(($par[''T0_chx_cible_id_source''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    }
    if(($par[''T0_chi_id_source''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_source`'',$par[''T0_chi_id_source'']);
    }
    if(($par[''T0_chp_nom_source''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_source` LIKE ''.sq1($par[''T0_chp_nom_source'']).''''.PHP_EOL;
    }
    if(($par[''T0_chp_type_source''] !== '''')){
        $where0.='' AND `T0`.`chp_type_source` LIKE ''.sq1($par[''T0_chp_type_source'']).''''.PHP_EOL;
    }
    if(($par[''T2_chp_nom_dossier''] !== '''')){
        $where0.='' AND `T2`.`chp_nom_dossier` LIKE ''.sq1($par[''T2_chp_nom_dossier'']).''''.PHP_EOL;
    }
    if(($par[''T0_chx_dossier_id_source''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_source`'',$par[''T0_chx_dossier_id_source'']);
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_nom_source` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_source'' => $tab0[0],
                ''T0.chx_cible_id_source'' => $tab0[1],
                ''T0.chp_nom_source'' => $tab0[2],
                ''T0.chp_commentaire_source'' => $tab0[3],
                ''T0.chx_dossier_id_source'' => $tab0[4],
                ''T0.chp_rev_source'' => $tab0[5],
                ''T0.chp_genere_source'' => $tab0[6],
                ''T0.chp_type_source'' => $tab0[7],
                ''T1.chi_id_cible'' => $tab0[8],
                ''T1.chp_nom_cible'' => $tab0[9],
                ''T1.chp_dossier_cible'' => $tab0[10],
                ''T1.chp_commentaire_cible'' => $tab0[11],
                ''T2.chi_id_dossier'' => $tab0[12],
                ''T2.chx_cible_dossier'' => $tab0[13],
                ''T2.chp_nom_dossier'' => $tab0[14],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => __xsu       ,
           __xva  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => __xer ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','sources','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,135,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,135,""],[4,"valeurs","f",1,0,42,48,1,15,2,2,49,50,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_source","c",3,2,72,84,5,0,2,0,62,135,""],[8,"champ","f",2,0,95,99,4,2,2,1,100,11,""],[9,"T0","c",3,2,103,104,8,0,1,0,100,10,""],[10,"chx_cible_id_source","c",3,2,110,128,8,0,2,0,100,135,""],[11,"champ","f",2,0,139,143,4,2,3,1,144,14,""],[12,"T0","c",3,2,147,148,11,0,1,0,144,13,""],[13,"chp_nom_source","c",3,2,154,167,11,0,2,0,144,135,""],[14,"champ","f",2,0,178,182,4,2,4,1,183,17,""],[15,"T0","c",3,2,186,187,14,0,1,0,183,16,""],[16,"chp_commentaire_source","c",3,2,193,214,14,0,2,0,183,135,""],[17,"champ","f",2,0,225,229,4,2,5,1,230,20,""],[18,"T0","c",3,2,233,234,17,0,1,0,230,19,""],[19,"chx_dossier_id_source","c",3,2,240,260,17,0,2,0,230,135,""],[20,"champ","f",2,0,271,275,4,2,6,1,276,23,""],[21,"T0","c",3,2,279,280,20,0,1,0,276,22,""],[22,"chp_rev_source","c",3,2,286,299,20,0,2,0,276,135,""],[23,"champ","f",2,0,310,314,4,2,7,1,315,26,""],[24,"T0","c",3,2,318,319,23,0,1,0,315,25,""],[25,"chp_genere_source","c",3,2,325,341,23,0,2,0,315,135,""],[26,"champ","f",2,0,352,356,4,2,8,1,357,29,""],[27,"T0","c",3,2,360,361,26,0,1,0,357,28,""],[28,"chp_type_source","c",3,2,367,381,26,0,2,0,357,135,""],[29,"champ","f",2,0,392,396,4,2,9,1,397,32,""],[30,"T1","c",3,2,400,401,29,0,1,0,397,31,""],[31,"chi_id_cible","c",3,2,407,418,29,0,2,0,397,135,""],[32,"champ","f",2,0,429,433,4,2,10,1,434,35,""],[33,"T1","c",3,2,437,438,32,0,1,0,434,34,""],[34,"chp_nom_cible","c",3,2,444,456,32,0,2,0,434,135,""],[35,"champ","f",2,0,467,471,4,2,11,1,472,38,""],[36,"T1","c",3,2,475,476,35,0,1,0,472,37,""],[37,"chp_dossier_cible","c",3,2,482,498,35,0,2,0,472,135,""],[38,"champ","f",2,0,509,513,4,2,12,1,514,41,""],[39,"T1","c",3,2,517,518,38,0,1,0,514,40,""],[40,"chp_commentaire_cible","c",3,2,524,544,38,0,2,0,514,135,""],[41,"champ","f",2,0,555,559,4,2,13,1,560,44,""],[42,"T2","c",3,2,563,564,41,0,1,0,560,43,""],[43,"chi_id_dossier","c",3,2,570,583,41,0,2,0,560,135,""],[44,"champ","f",2,0,594,598,4,2,14,1,599,47,""],[45,"T2","c",3,2,602,603,44,0,1,0,599,46,""],[46,"chx_cible_dossier","c",3,2,609,625,44,0,2,0,599,135,""],[47,"champ","f",2,0,636,640,4,2,15,1,641,135,""],[48,"T2","c",3,2,644,645,47,0,1,0,641,49,""],[49,"chp_nom_dossier","c",3,2,651,665,47,0,2,0,641,135,""],[50,"provenance","f",1,0,678,687,1,3,3,5,688,91,""],[51,"table_reference","f",2,0,696,710,50,1,1,4,711,59,""],[52,"source","f",3,0,722,727,51,1,1,3,728,135,""],[53,"nom_de_la_table","f",4,0,730,744,52,3,1,2,745,135,""],[54,"tbl_sources","c",5,0,747,757,53,0,1,0,0,55,""],[55,"alias","f",5,0,761,765,53,1,2,1,766,57,""],[56,"T0","c",6,0,767,768,55,0,1,0,766,135,""],[57,"base","f",5,0,773,776,53,1,3,1,777,135,""],[58,"b1","c",6,0,778,779,57,0,1,0,777,135,""],[59,"jointure_gauche","f",2,0,800,814,50,2,2,4,815,75,""],[60,"source","f",3,0,826,831,59,1,1,3,832,67,""],[61,"nom_de_la_table","f",4,0,834,848,60,3,1,2,849,135,""],[62,"tbl_cibles","c",5,0,851,860,61,0,1,0,0,63,""],[63,"alias","f",5,0,864,868,61,1,2,1,869,65,""],[64,"T1","c",6,0,870,871,63,0,1,0,869,135,""],[65,"base","f",5,0,876,879,61,1,3,1,880,135,""],[66,"b1","c",6,0,881,882,65,0,1,0,880,135,""],[67,"contrainte","f",3,0,898,907,59,1,2,3,908,135,""],[68,"egal","f",4,0,910,913,67,2,1,2,914,135,""],[69,"champ","f",5,0,916,920,68,2,1,1,921,72,""],[70,"T1","c",6,0,923,924,69,0,1,0,0,71,""],[71,"chi_id_cible","c",6,0,928,939,69,0,2,0,0,135,""],[72,"champ","f",5,0,945,949,68,2,2,1,950,135,""],[73,"T0","c",6,0,952,953,72,0,1,0,0,74,""],[74,"chx_cible_id_source","c",6,0,957,975,72,0,2,0,0,135,""],[75,"jointure_gauche","f",2,0,997,1011,50,2,3,4,1012,135,""],[76,"source","f",3,0,1023,1028,75,1,1,3,1029,83,""],[77,"nom_de_la_table","f",4,0,1031,1045,76,3,1,2,1046,135,""],[78,"tbl_dossiers","c",5,0,1048,1059,77,0,1,0,0,79,""],[79,"alias","f",5,0,1063,1067,77,1,2,1,1068,81,""],[80,"T2","c",6,0,1069,1070,79,0,1,0,1068,135,""],[81,"base","f",5,0,1075,1078,77,1,3,1,1079,135,""],[82,"b1","c",6,0,1080,1081,81,0,1,0,1079,135,""],[83,"contrainte","f",3,0,1097,1106,75,1,2,3,1107,135,""],[84,"egal","f",4,0,1109,1112,83,2,1,2,1113,135,""],[85,"champ","f",5,0,1115,1119,84,2,1,1,1120,88,""],[86,"T2","c",6,0,1122,1123,85,0,1,0,0,87,""],[87,"chi_id_dossier","c",6,0,1127,1140,85,0,2,0,0,135,""],[88,"champ","f",5,0,1146,1150,84,2,2,1,1151,135,""],[89,"T0","c",6,0,1153,1154,88,0,1,0,0,90,""],[90,"chx_dossier_id_source","c",6,0,1158,1178,88,0,2,0,0,135,""],[91,"conditions","f",1,0,1202,1211,1,1,4,4,1212,123,""],[92,"et","f",2,0,1220,1221,91,6,1,3,1222,135,""],[93,"egal","f",3,0,1233,1236,92,2,1,2,1237,98,""],[94,"champ","f",4,0,1239,1243,93,2,1,1,1244,97,""],[95,"T0","c",5,2,1247,1248,94,0,1,0,1244,96,""],[96,"chx_cible_id_source","c",5,2,1254,1272,94,0,2,0,1244,135,""],[97,":T0_chx_cible_id_source","c",4,0,1279,1301,93,0,2,0,1244,135,""],[98,"egal","f",3,0,1314,1317,92,2,2,2,1318,103,""],[99,"champ","f",4,0,1320,1324,98,2,1,1,1325,102,""],[100,"T0","c",5,2,1328,1329,99,0,1,0,1325,101,""],[101,"chi_id_source","c",5,2,1335,1347,99,0,2,0,1325,135,""],[102,":T0_chi_id_source","c",4,0,1354,1370,98,0,2,0,1325,135,""],[103,"comme","f",3,0,1383,1387,92,2,3,2,1388,108,""],[104,"champ","f",4,0,1390,1394,103,2,1,1,1395,107,""],[105,"T0","c",5,2,1398,1399,104,0,1,0,1395,106,""],[106,"chp_nom_source","c",5,2,1405,1418,104,0,2,0,1395,135,""],[107,":T0_chp_nom_source","c",4,0,1425,1442,103,0,2,0,1395,135,""],[108,"comme","f",3,0,1455,1459,92,2,4,2,1460,113,""],[109,"champ","f",4,0,1462,1466,108,2,1,1,1467,112,""],[110,"T0","c",5,2,1470,1471,109,0,1,0,1467,111,""],[111,"chp_type_source","c",5,2,1477,1491,109,0,2,0,1467,135,""],[112,":T0_chp_type_source","c",4,0,1498,1516,108,0,2,0,1467,135,""],[113,"comme","f",3,0,1529,1533,92,2,5,2,1534,118,""],[114,"champ","f",4,0,1536,1540,113,2,1,1,1541,117,""],[115,"T2","c",5,2,1544,1545,114,0,1,0,1541,116,""],[116,"chp_nom_dossier","c",5,2,1551,1565,114,0,2,0,1541,135,""],[117,":T2_chp_nom_dossier","c",4,0,1572,1590,113,0,2,0,1541,135,""],[118,"egal","f",3,0,1603,1606,92,2,6,2,1607,135,""],[119,"champ","f",4,0,1609,1613,118,2,1,1,1614,122,""],[120,"T0","c",5,2,1617,1618,119,0,1,0,1614,121,""],[121,"chx_dossier_id_source","c",5,2,1624,1644,119,0,2,0,1614,135,""],[122,":T0_chx_dossier_id_source","c",4,0,1651,1675,118,0,2,0,1614,135,""],[123,"complements","f",1,0,1695,1705,1,2,5,4,1706,135,""],[124,"trier_par","f",2,0,1714,1722,123,1,1,3,1723,130,""],[125,"","f",3,0,1714,1722,124,2,1,2,1725,135,""],[126,"champ","f",4,0,1727,1731,125,2,1,1,1732,129,""],[127,"T0","c",5,2,1735,1736,126,0,1,0,1732,128,""],[128,"chp_nom_source","c",5,2,1742,1755,126,0,2,0,1732,135,""],[129,"croissant","f",4,0,1762,1770,125,0,2,0,1771,135,""],[130,"limit\u00e9_\u00e0","f",2,0,1784,1791,123,2,2,2,1792,135,""],[131,"quantit\u00e9","f",3,0,1794,1801,130,1,1,1,1802,133,""],[132,":quantitee","c",4,0,1803,1812,131,0,1,0,1802,135,""],[133,"d\u00e9but","f",3,0,1817,1821,130,1,2,1,1822,135,""],[134,":debut","c",4,0,1823,1828,133,0,1,0,1822,135,""]]'),
('62','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ( `T0` , `chi_id_source`),
      champ( `T0` , `chx_cible_id_source`),
      champ( `T0` , `chp_nom_source`),
      champ( `T0` , `chp_commentaire_source`),
      champ( `T0` , `chx_dossier_id_source`),
      champ( `T0` , `chp_rev_source`),
      champ( `T0` , `chp_genere_source`),
      champ( `T0` , `chp_type_source`),
      champ( `T1` , `chi_id_cible`),
      champ( `T1` , `chp_nom_cible`),
      champ( `T1` , `chp_dossier_cible`),
      champ( `T1` , `chp_commentaire_cible`),
      champ( `T2` , `chi_id_dossier`),
      champ( `T2` , `chx_cible_dossier`),
      champ( `T2` , `chp_nom_dossier`)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , alias(T0) , base(b1) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_cibles , alias(T1) , base(b1) )),
         contrainte( egal( champ( T1 , chi_id_cible ) , champ( T0 , chx_cible_id_source ) ))
      ),
      jointure_gauche(
         source( nom_de_la_table( tbl_dossiers , alias(T2) , base(b1) )),
         contrainte( egal( champ( T2 , chi_id_dossier ) , champ( T0 , chx_dossier_id_source ) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_source` ) , :T0_chi_id_source ) , egal( champ( `T0` , `chx_cible_id_source` ) , :T0_chx_cible_id_source ))
   )
)','SELECT 
`T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
`T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
`T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
 FROM b1.tbl_sources T0
 LEFT JOIN b1.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

 LEFT JOIN b1.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source

WHERE (`T0`.`chi_id_source` = :T0_chi_id_source
   AND `T0`.`chx_cible_id_source` = :T0_chx_cible_id_source);','function sql_62($par){
    $champs0=''
      `T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
      `T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
      `T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chi_id_source`'',$par[''T0_chi_id_source'']);
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_source'' => $tab0[0],
                ''T0.chx_cible_id_source'' => $tab0[1],
                ''T0.chp_nom_source'' => $tab0[2],
                ''T0.chp_commentaire_source'' => $tab0[3],
                ''T0.chx_dossier_id_source'' => $tab0[4],
                ''T0.chp_rev_source'' => $tab0[5],
                ''T0.chp_genere_source'' => $tab0[6],
                ''T0.chp_type_source'' => $tab0[7],
                ''T1.chi_id_cible'' => $tab0[8],
                ''T1.chp_nom_cible'' => $tab0[9],
                ''T1.chp_dossier_cible'' => $tab0[10],
                ''T1.chp_commentaire_cible'' => $tab0[11],
                ''T2.chi_id_dossier'' => $tab0[12],
                ''T2.chx_cible_dossier'' => $tab0[13],
                ''T2.chp_nom_dossier'' => $tab0[14],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,103,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,103,""],[4,"valeurs","f",1,0,42,48,1,15,2,2,49,50,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,8,""],[6,"T0","c",3,2,65,66,5,0,1,0,62,7,""],[7,"chi_id_source","c",3,2,72,84,5,0,2,0,62,103,""],[8,"champ","f",2,0,95,99,4,2,2,1,100,11,""],[9,"T0","c",3,2,103,104,8,0,1,0,100,10,""],[10,"chx_cible_id_source","c",3,2,110,128,8,0,2,0,100,103,""],[11,"champ","f",2,0,139,143,4,2,3,1,144,14,""],[12,"T0","c",3,2,147,148,11,0,1,0,144,13,""],[13,"chp_nom_source","c",3,2,154,167,11,0,2,0,144,103,""],[14,"champ","f",2,0,178,182,4,2,4,1,183,17,""],[15,"T0","c",3,2,186,187,14,0,1,0,183,16,""],[16,"chp_commentaire_source","c",3,2,193,214,14,0,2,0,183,103,""],[17,"champ","f",2,0,225,229,4,2,5,1,230,20,""],[18,"T0","c",3,2,233,234,17,0,1,0,230,19,""],[19,"chx_dossier_id_source","c",3,2,240,260,17,0,2,0,230,103,""],[20,"champ","f",2,0,271,275,4,2,6,1,276,23,""],[21,"T0","c",3,2,279,280,20,0,1,0,276,22,""],[22,"chp_rev_source","c",3,2,286,299,20,0,2,0,276,103,""],[23,"champ","f",2,0,310,314,4,2,7,1,315,26,""],[24,"T0","c",3,2,318,319,23,0,1,0,315,25,""],[25,"chp_genere_source","c",3,2,325,341,23,0,2,0,315,103,""],[26,"champ","f",2,0,352,356,4,2,8,1,357,29,""],[27,"T0","c",3,2,360,361,26,0,1,0,357,28,""],[28,"chp_type_source","c",3,2,367,381,26,0,2,0,357,103,""],[29,"champ","f",2,0,392,396,4,2,9,1,397,32,""],[30,"T1","c",3,2,400,401,29,0,1,0,397,31,""],[31,"chi_id_cible","c",3,2,407,418,29,0,2,0,397,103,""],[32,"champ","f",2,0,429,433,4,2,10,1,434,35,""],[33,"T1","c",3,2,437,438,32,0,1,0,434,34,""],[34,"chp_nom_cible","c",3,2,444,456,32,0,2,0,434,103,""],[35,"champ","f",2,0,467,471,4,2,11,1,472,38,""],[36,"T1","c",3,2,475,476,35,0,1,0,472,37,""],[37,"chp_dossier_cible","c",3,2,482,498,35,0,2,0,472,103,""],[38,"champ","f",2,0,509,513,4,2,12,1,514,41,""],[39,"T1","c",3,2,517,518,38,0,1,0,514,40,""],[40,"chp_commentaire_cible","c",3,2,524,544,38,0,2,0,514,103,""],[41,"champ","f",2,0,555,559,4,2,13,1,560,44,""],[42,"T2","c",3,2,563,564,41,0,1,0,560,43,""],[43,"chi_id_dossier","c",3,2,570,583,41,0,2,0,560,103,""],[44,"champ","f",2,0,594,598,4,2,14,1,599,47,""],[45,"T2","c",3,2,602,603,44,0,1,0,599,46,""],[46,"chx_cible_dossier","c",3,2,609,625,44,0,2,0,599,103,""],[47,"champ","f",2,0,636,640,4,2,15,1,641,103,""],[48,"T2","c",3,2,644,645,47,0,1,0,641,49,""],[49,"chp_nom_dossier","c",3,2,651,665,47,0,2,0,641,103,""],[50,"provenance","f",1,0,678,687,1,3,3,5,688,91,""],[51,"table_reference","f",2,0,696,710,50,1,1,4,711,59,""],[52,"source","f",3,0,722,727,51,1,1,3,728,103,""],[53,"nom_de_la_table","f",4,0,730,744,52,3,1,2,745,103,""],[54,"tbl_sources","c",5,0,747,757,53,0,1,0,0,55,""],[55,"alias","f",5,0,761,765,53,1,2,1,766,57,""],[56,"T0","c",6,0,767,768,55,0,1,0,766,103,""],[57,"base","f",5,0,773,776,53,1,3,1,777,103,""],[58,"b1","c",6,0,778,779,57,0,1,0,777,103,""],[59,"jointure_gauche","f",2,0,800,814,50,2,2,4,815,75,""],[60,"source","f",3,0,826,831,59,1,1,3,832,67,""],[61,"nom_de_la_table","f",4,0,834,848,60,3,1,2,849,103,""],[62,"tbl_cibles","c",5,0,851,860,61,0,1,0,0,63,""],[63,"alias","f",5,0,864,868,61,1,2,1,869,65,""],[64,"T1","c",6,0,870,871,63,0,1,0,869,103,""],[65,"base","f",5,0,876,879,61,1,3,1,880,103,""],[66,"b1","c",6,0,881,882,65,0,1,0,880,103,""],[67,"contrainte","f",3,0,898,907,59,1,2,3,908,103,""],[68,"egal","f",4,0,910,913,67,2,1,2,914,103,""],[69,"champ","f",5,0,916,920,68,2,1,1,921,72,""],[70,"T1","c",6,0,923,924,69,0,1,0,0,71,""],[71,"chi_id_cible","c",6,0,928,939,69,0,2,0,0,103,""],[72,"champ","f",5,0,945,949,68,2,2,1,950,103,""],[73,"T0","c",6,0,952,953,72,0,1,0,0,74,""],[74,"chx_cible_id_source","c",6,0,957,975,72,0,2,0,0,103,""],[75,"jointure_gauche","f",2,0,997,1011,50,2,3,4,1012,103,""],[76,"source","f",3,0,1023,1028,75,1,1,3,1029,83,""],[77,"nom_de_la_table","f",4,0,1031,1045,76,3,1,2,1046,103,""],[78,"tbl_dossiers","c",5,0,1048,1059,77,0,1,0,0,79,""],[79,"alias","f",5,0,1063,1067,77,1,2,1,1068,81,""],[80,"T2","c",6,0,1069,1070,79,0,1,0,1068,103,""],[81,"base","f",5,0,1075,1078,77,1,3,1,1079,103,""],[82,"b1","c",6,0,1080,1081,81,0,1,0,1079,103,""],[83,"contrainte","f",3,0,1097,1106,75,1,2,3,1107,103,""],[84,"egal","f",4,0,1109,1112,83,2,1,2,1113,103,""],[85,"champ","f",5,0,1115,1119,84,2,1,1,1120,88,""],[86,"T2","c",6,0,1122,1123,85,0,1,0,0,87,""],[87,"chi_id_dossier","c",6,0,1127,1140,85,0,2,0,0,103,""],[88,"champ","f",5,0,1146,1150,84,2,2,1,1151,103,""],[89,"T0","c",6,0,1153,1154,88,0,1,0,0,90,""],[90,"chx_dossier_id_source","c",6,0,1158,1178,88,0,2,0,0,103,""],[91,"conditions","f",1,0,1202,1211,1,1,4,4,1212,103,""],[92,"et","f",2,0,1220,1221,91,2,1,3,1222,103,""],[93,"egal","f",3,0,1224,1227,92,2,1,2,1228,98,""],[94,"champ","f",4,0,1230,1234,93,2,1,1,1235,97,""],[95,"T0","c",5,2,1238,1239,94,0,1,0,1235,96,""],[96,"chi_id_source","c",5,2,1245,1257,94,0,2,0,1235,103,""],[97,":T0_chi_id_source","c",4,0,1264,1280,93,0,2,0,0,103,""],[98,"egal","f",3,0,1286,1289,92,2,2,2,1290,103,""],[99,"champ","f",4,0,1292,1296,98,2,1,1,1297,102,""],[100,"T0","c",5,2,1300,1301,99,0,1,0,1297,101,""],[101,"chx_cible_id_source","c",5,2,1307,1325,99,0,2,0,1297,103,""],[102,":T0_chx_cible_id_source","c",4,0,1332,1354,98,0,2,0,0,103,""]]'),
('63','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte( champ( `chp_nom_source` ) , :n_chp_nom_source),
      affecte( champ( `chp_commentaire_source` ) , :n_chp_commentaire_source),
      affecte( champ( `chx_dossier_id_source` ) , :n_chx_dossier_id_source),
      affecte( champ( `chp_rev_source` ) , :n_chp_rev_source),
      affecte( champ( `chp_genere_source` ) , :n_chp_genere_source),
      affecte( champ( `chp_type_source` ) , :n_chp_type_source)
   ),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_sources , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_source` ) , :c_chi_id_source ) , egal( champ( `chx_cible_id_source` ) , :c_chx_cible_id_source ))
   )
)','UPDATE b1.tbl_sources SET `chp_nom_source` = :n_chp_nom_source , `chp_commentaire_source` = :n_chp_commentaire_source , `chx_dossier_id_source` = :n_chx_dossier_id_source , `chp_rev_source` = :n_chp_rev_source , `chp_genere_source` = :n_chp_genere_source , `chp_type_source` = :n_chp_type_source
WHERE (`chi_id_source` = :c_chi_id_source
   AND `chx_cible_id_source` = :c_chx_cible_id_source) ;','function sql_63($par){
    $texte_sql_63=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_sources` SET ''.PHP_EOL;

    if($par[''n_chp_nom_source'']==='''' || $par[''n_chp_nom_source'']===NULL ){
        $texte_sql_63.=''    `chp_nom_source` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_63.=''    `chp_nom_source` = \''''.sq0($par[''n_chp_nom_source'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_commentaire_source'']==='''' || $par[''n_chp_commentaire_source'']===NULL ){
        $texte_sql_63.=''    `chp_commentaire_source` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_63.=''    `chp_commentaire_source` = \''''.sq0($par[''n_chp_commentaire_source'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chx_dossier_id_source'']==='''' || $par[''n_chx_dossier_id_source'']===NULL ){
        $texte_sql_63.=''    `chx_dossier_id_source` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_63.=''    `chx_dossier_id_source` = ''.sq0($par[''n_chx_dossier_id_source'']).'' , ''.PHP_EOL;
    }
    if($par[''n_chp_rev_source'']==='''' || $par[''n_chp_rev_source'']===NULL ){
        $texte_sql_63.=''    `chp_rev_source` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_63.=''    `chp_rev_source` = \''''.sq0($par[''n_chp_rev_source'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_genere_source'']==='''' || $par[''n_chp_genere_source'']===NULL ){
        $texte_sql_63.=''    `chp_genere_source` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_63.=''    `chp_genere_source` = \''''.sq0($par[''n_chp_genere_source'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_type_source'']==='''' || $par[''n_chp_type_source'']===NULL ){
        $texte_sql_63.=''    `chp_type_source` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_63.=''    `chp_type_source` = \''''.sq0($par[''n_chp_type_source'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_source` = ''.sq1($par[''c_chi_id_source'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_id_source` = ''.sq1($par[''c_chx_cible_id_source'']).''''.PHP_EOL;
    $texte_sql_63.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_63 = <pre>'' . $texte_sql_63 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_63);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_63()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,46,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,46,""],[4,"valeurs","f",1,0,38,44,1,6,2,3,45,29,""],[5,"affecte","f",2,0,53,59,4,2,1,2,60,9,""],[6,"champ","f",3,0,62,66,5,1,1,1,67,8,""],[7,"chp_nom_source","c",4,2,70,83,6,0,1,0,67,46,""],[8,":n_chp_nom_source","c",3,0,90,106,5,0,2,0,67,46,""],[9,"affecte","f",2,0,116,122,4,2,2,2,123,13,""],[10,"champ","f",3,0,125,129,9,1,1,1,130,12,""],[11,"chp_commentaire_source","c",4,2,133,154,10,0,1,0,130,46,""],[12,":n_chp_commentaire_source","c",3,0,161,185,9,0,2,0,130,46,""],[13,"affecte","f",2,0,195,201,4,2,3,2,202,17,""],[14,"champ","f",3,0,204,208,13,1,1,1,209,16,""],[15,"chx_dossier_id_source","c",4,2,212,232,14,0,1,0,209,46,""],[16,":n_chx_dossier_id_source","c",3,0,239,262,13,0,2,0,209,46,""],[17,"affecte","f",2,0,272,278,4,2,4,2,279,21,""],[18,"champ","f",3,0,281,285,17,1,1,1,286,20,""],[19,"chp_rev_source","c",4,2,289,302,18,0,1,0,286,46,""],[20,":n_chp_rev_source","c",3,0,309,325,17,0,2,0,286,46,""],[21,"affecte","f",2,0,335,341,4,2,5,2,342,25,""],[22,"champ","f",3,0,344,348,21,1,1,1,349,24,""],[23,"chp_genere_source","c",4,2,352,368,22,0,1,0,349,46,""],[24,":n_chp_genere_source","c",3,0,375,394,21,0,2,0,349,46,""],[25,"affecte","f",2,0,404,410,4,2,6,2,411,46,""],[26,"champ","f",3,0,413,417,25,1,1,1,418,28,""],[27,"chp_type_source","c",4,2,421,435,26,0,1,0,418,46,""],[28,":n_chp_type_source","c",3,0,442,459,25,0,2,0,418,46,""],[29,"provenance","f",1,0,471,480,1,1,3,5,481,36,""],[30,"table_reference","f",2,0,489,503,29,1,1,4,504,46,""],[31,"source","f",3,0,515,520,30,1,1,3,521,46,""],[32,"nom_de_la_table","f",4,0,523,537,31,2,1,2,538,46,""],[33,"tbl_sources","c",5,0,540,550,32,0,1,0,0,34,""],[34,"base","f",5,0,554,557,32,1,2,1,558,46,""],[35,"b1","c",6,0,559,560,34,0,1,0,558,46,""],[36,"conditions","f",1,0,583,592,1,1,4,4,593,46,""],[37,"et","f",2,0,601,602,36,2,1,3,603,46,""],[38,"egal","f",3,0,605,608,37,2,1,2,609,42,""],[39,"champ","f",4,0,611,615,38,1,1,1,616,41,""],[40,"chi_id_source","c",5,2,619,631,39,0,1,0,616,46,""],[41,":c_chi_id_source","c",4,0,638,653,38,0,2,0,0,46,""],[42,"egal","f",3,0,659,662,37,2,2,2,663,46,""],[43,"champ","f",4,0,665,669,42,1,1,1,670,45,""],[44,"chx_cible_id_source","c",5,2,673,691,43,0,1,0,670,46,""],[45,":c_chx_cible_id_source","c",4,0,698,719,42,0,2,0,0,46,""]]'),
('64','1','select','sélectionner(
   base_de_reference(1),
   valeurs( champ( `T0` , `chi_id_tache` ) , champ( `T0` , `chx_utilisateur_tache` ) , champ( `T0` , `chp_texte_tache` ) , champ( `T0` , `chp_priorite_tache` )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , alias(T0) , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chx_utilisateur_tache` ) , :T0_chx_utilisateur_tache ) , inf( champ( `T0` , `chp_priorite_tache` ) , :T0_chp_priorite_tache ))
   ),
   complements(
      trier_par( ( champ( `T0` , `chp_priorite_tache` ) , croissant() ))
   )
)','SELECT 
`T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
 FROM b1.tbl_taches T0
WHERE (`T0`.`chx_utilisateur_tache` = :T0_chx_utilisateur_tache
   AND `T0`.`chp_priorite_tache` < :T0_chp_priorite_tache) 
ORDER BY `T0`.`chp_priorite_tache` ASC;','function sql_64($par){
    $champs0=''
      `T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id(''`T0`.`chx_utilisateur_tache`'',$par[''T0_chx_utilisateur_tache'']);
    $where0.='' AND `T0`.`chp_priorite_tache` < ''.sq1($par[''T0_chp_priorite_tache'']).''''.PHP_EOL;
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_priorite_tache` ASC'';
    $sql0.=$order0;
    /* ATTENTION : pas de limites */
    $plage0='''';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_tache'' => $tab0[0],
                ''T0.chx_utilisateur_tache'' => $tab0[1],
                ''T0.chp_texte_tache'' => $tab0[2],
                ''T0.chp_priorite_tache'' => $tab0[3],
            );
        }
        return array(
           __xst  => __xsu  ,
           __xva  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => __xer ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','priorité tache < ?','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,45,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,4,""],[3,"1","c",2,0,35,35,2,0,1,0,34,45,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,17,""],[5,"champ","f",2,0,51,55,4,2,1,1,56,8,""],[6,"T0","c",3,2,59,60,5,0,1,0,56,7,""],[7,"chi_id_tache","c",3,2,66,77,5,0,2,0,56,45,""],[8,"champ","f",2,0,84,88,4,2,2,1,89,11,""],[9,"T0","c",3,2,92,93,8,0,1,0,89,10,""],[10,"chx_utilisateur_tache","c",3,2,99,119,8,0,2,0,89,45,""],[11,"champ","f",2,0,126,130,4,2,3,1,131,14,""],[12,"T0","c",3,2,134,135,11,0,1,0,131,13,""],[13,"chp_texte_tache","c",3,2,141,155,11,0,2,0,131,45,""],[14,"champ","f",2,0,162,166,4,2,4,1,167,45,""],[15,"T0","c",3,2,170,171,14,0,1,0,167,16,""],[16,"chp_priorite_tache","c",3,2,177,194,14,0,2,0,167,45,""],[17,"provenance","f",1,0,204,213,1,1,3,5,214,26,""],[18,"table_reference","f",2,0,222,236,17,1,1,4,237,45,""],[19,"source","f",3,0,248,253,18,1,1,3,254,45,""],[20,"nom_de_la_table","f",4,0,256,270,19,3,1,2,271,45,""],[21,"tbl_taches","c",5,0,273,282,20,0,1,0,0,22,""],[22,"alias","f",5,0,286,290,20,1,2,1,291,24,""],[23,"T0","c",6,0,292,293,22,0,1,0,291,45,""],[24,"base","f",5,0,298,301,20,1,3,1,302,45,""],[25,"b1","c",6,0,303,304,24,0,1,0,302,45,""],[26,"conditions","f",1,0,327,336,1,1,4,4,337,38,""],[27,"et","f",2,0,345,346,26,2,1,3,347,45,""],[28,"egal","f",3,0,349,352,27,2,1,2,353,33,""],[29,"champ","f",4,0,355,359,28,2,1,1,360,32,""],[30,"T0","c",5,2,363,364,29,0,1,0,360,31,""],[31,"chx_utilisateur_tache","c",5,2,370,390,29,0,2,0,360,45,""],[32,":T0_chx_utilisateur_tache","c",4,0,397,421,28,0,2,0,0,45,""],[33,"inf","f",3,0,427,429,27,2,2,2,430,45,""],[34,"champ","f",4,0,432,436,33,2,1,1,437,37,""],[35,"T0","c",5,2,440,441,34,0,1,0,437,36,""],[36,"chp_priorite_tache","c",5,2,447,464,34,0,2,0,437,45,""],[37,":T0_chp_priorite_tache","c",4,0,471,492,33,0,2,0,0,45,""],[38,"complements","f",1,0,506,516,1,1,5,4,517,45,""],[39,"trier_par","f",2,0,525,533,38,1,1,3,534,45,""],[40,"","f",3,0,525,533,39,2,1,2,536,45,""],[41,"champ","f",4,0,538,542,40,2,1,1,543,44,""],[42,"T0","c",5,2,546,547,41,0,1,0,543,43,""],[43,"chp_priorite_tache","c",5,2,553,570,41,0,2,0,543,45,""],[44,"croissant","f",4,0,577,585,40,0,2,0,586,45,""]]'),
('65','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chp_priorite_tache` ) , :n_chp_priorite_tache )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_taches , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_tache` ) , :c_chi_id_tache ) , egal( champ( `chx_utilisateur_tache` ) , :c_chx_utilisateur_tache ))
   )
)','UPDATE b1.tbl_taches SET `chp_priorite_tache` = :n_chp_priorite_tache
WHERE (`chi_id_tache` = :c_chi_id_tache
   AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache) ;','function sql_65($par){
    $texte_sql_65=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.PHP_EOL;

    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_65.=''    `chp_priorite_tache` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_65.=''    `chp_priorite_tache` = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.PHP_EOL;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.PHP_EOL;
    $texte_sql_65.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_65 = <pre>'' . $texte_sql_65 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_65);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_65()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','priorité tâche par id','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,26,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,26,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,9,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,26,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chp_priorite_tache","c",4,2,64,81,6,0,1,0,61,26,""],[8,":n_chp_priorite_tache","c",3,0,88,108,5,0,2,0,0,26,""],[9,"provenance","f",1,0,117,126,1,1,3,5,127,16,""],[10,"table_reference","f",2,0,135,149,9,1,1,4,150,26,""],[11,"source","f",3,0,161,166,10,1,1,3,167,26,""],[12,"nom_de_la_table","f",4,0,169,183,11,2,1,2,184,26,""],[13,"tbl_taches","c",5,0,186,195,12,0,1,0,0,14,""],[14,"base","f",5,0,199,202,12,1,2,1,203,26,""],[15,"b1","c",6,0,204,205,14,0,1,0,203,26,""],[16,"conditions","f",1,0,228,237,1,1,4,4,238,26,""],[17,"et","f",2,0,246,247,16,2,1,3,248,26,""],[18,"egal","f",3,0,250,253,17,2,1,2,254,22,""],[19,"champ","f",4,0,256,260,18,1,1,1,261,21,""],[20,"chi_id_tache","c",5,2,264,275,19,0,1,0,261,26,""],[21,":c_chi_id_tache","c",4,0,282,296,18,0,2,0,0,26,""],[22,"egal","f",3,0,302,305,17,2,2,2,306,26,""],[23,"champ","f",4,0,308,312,22,1,1,1,313,25,""],[24,"chx_utilisateur_tache","c",5,2,316,336,23,0,1,0,313,26,""],[25,":c_chx_utilisateur_tache","c",4,0,343,366,22,0,2,0,0,26,""]]'),
('66','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `cht_rev_requete` ) , :n_cht_rev_requete ) , affecte( champ( `cht_sql_requete` ) , :n_cht_sql_requete ) , affecte( champ( `cht_php_requete` ) , :n_cht_php_requete )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_requetes , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `chi_id_requete` ) , :c_chi_id_requete ) , egal( champ( `chx_cible_requete` ) , :c_chx_cible_requete ))
   )
)','UPDATE b1.tbl_requetes SET `cht_rev_requete` = :n_cht_rev_requete , `cht_sql_requete` = :n_cht_sql_requete , `cht_php_requete` = :n_cht_php_requete
WHERE (`chi_id_requete` = :c_chi_id_requete
   AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_66($par){
    $texte_sql_66=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.PHP_EOL;

    if($par[''n_cht_rev_requete'']==='''' || $par[''n_cht_rev_requete'']===NULL ){
        $texte_sql_66.=''    `cht_rev_requete` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_66.=''    `cht_rev_requete` = \''''.sq0($par[''n_cht_rev_requete'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_cht_sql_requete'']==='''' || $par[''n_cht_sql_requete'']===NULL ){
        $texte_sql_66.=''    `cht_sql_requete` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_66.=''    `cht_sql_requete` = \''''.sq0($par[''n_cht_sql_requete'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_cht_php_requete'']==='''' || $par[''n_cht_php_requete'']===NULL ){
        $texte_sql_66.=''    `cht_php_requete` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_66.=''    `cht_php_requete` = \''''.sq0($par[''n_cht_php_requete'']).''\'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.PHP_EOL;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.PHP_EOL;
    $texte_sql_66.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_66 = <pre>'' . $texte_sql_66 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_66);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_66()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','requetes pour rev,sql et php','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,34,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,34,""],[4,"valeurs","f",1,0,38,44,1,3,2,3,45,17,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,9,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"cht_rev_requete","c",4,2,64,78,6,0,1,0,61,34,""],[8,":n_cht_rev_requete","c",3,0,85,102,5,0,2,0,0,34,""],[9,"affecte","f",2,0,108,114,4,2,2,2,115,13,""],[10,"champ","f",3,0,117,121,9,1,1,1,122,12,""],[11,"cht_sql_requete","c",4,2,125,139,10,0,1,0,122,34,""],[12,":n_cht_sql_requete","c",3,0,146,163,9,0,2,0,0,34,""],[13,"affecte","f",2,0,169,175,4,2,3,2,176,34,""],[14,"champ","f",3,0,178,182,13,1,1,1,183,16,""],[15,"cht_php_requete","c",4,2,186,200,14,0,1,0,183,34,""],[16,":n_cht_php_requete","c",3,0,207,224,13,0,2,0,0,34,""],[17,"provenance","f",1,0,233,242,1,1,3,5,243,24,""],[18,"table_reference","f",2,0,251,265,17,1,1,4,266,34,""],[19,"source","f",3,0,277,282,18,1,1,3,283,34,""],[20,"nom_de_la_table","f",4,0,285,299,19,2,1,2,300,34,""],[21,"tbl_requetes","c",5,0,302,313,20,0,1,0,0,22,""],[22,"base","f",5,0,317,320,20,1,2,1,321,34,""],[23,"b1","c",6,0,322,323,22,0,1,0,321,34,""],[24,"conditions","f",1,0,346,355,1,1,4,4,356,34,""],[25,"et","f",2,0,364,365,24,2,1,3,366,34,""],[26,"egal","f",3,0,368,371,25,2,1,2,372,30,""],[27,"champ","f",4,0,374,378,26,1,1,1,379,29,""],[28,"chi_id_requete","c",5,2,382,395,27,0,1,0,379,34,""],[29,":c_chi_id_requete","c",4,0,402,418,26,0,2,0,0,34,""],[30,"egal","f",3,0,424,427,25,2,2,2,428,34,""],[31,"champ","f",4,0,430,434,30,1,1,1,435,33,""],[32,"chx_cible_requete","c",5,2,438,454,31,0,1,0,435,34,""],[33,":c_chx_cible_requete","c",4,0,461,480,30,0,2,0,0,34,""]]'),
('67','1','update','modifier(
   base_de_reference(1),
   valeurs( affecte( champ( `chx_test_parent_test` ) , :n_chx_test_parent_test ) , affecte( champ( `chp_texte1_test` ) , :n_chp_texte1_test ) , affecte( champ( `chp_nom_test` ) , :n_chp_nom_test ) , affecte( champ( `chi_id_test` ) , :n_chi_id_test )),
   provenance(
      table_reference(
         source( nom_de_la_table( tbl_tests , base(b1) ))
      )
   ),
   conditions(
      et( egal( champ( `T0` , `chi_id_test` ) , :T0_chi_id_test ))
   )
)','UPDATE b1.tbl_tests SET `chx_test_parent_test` = :n_chx_test_parent_test , `chp_texte1_test` = :n_chp_texte1_test , `chp_nom_test` = :n_chp_nom_test , `chi_id_test` = :n_chi_id_test
WHERE (`T0`.`chi_id_test` = :T0_chi_id_test) ;','function sql_67($par){
    $texte_sql_67=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_tests` SET ''.PHP_EOL;

    if($par[''n_chx_test_parent_test'']==='''' || $par[''n_chx_test_parent_test'']===NULL ){
        $texte_sql_67.=''    `chx_test_parent_test` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_67.=''    `chx_test_parent_test` = ''.sq0($par[''n_chx_test_parent_test'']).'' , ''.PHP_EOL;
    }
    if($par[''n_chp_texte1_test'']==='''' || $par[''n_chp_texte1_test'']===NULL ){
        $texte_sql_67.=''    `chp_texte1_test` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_67.=''    `chp_texte1_test` = \''''.sq0($par[''n_chp_texte1_test'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chp_nom_test'']==='''' || $par[''n_chp_nom_test'']===NULL ){
        $texte_sql_67.=''    `chp_nom_test` = NULL  , ''.PHP_EOL;
    }else{
        $texte_sql_67.=''    `chp_nom_test` = \''''.sq0($par[''n_chp_nom_test'']).''\'' , ''.PHP_EOL;
    }
    if($par[''n_chi_id_test'']==='''' || $par[''n_chi_id_test'']===NULL ){
        $texte_sql_67.=''    `chi_id_test` = NULL  ''.PHP_EOL;
    }else{
        $texte_sql_67.=''    `chi_id_test` = ''.sq0($par[''n_chi_id_test'']).'' ''.PHP_EOL;
    }

    $where0='' WHERE 1=1 ''.PHP_EOL;
    $where0.='' AND `T0`.`chi_id_test` = ''.sq1($par[''T0_chi_id_test'']).''''.PHP_EOL;
    $texte_sql_67.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_67 = <pre>'' . $texte_sql_67 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_67);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => __xer, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_67()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => __xsu, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','test','[[0,"","__I",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,35,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,4,""],[3,"1","c",2,0,31,31,2,0,1,0,30,35,""],[4,"valeurs","f",1,0,38,44,1,4,2,3,45,21,""],[5,"affecte","f",2,0,47,53,4,2,1,2,54,9,""],[6,"champ","f",3,0,56,60,5,1,1,1,61,8,""],[7,"chx_test_parent_test","c",4,2,64,83,6,0,1,0,61,35,""],[8,":n_chx_test_parent_test","c",3,0,90,112,5,0,2,0,0,35,""],[9,"affecte","f",2,0,118,124,4,2,2,2,125,13,""],[10,"champ","f",3,0,127,131,9,1,1,1,132,12,""],[11,"chp_texte1_test","c",4,2,135,149,10,0,1,0,132,35,""],[12,":n_chp_texte1_test","c",3,0,156,173,9,0,2,0,0,35,""],[13,"affecte","f",2,0,179,185,4,2,3,2,186,17,""],[14,"champ","f",3,0,188,192,13,1,1,1,193,16,""],[15,"chp_nom_test","c",4,2,196,207,14,0,1,0,193,35,""],[16,":n_chp_nom_test","c",3,0,214,228,13,0,2,0,0,35,""],[17,"affecte","f",2,0,234,240,4,2,4,2,241,35,""],[18,"champ","f",3,0,243,247,17,1,1,1,248,20,""],[19,"chi_id_test","c",4,2,251,261,18,0,1,0,248,35,""],[20,":n_chi_id_test","c",3,0,268,281,17,0,2,0,0,35,""],[21,"provenance","f",1,0,290,299,1,1,3,5,300,28,""],[22,"table_reference","f",2,0,308,322,21,1,1,4,323,35,""],[23,"source","f",3,0,334,339,22,1,1,3,340,35,""],[24,"nom_de_la_table","f",4,0,342,356,23,2,1,2,357,35,""],[25,"tbl_tests","c",5,0,359,367,24,0,1,0,0,26,""],[26,"base","f",5,0,371,374,24,1,2,1,375,35,""],[27,"b1","c",6,0,376,377,26,0,1,0,375,35,""],[28,"conditions","f",1,0,400,409,1,1,4,4,410,35,""],[29,"et","f",2,0,418,419,28,1,1,3,420,35,""],[30,"egal","f",3,0,422,425,29,2,1,2,426,35,""],[31,"champ","f",4,0,428,432,30,2,1,1,433,34,""],[32,"T0","c",5,2,436,437,31,0,1,0,433,33,""],[33,"chi_id_test","c",5,2,443,453,31,0,2,0,433,35,""],[34,":T0_chi_id_test","c",4,0,460,474,30,0,2,0,0,35,""]]');
/*



  =========================================================================
  Pour la table tbl_tests il n'y a aucune donnée à insérer
  =========================================================================
*/
