/*



  =========================================================================
  Pour la table tbl_cibles il y a 3 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_cibles`( `chi_id_cible`, `chp_nom_cible`, `chp_dossier_cible`, `chp_commentaire_cible`) VALUES
('1','fta','fta','la racine');
/*



  =========================================================================
  Pour la table tbl_dossiers il y a 5 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_dossiers`( `chi_id_dossier`, `chx_cible_dossier`, `chp_nom_dossier`) VALUES
('1','1','/'),
('2','1','/fta_inc/db/sqlite'),
('3','1','/fta_inc/sql');
/*



  =========================================================================
  Pour la table tbl_sources il y a 5 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_sources`( `chi_id_source`, `chx_cible_id_source`, `chp_nom_source`, `chp_commentaire_source`, `chx_dossier_id_source`, `chp_rev_source`, `chp_genere_source`, `chp_type_source`) VALUES
('1','1','index.html',NULL,'1','html(
   (doctype),
   head(
      meta((''http-equiv'' , "refresh") , (''content'' , "5; url=''./fta_www/''")),
      meta((''charset'' , "utf-8")),
      title(''page non valide''),
      meta((''name'' , "viewport") , (''content'' , "width=device-width, initial-scale=1")),
      style((''type'' , "text/css"),
         '':root{ 
            --yyvtrg:40px; 
            --yyvtrt:12px; /* taille de référence du texte */ 
            --yyvtrp:2px; /* taille de référence du espaces ( padding ) */ 
            --yyvtrb:1px; /* taille de référence des bordures */ 
            --yyvtrm:1px; /* taille de référence dus marges */ 
            --yyvhmb:22px; /* hauteur minimales des boutons */ 
            --yyvhal:14px; /* hauteur de ligne */ 
            --yyvhmd:35px; /* hauteur du menu à défilement */ 
            --yyvhgb:32px; /* hauteur des grands boutons ( quitter et index ) */ 
            --yyvhmc:24px; /* hauteur minimale de conteneur ( div ) */ 
            }''),
      link((''rel'' , "stylesheet") , (''as'' , "style") , (''type'' , "text/css") , (''href'' , "fta_www/6.css"))
   ),
   body(
      #( redirection vers la page d''accueil ),
      h1(''Dans 5 secondes, vous serez redirigé automatiquement vers la page d\''accueil''),
      div((''style'' , "text-align:center;") , a((''class'' , "yyinfo") , (''href'' , "fta_www/") , ''y aller maintenant'')),
      javascriptDansHtml(affecte(a , 3))
   )
)','<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="refresh" content="5; url=''./fta_www/''" />
        <meta charset="utf-8" />
        <title>page non valide</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <style type="text/css">
            :root{ 
                        --yyvtrg:40px; 
                        --yyvtrt:12px; /* taille de référence du texte */ 
                        --yyvtrp:2px; /* taille de référence du espaces ( padding ) */ 
                        --yyvtrb:1px; /* taille de référence des bordures */ 
                        --yyvtrm:1px; /* taille de référence dus marges */ 
                        --yyvhmb:22px; /* hauteur minimales des boutons */ 
                        --yyvhal:14px; /* hauteur de ligne */ 
                        --yyvhmd:35px; /* hauteur du menu à défilement */ 
                        --yyvhgb:32px; /* hauteur des grands boutons ( quitter et index ) */ 
                        --yyvhmc:24px; /* hauteur minimale de conteneur ( div ) */ 
                        }
        </style>
        <link rel="stylesheet" as="style" type="text/css" href="fta_www/6.css" />
    </head>
    <body>
        <!-- redirection vers la page d''accueil -->
        <h1>Dans 5 secondes, vous serez redirigé automatiquement vers la page d''accueil</h1>
        <div style="text-align:center;">
            <a class="yyinfo" href="fta_www/">y aller maintenant</a>
        </div>
<script>
//<![CDATA[
//<source_javascript_rev>

        a=3;
//</source_javascript_rev>
//]]>
</script>

    </body>
</html>','normal'),
('5','1','tictactoe.html',NULL,'1','html(
   (doctype),
   (''lang'' , "fr"),
   head(
      meta((''charset'' , "utf-8")),
      meta((''name'' , "viewport") , (''content'' , "width=device-width, initial-scale=1")),
      title("tictactoe"),
      meta((''name'' , "description") , (''content'' , "tictactoe")),
      style((''type'' , "text/css"),
         "h1{text-align:center;}                                   #t1{width:70vmin;  height:70vmin; margin-left:auto; margin-right:auto;}                                        #t1 td {  width:33%;  text-align:center;  font-size:10vw; }                           h1{  border:0;  margin:0;  height:10vmin; }                           #numero_de_joueur{  font-size:2em;  color:navy; text-align:center;}"
      )
   ),
   body(
      h1("tictactoe 1h00"),
      table(
         (''border'' , "1"),
         (''id'' , "t1"),
         tbody(
            tr(td((''id'' , "0") , "&nbsp;") , td((''id'' , "1") , "&nbsp;") , td((''id'' , "2") , "&nbsp;")),
            tr(td((''id'' , "3") , "&nbsp;") , td((''id'' , "4") , "&nbsp;") , td((''id'' , "5") , "&nbsp;")),
            tr(td((''id'' , "6") , "&nbsp;") , td((''id'' , "7") , "&nbsp;") , td((''id'' , "8") , "&nbsp;"))
         )
      ),
      div((''id'' , "numero_de_joueur")),
      javascriptDansHtml(
         (''type'' , "text/javascript"),
         useStrict(),
         declare(numero_de_joueur , ''x''),
         declare(termine , false),
         #(================================================================),
         fonction(
            definition(nom(virifie_gagnant) , argument(nj)),
            contenu(
               declare(i , 0),
               boucle(
                  initialisation(affecte(i , 0)),
                  condition((inf(i , 3))),
                  increment(postinc(i)),
                  faire(
                     choix(
                        si(
                           condition(
                              (
                                 (
                                    egalstricte(
                                       appelf(
                                          element(document),
                                          nomf(getElementById),
                                          p(plus(mult(i , 3) , 0)),
                                          prop(innerHTML)
                                       ),
                                       nj
                                    )
                                 ),
                                 et(
                                    (
                                       egalstricte(
                                          appelf(
                                             element(document),
                                             nomf(getElementById),
                                             p(plus(mult(i , 3) , 1)),
                                             prop(innerHTML)
                                          ),
                                          nj
                                       )
                                    )
                                 ),
                                 et(
                                    (
                                       egalstricte(
                                          appelf(
                                             element(document),
                                             nomf(getElementById),
                                             p(plus(mult(i , 3) , 2)),
                                             prop(innerHTML)
                                          ),
                                          nj
                                       )
                                    )
                                 )
                              )
                           ),
                           alors(retourner(1))
                        )
                     )
                  )
               ),
               boucle(
                  initialisation(affecte(i , 0)),
                  condition((inf(i , 3))),
                  increment(postinc(i)),
                  faire(
                     choix(
                        si(
                           condition(
                              (
                                 (
                                    egalstricte(
                                       appelf(element(document) , nomf(getElementById) , p(plus(i , 0)) , prop(innerHTML)),
                                       nj
                                    )
                                 ),
                                 et(
                                    (
                                       egalstricte(
                                          appelf(element(document) , nomf(getElementById) , p(plus(i , 3)) , prop(innerHTML)),
                                          nj
                                       )
                                    )
                                 ),
                                 et(
                                    (
                                       egalstricte(
                                          appelf(element(document) , nomf(getElementById) , p(plus(i , 6)) , prop(innerHTML)),
                                          nj
                                       )
                                    )
                                 )
                              )
                           ),
                           alors(retourner(1))
                        )
                     )
                  )
               ),
               choix(
                  si(
                     condition(
                        (
                           (
                              egalstricte(appelf(element(document) , nomf(getElementById) , p(0) , prop(innerHTML)) , nj)
                           ),
                           et(
                              (
                                 egalstricte(appelf(element(document) , nomf(getElementById) , p(4) , prop(innerHTML)) , nj)
                              )
                           ),
                           et(
                              (
                                 egalstricte(appelf(element(document) , nomf(getElementById) , p(8) , prop(innerHTML)) , nj)
                              )
                           )
                        )
                     ),
                     alors(retourner(1))
                  )
               ),
               choix(
                  si(
                     condition(
                        (
                           (
                              egalstricte(appelf(element(document) , nomf(getElementById) , p(6) , prop(innerHTML)) , nj)
                           ),
                           et(
                              (
                                 egalstricte(appelf(element(document) , nomf(getElementById) , p(4) , prop(innerHTML)) , nj)
                              )
                           ),
                           et(
                              (
                                 egalstricte(appelf(element(document) , nomf(getElementById) , p(2) , prop(innerHTML)) , nj)
                              )
                           )
                        )
                     ),
                     alors(retourner(1))
                  )
               ),
               #( egalite ),
               declare(case_vide_trouve , false),
               declare(
                  lst,
                  appelf(
                     element(document),
                     nomf(getElementById),
                     p(''t1''),
                     prop(appelf(nomf(getElementsByTagName) , p(''td'')))
                  )
               ),
               boucle(
                  initialisation(affecte(i , 0)),
                  condition((inf(i , lst.length))),
                  increment(postinc(i)),
                  faire(
                     choix(
                        si(
                           condition(
                              (
                                 non(
                                    (egalstricte(lst[i].innerHTML , ''x'')),
                                    ou((egalstricte(lst[i].innerHTML , ''o'')))
                                 )
                              )
                           ),
                           alors(affecte(case_vide_trouve , true))
                        )
                     )
                  )
               ),
               choix(
                  si(
                     condition((egalstricte(case_vide_trouve , false))),
                     alors(
                        retourner(0),
                        #( egalite )
                     )
                  )
               ),
               retourner(2)
            )
         ),
         #(================================================================),
         fonction(
            definition(nom(recommencer)),
            contenu(
               declare(
                  lst,
                  appelf(
                     element(document),
                     nomf(getElementById),
                     p(''t1''),
                     prop(appelf(nomf(getElementsByTagName) , p(''td'')))
                  )
               ),
               declare(i , 0),
               boucle(
                  initialisation(affecte(i , 0)),
                  condition((inf(i , lst.length))),
                  increment(postinc(i)),
                  faire(affecte(lst[i].innerHTML , ''&nbsp;''))
               ),
               affecte(numero_de_joueur , ''x''),
               affecte(termine , false),
               affecte(appelf(element(document) , nomf(getElementById) , p(''numero_de_joueur'') , prop(innerHTML)) , concat(numero_de_joueur , '' joue''))
            )
         ),
         #(================================================================),
         fonction(
            definition(nom(monClick) , argument(e)),
            contenu(
               choix(
                  si(
                     condition((egalstricte(termine , true))),
                     alors(revenir())
                  )
               ),
               choix(
                  si(
                     condition(
                        (
                           (egalstricte(e.target.innerHTML , ''x'')),
                           ou((egalstricte(e.target.innerHTML , ''o'')))
                        )
                     ),
                     alors(revenir())
                  )
               ),
               affecte(e.target.innerHTML , numero_de_joueur),
               declare(a_gagne , appelf(nomf(virifie_gagnant) , p(numero_de_joueur))),
               choix(
                  si(
                     condition((egalstricte(a_gagne , 1))),
                     alors(
                        declare(t , concat(numero_de_joueur , '' a gagné : '')),
                        affectop(''+='' , t , ''<button type="button" onclick="recommencer()">recommencer</button>''),
                        affecte(appelf(element(document) , nomf(getElementById) , p(''numero_de_joueur'') , prop(innerHTML)) , t),
                        affecte(termine , true)
                     )
                  ),
                  sinonsi(
                     condition((egalstricte(a_gagne , 2))),
                     alors(
                        affecte(
                           numero_de_joueur,
                           testEnLigne(
                              condition((egalstricte(numero_de_joueur , ''o''))),
                              siVrai(''x''),
                              siFaux(''o'')
                           )
                        ),
                        affecte(appelf(element(document) , nomf(getElementById) , p(''numero_de_joueur'') , prop(innerHTML)) , concat(numero_de_joueur , '' joue''))
                     )
                  ),
                  sinonsi(
                     condition((egalstricte(a_gagne , 0))),
                     alors(
                        declare(t , '' personne n\''a gagné''),
                        affectop(''+='' , t , ''<button type="button" onclick="recommencer()">recommencer</button>''),
                        affecte(appelf(element(document) , nomf(getElementById) , p(''numero_de_joueur'') , prop(innerHTML)) , t),
                        affecte(termine , true)
                     )
                  )
               )
            )
         ),
         #(================================================================),
         fonction(
            definition(nom(init)),
            contenu(
               declare(
                  lst,
                  appelf(
                     element(document),
                     nomf(getElementById),
                     p(''t1''),
                     prop(appelf(nomf(getElementsByTagName) , p(''td'')))
                  )
               ),
               declare(i , 0),
               boucle(
                  initialisation(affecte(i , 0)),
                  condition((inf(i , lst.length))),
                  increment(postinc(i)),
                  faire(appelf(element(lst[i]) , nomf(addEventListener) , p(''click'') , p(monClick)))
               ),
               affecte(appelf(element(document) , nomf(getElementById) , p(''numero_de_joueur'') , prop(innerHTML)) , concat(numero_de_joueur , '' joue''))
            )
         ),
         #(================================================================),
         appelf(
            element(window),
            nomf(addEventListener),
            p(''load''),
            p(
               appelf(
                  nomf(function),
                  contenu(appelf(nomf(init)))
               )
            )
         )
      )
   )
)','<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>tictactoe</title>
        <meta name="description" content="tictactoe" />
        <style type="text/css">
            h1{text-align:center;}                                   #t1{width:70vmin;  height:70vmin; margin-left:auto; margin-right:auto;}                                        #t1 td {  width:33%;  text-align:center;  font-size:10vw; }                           h1{  border:0;  margin:0;  height:10vmin; }                           #numero_de_joueur{  font-size:2em;  color:navy; text-align:center;}
        </style>
    </head>
    <body>
        <h1>tictactoe 1h00</h1>
        <table border="1" id="t1">
            <tbody>
                <tr>
                    <td id="0">&nbsp;</td>
                    <td id="1">&nbsp;</td>
                    <td id="2">&nbsp;</td>
                </tr>
                <tr>
                    <td id="3">&nbsp;</td>
                    <td id="4">&nbsp;</td>
                    <td id="5">&nbsp;</td>
                </tr>
                <tr>
                    <td id="6">&nbsp;</td>
                    <td id="7">&nbsp;</td>
                    <td id="8">&nbsp;</td>
                </tr>
            </tbody>
        </table>
        <div id="numero_de_joueur"></div>
<script type="text/javascript">
//<![CDATA[
//<source_javascript_rev>

        "use strict";
        var numero_de_joueur=''x'';
        var termine=false;
        /*================================================================*/
        function virifie_gagnant(nj){
            var i=0;
            for(i=0;i < 3;i++){
                if((document.getElementById(((i * 3) + 0)).innerHTML === nj)
                 && (document.getElementById(((i * 3) + 1)).innerHTML === nj)
                 && (document.getElementById(((i * 3) + 2)).innerHTML === nj)
                ){
                    return 1;
                }
            }
            for(i=0;i < 3;i++){
                if((document.getElementById((i + 0)).innerHTML === nj)
                 && (document.getElementById((i + 3)).innerHTML === nj)
                 && (document.getElementById((i + 6)).innerHTML === nj)
                ){
                    return 1;
                }
            }
            if((document.getElementById(0).innerHTML === nj)
             && (document.getElementById(4).innerHTML === nj)
             && (document.getElementById(8).innerHTML === nj)
            ){
                return 1;
            }
            if((document.getElementById(6).innerHTML === nj)
             && (document.getElementById(4).innerHTML === nj)
             && (document.getElementById(2).innerHTML === nj)
            ){
                return 1;
            }
            /* egalite */
            var case_vide_trouve=false;
            var lst = document.getElementById(''t1'').getElementsByTagName(''td'');
            for(i=0;i < lst.length;i++){
                if( !((lst[i].innerHTML === ''x'') || (lst[i].innerHTML === ''o''))){
                    case_vide_trouve=true;
                }
            }
            if(case_vide_trouve === false){
                return 0;
                /* egalite */
            }
            return 2;
        }
        /*================================================================*/
        function recommencer(){
            var lst = document.getElementById(''t1'').getElementsByTagName(''td'');
            var i=0;
            for(i=0;i < lst.length;i++){
                lst[i].innerHTML=''&nbsp;'';
            }
            numero_de_joueur=''x'';
            termine=false;
            document.getElementById(''numero_de_joueur'').innerHTML=numero_de_joueur + '' joue'';
        }
        /*================================================================*/
        function monClick(e){
            if(termine === true){
                return;
            }
            if((e.target.innerHTML === ''x'') || (e.target.innerHTML === ''o'')){
                return;
            }
            e.target.innerHTML=numero_de_joueur;
            var a_gagne = virifie_gagnant(numero_de_joueur);
            if(a_gagne === 1){
                var t = numero_de_joueur + '' a gagné : '';
                t+=''<button type="button" onclick="recommencer()">recommencer</button>'';
                document.getElementById(''numero_de_joueur'').innerHTML=t;
                termine=true;
            }else if(a_gagne === 2){
                numero_de_joueur=((numero_de_joueur === ''o'')?''x'':''o'');
                document.getElementById(''numero_de_joueur'').innerHTML=numero_de_joueur + '' joue'';
            }else if(a_gagne === 0){
                var t='' personne n\''a gagné'';
                t+=''<button type="button" onclick="recommencer()">recommencer</button>'';
                document.getElementById(''numero_de_joueur'').innerHTML=t;
                termine=true;
            }
        }
        /*================================================================*/
        function init(){
            var lst = document.getElementById(''t1'').getElementsByTagName(''td'');
            var i=0;
            for(i=0;i < lst.length;i++){
                lst[i].addEventListener(''click'',monClick);
            }
            document.getElementById(''numero_de_joueur'').innerHTML=numero_de_joueur + '' joue'';
        }
        /*================================================================*/
        window.addEventListener(''load'',function(){
            init();
        });
//</source_javascript_rev>
//]]>
</script>

    </body>
</html>','normal');
/*



  =========================================================================
  Pour la table tbl_utilisateurs il y a 1 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_utilisateurs`( `chi_id_utilisateur`, `chp_nom_de_connexion_utilisateur`, `chp_mot_de_passe_utilisateur`, `chp_parametres_utilisateur`, `chp_commentaire_utilisateur`) VALUES
('1','admin','$2y$13$511GXb2mv6/lIM8yBiyGte7CNn.rMaTvD0aPNW6BF/GYlmv946RVK','{"zz_sources_l1.php":{"nombre_de_lignes":20},"zz_taches_l1.php":{"nombre_de_lignes":50},"zz_revs_l1.php":{"nombre_de_lignes":30},"zz_cibles_l1.php":{"nombre_de_lignes":30}}','mdp = admin');
/*



  =========================================================================
  Pour la table tbl_bdds il y a 2 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_bdds`(`chi_id_basedd`, `chx_dossier_id_basedd`, `chx_cible_id_basedd`, `chp_nom_basedd`, `chp_commentaire_basedd`, `chp_rev_basedd`) VALUES
('1','2','1','system.db','test de base virtuelle','#(
  =====================================================================================================================
  table tbl_cibles
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_cibles''),
      (nom_long_de_la_table , ''liste des systèmes cibles''),
      (nom_court_de_la_table , ''une cible''),
      (nom_bref_de_la_table , ''cible''),
      (transform_table_sur_svg , transform(translate(-69 , -131)))
   ),
   nom_de_la_table(''tbl_cibles''),
   fields(
      #(),
      field(nom_du_champ(chi_id_cible) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_cible'') , (nom_long_du_champ , ''identifiant unique de la cible'') , (nom_court_du_champ , ''identifiant cible'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_cible) , type(TEXT) , non_nulle() , meta((champ , ''chp_nom_cible'') , (nom_long_du_champ , ''nom de la cible'') , (nom_court_du_champ , ''nom cible'') , (nom_bref_du_champ , ''nom'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_dossier_cible) , type(CHARACTER , 3) , meta((champ , ''chp_dossier_cible'') , (nom_long_du_champ , ''à faire chp_dossier_cible'') , (nom_court_du_champ , ''à faire chp_dossier_cible'') , (nom_bref_du_champ , ''à faire chp_dossier_cible'') , (typologie , ''cho''))),
      field(nom_du_champ(chp_commentaire_cible) , type(TEXT) , meta((champ , ''chp_commentaire_cible'') , (nom_long_du_champ , ''à faire chp_commentaire_cible'') , (nom_court_du_champ , ''à faire chp_commentaire_cible'') , (nom_bref_du_champ , ''à faire chp_commentaire_cible'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_cibles'') , unique() , index_name(''idx_dossier_cible'') , fields(''chp_dossier_cible'') , meta((index , ''idx_dossier_cible'') , (__xme , ''à faire idx_dossier_cible''))),
#(
  =====================================================================================================================
  table tbl_dossiers
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_dossiers''),
      (nom_long_de_la_table , ''liste des dossiers sur disque''),
      (nom_court_de_la_table , ''un dossier''),
      (nom_bref_de_la_table , ''dossiers''),
      (transform_table_sur_svg , transform(translate(309 , -24)))
   ),
   nom_de_la_table(''tbl_dossiers''),
   fields(
      #(),
      field(nom_du_champ(chi_id_dossier) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_dossier'') , (nom_long_du_champ , ''à faire chi_id_dossier'') , (nom_court_du_champ , ''à faire chi_id_dossier'') , (nom_bref_du_champ , ''à faire chi_id_dossier'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_cible_dossier) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_dossier'') , (nom_long_du_champ , ''à faire chx_cible_dossier'') , (nom_court_du_champ , ''à faire chx_cible_dossier'') , (nom_bref_du_champ , ''à faire chx_cible_dossier'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_nom_dossier) , type(CHARACTER , 256) , meta((champ , ''chp_nom_dossier'') , (nom_long_du_champ , ''à faire chp_nom_dossier'') , (nom_court_du_champ , ''à faire chp_nom_dossier'') , (nom_bref_du_champ , ''à faire chp_nom_dossier'') , (typologie , ''cho'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_dossiers'') , unique() , index_name(''idx_cible_et_nom'') , fields(''chx_cible_dossier'' , ''chp_nom_dossier'') , meta((index , ''idx_cible_et_nom'') , (__xme , ''à faire idx_cible_et_nom''))),
#(
  =====================================================================================================================
  table tbl_sources
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_sources''),
      (nom_long_de_la_table , ''liste des programmes sources''),
      (nom_court_de_la_table , ''le source''),
      (nom_bref_de_la_table , ''sources''),
      (transform_table_sur_svg , transform(translate(454 , -74)))
   ),
   nom_de_la_table(''tbl_sources''),
   fields(
      #(),
      field(nom_du_champ(chi_id_source) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_source'') , (nom_long_du_champ , ''à faire chi_id_source'') , (nom_court_du_champ , ''à faire chi_id_source'') , (nom_bref_du_champ , ''à faire chi_id_source'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_cible_id_source) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_id_source'') , (nom_long_du_champ , ''à faire chx_cible_id_source'') , (nom_court_du_champ , ''à faire chx_cible_id_source'') , (nom_bref_du_champ , ''à faire chx_cible_id_source'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_nom_source) , type(CHARACTER , 256) , non_nulle() , valeur_par_defaut('''') , meta((champ , ''chp_nom_source'') , (nom_long_du_champ , ''à faire chp_nom_source'') , (nom_court_du_champ , ''à faire chp_nom_source'') , (nom_bref_du_champ , ''à faire chp_nom_source'') , (typologie , ''cho''))),
      field(nom_du_champ(chp_commentaire_source) , type(TEXT) , meta((champ , ''chp_commentaire_source'') , (nom_long_du_champ , ''à faire chp_commentaire_source'') , (nom_court_du_champ , ''à faire chp_commentaire_source'') , (nom_bref_du_champ , ''à faire chp_commentaire_source'') , (typologie , ''cht''))),
      field(nom_du_champ(chx_dossier_id_source) , type(INTEGER) , references(''tbl_dossiers'' , ''chi_id_dossier'') , meta((champ , ''chx_dossier_id_source'') , (nom_long_du_champ , ''à faire chx_dossier_id_source'') , (nom_court_du_champ , ''à faire chx_dossier_id_source'') , (nom_bref_du_champ , ''à faire chx_dossier_id_source'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_rev_source) , type(TEXT) , meta((champ , ''chp_rev_source'') , (nom_long_du_champ , ''à faire chp_rev_source'') , (nom_court_du_champ , ''à faire chp_rev_source'') , (nom_bref_du_champ , ''à faire chp_rev_source'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_genere_source) , type(TEXT) , meta((champ , ''chp_genere_source'') , (nom_long_du_champ , ''à faire chp_genere_source'') , (nom_court_du_champ , ''à faire chp_genere_source'') , (nom_bref_du_champ , ''à faire chp_genere_source'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_type_source) , type(TEXT) , non_nulle() , valeur_par_defaut(''normal'') , meta((champ , ''chp_type_source'') , (nom_long_du_champ , ''à faire chp_type_source'') , (nom_court_du_champ , ''à faire chp_type_source'') , (nom_bref_du_champ , ''à faire chp_type_source'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_sources'') , unique() , index_name(''idx_nom_et_dossier'') , fields(''chx_dossier_id_source'' , ''chp_nom_source'') , meta((index , ''idx_nom_et_dossier'') , (__xme , ''à faire idx_nom_et_dossier''))),
#(
  =====================================================================================================================
  table tbl_utilisateurs
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_utilisateurs''),
      (nom_long_de_la_table , ''liste des utilisateurs''),
      (nom_court_de_la_table , ''un utilisateur''),
      (nom_bref_de_la_table , ''utilisateurs''),
      (transform_table_sur_svg , transform(translate(-70 , 248)))
   ),
   nom_de_la_table(''tbl_utilisateurs''),
   fields(
      #(),
      field(nom_du_champ(chi_id_utilisateur) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_utilisateur'') , (nom_long_du_champ , ''à faire chi_id_utilisateur'') , (nom_court_du_champ , ''à faire chi_id_utilisateur'') , (nom_bref_du_champ , ''à faire chi_id_utilisateur'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_de_connexion_utilisateur) , type(TEXT) , meta((champ , ''chp_nom_de_connexion_utilisateur'') , (nom_long_du_champ , ''à faire chp_nom_de_connexion_utilisateur'') , (nom_court_du_champ , ''à faire chp_nom_de_connexion_utilisateur'') , (nom_bref_du_champ , ''à faire chp_nom_de_connexion_utilisateur'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_mot_de_passe_utilisateur) , type(TEXT) , meta((champ , ''chp_mot_de_passe_utilisateur'') , (nom_long_du_champ , ''à faire chp_mot_de_passe_utilisateur'') , (nom_court_du_champ , ''à faire chp_mot_de_passe_utilisateur'') , (nom_bref_du_champ , ''à faire chp_mot_de_passe_utilisateur'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_parametres_utilisateur) , type(TEXT) , meta((champ , ''chp_parametres_utilisateur'') , (nom_long_du_champ , ''à faire chp_parametres_utilisateur'') , (nom_court_du_champ , ''à faire chp_parametres_utilisateur'') , (nom_bref_du_champ , ''à faire chp_parametres_utilisateur'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_commentaire_utilisateur) , type(TEXT) , meta((champ , ''chp_commentaire_utilisateur'') , (nom_long_du_champ , ''à faire chp_commentaire_utilisateur'') , (nom_court_du_champ , ''à faire chp_commentaire_utilisateur'') , (nom_bref_du_champ , ''à faire chp_commentaire_utilisateur'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_utilisateurs'') , unique() , index_name(''idxNomUtilisateur'') , fields(''chp_nom_de_connexion_utilisateur'') , meta((index , ''idxNomUtilisateur'') , (__xme , ''à faire idxNomUtilisateur''))),
#(
  =====================================================================================================================
  table tbl_taches
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_taches''),
      (nom_long_de_la_table , ''liste des tâches à réaliser''),
      (nom_court_de_la_table , ''une tâche''),
      (nom_bref_de_la_table , ''taches''),
      (transform_table_sur_svg , transform(translate(201 , 286)))
   ),
   nom_de_la_table(''tbl_taches''),
   fields(
      #(),
      field(nom_du_champ(chi_id_tache) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_tache'') , (nom_long_du_champ , ''à faire chi_id_tache'') , (nom_court_du_champ , ''à faire chi_id_tache'') , (nom_bref_du_champ , ''à faire chi_id_tache'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_utilisateur_tache) , type(INTEGER) , non_nulle() , references(''tbl_utilisateurs'' , ''chi_id_utilisateur'') , meta((champ , ''chx_utilisateur_tache'') , (nom_long_du_champ , ''à faire chx_utilisateur_tache'') , (nom_court_du_champ , ''à faire chx_utilisateur_tache'') , (nom_bref_du_champ , ''à faire chx_utilisateur_tache'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_texte_tache) , type(TEXT) , non_nulle() , meta((champ , ''chp_texte_tache'') , (nom_long_du_champ , ''à faire chp_texte_tache'') , (nom_court_du_champ , ''à faire chp_texte_tache'') , (nom_bref_du_champ , ''à faire chp_texte_tache'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_priorite_tache) , type(INTEGER) , meta((champ , ''chp_priorite_tache'') , (nom_long_du_champ , ''à faire chp_priorite_tache'') , (nom_court_du_champ , ''à faire chp_priorite_tache'') , (nom_bref_du_champ , ''à faire chp_priorite_tache'') , (typologie , ''che'')))
   )
),
#(
  =====================================================================================================================
  table tbl_revs
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_revs''),
      (nom_long_de_la_table , ''à faire tbl_revs''),
      (nom_court_de_la_table , ''à faire tbl_revs''),
      (nom_bref_de_la_table , ''à faire tbl_revs''),
      (transform_table_sur_svg , transform(translate(643 , -132)))
   ),
   nom_de_la_table(''tbl_revs''),
   fields(
      #(),
      field(nom_du_champ(chi_id_rev) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_rev'') , (nom_long_du_champ , ''à faire chi_id_rev'') , (nom_court_du_champ , ''à faire chi_id_rev'') , (nom_bref_du_champ , ''à faire chi_id_rev'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_cible_rev) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_rev'') , (nom_long_du_champ , ''à faire chx_cible_rev'') , (nom_court_du_champ , ''à faire chx_cible_rev'') , (nom_bref_du_champ , ''à faire chx_cible_rev'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_provenance_rev) , type(CHARACTER , 32) , meta((champ , ''chp_provenance_rev'') , (nom_long_du_champ , ''à faire chp_provenance_rev'') , (nom_court_du_champ , ''à faire chp_provenance_rev'') , (nom_bref_du_champ , ''à faire chp_provenance_rev'') , (typologie , ''cho''))),
      field(nom_du_champ(chx_source_rev) , type(INTEGER) , meta((champ , ''chx_source_rev'') , (nom_long_du_champ , ''à faire chx_source_rev'') , (nom_court_du_champ , ''à faire chx_source_rev'') , (nom_bref_du_champ , ''à faire chx_source_rev'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_id_rev) , type(INTEGER) , meta((champ , ''chp_id_rev'') , (nom_long_du_champ , ''à faire chp_id_rev'') , (nom_court_du_champ , ''à faire chp_id_rev'') , (nom_bref_du_champ , ''à faire chp_id_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_valeur_rev) , type(TEXT) , meta((champ , ''chp_valeur_rev'') , (nom_long_du_champ , ''à faire chp_valeur_rev'') , (nom_court_du_champ , ''à faire chp_valeur_rev'') , (nom_bref_du_champ , ''à faire chp_valeur_rev'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_type_rev) , type(CHARACTER , 4) , meta((champ , ''chp_type_rev'') , (nom_long_du_champ , ''à faire chp_type_rev'') , (nom_court_du_champ , ''à faire chp_type_rev'') , (nom_bref_du_champ , ''à faire chp_type_rev'') , (typologie , ''cho''))),
      field(nom_du_champ(chp_niveau_rev) , type(INTEGER) , meta((champ , ''chp_niveau_rev'') , (nom_long_du_champ , ''à faire chp_niveau_rev'') , (nom_court_du_champ , ''à faire chp_niveau_rev'') , (nom_bref_du_champ , ''à faire chp_niveau_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_quotee_rev) , type(INTEGER) , meta((champ , ''chp_quotee_rev'') , (nom_long_du_champ , ''à faire chp_quotee_rev'') , (nom_court_du_champ , ''à faire chp_quotee_rev'') , (nom_bref_du_champ , ''à faire chp_quotee_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_premier_rev) , type(INTEGER) , meta((champ , ''chp_pos_premier_rev'') , (nom_long_du_champ , ''à faire chp_pos_premier_rev'') , (nom_court_du_champ , ''à faire chp_pos_premier_rev'') , (nom_bref_du_champ , ''à faire chp_pos_premier_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_dernier_rev) , type(INTEGER) , meta((champ , ''chp_pos_dernier_rev'') , (nom_long_du_champ , ''à faire chp_pos_dernier_rev'') , (nom_court_du_champ , ''à faire chp_pos_dernier_rev'') , (nom_bref_du_champ , ''à faire chp_pos_dernier_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_parent_rev) , type(INTEGER) , meta((champ , ''chp_parent_rev'') , (nom_long_du_champ , ''à faire chp_parent_rev'') , (nom_court_du_champ , ''à faire chp_parent_rev'') , (nom_bref_du_champ , ''à faire chp_parent_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_nbr_enfants_rev) , type(INTEGER) , meta((champ , ''chp_nbr_enfants_rev'') , (nom_long_du_champ , ''à faire chp_nbr_enfants_rev'') , (nom_court_du_champ , ''à faire chp_nbr_enfants_rev'') , (nom_bref_du_champ , ''à faire chp_nbr_enfants_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_num_enfant_rev) , type(INTEGER) , meta((champ , ''chp_num_enfant_rev'') , (nom_long_du_champ , ''à faire chp_num_enfant_rev'') , (nom_court_du_champ , ''à faire chp_num_enfant_rev'') , (nom_bref_du_champ , ''à faire chp_num_enfant_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_profondeur_rev) , type(INTEGER) , meta((champ , ''chp_profondeur_rev'') , (nom_long_du_champ , ''à faire chp_profondeur_rev'') , (nom_court_du_champ , ''à faire chp_profondeur_rev'') , (nom_bref_du_champ , ''à faire chp_profondeur_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_ouver_parenthese_rev) , type(INTEGER) , meta((champ , ''chp_pos_ouver_parenthese_rev'') , (nom_long_du_champ , ''à faire chp_pos_ouver_parenthese_rev'') , (nom_court_du_champ , ''à faire chp_pos_ouver_parenthese_rev'') , (nom_bref_du_champ , ''à faire chp_pos_ouver_parenthese_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_pos_fermer_parenthese_rev) , type(INTEGER) , meta((champ , ''chp_pos_fermer_parenthese_rev'') , (nom_long_du_champ , ''à faire chp_pos_fermer_parenthese_rev'') , (nom_court_du_champ , ''à faire chp_pos_fermer_parenthese_rev'') , (nom_bref_du_champ , ''à faire chp_pos_fermer_parenthese_rev'') , (typologie , ''che''))),
      field(nom_du_champ(chp_commentaire_rev) , type(TEXT) , meta((champ , ''chp_commentaire_rev'') , (nom_long_du_champ , ''à faire chp_commentaire_rev'') , (nom_court_du_champ , ''à faire chp_commentaire_rev'') , (nom_bref_du_champ , ''à faire chp_commentaire_rev'') , (typologie , ''cht'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_revs'') , unique() , index_name(''idx_ligne_rev'') , fields(''chx_cible_rev'' , ''chp_provenance_rev'' , ''chx_source_rev'' , ''chp_id_rev'') , meta((index , ''idx_ligne_rev'') , (__xme , ''à faire idx_ligne_rev''))),
#(
  =====================================================================================================================
  table tbl_bdds
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_bdds''),
      (nom_long_de_la_table , ''liste des bases de données''),
      (nom_court_de_la_table , ''une base''),
      (nom_bref_de_la_table , ''bases''),
      (transform_table_sur_svg , transform(translate(450 , 129)))
   ),
   nom_de_la_table(''tbl_bdds''),
   fields(
      #(),
      field(nom_du_champ(chi_id_basedd) , type(INTEGER) , primary_key() , auto_increment() , meta((champ , ''chi_id_basedd'') , (nom_long_du_champ , ''à faire chi_id_basedd'') , (nom_court_du_champ , ''à faire chi_id_basedd'') , (nom_bref_du_champ , ''à faire chi_id_basedd'') , (typologie , ''chi''))),
      field(nom_du_champ(chx_dossier_id_basedd) , type(INTEGER) , references(''tbl_dossiers'' , ''chi_id_dossier'') , meta((champ , ''chx_dossier_id_basedd'') , (nom_long_du_champ , ''à faire chx_dossier_id_basedd'') , (nom_court_du_champ , ''à faire chx_dossier_id_basedd'') , (nom_bref_du_champ , ''à faire chx_dossier_id_basedd'') , (typologie , ''chx''))),
      field(nom_du_champ(chx_cible_id_basedd) , type(INTEGER) , non_nulle() , references(''tbl_cibles'' , ''chi_id_cible'') , meta((champ , ''chx_cible_id_basedd'') , (nom_long_du_champ , ''à faire chx_cible_id_basedd'') , (nom_court_du_champ , ''à faire chx_cible_id_basedd'') , (nom_bref_du_champ , ''à faire chx_cible_id_basedd'') , (typologie , ''chx''))),
      field(nom_du_champ(chp_nom_basedd) , type(TEXT) , non_nulle() , valeur_par_defaut('''') , meta((champ , ''chp_nom_basedd'') , (nom_long_du_champ , ''à faire chp_nom_basedd'') , (nom_court_du_champ , ''à faire chp_nom_basedd'') , (nom_bref_du_champ , ''à faire chp_nom_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_rev_basedd) , type(TEXT) , meta((champ , ''chp_rev_basedd'') , (nom_long_du_champ , ''à faire chp_rev_basedd'') , (nom_court_du_champ , ''à faire chp_rev_basedd'') , (nom_bref_du_champ , ''à faire chp_rev_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_commentaire_basedd) , type(TEXT) , meta((champ , ''chp_commentaire_basedd'') , (nom_long_du_champ , ''à faire chp_commentaire_basedd'') , (nom_court_du_champ , ''à faire chp_commentaire_basedd'') , (nom_bref_du_champ , ''à faire chp_commentaire_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_genere_basedd) , type(TEXT) , meta((champ , ''chp_genere_basedd'') , (nom_long_du_champ , ''à faire chp_genere_basedd'') , (nom_court_du_champ , ''à faire chp_genere_basedd'') , (nom_bref_du_champ , ''à faire chp_genere_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_rev_travail_basedd) , type(TEXT) , meta((champ , ''chp_rev_travail_basedd'') , (nom_long_du_champ , ''à faire chp_rev_travail_basedd'') , (nom_court_du_champ , ''à faire chp_rev_travail_basedd'') , (nom_bref_du_champ , ''à faire chp_rev_travail_basedd'') , (typologie , ''cht''))),
      field(nom_du_champ(chp_fournisseur_basedd) , type(TEXT) , valeur_par_defaut(''sqlite'') , meta((champ , ''chp_fournisseur_basedd'') , (nom_long_du_champ , ''à faire chp_fournisseur_basedd'') , (nom_court_du_champ , ''à faire chp_fournisseur_basedd'') , (nom_bref_du_champ , ''à faire chp_fournisseur_basedd'') , (typologie , ''cht'')))
   )
),
#(
  =====================================================================================================================
  table tbl_requetes
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_requetes''),
      (nom_long_de_la_table , ''liste des requêtes''),
      (nom_court_de_la_table , ''une requête''),
      (nom_bref_de_la_table , ''requêtes''),
      (transform_table_sur_svg , transform(translate(115 , 69)))
   ),
   nom_de_la_table(''tbl_requetes''),
   fields(
      #(),
      field(nom_du_champ(chi_id_requete) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_requete'') , (nom_long_du_champ , ''identifiant unique de la requête'') , (nom_court_du_champ , ''id unique'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(
         nom_du_champ(chx_cible_requete),
         type(INTEGER),
         non_nulle(),
         valeur_par_defaut(1),
         references(''tbl_cibles'' , ''chi_id_cible''),
         meta((champ , ''chx_cible_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''chi''))
      ),
      field(nom_du_champ(chp_type_requete) , type(VARCHAR , 64) , valeur_par_defaut(''selectionner'') , meta((champ , ''chp_type_requete'') , (nom_long_du_champ , ''type de la requête sql'') , (nom_court_du_champ , ''type requete'') , (nom_bref_du_champ , ''type'') , (typologie , ''chi''))),
      field(nom_du_champ(cht_rev_requete) , type(TEXT) , meta((champ , ''cht_rev_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_sql_requete) , type(TEXT) , meta((champ , ''cht_sql_requete'') , (nom_long_du_champ , ''requete au format sql'') , (nom_court_du_champ , ''format sql'') , (nom_bref_du_champ , ''sql'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_php_requete) , type(TEXT) , meta((champ , ''cht_php_requete'') , (nom_long_du_champ , ''requete au format php'') , (nom_court_du_champ , ''format php'') , (nom_bref_du_champ , ''php'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_commentaire_requete) , type(TEXT) , meta((champ , ''cht_commentaire_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''cht''))),
      field(nom_du_champ(cht_matrice_requete) , type(TEXT) , meta((champ , ''cht_matrice_requete'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''cht'')))
   )
),
#(
  =====================================================================================================================
  table tbl_tests
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_tests''),
      (nom_long_de_la_table , ''liste d\''enregistrements \\ de test''),
      (nom_court_de_la_table , ''un test''),
      (nom_bref_de_la_table , ''test''),
      (transform_table_sur_svg , transform(translate(645 , 268)))
   ),
   nom_de_la_table(''tbl_tests''),
   fields(
      #(),
      field(nom_du_champ(chi_id_test) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_test'') , (nom_long_du_champ , ''identifiant unique \'' du \\ test'') , (nom_court_du_champ , ''id du test'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_test) , type(VARCHAR , 64) , non_nulle() , valeur_par_defaut('''') , meta((champ , ''chp_nom_test'') , (nom_long_du_champ , ''nom du test'') , (nom_court_du_champ , ''nom test'') , (nom_bref_du_champ , ''nom'') , (typologie , ''chp''))),
      field(
         nom_du_champ(chx_test_parent_test),
         type(INTEGER),
         non_nulle(),
         valeur_par_defaut(0),
         references(''tbl_tests'' , ''chi_id_test''),
         meta((champ , ''chx_test_parent_test'') , (nom_long_du_champ , ''à faire ...'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''chi''))
      ),
      field(nom_du_champ(chp_texte1_test) , type(VARCHAR , 32) , valeur_par_defaut(''hello world'') , meta((champ , ''chp_texte1_test'') , (nom_long_du_champ , ''test'') , (nom_court_du_champ , ''à faire ...'') , (nom_bref_du_champ , ''à faire ...'') , (typologie , ''chp'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_tests'') , unique() , index_name(''idx_nom'') , fields(''chp_nom_test'') , meta((index , ''idx_nom'') , (__xme , ''à faire idx_nom'')))'),
('9','2','1','test.db','test de base virtuelle','#(
  =====================================================================================================================
  table tbl_a
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_a''),
      (nom_long_de_la_table , ''long table a''),
      (nom_court_de_la_table , ''court tbl_a''),
      (nom_bref_de_la_table , ''bref tbl_a''),
      (transform_table_sur_svg , transform(translate(-52 , -188)))
   ),
   nom_de_la_table(''tbl_a''),
   fields(
      #(),
      field(nom_du_champ(chi_id_a) , type(INTEGER , 20) , primary_key() , meta((champ , ''chi_id_a'') , (nom_long_du_champ , ''identifiant unique'') , (nom_court_du_champ , ''id aaa'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_a) , type(STRING) , meta((champ , ''chp_nom_a'') , (nom_long_du_champ , ''à faire chp_nom_cible'') , (nom_court_du_champ , ''à faire chp_nom_cible'') , (nom_bref_du_champ , ''à faire chp_nom_cible'') , (typologie , ''cht''))),
      field(nom_du_champ(chx_a_a) , type(INTEGER) , non_nulle() , references(''tbl_a'' , ''chi_id_a'') , meta((champ , ''chx_a_a'') , (nom_long_du_champ , ''à faire chx_a_a'') , (nom_court_du_champ , ''à faire chx_a_a'') , (nom_bref_du_champ , ''à faire chx_a_a'') , (typologie , ''chx''))),
      field(nom_du_champ(chx_a2_a) , type(INTEGER) , non_nulle() , references(''tbl_a'' , ''chx_a_a'') , meta((champ , ''chx_a2_a'') , (nom_long_du_champ , ''à faire chx_a2_a'') , (nom_court_du_champ , ''à faire chx_a2_a'') , (nom_bref_du_champ , ''à faire chx_a2_a'') , (typologie , ''chx'')))
   )
),
#(==============================),
add_index(nom_de_la_table_pour_l_index(''tbl_a'') , unique() , index_name(''idx_nom_a'') , fields(''chp_nom_a'' , ''chx_a_a'') , meta((index , ''idx_nom_a'') , (message , ''bla''))),
#(
  =====================================================================================================================
  table tbl_b
  =====================================================================================================================
),
create_table(
   meta(
      (table , ''tbl_b''),
      (nom_long_de_la_table , ''à faire tbl_b''),
      (nom_court_de_la_table , ''à faire tbl_b''),
      (nom_bref_de_la_table , ''à faire tbl_b''),
      (transform_table_sur_svg , transform(translate(0 , 0)))
   ),
   nom_de_la_table(''tbl_b''),
   fields(
      #(),
      field(nom_du_champ(chi_id_b) , type(INTEGER) , primary_key() , meta((champ , ''chi_id_b'') , (nom_long_du_champ , ''identifiant unique'') , (nom_court_du_champ , ''id bbb'') , (nom_bref_du_champ , ''id'') , (typologie , ''chi''))),
      field(nom_du_champ(chp_nom_b) , type(STRING) , valeur_par_defaut(''toto'') , meta((champ , ''chp_nom_b'') , (nom_long_du_champ , ''à faire chp_nom_b'') , (nom_court_du_champ , ''à faire chp_nom_b'') , (nom_bref_du_champ , ''à faire chp_nom_b'') , (typologie , ''cht''))),
      field(nom_du_champ(chx_a_b) , type(INTEGER) , non_nulle() , references(''tbl_a'' , ''chi_id_a'') , meta((champ , ''chx_a_b'') , (nom_long_du_champ , ''à faire'') , (nom_court_du_champ , ''à faire'') , (nom_bref_du_champ , ''id'') , (typologie , ''chx''))),
      field(nom_du_champ(cht_t_b) , type(CHARACTER) , meta((champ , ''cht_t_b'') , (nom_long_du_champ , ''à faire cht_t_b'') , (nom_court_du_champ , ''à faire cht_t_b'') , (nom_bref_du_champ , ''à faire cht_t_b'') , (typologie , ''cht'')))
   )
)');
/*



  =========================================================================
  Pour la table tbl_requetes il y a 66 enregistrement(s) à insérer 
  =========================================================================
*/

INSERT INTO `tbl_requetes`( `chi_id_requete`, `chx_cible_requete`, `chp_type_requete`, `cht_rev_requete`, `cht_sql_requete`, `cht_php_requete`, `cht_commentaire_requete`, `cht_matrice_requete`) VALUES
('1','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_utilisateur`) , champ(`T0` , `chp_mot_de_passe_utilisateur`) , champ(`T0` , `chp_parametres_utilisateur`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_utilisateurs , alias(T0) , base(b1)))
      )
   ),
   conditions(egal(champ(`T0` , `chp_nom_de_connexion_utilisateur`) , :nom_de_connexion)),
   complements(limité_à(quantité(1) , début(0)))
)','SELECT 
`T0`.`chi_id_utilisateur` , `T0`.`chp_mot_de_passe_utilisateur` , `T0`.`chp_parametres_utilisateur`
 FROM b1.tbl_utilisateurs T0
WHERE `T0`.`chp_nom_de_connexion_utilisateur` = :nom_de_connexion  
LIMIT 1 OFFSET 0 ;','function sql_1($par){
    $champs0=''
      `T0`.`chi_id_utilisateur` , `T0`.`chp_mot_de_passe_utilisateur` , `T0`.`chp_parametres_utilisateur`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_utilisateurs T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `T0`.`chp_nom_de_connexion_utilisateur` = ''.sq1($par[''nom_de_connexion'']).''''.CRLF;
    $sql0.=$where0;
    $order0='''';
    $sql0.=$order0;
    $plage0=''
        LIMIT 1 OFFSET 0 '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_utilisateur'' => $tab0[0],
                ''T0.chp_mot_de_passe_utilisateur'' => $tab0[1],
                ''T0.chp_parametres_utilisateur'' => $tab0[2],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_utilisateur","c",3,2,64,81,5,0,2,0,55,0,""],[8,"champ","f",2,0,87,91,4,2,2,1,92,0,""],[9,"T0","c",3,2,94,95,8,0,1,0,92,0,""],[10,"chp_mot_de_passe_utilisateur","c",3,2,101,128,8,0,2,0,92,0,""],[11,"champ","f",2,0,134,138,4,2,3,1,139,0,""],[12,"T0","c",3,2,141,142,11,0,1,0,139,0,""],[13,"chp_parametres_utilisateur","c",3,2,148,173,11,0,2,0,139,0,""],[14,"provenance","f",1,0,182,191,1,1,3,5,192,0,""],[15,"table_reference","f",2,0,200,214,14,1,1,4,215,0,""],[16,"source","f",3,0,226,231,15,1,1,3,232,0,""],[17,"nom_de_la_table","f",4,0,233,247,16,3,1,2,248,0,""],[18,"tbl_utilisateurs","c",5,0,249,264,17,0,1,0,0,0,""],[19,"alias","f",5,0,268,272,17,1,2,1,273,0,""],[20,"T0","c",6,0,274,275,19,0,1,0,273,276,""],[21,"base","f",5,0,280,283,17,1,3,1,284,0,""],[22,"b1","c",6,0,285,286,21,0,1,0,284,287,""],[23,"conditions","f",1,0,308,317,1,1,4,3,318,0,""],[24,"egal","f",2,0,319,322,23,2,1,2,323,0,""],[25,"champ","f",3,0,324,328,24,2,1,1,329,0,""],[26,"T0","c",4,2,331,332,25,0,1,0,329,0,""],[27,"chp_nom_de_connexion_utilisateur","c",4,2,338,369,25,0,2,0,329,0,""],[28,":nom_de_connexion","c",3,0,375,391,24,0,2,0,329,392,""],[29,"complements","f",1,0,399,409,1,1,5,3,410,0,""],[30,"limit\u00e9_\u00e0","f",2,0,411,418,29,2,1,2,419,0,""],[31,"quantit\u00e9","f",3,0,420,427,30,1,1,1,428,0,""],[32,"1","c",4,0,429,429,31,0,1,0,428,430,""],[33,"d\u00e9but","f",3,0,434,438,30,1,2,1,439,0,""],[34,"0","c",4,0,440,440,33,0,1,0,439,441,""]]'),
('2','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_requete`),
      champ(`T0` , `chp_type_requete`),
      champ(`T0` , `cht_rev_requete`),
      champ(`T0` , `cht_sql_requete`),
      champ(`T0` , `cht_php_requete`),
      champ(`T0` , `cht_commentaire_requete`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         egal(champ(`T0` , `chx_cible_requete`) , :T0_chx_cible_requete),
         egal(champ(`T0` , `chi_id_requete`) , :T0_chi_id_requete),
         comme(champ(`T0` , `chp_type_requete`) , :T0_chp_type_requete),
         comme(champ(`T0` , `cht_rev_requete`) , :T0_cht_rev_requete)
      )
   ),
   complements(
      trier_par((champ(`T0` , `chi_id_requete`) , décroissant())),
      limité_à(quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , 
`T0`.`cht_commentaire_requete`
 FROM b1.tbl_requetes T0
WHERE (/*  */ `T0`.`chx_cible_requete` = :T0_chx_cible_requete
   AND `T0`.`chi_id_requete` = :T0_chi_id_requete
   AND `T0`.`chp_type_requete` LIKE :T0_chp_type_requete
   AND `T0`.`cht_rev_requete` LIKE :T0_cht_rev_requete) 
ORDER BY `T0`.`chi_id_requete` DESC  
LIMIT :quantitee OFFSET :debut ;','function sql_2($par){
    $champs0=''
      `T0`.`chi_id_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , 
      `T0`.`cht_commentaire_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    if(($par[''T0_chx_cible_requete''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_requete`'',$par[''T0_chx_cible_requete'']);
    }
    if(($par[''T0_chi_id_requete''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_requete`'',$par[''T0_chi_id_requete'']);
    }
    if(($par[''T0_chp_type_requete''] !== '''')){
        $where0.='' AND `T0`.`chp_type_requete` LIKE ''.sq1($par[''T0_chp_type_requete'']).''''.CRLF;
    }
    if(($par[''T0_cht_rev_requete''] !== '''')){
        $where0.='' AND `T0`.`cht_rev_requete` LIKE ''.sq1($par[''T0_cht_rev_requete'']).''''.CRLF;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_requete` DESC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_requete'' => $tab0[0],
                ''T0.chp_type_requete'' => $tab0[1],
                ''T0.cht_rev_requete'' => $tab0[2],
                ''T0.cht_sql_requete'' => $tab0[3],
                ''T0.cht_php_requete'' => $tab0[4],
                ''T0.cht_commentaire_requete'' => $tab0[5],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','requêtes','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,6,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_requete","c",3,2,71,84,5,0,2,0,62,0,""],[8,"champ","f",2,0,95,99,4,2,2,1,100,0,""],[9,"T0","c",3,2,102,103,8,0,1,0,100,0,""],[10,"chp_type_requete","c",3,2,109,124,8,0,2,0,100,0,""],[11,"champ","f",2,0,135,139,4,2,3,1,140,0,""],[12,"T0","c",3,2,142,143,11,0,1,0,140,0,""],[13,"cht_rev_requete","c",3,2,149,163,11,0,2,0,140,0,""],[14,"champ","f",2,0,174,178,4,2,4,1,179,0,""],[15,"T0","c",3,2,181,182,14,0,1,0,179,0,""],[16,"cht_sql_requete","c",3,2,188,202,14,0,2,0,179,0,""],[17,"champ","f",2,0,213,217,4,2,5,1,218,0,""],[18,"T0","c",3,2,220,221,17,0,1,0,218,0,""],[19,"cht_php_requete","c",3,2,227,241,17,0,2,0,218,0,""],[20,"champ","f",2,0,252,256,4,2,6,1,257,0,""],[21,"T0","c",3,2,259,260,20,0,1,0,257,0,""],[22,"cht_commentaire_requete","c",3,2,266,288,20,0,2,0,257,0,""],[23,"provenance","f",1,0,301,310,1,1,3,5,311,0,""],[24,"table_reference","f",2,0,319,333,23,1,1,4,334,0,""],[25,"source","f",3,0,345,350,24,1,1,3,351,0,""],[26,"nom_de_la_table","f",4,0,352,366,25,3,1,2,367,0,""],[27,"tbl_requetes","c",5,0,368,379,26,0,1,0,0,0,""],[28,"alias","f",5,0,383,387,26,1,2,1,388,0,""],[29,"T0","c",6,0,389,390,28,0,1,0,388,391,""],[30,"base","f",5,0,395,398,26,1,3,1,399,0,""],[31,"b1","c",6,0,400,401,30,0,1,0,399,402,""],[32,"conditions","f",1,0,423,432,1,1,4,4,433,0,""],[33,"et","f",2,0,441,442,32,5,1,3,443,0,""],[34,"#","f",3,0,454,454,33,0,1,0,455,456,""],[35,"egal","f",3,0,468,471,33,2,2,2,472,0,""],[36,"champ","f",4,0,473,477,35,2,1,1,478,0,""],[37,"T0","c",5,2,480,481,36,0,1,0,478,0,""],[38,"chx_cible_requete","c",5,2,487,503,36,0,2,0,478,0,""],[39,":T0_chx_cible_requete","c",4,0,509,529,35,0,2,0,478,530,""],[40,"egal","f",3,0,542,545,33,2,3,2,546,0,""],[41,"champ","f",4,0,547,551,40,2,1,1,552,0,""],[42,"T0","c",5,2,554,555,41,0,1,0,552,0,""],[43,"chi_id_requete","c",5,2,561,574,41,0,2,0,552,0,""],[44,":T0_chi_id_requete","c",4,0,580,597,40,0,2,0,552,598,""],[45,"comme","f",3,0,610,614,33,2,4,2,615,0,""],[46,"champ","f",4,0,616,620,45,2,1,1,621,0,""],[47,"T0","c",5,2,623,624,46,0,1,0,621,0,""],[48,"chp_type_requete","c",5,2,630,645,46,0,2,0,621,0,""],[49,":T0_chp_type_requete","c",4,0,651,670,45,0,2,0,621,671,""],[50,"comme","f",3,0,683,687,33,2,5,2,688,0,""],[51,"champ","f",4,0,689,693,50,2,1,1,694,0,""],[52,"T0","c",5,2,696,697,51,0,1,0,694,0,""],[53,"cht_rev_requete","c",5,2,703,717,51,0,2,0,694,0,""],[54,":T0_cht_rev_requete","c",4,0,723,741,50,0,2,0,694,742,""],[55,"complements","f",1,0,761,771,1,2,5,4,772,0,""],[56,"trier_par","f",2,0,780,788,55,1,1,3,789,0,""],[57,"","f",3,0,780,788,56,2,1,2,790,0,""],[58,"champ","f",4,0,791,795,57,2,1,1,796,0,""],[59,"T0","c",5,2,798,799,58,0,1,0,796,0,""],[60,"chi_id_requete","c",5,2,805,818,58,0,2,0,796,0,""],[61,"d\u00e9croissant","f",4,0,824,834,57,0,2,0,835,0,""],[62,"limit\u00e9_\u00e0","f",2,0,847,854,55,2,2,2,855,0,""],[63,"quantit\u00e9","f",3,0,856,863,62,1,1,1,864,0,""],[64,":quantitee","c",4,0,865,874,63,0,1,0,864,875,""],[65,"d\u00e9but","f",3,0,879,883,62,1,2,1,884,0,""],[66,":debut","c",4,0,885,890,65,0,1,0,884,891,""]]'),
('3','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chi_id_requete`) , :n_chi_id_requete)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         egal(champ(`chi_id_requete`) , :c_chi_id_requete),
         egal(champ(`chx_cible_requete`) , :c_chx_cible_requete)
      )
   )
)','
UPDATE b1.tbl_requetes SET `chi_id_requete` = :n_chi_id_requete
WHERE (/*  */ `chi_id_requete` = :c_chi_id_requete AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_3($par){
    $texte_sql_3=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.CRLF;
    if($par[''n_chi_id_requete'']==='''' || $par[''n_chi_id_requete'']===NULL ){
        $texte_sql_3.=''    `chi_id_requete`  = NULL  ''.CRLF;
    }else{
        $texte_sql_3.=''    `chi_id_requete`  = ''.sq0($par[''n_chi_id_requete'']).'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.CRLF;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.CRLF;
    $texte_sql_3.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_3 = <pre>'' . $texte_sql_3 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_3)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_3()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','changer le numéro d''une requête','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chi_id_requete","c",4,2,61,74,6,0,1,0,59,0,""],[8,":n_chi_id_requete","c",3,0,80,96,5,0,2,0,59,97,""],[9,"provenance","f",1,0,104,113,1,1,3,5,114,0,""],[10,"table_reference","f",2,0,122,136,9,1,1,4,137,0,""],[11,"source","f",3,0,148,153,10,1,1,3,154,0,""],[12,"nom_de_la_table","f",4,0,155,169,11,2,1,2,170,0,""],[13,"tbl_requetes","c",5,0,171,182,12,0,1,0,0,0,""],[14,"base","f",5,0,186,189,12,1,2,1,190,0,""],[15,"b1","c",6,0,191,192,14,0,1,0,190,193,""],[16,"conditions","f",1,0,214,223,1,1,4,4,224,0,""],[17,"et","f",2,0,232,233,16,3,1,3,234,0,""],[18,"#","f",3,0,245,245,17,0,1,0,246,247,""],[19,"egal","f",3,0,259,262,17,2,2,2,263,0,""],[20,"champ","f",4,0,264,268,19,1,1,1,269,0,""],[21,"chi_id_requete","c",5,2,271,284,20,0,1,0,269,0,""],[22,":c_chi_id_requete","c",4,0,290,306,19,0,2,0,269,307,""],[23,"egal","f",3,0,319,322,17,2,3,2,323,0,""],[24,"champ","f",4,0,324,328,23,1,1,1,329,0,""],[25,"chx_cible_requete","c",5,2,331,347,24,0,1,0,329,0,""],[26,":c_chx_cible_requete","c",4,0,353,372,23,0,2,0,329,373,""]]'),
('4','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_requete`) , :chi_id_requete) , egal(champ(`chx_cible_requete`) , :chx_cible_requete))
   )
)','
DELETE FROM b1.tbl_requetes
WHERE (`chi_id_requete` = :chi_id_requete AND `chx_cible_requete` = :chx_cible_requete) ;','function sql_4($par){
    $texte_sql_4=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes
          WHERE (`chi_id_requete` = ''.sq1($par[''chi_id_requete'']).'' AND `chx_cible_requete` = ''.sq1($par[''chx_cible_requete'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_4 = <pre>'' . $texte_sql_4 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_4)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_4()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_requetes","c",5,0,106,117,7,0,1,0,0,0,""],[9,"base","f",5,0,121,124,7,1,2,1,125,0,""],[10,"b1","c",6,0,126,127,9,0,1,0,125,128,""],[11,"conditions","f",1,0,149,158,1,1,3,4,159,0,""],[12,"et","f",2,0,167,168,11,2,1,3,169,0,""],[13,"egal","f",3,0,170,173,12,2,1,2,174,0,""],[14,"champ","f",4,0,175,179,13,1,1,1,180,0,""],[15,"chi_id_requete","c",5,2,182,195,14,0,1,0,180,0,""],[16,":chi_id_requete","c",4,0,201,215,13,0,2,0,180,216,""],[17,"egal","f",3,0,220,223,12,2,2,2,224,0,""],[18,"champ","f",4,0,225,229,17,1,1,1,230,0,""],[19,"chx_cible_requete","c",5,2,232,248,18,0,1,0,230,0,""],[20,":chx_cible_requete","c",4,0,254,271,17,0,2,0,230,272,""]]'),
('5','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_revs , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chx_cible_rev`) , :chx_cible_rev) , egal(champ(`chp_provenance_rev`) , :chp_provenance_rev) , egal(champ(`chx_source_rev`) , :chx_source_rev))
   )
)','
DELETE FROM b1.tbl_revs
WHERE (`chx_cible_rev` = :chx_cible_rev
   AND `chp_provenance_rev` = :chp_provenance_rev
   AND `chx_source_rev` = :chx_source_rev) ;','function sql_5($par){
    $texte_sql_5=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_revs
          WHERE (`chx_cible_rev` = ''.sq1($par[''chx_cible_rev'']).'' AND `chp_provenance_rev` = ''.sq1($par[''chp_provenance_rev'']).'' AND `chx_source_rev` = ''.sq1($par[''chx_source_rev'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_5 = <pre>'' . $texte_sql_5 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_5);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_5()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','rev par cible, provenance et source','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_revs","c",5,0,106,113,7,0,1,0,0,0,""],[9,"base","f",5,0,117,120,7,1,2,1,121,0,""],[10,"b1","c",6,0,122,123,9,0,1,0,121,124,""],[11,"conditions","f",1,0,145,154,1,1,3,4,155,0,""],[12,"et","f",2,0,163,164,11,3,1,3,165,0,""],[13,"egal","f",3,0,166,169,12,2,1,2,170,0,""],[14,"champ","f",4,0,171,175,13,1,1,1,176,0,""],[15,"chx_cible_rev","c",5,2,178,190,14,0,1,0,176,0,""],[16,":chx_cible_rev","c",4,0,196,209,13,0,2,0,176,210,""],[17,"egal","f",3,0,214,217,12,2,2,2,218,0,""],[18,"champ","f",4,0,219,223,17,1,1,1,224,0,""],[19,"chp_provenance_rev","c",5,2,226,243,18,0,1,0,224,0,""],[20,":chp_provenance_rev","c",4,0,249,267,17,0,2,0,224,268,""],[21,"egal","f",3,0,272,275,12,2,3,2,276,0,""],[22,"champ","f",4,0,277,281,21,1,1,1,282,0,""],[23,"chx_source_rev","c",5,2,284,297,22,0,1,0,282,0,""],[24,":chx_source_rev","c",4,0,303,317,21,0,2,0,282,318,""]]'),
('6','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_requete`) , champ(`T0` , `cht_sql_requete`) , champ(`T0` , `cht_php_requete`) , champ(`T0` , `cht_matrice_requete`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chx_cible_requete`) , :T0_chx_cible_requete))
   ),
   complements(trier_par(champ(`T0` , `chi_id_requete`) , croissant()))
)','SELECT 
`T0`.`chi_id_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , `T0`.`cht_matrice_requete`
 FROM b1.tbl_requetes T0
WHERE (`T0`.`chx_cible_requete` = :T0_chx_cible_requete) ORDER BY  `T0`.`chi_id_requete`  ASC;','function sql_6($par){
    $champs0=''
      `T0`.`chi_id_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , `T0`.`cht_matrice_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_requete`'',$par[''T0_chx_cible_requete'']);
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_requete`  ASC'';
    $sql0.=$order0;
    /* ATTENTION : pas de limites */
    $plage0='''';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_requete'' => $tab0[0],
                ''T0.cht_sql_requete'' => $tab0[1],
                ''T0.cht_php_requete'' => $tab0[2],
                ''T0.cht_matrice_requete'' => $tab0[3],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_requete","c",3,2,64,77,5,0,2,0,55,0,""],[8,"champ","f",2,0,83,87,4,2,2,1,88,0,""],[9,"T0","c",3,2,90,91,8,0,1,0,88,0,""],[10,"cht_sql_requete","c",3,2,97,111,8,0,2,0,88,0,""],[11,"champ","f",2,0,117,121,4,2,3,1,122,0,""],[12,"T0","c",3,2,124,125,11,0,1,0,122,0,""],[13,"cht_php_requete","c",3,2,131,145,11,0,2,0,122,0,""],[14,"champ","f",2,0,151,155,4,2,4,1,156,0,""],[15,"T0","c",3,2,158,159,14,0,1,0,156,0,""],[16,"cht_matrice_requete","c",3,2,165,183,14,0,2,0,156,0,""],[17,"provenance","f",1,0,192,201,1,1,3,5,202,0,""],[18,"table_reference","f",2,0,210,224,17,1,1,4,225,0,""],[19,"source","f",3,0,236,241,18,1,1,3,242,0,""],[20,"nom_de_la_table","f",4,0,243,257,19,3,1,2,258,0,""],[21,"tbl_requetes","c",5,0,259,270,20,0,1,0,0,0,""],[22,"alias","f",5,0,274,278,20,1,2,1,279,0,""],[23,"T0","c",6,0,280,281,22,0,1,0,279,282,""],[24,"base","f",5,0,286,289,20,1,3,1,290,0,""],[25,"b1","c",6,0,291,292,24,0,1,0,290,293,""],[26,"conditions","f",1,0,314,323,1,1,4,4,324,0,""],[27,"et","f",2,0,332,333,26,1,1,3,334,0,""],[28,"egal","f",3,0,335,338,27,2,1,2,339,0,""],[29,"champ","f",4,0,340,344,28,2,1,1,345,0,""],[30,"T0","c",5,2,347,348,29,0,1,0,345,0,""],[31,"chx_cible_requete","c",5,2,354,370,29,0,2,0,345,0,""],[32,":T0_chx_cible_requete","c",4,0,376,396,28,0,2,0,345,397,""],[33,"complements","f",1,0,409,419,1,1,5,3,420,0,""],[34,"trier_par","f",2,0,421,429,33,2,1,2,430,0,""],[35,"champ","f",3,0,431,435,34,2,1,1,436,0,""],[36,"T0","c",4,2,438,439,35,0,1,0,436,0,""],[37,"chi_id_requete","c",4,2,445,458,35,0,2,0,436,0,""],[38,"croissant","f",3,0,464,472,34,0,2,0,473,0,""]]'),
('7','1','insert','insérer(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chx_cible_requete`) , :chx_cible_requete),
      affecte(champ(`chp_type_requete`) , :chp_type_requete),
      affecte(champ(`cht_rev_requete`) , :cht_rev_requete),
      affecte(champ(`cht_sql_requete`) , :cht_sql_requete),
      affecte(champ(`cht_php_requete`) , :cht_php_requete),
      affecte(champ(`cht_commentaire_requete`) , :cht_commentaire_requete)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , base(b1)))
      )
   )
)','
INSERT INTO b1.`tbl_requetes`(
    `chx_cible_requete` , 
    `chp_type_requete` , 
    `cht_rev_requete` , 
    `cht_sql_requete` , 
    `cht_php_requete` , 
    `cht_commentaire_requete`
) VALUES (
    :chx_cible_requete , 
    :chp_type_requete , 
    :cht_rev_requete , 
    :cht_sql_requete , 
    :cht_php_requete , 
    :cht_commentaire_requete
);','function sql_7($par){
    $texte_sql_7=''
      INSERT INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes`(
         `chx_cible_requete` , 
         `chp_type_requete` , 
         `cht_rev_requete` , 
         `cht_sql_requete` , 
         `cht_php_requete` , 
         `cht_commentaire_requete`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_type_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_rev_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_sql_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_php_requete'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''cht_commentaire_requete'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_7.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_7 = <pre>'' . $texte_sql_7 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_7)){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_7()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,6,2,3,44,0,""],[5,"affecte","f",2,0,52,58,4,2,1,2,59,0,""],[6,"champ","f",3,0,60,64,5,1,1,1,65,0,""],[7,"chx_cible_requete","c",4,2,67,83,6,0,1,0,65,0,""],[8,":chx_cible_requete","c",3,0,89,106,5,0,2,0,65,107,""],[9,"affecte","f",2,0,116,122,4,2,2,2,123,0,""],[10,"champ","f",3,0,124,128,9,1,1,1,129,0,""],[11,"chp_type_requete","c",4,2,131,146,10,0,1,0,129,0,""],[12,":chp_type_requete","c",3,0,152,168,9,0,2,0,129,169,""],[13,"affecte","f",2,0,178,184,4,2,3,2,185,0,""],[14,"champ","f",3,0,186,190,13,1,1,1,191,0,""],[15,"cht_rev_requete","c",4,2,193,207,14,0,1,0,191,0,""],[16,":cht_rev_requete","c",3,0,213,228,13,0,2,0,191,229,""],[17,"affecte","f",2,0,238,244,4,2,4,2,245,0,""],[18,"champ","f",3,0,246,250,17,1,1,1,251,0,""],[19,"cht_sql_requete","c",4,2,253,267,18,0,1,0,251,0,""],[20,":cht_sql_requete","c",3,0,273,288,17,0,2,0,251,289,""],[21,"affecte","f",2,0,298,304,4,2,5,2,305,0,""],[22,"champ","f",3,0,306,310,21,1,1,1,311,0,""],[23,"cht_php_requete","c",4,2,313,327,22,0,1,0,311,0,""],[24,":cht_php_requete","c",3,0,333,348,21,0,2,0,311,349,""],[25,"affecte","f",2,0,358,364,4,2,6,2,365,0,""],[26,"champ","f",3,0,366,370,25,1,1,1,371,0,""],[27,"cht_commentaire_requete","c",4,2,373,395,26,0,1,0,371,0,""],[28,":cht_commentaire_requete","c",3,0,401,424,25,0,2,0,371,425,""],[29,"provenance","f",1,0,436,445,1,1,3,5,446,0,""],[30,"table_reference","f",2,0,454,468,29,1,1,4,469,0,""],[31,"source","f",3,0,480,485,30,1,1,3,486,0,""],[32,"nom_de_la_table","f",4,0,487,501,31,2,1,2,502,0,""],[33,"tbl_requetes","c",5,0,503,514,32,0,1,0,0,0,""],[34,"base","f",5,0,518,521,32,1,2,1,522,0,""],[35,"b1","c",6,0,523,524,34,0,1,0,522,525,""]]'),
('8','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chx_source_rev`) , :n_chx_source_rev)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_revs , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chx_cible_rev`) , :c_chx_cible_rev) , egal(champ(`chp_provenance_rev`) , :c_chp_provenance_rev) , egal(champ(`chx_source_rev`) , :c_chx_source_rev))
   )
)','
UPDATE b1.tbl_revs SET `chx_source_rev` = :n_chx_source_rev
WHERE (`chx_cible_rev` = :c_chx_cible_rev AND `chp_provenance_rev` = :c_chp_provenance_rev AND `chx_source_rev` = :c_chx_source_rev) ;','function sql_8($par){
    $texte_sql_8=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_revs` SET ''.CRLF;
    if($par[''n_chx_source_rev'']==='''' || $par[''n_chx_source_rev'']===NULL ){
        $texte_sql_8.=''    `chx_source_rev`  = NULL  ''.CRLF;
    }else{
        $texte_sql_8.=''    `chx_source_rev`  = ''.sq0($par[''n_chx_source_rev'']).'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chx_cible_rev` = ''.sq1($par[''c_chx_cible_rev'']).''''.CRLF;
    $where0.='' AND `chp_provenance_rev` = ''.sq1($par[''c_chp_provenance_rev'']).''''.CRLF;
    $where0.='' AND `chx_source_rev` = ''.sq1($par[''c_chx_source_rev'']).''''.CRLF;
    $texte_sql_8.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_8 = <pre>'' . $texte_sql_8 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_8)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_8()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chx_source_rev","c",4,2,61,74,6,0,1,0,59,0,""],[8,":n_chx_source_rev","c",3,0,80,96,5,0,2,0,59,97,""],[9,"provenance","f",1,0,104,113,1,1,3,5,114,0,""],[10,"table_reference","f",2,0,122,136,9,1,1,4,137,0,""],[11,"source","f",3,0,148,153,10,1,1,3,154,0,""],[12,"nom_de_la_table","f",4,0,155,169,11,2,1,2,170,0,""],[13,"tbl_revs","c",5,0,171,178,12,0,1,0,0,0,""],[14,"base","f",5,0,182,185,12,1,2,1,186,0,""],[15,"b1","c",6,0,187,188,14,0,1,0,186,189,""],[16,"conditions","f",1,0,210,219,1,1,4,4,220,0,""],[17,"et","f",2,0,228,229,16,3,1,3,230,0,""],[18,"egal","f",3,0,231,234,17,2,1,2,235,0,""],[19,"champ","f",4,0,236,240,18,1,1,1,241,0,""],[20,"chx_cible_rev","c",5,2,243,255,19,0,1,0,241,0,""],[21,":c_chx_cible_rev","c",4,0,261,276,18,0,2,0,241,277,""],[22,"egal","f",3,0,281,284,17,2,2,2,285,0,""],[23,"champ","f",4,0,286,290,22,1,1,1,291,0,""],[24,"chp_provenance_rev","c",5,2,293,310,23,0,1,0,291,0,""],[25,":c_chp_provenance_rev","c",4,0,316,336,22,0,2,0,291,337,""],[26,"egal","f",3,0,341,344,17,2,3,2,345,0,""],[27,"champ","f",4,0,346,350,26,1,1,1,351,0,""],[28,"chx_source_rev","c",5,2,353,366,27,0,1,0,351,0,""],[29,":c_chx_source_rev","c",4,0,372,388,26,0,2,0,351,389,""]]'),
('9','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chp_type_requete`) , :n_chp_type_requete),
      affecte(champ(`cht_rev_requete`) , :n_cht_rev_requete),
      affecte(champ(`cht_sql_requete`) , :n_cht_sql_requete),
      affecte(champ(`cht_php_requete`) , :n_cht_php_requete),
      affecte(champ(`cht_matrice_requete`) , :n_cht_matrice_requete),
      affecte(champ(`cht_commentaire_requete`) , :n_cht_commentaire_requete)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_requete`) , :c_chi_id_requete) , egal(champ(`chx_cible_requete`) , :c_chx_cible_requete))
   )
)','
UPDATE b1.tbl_requetes SET `chp_type_requete` = :n_chp_type_requete , `cht_rev_requete` = :n_cht_rev_requete , `cht_sql_requete` = :n_cht_sql_requete , `cht_php_requete` = :n_cht_php_requete , `cht_matrice_requete` = :n_cht_matrice_requete , `cht_commentaire_requete` = :n_cht_commentaire_requete
WHERE (`chi_id_requete` = :c_chi_id_requete AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_9($par){
    $texte_sql_9=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.CRLF;
    if($par[''n_chp_type_requete'']==='''' || $par[''n_chp_type_requete'']===NULL ){
        $texte_sql_9.=''    `chp_type_requete`         = NULL         , ''.CRLF;
    }else{
        $texte_sql_9.=''    `chp_type_requete`         = \''''.sq0($par[''n_chp_type_requete'']).''\'' , ''.CRLF;
    }
    if($par[''n_cht_rev_requete'']==='''' || $par[''n_cht_rev_requete'']===NULL ){
        $texte_sql_9.=''    `cht_rev_requete`          = NULL          , ''.CRLF;
    }else{
        $texte_sql_9.=''    `cht_rev_requete`          = \''''.sq0($par[''n_cht_rev_requete'']).''\'' , ''.CRLF;
    }
    if($par[''n_cht_sql_requete'']==='''' || $par[''n_cht_sql_requete'']===NULL ){
        $texte_sql_9.=''    `cht_sql_requete`          = NULL          , ''.CRLF;
    }else{
        $texte_sql_9.=''    `cht_sql_requete`          = \''''.sq0($par[''n_cht_sql_requete'']).''\'' , ''.CRLF;
    }
    if($par[''n_cht_php_requete'']==='''' || $par[''n_cht_php_requete'']===NULL ){
        $texte_sql_9.=''    `cht_php_requete`          = NULL          , ''.CRLF;
    }else{
        $texte_sql_9.=''    `cht_php_requete`          = \''''.sq0($par[''n_cht_php_requete'']).''\'' , ''.CRLF;
    }
    if($par[''n_cht_matrice_requete'']==='''' || $par[''n_cht_matrice_requete'']===NULL ){
        $texte_sql_9.=''    `cht_matrice_requete`      = NULL      , ''.CRLF;
    }else{
        $texte_sql_9.=''    `cht_matrice_requete`      = \''''.sq0($par[''n_cht_matrice_requete'']).''\'' , ''.CRLF;
    }
    if($par[''n_cht_commentaire_requete'']==='''' || $par[''n_cht_commentaire_requete'']===NULL ){
        $texte_sql_9.=''    `cht_commentaire_requete`  = NULL  ''.CRLF;
    }else{
        $texte_sql_9.=''    `cht_commentaire_requete`  = \''''.sq0($par[''n_cht_commentaire_requete'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.CRLF;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.CRLF;
    $texte_sql_9.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_9 = <pre>'' . $texte_sql_9 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_9)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_9()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','maj d''une requête','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,6,2,3,45,0,""],[5,"affecte","f",2,0,53,59,4,2,1,2,60,0,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,0,""],[7,"chp_type_requete","c",4,2,68,83,6,0,1,0,66,0,""],[8,":n_chp_type_requete","c",3,0,89,107,5,0,2,0,66,108,""],[9,"affecte","f",2,0,117,123,4,2,2,2,124,0,""],[10,"champ","f",3,0,125,129,9,1,1,1,130,0,""],[11,"cht_rev_requete","c",4,2,132,146,10,0,1,0,130,0,""],[12,":n_cht_rev_requete","c",3,0,152,169,9,0,2,0,130,170,""],[13,"affecte","f",2,0,179,185,4,2,3,2,186,0,""],[14,"champ","f",3,0,187,191,13,1,1,1,192,0,""],[15,"cht_sql_requete","c",4,2,194,208,14,0,1,0,192,0,""],[16,":n_cht_sql_requete","c",3,0,214,231,13,0,2,0,192,232,""],[17,"affecte","f",2,0,241,247,4,2,4,2,248,0,""],[18,"champ","f",3,0,249,253,17,1,1,1,254,0,""],[19,"cht_php_requete","c",4,2,256,270,18,0,1,0,254,0,""],[20,":n_cht_php_requete","c",3,0,276,293,17,0,2,0,254,294,""],[21,"affecte","f",2,0,303,309,4,2,5,2,310,0,""],[22,"champ","f",3,0,311,315,21,1,1,1,316,0,""],[23,"cht_matrice_requete","c",4,2,318,336,22,0,1,0,316,0,""],[24,":n_cht_matrice_requete","c",3,0,342,363,21,0,2,0,316,364,""],[25,"affecte","f",2,0,373,379,4,2,6,2,380,0,""],[26,"champ","f",3,0,381,385,25,1,1,1,386,0,""],[27,"cht_commentaire_requete","c",4,2,388,410,26,0,1,0,386,0,""],[28,":n_cht_commentaire_requete","c",3,0,416,441,25,0,2,0,386,442,""],[29,"provenance","f",1,0,453,462,1,1,3,5,463,0,""],[30,"table_reference","f",2,0,471,485,29,1,1,4,486,0,""],[31,"source","f",3,0,497,502,30,1,1,3,503,0,""],[32,"nom_de_la_table","f",4,0,504,518,31,2,1,2,519,0,""],[33,"tbl_requetes","c",5,0,520,531,32,0,1,0,0,0,""],[34,"base","f",5,0,535,538,32,1,2,1,539,0,""],[35,"b1","c",6,0,540,541,34,0,1,0,539,542,""],[36,"conditions","f",1,0,563,572,1,1,4,4,573,0,""],[37,"et","f",2,0,581,582,36,2,1,3,583,0,""],[38,"egal","f",3,0,584,587,37,2,1,2,588,0,""],[39,"champ","f",4,0,589,593,38,1,1,1,594,0,""],[40,"chi_id_requete","c",5,2,596,609,39,0,1,0,594,0,""],[41,":c_chi_id_requete","c",4,0,615,631,38,0,2,0,594,632,""],[42,"egal","f",3,0,636,639,37,2,2,2,640,0,""],[43,"champ","f",4,0,641,645,42,1,1,1,646,0,""],[44,"chx_cible_requete","c",5,2,648,664,43,0,1,0,646,0,""],[45,":c_chx_cible_requete","c",4,0,670,689,42,0,2,0,646,690,""]]'),
('10','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_rev_travail_basedd`) , :n_chp_rev_travail_basedd)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_basedd`) , :c_chi_id_basedd) , egal(champ(`chx_cible_id_basedd`) , :c_chx_cible_id_basedd))
   )
)','
UPDATE b1.tbl_bdds SET `chp_rev_travail_basedd` = :n_chp_rev_travail_basedd
WHERE (`chi_id_basedd` = :c_chi_id_basedd AND `chx_cible_id_basedd` = :c_chx_cible_id_basedd) ;','function sql_10($par){
    $texte_sql_10=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_bdds` SET ''.CRLF;
    if($par[''n_chp_rev_travail_basedd'']==='''' || $par[''n_chp_rev_travail_basedd'']===NULL ){
        $texte_sql_10.=''    `chp_rev_travail_basedd`  = NULL  ''.CRLF;
    }else{
        $texte_sql_10.=''    `chp_rev_travail_basedd`  = \''''.sq0($par[''n_chp_rev_travail_basedd'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_basedd` = ''.sq1($par[''c_chi_id_basedd'']).''''.CRLF;
    $where0.='' AND `chx_cible_id_basedd` = ''.sq1($par[''c_chx_cible_id_basedd'']).''''.CRLF;
    $texte_sql_10.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_10 = <pre>'' . $texte_sql_10 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_10)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_10()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chp_rev_travail_basedd","c",4,2,61,82,6,0,1,0,59,0,""],[8,":n_chp_rev_travail_basedd","c",3,0,88,112,5,0,2,0,59,113,""],[9,"provenance","f",1,0,120,129,1,1,3,5,130,0,""],[10,"table_reference","f",2,0,138,152,9,1,1,4,153,0,""],[11,"source","f",3,0,164,169,10,1,1,3,170,0,""],[12,"nom_de_la_table","f",4,0,171,185,11,2,1,2,186,0,""],[13,"tbl_bdds","c",5,0,187,194,12,0,1,0,0,0,""],[14,"base","f",5,0,198,201,12,1,2,1,202,0,""],[15,"b1","c",6,0,203,204,14,0,1,0,202,205,""],[16,"conditions","f",1,0,226,235,1,1,4,4,236,0,""],[17,"et","f",2,0,244,245,16,2,1,3,246,0,""],[18,"egal","f",3,0,247,250,17,2,1,2,251,0,""],[19,"champ","f",4,0,252,256,18,1,1,1,257,0,""],[20,"chi_id_basedd","c",5,2,259,271,19,0,1,0,257,0,""],[21,":c_chi_id_basedd","c",4,0,277,292,18,0,2,0,257,293,""],[22,"egal","f",3,0,297,300,17,2,2,2,301,0,""],[23,"champ","f",4,0,302,306,22,1,1,1,307,0,""],[24,"chx_cible_id_basedd","c",5,2,309,327,23,0,1,0,307,0,""],[25,":c_chx_cible_id_basedd","c",4,0,333,354,22,0,2,0,307,355,""]]'),
('11','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_basedd`) , champ(`T0` , `chp_nom_basedd`) , champ(`T0` , `chp_rev_travail_basedd`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         dans(champ(`T0` , `chi_id_basedd`) , (:les_id_des_bases)),
         egal(champ(`T0` , `chx_cible_id_basedd`) , :chx_cible_id_basedd)
      )
   )
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_travail_basedd`
 FROM b1.tbl_bdds T0
WHERE (/*  */ `T0`.`chi_id_basedd` IN (:les_id_des_bases) AND `T0`.`chx_cible_id_basedd` = :chx_cible_id_basedd);','function sql_11($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_travail_basedd`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `T0`.`chi_id_basedd` IN (''.sq0($par[''les_id_des_bases'']).'')''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chp_nom_basedd'' => $tab0[1],
                ''T0.chp_rev_travail_basedd'' => $tab0[2],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_basedd","c",3,2,64,76,5,0,2,0,55,0,""],[8,"champ","f",2,0,82,86,4,2,2,1,87,0,""],[9,"T0","c",3,2,89,90,8,0,1,0,87,0,""],[10,"chp_nom_basedd","c",3,2,96,109,8,0,2,0,87,0,""],[11,"champ","f",2,0,115,119,4,2,3,1,120,0,""],[12,"T0","c",3,2,122,123,11,0,1,0,120,0,""],[13,"chp_rev_travail_basedd","c",3,2,129,150,11,0,2,0,120,0,""],[14,"provenance","f",1,0,159,168,1,1,3,5,169,0,""],[15,"table_reference","f",2,0,177,191,14,1,1,4,192,0,""],[16,"source","f",3,0,203,208,15,1,1,3,209,0,""],[17,"nom_de_la_table","f",4,0,210,224,16,3,1,2,225,0,""],[18,"tbl_bdds","c",5,0,226,233,17,0,1,0,0,0,""],[19,"alias","f",5,0,237,241,17,1,2,1,242,0,""],[20,"T0","c",6,0,243,244,19,0,1,0,242,245,""],[21,"base","f",5,0,249,252,17,1,3,1,253,0,""],[22,"b1","c",6,0,254,255,21,0,1,0,253,256,""],[23,"conditions","f",1,0,277,286,1,1,4,4,287,0,""],[24,"et","f",2,0,295,296,23,3,1,3,297,0,""],[25,"#","f",3,0,308,308,24,0,1,0,309,310,""],[26,"dans","f",3,0,322,325,24,2,2,2,326,0,""],[27,"champ","f",4,0,327,331,26,2,1,1,332,0,""],[28,"T0","c",5,2,334,335,27,0,1,0,332,0,""],[29,"chi_id_basedd","c",5,2,341,353,27,0,2,0,332,0,""],[30,"","f",4,0,341,353,26,1,2,1,359,0,""],[31,":les_id_des_bases","c",5,0,360,376,30,0,1,0,359,377,""],[32,"egal","f",3,0,390,393,24,2,3,2,394,0,""],[33,"champ","f",4,0,395,399,32,2,1,1,400,0,""],[34,"T0","c",5,2,402,403,33,0,1,0,400,0,""],[35,"chx_cible_id_basedd","c",5,2,409,427,33,0,2,0,400,0,""],[36,":chx_cible_id_basedd","c",4,0,433,452,32,0,2,0,400,453,""]]'),
('12','1','insert','insérer(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chx_cible_rev`) , :chx_cible_rev),
      affecte(champ(`chp_provenance_rev`) , :chp_provenance_rev),
      affecte(champ(`chx_source_rev`) , :chx_source_rev),
      affecte(champ(`chp_id_rev`) , :chp_id_rev),
      affecte(champ(`chp_valeur_rev`) , :chp_valeur_rev),
      affecte(champ(`chp_type_rev`) , :chp_type_rev),
      affecte(champ(`chp_niveau_rev`) , :chp_niveau_rev),
      affecte(champ(`chp_quotee_rev`) , :chp_quotee_rev),
      affecte(champ(`chp_pos_premier_rev`) , :chp_pos_premier_rev),
      affecte(champ(`chp_pos_dernier_rev`) , :chp_pos_dernier_rev),
      affecte(champ(`chp_parent_rev`) , :chp_parent_rev),
      affecte(champ(`chp_nbr_enfants_rev`) , :chp_nbr_enfants_rev),
      affecte(champ(`chp_num_enfant_rev`) , :chp_num_enfant_rev),
      affecte(champ(`chp_profondeur_rev`) , :chp_profondeur_rev),
      affecte(champ(`chp_pos_ouver_parenthese_rev`) , :chp_pos_ouver_parenthese_rev),
      affecte(champ(`chp_pos_fermer_parenthese_rev`) , :chp_pos_fermer_parenthese_rev),
      affecte(champ(`chp_commentaire_rev`) , :chp_commentaire_rev)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_revs , base(b1)))
      )
   )
)','
INSERT INTO b1.`tbl_revs`(
    `chx_cible_rev` , 
    `chp_provenance_rev` , 
    `chx_source_rev` , 
    `chp_id_rev` , 
    `chp_valeur_rev` , 
    `chp_type_rev` , 
    `chp_niveau_rev` , 
    `chp_quotee_rev` , 
    `chp_pos_premier_rev` , 
    `chp_pos_dernier_rev` , 
    `chp_parent_rev` , 
    `chp_nbr_enfants_rev` , 
    `chp_num_enfant_rev` , 
    `chp_profondeur_rev` , 
    `chp_pos_ouver_parenthese_rev` , 
    `chp_pos_fermer_parenthese_rev` , 
    `chp_commentaire_rev`
) VALUES (
    :chx_cible_rev , 
    :chp_provenance_rev , 
    :chx_source_rev , 
    :chp_id_rev , 
    :chp_valeur_rev , 
    :chp_type_rev , 
    :chp_niveau_rev , 
    :chp_quotee_rev , 
    :chp_pos_premier_rev , 
    :chp_pos_dernier_rev , 
    :chp_parent_rev , 
    :chp_nbr_enfants_rev , 
    :chp_num_enfant_rev , 
    :chp_profondeur_rev , 
    :chp_pos_ouver_parenthese_rev , 
    :chp_pos_fermer_parenthese_rev , 
    :chp_commentaire_rev
);','function sql_12($par){
    $texte_sql_12=''
      INSERT INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_revs`(
         `chx_cible_rev` , 
         `chp_provenance_rev` , 
         `chx_source_rev` , 
         `chp_id_rev` , 
         `chp_valeur_rev` , 
         `chp_type_rev` , 
         `chp_niveau_rev` , 
         `chp_quotee_rev` , 
         `chp_pos_premier_rev` , 
         `chp_pos_dernier_rev` , 
         `chp_parent_rev` , 
         `chp_nbr_enfants_rev` , 
         `chp_num_enfant_rev` , 
         `chp_profondeur_rev` , 
         `chp_pos_ouver_parenthese_rev` , 
         `chp_pos_fermer_parenthese_rev` , 
         `chp_commentaire_rev`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_provenance_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_source_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_id_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_valeur_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_type_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_niveau_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_quotee_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_premier_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_dernier_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_parent_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nbr_enfants_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_num_enfant_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_profondeur_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_ouver_parenthese_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_pos_fermer_parenthese_rev'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_rev'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_12.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_12 = <pre>'' . $texte_sql_12 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_12)){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_12()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,17,2,3,44,0,""],[5,"affecte","f",2,0,52,58,4,2,1,2,59,0,""],[6,"champ","f",3,0,60,64,5,1,1,1,65,0,""],[7,"chx_cible_rev","c",4,2,67,79,6,0,1,0,65,0,""],[8,":chx_cible_rev","c",3,0,85,98,5,0,2,0,65,99,""],[9,"affecte","f",2,0,108,114,4,2,2,2,115,0,""],[10,"champ","f",3,0,116,120,9,1,1,1,121,0,""],[11,"chp_provenance_rev","c",4,2,123,140,10,0,1,0,121,0,""],[12,":chp_provenance_rev","c",3,0,146,164,9,0,2,0,121,165,""],[13,"affecte","f",2,0,174,180,4,2,3,2,181,0,""],[14,"champ","f",3,0,182,186,13,1,1,1,187,0,""],[15,"chx_source_rev","c",4,2,189,202,14,0,1,0,187,0,""],[16,":chx_source_rev","c",3,0,208,222,13,0,2,0,187,223,""],[17,"affecte","f",2,0,232,238,4,2,4,2,239,0,""],[18,"champ","f",3,0,240,244,17,1,1,1,245,0,""],[19,"chp_id_rev","c",4,2,247,256,18,0,1,0,245,0,""],[20,":chp_id_rev","c",3,0,262,272,17,0,2,0,245,273,""],[21,"affecte","f",2,0,282,288,4,2,5,2,289,0,""],[22,"champ","f",3,0,290,294,21,1,1,1,295,0,""],[23,"chp_valeur_rev","c",4,2,297,310,22,0,1,0,295,0,""],[24,":chp_valeur_rev","c",3,0,316,330,21,0,2,0,295,331,""],[25,"affecte","f",2,0,340,346,4,2,6,2,347,0,""],[26,"champ","f",3,0,348,352,25,1,1,1,353,0,""],[27,"chp_type_rev","c",4,2,355,366,26,0,1,0,353,0,""],[28,":chp_type_rev","c",3,0,372,384,25,0,2,0,353,385,""],[29,"affecte","f",2,0,394,400,4,2,7,2,401,0,""],[30,"champ","f",3,0,402,406,29,1,1,1,407,0,""],[31,"chp_niveau_rev","c",4,2,409,422,30,0,1,0,407,0,""],[32,":chp_niveau_rev","c",3,0,428,442,29,0,2,0,407,443,""],[33,"affecte","f",2,0,452,458,4,2,8,2,459,0,""],[34,"champ","f",3,0,460,464,33,1,1,1,465,0,""],[35,"chp_quotee_rev","c",4,2,467,480,34,0,1,0,465,0,""],[36,":chp_quotee_rev","c",3,0,486,500,33,0,2,0,465,501,""],[37,"affecte","f",2,0,510,516,4,2,9,2,517,0,""],[38,"champ","f",3,0,518,522,37,1,1,1,523,0,""],[39,"chp_pos_premier_rev","c",4,2,525,543,38,0,1,0,523,0,""],[40,":chp_pos_premier_rev","c",3,0,549,568,37,0,2,0,523,569,""],[41,"affecte","f",2,0,578,584,4,2,10,2,585,0,""],[42,"champ","f",3,0,586,590,41,1,1,1,591,0,""],[43,"chp_pos_dernier_rev","c",4,2,593,611,42,0,1,0,591,0,""],[44,":chp_pos_dernier_rev","c",3,0,617,636,41,0,2,0,591,637,""],[45,"affecte","f",2,0,646,652,4,2,11,2,653,0,""],[46,"champ","f",3,0,654,658,45,1,1,1,659,0,""],[47,"chp_parent_rev","c",4,2,661,674,46,0,1,0,659,0,""],[48,":chp_parent_rev","c",3,0,680,694,45,0,2,0,659,695,""],[49,"affecte","f",2,0,704,710,4,2,12,2,711,0,""],[50,"champ","f",3,0,712,716,49,1,1,1,717,0,""],[51,"chp_nbr_enfants_rev","c",4,2,719,737,50,0,1,0,717,0,""],[52,":chp_nbr_enfants_rev","c",3,0,743,762,49,0,2,0,717,763,""],[53,"affecte","f",2,0,772,778,4,2,13,2,779,0,""],[54,"champ","f",3,0,780,784,53,1,1,1,785,0,""],[55,"chp_num_enfant_rev","c",4,2,787,804,54,0,1,0,785,0,""],[56,":chp_num_enfant_rev","c",3,0,810,828,53,0,2,0,785,829,""],[57,"affecte","f",2,0,838,844,4,2,14,2,845,0,""],[58,"champ","f",3,0,846,850,57,1,1,1,851,0,""],[59,"chp_profondeur_rev","c",4,2,853,870,58,0,1,0,851,0,""],[60,":chp_profondeur_rev","c",3,0,876,894,57,0,2,0,851,895,""],[61,"affecte","f",2,0,904,910,4,2,15,2,911,0,""],[62,"champ","f",3,0,912,916,61,1,1,1,917,0,""],[63,"chp_pos_ouver_parenthese_rev","c",4,2,919,946,62,0,1,0,917,0,""],[64,":chp_pos_ouver_parenthese_rev","c",3,0,952,980,61,0,2,0,917,981,""],[65,"affecte","f",2,0,990,996,4,2,16,2,997,0,""],[66,"champ","f",3,0,998,1002,65,1,1,1,1003,0,""],[67,"chp_pos_fermer_parenthese_rev","c",4,2,1005,1033,66,0,1,0,1003,0,""],[68,":chp_pos_fermer_parenthese_rev","c",3,0,1039,1068,65,0,2,0,1003,1069,""],[69,"affecte","f",2,0,1078,1084,4,2,17,2,1085,0,""],[70,"champ","f",3,0,1086,1090,69,1,1,1,1091,0,""],[71,"chp_commentaire_rev","c",4,2,1093,1111,70,0,1,0,1091,0,""],[72,":chp_commentaire_rev","c",3,0,1117,1136,69,0,2,0,1091,1137,""],[73,"provenance","f",1,0,1148,1157,1,1,3,5,1158,0,""],[74,"table_reference","f",2,0,1166,1180,73,1,1,4,1181,0,""],[75,"source","f",3,0,1192,1197,74,1,1,3,1198,0,""],[76,"nom_de_la_table","f",4,0,1199,1213,75,2,1,2,1214,0,""],[77,"tbl_revs","c",5,0,1215,1222,76,0,1,0,0,0,""],[78,"base","f",5,0,1226,1229,76,1,2,1,1230,0,""],[79,"b1","c",6,0,1231,1232,78,0,1,0,1230,1233,""]]'),
('13','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_rev`),
      champ(`T0` , `chp_provenance_rev`),
      champ(`T0` , `chx_source_rev`),
      champ(`T1` , `chp_nom_source`),
      champ(`T0` , `chp_valeur_rev`),
      champ(`T0` , `chp_type_rev`),
      champ(`T0` , `chp_niveau_rev`),
      champ(`T0` , `chp_pos_premier_rev`),
      champ(`T0` , `chp_commentaire_rev`),
      champ(`T2` , `chp_type_requete`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_revs , alias(T0) , base(b1)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_sources , alias(T1) , base(b1))),
         contrainte(egal(champ(T1 , chi_id_source) , champ(T0 , chx_source_rev)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_requetes , alias(T2) , base(b1))),
         contrainte(egal(champ(T2 , chi_id_requete) , champ(T0 , chx_source_rev)))
      )
   ),
   conditions(
      et(
         egal(champ(`T0` , `chx_cible_rev`) , :T0_chx_cible_rev),
         comme(champ(`T0` , `chp_provenance_rev`) , :T0_chp_provenance_rev),
         egal(champ(`T0` , `chx_source_rev`) , :T0_chx_source_rev),
         comme(champ(`T1` , `chp_nom_source`) , :T1_chp_nom_source1),
         pas_comme(champ(`T1` , `chp_nom_source`) , :T1_chp_nom_source2),
         comme(champ(`T0` , `chp_valeur_rev`) , :T0_chp_valeur_rev),
         comme(champ(`T0` , `chp_commentaire_rev`) , :T0_chp_commentaire_rev),
         egal(champ(`T0` , `chi_id_rev`) , :T0_chi_id_rev)
      )
   ),
   complements(
      trier_par((champ(`T0` , `chp_provenance_rev`) , croissant()) , (champ(`T0` , `chx_source_rev`) , croissant())),
      limité_à(quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_rev` , `T0`.`chp_provenance_rev` , `T0`.`chx_source_rev` , `T1`.`chp_nom_source` , `T0`.`chp_valeur_rev` , 
`T0`.`chp_type_rev` , `T0`.`chp_niveau_rev` , `T0`.`chp_pos_premier_rev` , `T0`.`chp_commentaire_rev` , `T2`.`chp_type_requete`
 FROM b1.tbl_revs T0
 LEFT JOIN b1.tbl_sources T1 ON T1.chi_id_source = T0.chx_source_rev

 LEFT JOIN b1.tbl_requetes T2 ON T2.chi_id_requete = T0.chx_source_rev

WHERE (`T0`.`chx_cible_rev` = :T0_chx_cible_rev
   AND `T0`.`chp_provenance_rev` LIKE :T0_chp_provenance_rev
   AND `T0`.`chx_source_rev` = :T0_chx_source_rev
   AND `T1`.`chp_nom_source` LIKE :T1_chp_nom_source1
   AND `T1`.`chp_nom_source` NOT LIKE :T1_chp_nom_source2
   AND `T0`.`chp_valeur_rev` LIKE :T0_chp_valeur_rev
   AND `T0`.`chp_commentaire_rev` LIKE :T0_chp_commentaire_rev
   AND `T0`.`chi_id_rev` = :T0_chi_id_rev) 
ORDER BY `T0`.`chp_provenance_rev` ASC, `T0`.`chx_source_rev` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_13($par){
    $champs0=''
      `T0`.`chi_id_rev` , `T0`.`chp_provenance_rev` , `T0`.`chx_source_rev` , `T1`.`chp_nom_source` , `T0`.`chp_valeur_rev` , 
      `T0`.`chp_type_rev` , `T0`.`chp_niveau_rev` , `T0`.`chp_pos_premier_rev` , `T0`.`chp_commentaire_rev` , `T2`.`chp_type_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_revs T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T1 ON T1.chi_id_source = T0.chx_source_rev

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T2 ON T2.chi_id_requete = T0.chx_source_rev
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    if(($par[''T0_chx_cible_rev''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_rev`'',$par[''T0_chx_cible_rev'']);
    }
    if(($par[''T0_chp_provenance_rev''] !== '''')){
        $where0.='' AND `T0`.`chp_provenance_rev` LIKE ''.sq1($par[''T0_chp_provenance_rev'']).''''.CRLF;
    }
    if(($par[''T0_chx_source_rev''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_source_rev`'',$par[''T0_chx_source_rev'']);
    }
    if(($par[''T1_chp_nom_source1''] !== '''')){
        $where0.='' AND `T1`.`chp_nom_source` LIKE ''.sq1($par[''T1_chp_nom_source1'']).''''.CRLF;
    }
    if(($par[''T1_chp_nom_source2''] !== '''')){
        $where0.='' AND `T1`.`chp_nom_source` NOT LIKE ''.sq1($par[''T1_chp_nom_source2'']).''''.CRLF;
    }
    if(($par[''T0_chp_valeur_rev''] !== '''')){
        $where0.='' AND `T0`.`chp_valeur_rev` LIKE ''.sq1($par[''T0_chp_valeur_rev'']).''''.CRLF;
    }
    if(($par[''T0_chp_commentaire_rev''] !== '''')){
        $where0.='' AND `T0`.`chp_commentaire_rev` LIKE ''.sq1($par[''T0_chp_commentaire_rev'']).''''.CRLF;
    }
    if(($par[''T0_chi_id_rev''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_rev`'',$par[''T0_chi_id_rev'']);
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_provenance_rev` ASC, `T0`.`chx_source_rev` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_rev'' => $tab0[0],
                ''T0.chp_provenance_rev'' => $tab0[1],
                ''T0.chx_source_rev'' => $tab0[2],
                ''T1.chp_nom_source'' => $tab0[3],
                ''T0.chp_valeur_rev'' => $tab0[4],
                ''T0.chp_type_rev'' => $tab0[5],
                ''T0.chp_niveau_rev'' => $tab0[6],
                ''T0.chp_pos_premier_rev'' => $tab0[7],
                ''T0.chp_commentaire_rev'' => $tab0[8],
                ''T2.chp_type_requete'' => $tab0[9],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','revs','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,10,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_rev","c",3,2,71,80,5,0,2,0,62,0,""],[8,"champ","f",2,0,91,95,4,2,2,1,96,0,""],[9,"T0","c",3,2,98,99,8,0,1,0,96,0,""],[10,"chp_provenance_rev","c",3,2,105,122,8,0,2,0,96,0,""],[11,"champ","f",2,0,133,137,4,2,3,1,138,0,""],[12,"T0","c",3,2,140,141,11,0,1,0,138,0,""],[13,"chx_source_rev","c",3,2,147,160,11,0,2,0,138,0,""],[14,"champ","f",2,0,171,175,4,2,4,1,176,0,""],[15,"T1","c",3,2,178,179,14,0,1,0,176,0,""],[16,"chp_nom_source","c",3,2,185,198,14,0,2,0,176,0,""],[17,"champ","f",2,0,209,213,4,2,5,1,214,0,""],[18,"T0","c",3,2,216,217,17,0,1,0,214,0,""],[19,"chp_valeur_rev","c",3,2,223,236,17,0,2,0,214,0,""],[20,"champ","f",2,0,247,251,4,2,6,1,252,0,""],[21,"T0","c",3,2,254,255,20,0,1,0,252,0,""],[22,"chp_type_rev","c",3,2,261,272,20,0,2,0,252,0,""],[23,"champ","f",2,0,283,287,4,2,7,1,288,0,""],[24,"T0","c",3,2,290,291,23,0,1,0,288,0,""],[25,"chp_niveau_rev","c",3,2,297,310,23,0,2,0,288,0,""],[26,"champ","f",2,0,321,325,4,2,8,1,326,0,""],[27,"T0","c",3,2,328,329,26,0,1,0,326,0,""],[28,"chp_pos_premier_rev","c",3,2,335,353,26,0,2,0,326,0,""],[29,"champ","f",2,0,364,368,4,2,9,1,369,0,""],[30,"T0","c",3,2,371,372,29,0,1,0,369,0,""],[31,"chp_commentaire_rev","c",3,2,378,396,29,0,2,0,369,0,""],[32,"champ","f",2,0,407,411,4,2,10,1,412,0,""],[33,"T2","c",3,2,414,415,32,0,1,0,412,0,""],[34,"chp_type_requete","c",3,2,421,436,32,0,2,0,412,0,""],[35,"provenance","f",1,0,449,458,1,3,3,5,459,0,""],[36,"table_reference","f",2,0,467,481,35,1,1,4,482,0,""],[37,"source","f",3,0,493,498,36,1,1,3,499,0,""],[38,"nom_de_la_table","f",4,0,500,514,37,3,1,2,515,0,""],[39,"tbl_revs","c",5,0,516,523,38,0,1,0,0,0,""],[40,"alias","f",5,0,527,531,38,1,2,1,532,0,""],[41,"T0","c",6,0,533,534,40,0,1,0,532,535,""],[42,"base","f",5,0,539,542,38,1,3,1,543,0,""],[43,"b1","c",6,0,544,545,42,0,1,0,543,546,""],[44,"jointure_gauche","f",2,0,565,579,35,2,2,4,580,0,""],[45,"source","f",3,0,591,596,44,1,1,3,597,0,""],[46,"nom_de_la_table","f",4,0,598,612,45,3,1,2,613,0,""],[47,"tbl_sources","c",5,0,614,624,46,0,1,0,0,0,""],[48,"alias","f",5,0,628,632,46,1,2,1,633,0,""],[49,"T1","c",6,0,634,635,48,0,1,0,633,636,""],[50,"base","f",5,0,640,643,46,1,3,1,644,0,""],[51,"b1","c",6,0,645,646,50,0,1,0,644,647,""],[52,"contrainte","f",3,0,661,670,44,1,2,3,671,0,""],[53,"egal","f",4,0,672,675,52,2,1,2,676,0,""],[54,"champ","f",5,0,677,681,53,2,1,1,682,0,""],[55,"T1","c",6,0,683,684,54,0,1,0,0,0,""],[56,"chi_id_source","c",6,0,688,700,54,0,2,0,682,701,""],[57,"champ","f",5,0,705,709,53,2,2,1,710,0,""],[58,"T0","c",6,0,711,712,57,0,1,0,0,0,""],[59,"chx_source_rev","c",6,0,716,729,57,0,2,0,710,730,""],[60,"jointure_gauche","f",2,0,749,763,35,2,3,4,764,0,""],[61,"source","f",3,0,775,780,60,1,1,3,781,0,""],[62,"nom_de_la_table","f",4,0,782,796,61,3,1,2,797,0,""],[63,"tbl_requetes","c",5,0,798,809,62,0,1,0,0,0,""],[64,"alias","f",5,0,813,817,62,1,2,1,818,0,""],[65,"T2","c",6,0,819,820,64,0,1,0,818,821,""],[66,"base","f",5,0,825,828,62,1,3,1,829,0,""],[67,"b1","c",6,0,830,831,66,0,1,0,829,832,""],[68,"contrainte","f",3,0,846,855,60,1,2,3,856,0,""],[69,"egal","f",4,0,857,860,68,2,1,2,861,0,""],[70,"champ","f",5,0,862,866,69,2,1,1,867,0,""],[71,"T2","c",6,0,868,869,70,0,1,0,0,0,""],[72,"chi_id_requete","c",6,0,873,886,70,0,2,0,867,887,""],[73,"champ","f",5,0,891,895,69,2,2,1,896,0,""],[74,"T0","c",6,0,897,898,73,0,1,0,0,0,""],[75,"chx_source_rev","c",6,0,902,915,73,0,2,0,896,916,""],[76,"conditions","f",1,0,937,946,1,1,4,4,947,0,""],[77,"et","f",2,0,955,956,76,8,1,3,957,0,""],[78,"egal","f",3,0,968,971,77,2,1,2,972,0,""],[79,"champ","f",4,0,973,977,78,2,1,1,978,0,""],[80,"T0","c",5,2,980,981,79,0,1,0,978,0,""],[81,"chx_cible_rev","c",5,2,987,999,79,0,2,0,978,0,""],[82,":T0_chx_cible_rev","c",4,0,1005,1021,78,0,2,0,978,1022,""],[83,"comme","f",3,0,1034,1038,77,2,2,2,1039,0,""],[84,"champ","f",4,0,1040,1044,83,2,1,1,1045,0,""],[85,"T0","c",5,2,1047,1048,84,0,1,0,1045,0,""],[86,"chp_provenance_rev","c",5,2,1054,1071,84,0,2,0,1045,0,""],[87,":T0_chp_provenance_rev","c",4,0,1077,1098,83,0,2,0,1045,1099,""],[88,"egal","f",3,0,1111,1114,77,2,3,2,1115,0,""],[89,"champ","f",4,0,1116,1120,88,2,1,1,1121,0,""],[90,"T0","c",5,2,1123,1124,89,0,1,0,1121,0,""],[91,"chx_source_rev","c",5,2,1130,1143,89,0,2,0,1121,0,""],[92,":T0_chx_source_rev","c",4,0,1149,1166,88,0,2,0,1121,1167,""],[93,"comme","f",3,0,1179,1183,77,2,4,2,1184,0,""],[94,"champ","f",4,0,1185,1189,93,2,1,1,1190,0,""],[95,"T1","c",5,2,1192,1193,94,0,1,0,1190,0,""],[96,"chp_nom_source","c",5,2,1199,1212,94,0,2,0,1190,0,""],[97,":T1_chp_nom_source1","c",4,0,1218,1236,93,0,2,0,1190,1237,""],[98,"pas_comme","f",3,0,1249,1257,77,2,5,2,1258,0,""],[99,"champ","f",4,0,1259,1263,98,2,1,1,1264,0,""],[100,"T1","c",5,2,1266,1267,99,0,1,0,1264,0,""],[101,"chp_nom_source","c",5,2,1273,1286,99,0,2,0,1264,0,""],[102,":T1_chp_nom_source2","c",4,0,1292,1310,98,0,2,0,1264,1311,""],[103,"comme","f",3,0,1323,1327,77,2,6,2,1328,0,""],[104,"champ","f",4,0,1329,1333,103,2,1,1,1334,0,""],[105,"T0","c",5,2,1336,1337,104,0,1,0,1334,0,""],[106,"chp_valeur_rev","c",5,2,1343,1356,104,0,2,0,1334,0,""],[107,":T0_chp_valeur_rev","c",4,0,1362,1379,103,0,2,0,1334,1380,""],[108,"comme","f",3,0,1392,1396,77,2,7,2,1397,0,""],[109,"champ","f",4,0,1398,1402,108,2,1,1,1403,0,""],[110,"T0","c",5,2,1405,1406,109,0,1,0,1403,0,""],[111,"chp_commentaire_rev","c",5,2,1412,1430,109,0,2,0,1403,0,""],[112,":T0_chp_commentaire_rev","c",4,0,1436,1458,108,0,2,0,1403,1459,""],[113,"egal","f",3,0,1471,1474,77,2,8,2,1475,0,""],[114,"champ","f",4,0,1476,1480,113,2,1,1,1481,0,""],[115,"T0","c",5,2,1483,1484,114,0,1,0,1481,0,""],[116,"chi_id_rev","c",5,2,1490,1499,114,0,2,0,1481,0,""],[117,":T0_chi_id_rev","c",4,0,1505,1518,113,0,2,0,1481,1519,""],[118,"complements","f",1,0,1538,1548,1,2,5,4,1549,0,""],[119,"trier_par","f",2,0,1557,1565,118,2,1,3,1566,0,""],[120,"","f",3,0,1557,1565,119,2,1,2,1567,0,""],[121,"champ","f",4,0,1568,1572,120,2,1,1,1573,0,""],[122,"T0","c",5,2,1575,1576,121,0,1,0,1573,0,""],[123,"chp_provenance_rev","c",5,2,1582,1599,121,0,2,0,1573,0,""],[124,"croissant","f",4,0,1605,1613,120,0,2,0,1614,0,""],[125,"","f",3,0,1605,1613,119,2,2,2,1620,0,""],[126,"champ","f",4,0,1621,1625,125,2,1,1,1626,0,""],[127,"T0","c",5,2,1628,1629,126,0,1,0,1626,0,""],[128,"chx_source_rev","c",5,2,1635,1648,126,0,2,0,1626,0,""],[129,"croissant","f",4,0,1654,1662,125,0,2,0,1663,0,""],[130,"limit\u00e9_\u00e0","f",2,0,1675,1682,118,2,2,2,1683,0,""],[131,"quantit\u00e9","f",3,0,1684,1691,130,1,1,1,1692,0,""],[132,":quantitee","c",4,0,1693,1702,131,0,1,0,1692,1703,""],[133,"d\u00e9but","f",3,0,1707,1711,130,1,2,1,1712,0,""],[134,":debut","c",4,0,1713,1718,133,0,1,0,1712,1719,""]]'),
('14','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_revs , base(b1)))
      )
   ),
   conditions(egal(champ(`chx_cible_rev`) , :chx_cible_rev))
)','
DELETE FROM b1.tbl_revs
WHERE `chx_cible_rev` = :chx_cible_rev ;','function sql_14($par){
    $texte_sql_14=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_revs
          WHERE `chx_cible_rev` = ''.sq1($par[''chx_cible_rev'']).'' ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_14 = <pre>'' . $texte_sql_14 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_14);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_14()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','rev par cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_revs","c",5,0,106,113,7,0,1,0,0,0,""],[9,"base","f",5,0,117,120,7,1,2,1,121,0,""],[10,"b1","c",6,0,122,123,9,0,1,0,121,124,""],[11,"conditions","f",1,0,145,154,1,1,3,3,155,0,""],[12,"egal","f",2,0,156,159,11,2,1,2,160,0,""],[13,"champ","f",3,0,161,165,12,1,1,1,166,0,""],[14,"chx_cible_rev","c",4,2,168,180,13,0,1,0,166,0,""],[15,":chx_cible_rev","c",3,0,186,199,12,0,2,0,166,200,""]]'),
('15','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_basedd`) , champ(`T0` , `chp_nom_basedd`) , champ(`T0` , `chp_commentaire_basedd`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         egal(champ(`T0` , `chx_cible_id_basedd`) , :T0_chx_cible_id_basedd),
         egal(champ(`T0` , `chi_id_basedd`) , :T0_chi_id_basedd),
         comme(champ(`T0` , `chp_nom_basedd`) , :T0_chp_nom_basedd)
      )
   ),
   complements(
      trier_par((champ(`T0` , `chi_id_basedd`) , croissant())),
      limité_à(quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_commentaire_basedd`
 FROM b1.tbl_bdds T0
WHERE (/*  */ `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd
   AND `T0`.`chi_id_basedd` = :T0_chi_id_basedd
   AND `T0`.`chp_nom_basedd` LIKE :T0_chp_nom_basedd) 
ORDER BY `T0`.`chi_id_basedd` ASC 
LIMIT:quantitee OFFSET :debut ;','function sql_15($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_commentaire_basedd`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    if(($par[''T0_chx_cible_id_basedd''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    }
    if(($par[''T0_chi_id_basedd''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_basedd`'',$par[''T0_chi_id_basedd'']);
    }
    if(($par[''T0_chp_nom_basedd''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_basedd` LIKE ''.sq1($par[''T0_chp_nom_basedd'']).''''.CRLF;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_basedd` ASC'';
    $sql0.=$order0;
    $plage0=''
       LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chp_nom_basedd'' => $tab0[1],
                ''T0.chp_commentaire_basedd'' => $tab0[2],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','bdd','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_basedd","c",3,2,64,76,5,0,2,0,55,0,""],[8,"champ","f",2,0,82,86,4,2,2,1,87,0,""],[9,"T0","c",3,2,89,90,8,0,1,0,87,0,""],[10,"chp_nom_basedd","c",3,2,96,109,8,0,2,0,87,0,""],[11,"champ","f",2,0,115,119,4,2,3,1,120,0,""],[12,"T0","c",3,2,122,123,11,0,1,0,120,0,""],[13,"chp_commentaire_basedd","c",3,2,129,150,11,0,2,0,120,0,""],[14,"provenance","f",1,0,159,168,1,1,3,5,169,0,""],[15,"table_reference","f",2,0,177,191,14,1,1,4,192,0,""],[16,"source","f",3,0,203,208,15,1,1,3,209,0,""],[17,"nom_de_la_table","f",4,0,210,224,16,3,1,2,225,0,""],[18,"tbl_bdds","c",5,0,226,233,17,0,1,0,0,0,""],[19,"alias","f",5,0,237,241,17,1,2,1,242,0,""],[20,"T0","c",6,0,243,244,19,0,1,0,242,245,""],[21,"base","f",5,0,249,252,17,1,3,1,253,0,""],[22,"b1","c",6,0,254,255,21,0,1,0,253,256,""],[23,"conditions","f",1,0,277,286,1,1,4,4,287,0,""],[24,"et","f",2,0,295,296,23,4,1,3,297,0,""],[25,"#","f",3,0,308,308,24,0,1,0,309,310,""],[26,"egal","f",3,0,322,325,24,2,2,2,326,0,""],[27,"champ","f",4,0,327,331,26,2,1,1,332,0,""],[28,"T0","c",5,2,334,335,27,0,1,0,332,0,""],[29,"chx_cible_id_basedd","c",5,2,341,359,27,0,2,0,332,0,""],[30,":T0_chx_cible_id_basedd","c",4,0,365,387,26,0,2,0,332,388,""],[31,"egal","f",3,0,400,403,24,2,3,2,404,0,""],[32,"champ","f",4,0,405,409,31,2,1,1,410,0,""],[33,"T0","c",5,2,412,413,32,0,1,0,410,0,""],[34,"chi_id_basedd","c",5,2,419,431,32,0,2,0,410,0,""],[35,":T0_chi_id_basedd","c",4,0,437,453,31,0,2,0,410,454,""],[36,"comme","f",3,0,466,470,24,2,4,2,471,0,""],[37,"champ","f",4,0,472,476,36,2,1,1,477,0,""],[38,"T0","c",5,2,479,480,37,0,1,0,477,0,""],[39,"chp_nom_basedd","c",5,2,486,499,37,0,2,0,477,0,""],[40,":T0_chp_nom_basedd","c",4,0,505,522,36,0,2,0,477,523,""],[41,"complements","f",1,0,542,552,1,2,5,4,553,0,""],[42,"trier_par","f",2,0,561,569,41,1,1,3,570,0,""],[43,"","f",3,0,561,569,42,2,1,2,571,0,""],[44,"champ","f",4,0,572,576,43,2,1,1,577,0,""],[45,"T0","c",5,2,579,580,44,0,1,0,577,0,""],[46,"chi_id_basedd","c",5,2,586,598,44,0,2,0,577,0,""],[47,"croissant","f",4,0,604,612,43,0,2,0,613,0,""],[48,"limit\u00e9_\u00e0","f",2,0,625,632,41,2,2,2,633,0,""],[49,"quantit\u00e9","f",3,0,634,641,48,1,1,1,642,0,""],[50,":quantitee","c",4,0,643,652,49,0,1,0,642,653,""],[51,"d\u00e9but","f",3,0,657,661,48,1,2,1,662,0,""],[52,":debut","c",4,0,663,668,51,0,1,0,662,669,""]]'),
('16','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chx_dossier_id_basedd`) , :n_chx_dossier_id_basedd),
      affecte(champ(`chp_nom_basedd`) , :n_chp_nom_basedd),
      affecte(champ(`chp_rev_basedd`) , :n_chp_rev_basedd),
      affecte(champ(`chp_commentaire_basedd`) , :n_chp_commentaire_basedd),
      affecte(champ(`chp_genere_basedd`) , :n_chp_genere_basedd),
      affecte(champ(`chp_rev_travail_basedd`) , :n_chp_rev_travail_basedd),
      affecte(champ(`chp_fournisseur_basedd`) , :n_chp_fournisseur_basedd)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_basedd`) , :c_chi_id_basedd) , egal(champ(`chx_cible_id_basedd`) , :c_chx_cible_id_basedd))
   )
)','
UPDATE b1.tbl_bdds SET `chx_dossier_id_basedd` = :n_chx_dossier_id_basedd , `chp_nom_basedd` = :n_chp_nom_basedd , `chp_rev_basedd` = :n_chp_rev_basedd , `chp_commentaire_basedd` = :n_chp_commentaire_basedd , `chp_genere_basedd` = :n_chp_genere_basedd , `chp_rev_travail_basedd` = :n_chp_rev_travail_basedd , `chp_fournisseur_basedd` = :n_chp_fournisseur_basedd
WHERE (`chi_id_basedd` = :c_chi_id_basedd AND `chx_cible_id_basedd` = :c_chx_cible_id_basedd) ;','function sql_16($par){
    $texte_sql_16=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_bdds` SET ''.CRLF;
    if($par[''n_chx_dossier_id_basedd'']==='''' || $par[''n_chx_dossier_id_basedd'']===NULL ){
        $texte_sql_16.=''    `chx_dossier_id_basedd`   = NULL   , ''.CRLF;
    }else{
        $texte_sql_16.=''    `chx_dossier_id_basedd`   = ''.sq0($par[''n_chx_dossier_id_basedd'']).'' , ''.CRLF;
    }
    $texte_sql_16.=''    `chp_nom_basedd`          = \''''.sq0($par[''n_chp_nom_basedd'']).''\''          , ''.CRLF;
    if($par[''n_chp_rev_basedd'']==='''' || $par[''n_chp_rev_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_rev_basedd`          = NULL          , ''.CRLF;
    }else{
        $texte_sql_16.=''    `chp_rev_basedd`          = \''''.sq0($par[''n_chp_rev_basedd'']).''\'' , ''.CRLF;
    }
    if($par[''n_chp_commentaire_basedd'']==='''' || $par[''n_chp_commentaire_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_commentaire_basedd`  = NULL  , ''.CRLF;
    }else{
        $texte_sql_16.=''    `chp_commentaire_basedd`  = \''''.sq0($par[''n_chp_commentaire_basedd'']).''\'' , ''.CRLF;
    }
    if($par[''n_chp_genere_basedd'']==='''' || $par[''n_chp_genere_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_genere_basedd`       = NULL       , ''.CRLF;
    }else{
        $texte_sql_16.=''    `chp_genere_basedd`       = \''''.sq0($par[''n_chp_genere_basedd'']).''\'' , ''.CRLF;
    }
    if($par[''n_chp_rev_travail_basedd'']==='''' || $par[''n_chp_rev_travail_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_rev_travail_basedd`  = NULL  , ''.CRLF;
    }else{
        $texte_sql_16.=''    `chp_rev_travail_basedd`  = \''''.sq0($par[''n_chp_rev_travail_basedd'']).''\'' , ''.CRLF;
    }
    if($par[''n_chp_fournisseur_basedd'']==='''' || $par[''n_chp_fournisseur_basedd'']===NULL ){
        $texte_sql_16.=''    `chp_fournisseur_basedd`  = NULL  ''.CRLF;
    }else{
        $texte_sql_16.=''    `chp_fournisseur_basedd`  = \''''.sq0($par[''n_chp_fournisseur_basedd'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_basedd` = ''.sq1($par[''c_chi_id_basedd'']).''''.CRLF;
    $where0.='' AND `chx_cible_id_basedd` = ''.sq1($par[''c_chx_cible_id_basedd'']).''''.CRLF;
    $texte_sql_16.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_16 = <pre>'' . $texte_sql_16 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_16)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_16()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,7,2,3,45,0,""],[5,"affecte","f",2,0,53,59,4,2,1,2,60,0,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,0,""],[7,"chx_dossier_id_basedd","c",4,2,68,88,6,0,1,0,66,0,""],[8,":n_chx_dossier_id_basedd","c",3,0,94,117,5,0,2,0,66,118,""],[9,"affecte","f",2,0,127,133,4,2,2,2,134,0,""],[10,"champ","f",3,0,135,139,9,1,1,1,140,0,""],[11,"chp_nom_basedd","c",4,2,142,155,10,0,1,0,140,0,""],[12,":n_chp_nom_basedd","c",3,0,161,177,9,0,2,0,140,178,""],[13,"affecte","f",2,0,187,193,4,2,3,2,194,0,""],[14,"champ","f",3,0,195,199,13,1,1,1,200,0,""],[15,"chp_rev_basedd","c",4,2,202,215,14,0,1,0,200,0,""],[16,":n_chp_rev_basedd","c",3,0,221,237,13,0,2,0,200,238,""],[17,"affecte","f",2,0,247,253,4,2,4,2,254,0,""],[18,"champ","f",3,0,255,259,17,1,1,1,260,0,""],[19,"chp_commentaire_basedd","c",4,2,262,283,18,0,1,0,260,0,""],[20,":n_chp_commentaire_basedd","c",3,0,289,313,17,0,2,0,260,314,""],[21,"affecte","f",2,0,323,329,4,2,5,2,330,0,""],[22,"champ","f",3,0,331,335,21,1,1,1,336,0,""],[23,"chp_genere_basedd","c",4,2,338,354,22,0,1,0,336,0,""],[24,":n_chp_genere_basedd","c",3,0,360,379,21,0,2,0,336,380,""],[25,"affecte","f",2,0,389,395,4,2,6,2,396,0,""],[26,"champ","f",3,0,397,401,25,1,1,1,402,0,""],[27,"chp_rev_travail_basedd","c",4,2,404,425,26,0,1,0,402,0,""],[28,":n_chp_rev_travail_basedd","c",3,0,431,455,25,0,2,0,402,456,""],[29,"affecte","f",2,0,465,471,4,2,7,2,472,0,""],[30,"champ","f",3,0,473,477,29,1,1,1,478,0,""],[31,"chp_fournisseur_basedd","c",4,2,480,501,30,0,1,0,478,0,""],[32,":n_chp_fournisseur_basedd","c",3,0,507,531,29,0,2,0,478,532,""],[33,"provenance","f",1,0,543,552,1,1,3,5,553,0,""],[34,"table_reference","f",2,0,561,575,33,1,1,4,576,0,""],[35,"source","f",3,0,587,592,34,1,1,3,593,0,""],[36,"nom_de_la_table","f",4,0,594,608,35,2,1,2,609,0,""],[37,"tbl_bdds","c",5,0,610,617,36,0,1,0,0,0,""],[38,"base","f",5,0,621,624,36,1,2,1,625,0,""],[39,"b1","c",6,0,626,627,38,0,1,0,625,628,""],[40,"conditions","f",1,0,649,658,1,1,4,4,659,0,""],[41,"et","f",2,0,667,668,40,2,1,3,669,0,""],[42,"egal","f",3,0,670,673,41,2,1,2,674,0,""],[43,"champ","f",4,0,675,679,42,1,1,1,680,0,""],[44,"chi_id_basedd","c",5,2,682,694,43,0,1,0,680,0,""],[45,":c_chi_id_basedd","c",4,0,700,715,42,0,2,0,680,716,""],[46,"egal","f",3,0,720,723,41,2,2,2,724,0,""],[47,"champ","f",4,0,725,729,46,1,1,1,730,0,""],[48,"chx_cible_id_basedd","c",5,2,732,750,47,0,1,0,730,0,""],[49,":c_chx_cible_id_basedd","c",4,0,756,777,46,0,2,0,730,778,""]]'),
('17','1','insert','insérer(
   base_de_reference(1),
   valeurs(affecte(champ(`chx_dossier_id_basedd`) , :chx_dossier_id_basedd) , affecte(champ(`chx_cible_id_basedd`) , :chx_cible_id_basedd) , affecte(champ(`chp_nom_basedd`) , :chp_nom_basedd) , affecte(champ(`chp_commentaire_basedd`) , :chp_commentaire_basedd) , affecte(champ(`chp_fournisseur_basedd`) , :chp_fournisseur_basedd)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , base(b1)))
      )
   )
)','
INSERT INTO b1.`tbl_bdds`(
    `chx_dossier_id_basedd` , 
    `chx_cible_id_basedd` , 
    `chp_nom_basedd` , 
    `chp_commentaire_basedd` , 
    `chp_fournisseur_basedd`
) VALUES (
    :chx_dossier_id_basedd , 
    :chx_cible_id_basedd , 
    :chp_nom_basedd , 
    :chp_commentaire_basedd , 
    :chp_fournisseur_basedd
);','function sql_17($par){
    $texte_sql_17=''
      INSERT INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_bdds`(
         `chx_dossier_id_basedd` , 
         `chx_cible_id_basedd` , 
         `chp_nom_basedd` , 
         `chp_commentaire_basedd` , 
         `chp_fournisseur_basedd`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_dossier_id_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_id_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_basedd'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_fournisseur_basedd'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_17.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_17 = <pre>'' . $texte_sql_17 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_17)){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_17()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,5,2,3,44,0,""],[5,"affecte","f",2,0,45,51,4,2,1,2,52,0,""],[6,"champ","f",3,0,53,57,5,1,1,1,58,0,""],[7,"chx_dossier_id_basedd","c",4,2,60,80,6,0,1,0,58,0,""],[8,":chx_dossier_id_basedd","c",3,0,86,107,5,0,2,0,58,108,""],[9,"affecte","f",2,0,112,118,4,2,2,2,119,0,""],[10,"champ","f",3,0,120,124,9,1,1,1,125,0,""],[11,"chx_cible_id_basedd","c",4,2,127,145,10,0,1,0,125,0,""],[12,":chx_cible_id_basedd","c",3,0,151,170,9,0,2,0,125,171,""],[13,"affecte","f",2,0,175,181,4,2,3,2,182,0,""],[14,"champ","f",3,0,183,187,13,1,1,1,188,0,""],[15,"chp_nom_basedd","c",4,2,190,203,14,0,1,0,188,0,""],[16,":chp_nom_basedd","c",3,0,209,223,13,0,2,0,188,224,""],[17,"affecte","f",2,0,228,234,4,2,4,2,235,0,""],[18,"champ","f",3,0,236,240,17,1,1,1,241,0,""],[19,"chp_commentaire_basedd","c",4,2,243,264,18,0,1,0,241,0,""],[20,":chp_commentaire_basedd","c",3,0,270,292,17,0,2,0,241,293,""],[21,"affecte","f",2,0,297,303,4,2,5,2,304,0,""],[22,"champ","f",3,0,305,309,21,1,1,1,310,0,""],[23,"chp_fournisseur_basedd","c",4,2,312,333,22,0,1,0,310,0,""],[24,":chp_fournisseur_basedd","c",3,0,339,361,21,0,2,0,310,362,""],[25,"provenance","f",1,0,369,378,1,1,3,5,379,0,""],[26,"table_reference","f",2,0,387,401,25,1,1,4,402,0,""],[27,"source","f",3,0,413,418,26,1,1,3,419,0,""],[28,"nom_de_la_table","f",4,0,420,434,27,2,1,2,435,0,""],[29,"tbl_bdds","c",5,0,436,443,28,0,1,0,0,0,""],[30,"base","f",5,0,447,450,28,1,2,1,451,0,""],[31,"b1","c",6,0,452,453,30,0,1,0,451,454,""]]'),
('18','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_basedd`) , :chi_id_basedd) , egal(champ(`chx_cible_id_basedd`) , :chx_cible_id_basedd))
   )
)','
DELETE FROM b1.tbl_bdds
WHERE (`chi_id_basedd` = :chi_id_basedd
   AND `chx_cible_id_basedd` = :chx_cible_id_basedd) ;','function sql_18($par){
    $texte_sql_18=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds
          WHERE (`chi_id_basedd` = ''.sq1($par[''chi_id_basedd'']).'' AND `chx_cible_id_basedd` = ''.sq1($par[''chx_cible_id_basedd'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_18 = <pre>'' . $texte_sql_18 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_18);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_18()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','bdds par id et cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_bdds","c",5,0,106,113,7,0,1,0,0,0,""],[9,"base","f",5,0,117,120,7,1,2,1,121,0,""],[10,"b1","c",6,0,122,123,9,0,1,0,121,124,""],[11,"conditions","f",1,0,145,154,1,1,3,4,155,0,""],[12,"et","f",2,0,163,164,11,2,1,3,165,0,""],[13,"egal","f",3,0,166,169,12,2,1,2,170,0,""],[14,"champ","f",4,0,171,175,13,1,1,1,176,0,""],[15,"chi_id_basedd","c",5,2,178,190,14,0,1,0,176,0,""],[16,":chi_id_basedd","c",4,0,196,209,13,0,2,0,176,210,""],[17,"egal","f",3,0,214,217,12,2,2,2,218,0,""],[18,"champ","f",4,0,219,223,17,1,1,1,224,0,""],[19,"chx_cible_id_basedd","c",5,2,226,244,18,0,1,0,224,0,""],[20,":chx_cible_id_basedd","c",4,0,250,269,17,0,2,0,224,270,""]]'),
('19','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_tache`) , champ(`T0` , `chp_texte_tache`) , champ(`T0` , `chp_priorite_tache`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         egal(champ(`T0` , `chx_utilisateur_tache`) , :T0_chx_utilisateur_tache),
         egal(champ(`T0` , `chi_id_tache`) , :T0_chi_id_tache),
         comme(champ(`T0` , `chp_texte_tache`) , :T0_chp_texte_tache),
         egal(champ(`T0` , `chp_priorite_tache`) , :T0_chp_priorite_tache),
         inf(champ(`T0` , `chp_priorite_tache`) , :T0_chp_priorite_tache2)
      )
   ),
   complements(
      trier_par((champ(`T0` , `chp_priorite_tache`) , croissant())),
      limité_à(quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
 FROM b1.tbl_taches T0
WHERE (/*  */ `T0`.`chx_utilisateur_tache` = :T0_chx_utilisateur_tache
   AND `T0`.`chi_id_tache` = :T0_chi_id_tache
   AND `T0`.`chp_texte_tache` LIKE :T0_chp_texte_tache
   AND `T0`.`chp_priorite_tache` = :T0_chp_priorite_tache
   AND `T0`.`chp_priorite_tache` < :T0_chp_priorite_tache2) 
ORDER BY `T0`.`chp_priorite_tache` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_19($par){
    $champs0=''
      `T0`.`chi_id_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    if(($par[''T0_chx_utilisateur_tache''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_utilisateur_tache`'',$par[''T0_chx_utilisateur_tache'']);
    }
    if(($par[''T0_chi_id_tache''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_tache`'',$par[''T0_chi_id_tache'']);
    }
    if(($par[''T0_chp_texte_tache''] !== '''')){
        $where0.='' AND `T0`.`chp_texte_tache` LIKE ''.sq1($par[''T0_chp_texte_tache'']).''''.CRLF;
    }
    if(($par[''T0_chp_priorite_tache''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chp_priorite_tache`'',$par[''T0_chp_priorite_tache'']);
    }
    if(($par[''T0_chp_priorite_tache2''] !== '''')){
        $where0.='' AND `T0`.`chp_priorite_tache` < ''.sq1($par[''T0_chp_priorite_tache2'']).''''.CRLF;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_priorite_tache` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_tache'' => $tab0[0],
                ''T0.chp_texte_tache'' => $tab0[1],
                ''T0.chp_priorite_tache'' => $tab0[2],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','tâches','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_tache","c",3,2,64,75,5,0,2,0,55,0,""],[8,"champ","f",2,0,81,85,4,2,2,1,86,0,""],[9,"T0","c",3,2,88,89,8,0,1,0,86,0,""],[10,"chp_texte_tache","c",3,2,95,109,8,0,2,0,86,0,""],[11,"champ","f",2,0,115,119,4,2,3,1,120,0,""],[12,"T0","c",3,2,122,123,11,0,1,0,120,0,""],[13,"chp_priorite_tache","c",3,2,129,146,11,0,2,0,120,0,""],[14,"provenance","f",1,0,155,164,1,1,3,5,165,0,""],[15,"table_reference","f",2,0,173,187,14,1,1,4,188,0,""],[16,"source","f",3,0,199,204,15,1,1,3,205,0,""],[17,"nom_de_la_table","f",4,0,206,220,16,3,1,2,221,0,""],[18,"tbl_taches","c",5,0,222,231,17,0,1,0,0,0,""],[19,"alias","f",5,0,235,239,17,1,2,1,240,0,""],[20,"T0","c",6,0,241,242,19,0,1,0,240,243,""],[21,"base","f",5,0,247,250,17,1,3,1,251,0,""],[22,"b1","c",6,0,252,253,21,0,1,0,251,254,""],[23,"conditions","f",1,0,275,284,1,1,4,4,285,0,""],[24,"et","f",2,0,293,294,23,6,1,3,295,0,""],[25,"#","f",3,0,306,306,24,0,1,0,307,308,""],[26,"egal","f",3,0,320,323,24,2,2,2,324,0,""],[27,"champ","f",4,0,325,329,26,2,1,1,330,0,""],[28,"T0","c",5,2,332,333,27,0,1,0,330,0,""],[29,"chx_utilisateur_tache","c",5,2,339,359,27,0,2,0,330,0,""],[30,":T0_chx_utilisateur_tache","c",4,0,365,389,26,0,2,0,330,390,""],[31,"egal","f",3,0,402,405,24,2,3,2,406,0,""],[32,"champ","f",4,0,407,411,31,2,1,1,412,0,""],[33,"T0","c",5,2,414,415,32,0,1,0,412,0,""],[34,"chi_id_tache","c",5,2,421,432,32,0,2,0,412,0,""],[35,":T0_chi_id_tache","c",4,0,438,453,31,0,2,0,412,454,""],[36,"comme","f",3,0,466,470,24,2,4,2,471,0,""],[37,"champ","f",4,0,472,476,36,2,1,1,477,0,""],[38,"T0","c",5,2,479,480,37,0,1,0,477,0,""],[39,"chp_texte_tache","c",5,2,486,500,37,0,2,0,477,0,""],[40,":T0_chp_texte_tache","c",4,0,506,524,36,0,2,0,477,525,""],[41,"egal","f",3,0,537,540,24,2,5,2,541,0,""],[42,"champ","f",4,0,542,546,41,2,1,1,547,0,""],[43,"T0","c",5,2,549,550,42,0,1,0,547,0,""],[44,"chp_priorite_tache","c",5,2,556,573,42,0,2,0,547,0,""],[45,":T0_chp_priorite_tache","c",4,0,579,600,41,0,2,0,547,601,""],[46,"inf","f",3,0,613,615,24,2,6,2,616,0,""],[47,"champ","f",4,0,617,621,46,2,1,1,622,0,""],[48,"T0","c",5,2,624,625,47,0,1,0,622,0,""],[49,"chp_priorite_tache","c",5,2,631,648,47,0,2,0,622,0,""],[50,":T0_chp_priorite_tache2","c",4,0,654,676,46,0,2,0,622,677,""],[51,"complements","f",1,0,696,706,1,2,5,4,707,0,""],[52,"trier_par","f",2,0,715,723,51,1,1,3,724,0,""],[53,"","f",3,0,715,723,52,2,1,2,725,0,""],[54,"champ","f",4,0,726,730,53,2,1,1,731,0,""],[55,"T0","c",5,2,733,734,54,0,1,0,731,0,""],[56,"chp_priorite_tache","c",5,2,740,757,54,0,2,0,731,0,""],[57,"croissant","f",4,0,763,771,53,0,2,0,772,0,""],[58,"limit\u00e9_\u00e0","f",2,0,784,791,51,2,2,2,792,0,""],[59,"quantit\u00e9","f",3,0,793,800,58,1,1,1,801,0,""],[60,":quantitee","c",4,0,802,811,59,0,1,0,801,812,""],[61,"d\u00e9but","f",3,0,816,820,58,1,2,1,821,0,""],[62,":debut","c",4,0,822,827,61,0,1,0,821,828,""]]'),
('20','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chp_priorite_tache`) , moins(champ(`chp_priorite_tache`) , 1))
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         egal(champ(`chi_id_tache`) , :c_chi_id_tache),
         egal(champ(`chx_utilisateur_tache`) , :c_chx_utilisateur_tache),
         supegal(champ(`chp_priorite_tache`) , 1)
      )
   )
)','
UPDATE b1.tbl_taches SET `chp_priorite_tache` = (`chp_priorite_tache`-1)
WHERE (/*  */ `chi_id_tache` = :c_chi_id_tache AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache AND `chp_priorite_tache` >= 1) ;','function sql_20($par){
    $texte_sql_20=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    $texte_sql_20.='' `chp_priorite_tache` = (`chp_priorite_tache`-1) ''.CRLF;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.CRLF;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $where0.='' AND `chp_priorite_tache` >= 1''.CRLF;
    $texte_sql_20.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_20 = <pre>'' . $texte_sql_20 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_20)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_20()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,4,45,0,""],[5,"affecte","f",2,0,53,59,4,2,1,3,60,0,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,0,""],[7,"chp_priorite_tache","c",4,2,68,85,6,0,1,0,66,0,""],[8,"moins","f",3,0,91,95,5,2,2,2,96,0,""],[9,"champ","f",4,0,97,101,8,1,1,1,102,0,""],[10,"chp_priorite_tache","c",5,2,104,121,9,0,1,0,102,0,""],[11,"1","c",4,0,127,127,8,0,2,0,102,128,""],[12,"provenance","f",1,0,140,149,1,1,3,5,150,0,""],[13,"table_reference","f",2,0,158,172,12,1,1,4,173,0,""],[14,"source","f",3,0,184,189,13,1,1,3,190,0,""],[15,"nom_de_la_table","f",4,0,191,205,14,2,1,2,206,0,""],[16,"tbl_taches","c",5,0,207,216,15,0,1,0,0,0,""],[17,"base","f",5,0,220,223,15,1,2,1,224,0,""],[18,"b1","c",6,0,225,226,17,0,1,0,224,227,""],[19,"conditions","f",1,0,248,257,1,1,4,4,258,0,""],[20,"et","f",2,0,266,267,19,4,1,3,268,0,""],[21,"#","f",3,0,279,279,20,0,1,0,280,281,""],[22,"egal","f",3,0,293,296,20,2,2,2,297,0,""],[23,"champ","f",4,0,298,302,22,1,1,1,303,0,""],[24,"chi_id_tache","c",5,2,305,316,23,0,1,0,303,0,""],[25,":c_chi_id_tache","c",4,0,322,336,22,0,2,0,303,337,""],[26,"egal","f",3,0,349,352,20,2,3,2,353,0,""],[27,"champ","f",4,0,354,358,26,1,1,1,359,0,""],[28,"chx_utilisateur_tache","c",5,2,361,381,27,0,1,0,359,0,""],[29,":c_chx_utilisateur_tache","c",4,0,387,410,26,0,2,0,359,411,""],[30,"supegal","f",3,0,423,429,20,2,4,2,430,0,""],[31,"champ","f",4,0,431,435,30,1,1,1,436,0,""],[32,"chp_priorite_tache","c",5,2,438,455,31,0,1,0,436,0,""],[33,"1","c",4,0,461,461,30,0,2,0,436,462,""]]'),
('21','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chp_priorite_tache`) , plus(champ(`chp_priorite_tache`) , 1))
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_tache`) , :c_chi_id_tache) , egal(champ(`chx_utilisateur_tache`) , :c_chx_utilisateur_tache) , inf(champ(`chp_priorite_tache`) , 50))
   )
)','
UPDATE b1.tbl_taches SET `chp_priorite_tache` = (`chp_priorite_tache`+1)
WHERE (`chi_id_tache` = :c_chi_id_tache AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache AND `chp_priorite_tache` < 50) ;','function sql_21($par){
    $texte_sql_21=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    $texte_sql_21.='' `chp_priorite_tache` = (`chp_priorite_tache`+1) ''.CRLF;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.CRLF;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $where0.='' AND `chp_priorite_tache` < 50''.CRLF;
    $texte_sql_21.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_21 = <pre>'' . $texte_sql_21 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_21)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_21()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,4,45,0,""],[5,"affecte","f",2,0,53,59,4,2,1,3,60,0,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,0,""],[7,"chp_priorite_tache","c",4,2,68,85,6,0,1,0,66,0,""],[8,"plus","f",3,0,91,94,5,2,2,2,95,0,""],[9,"champ","f",4,0,96,100,8,1,1,1,101,0,""],[10,"chp_priorite_tache","c",5,2,103,120,9,0,1,0,101,0,""],[11,"1","c",4,0,126,126,8,0,2,0,101,127,""],[12,"provenance","f",1,0,139,148,1,1,3,5,149,0,""],[13,"table_reference","f",2,0,157,171,12,1,1,4,172,0,""],[14,"source","f",3,0,183,188,13,1,1,3,189,0,""],[15,"nom_de_la_table","f",4,0,190,204,14,2,1,2,205,0,""],[16,"tbl_taches","c",5,0,206,215,15,0,1,0,0,0,""],[17,"base","f",5,0,219,222,15,1,2,1,223,0,""],[18,"b1","c",6,0,224,225,17,0,1,0,223,226,""],[19,"conditions","f",1,0,247,256,1,1,4,4,257,0,""],[20,"et","f",2,0,265,266,19,3,1,3,267,0,""],[21,"egal","f",3,0,268,271,20,2,1,2,272,0,""],[22,"champ","f",4,0,273,277,21,1,1,1,278,0,""],[23,"chi_id_tache","c",5,2,280,291,22,0,1,0,278,0,""],[24,":c_chi_id_tache","c",4,0,297,311,21,0,2,0,278,312,""],[25,"egal","f",3,0,316,319,20,2,2,2,320,0,""],[26,"champ","f",4,0,321,325,25,1,1,1,326,0,""],[27,"chx_utilisateur_tache","c",5,2,328,348,26,0,1,0,326,0,""],[28,":c_chx_utilisateur_tache","c",4,0,354,377,25,0,2,0,326,378,""],[29,"inf","f",3,0,382,384,20,2,3,2,385,0,""],[30,"champ","f",4,0,386,390,29,1,1,1,391,0,""],[31,"chp_priorite_tache","c",5,2,393,410,30,0,1,0,391,0,""],[32,"50","c",4,0,416,417,29,0,2,0,391,418,""]]'),
('22','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_priorite_tache`) , :n_chp_priorite_tache)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_tache`) , :c_chi_id_tache) , egal(champ(`chx_utilisateur_tache`) , :c_chx_utilisateur_tache))
   )
)','
UPDATE b1.tbl_taches SET `chp_priorite_tache` = :n_chp_priorite_tache
WHERE (`chi_id_tache` = :c_chi_id_tache AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache) ;','function sql_22($par){
    $texte_sql_22=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_22.=''    `chp_priorite_tache`  = NULL  ''.CRLF;
    }else{
        $texte_sql_22.=''    `chp_priorite_tache`  = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.CRLF;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $texte_sql_22.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_22 = <pre>'' . $texte_sql_22 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_22)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_22()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chp_priorite_tache","c",4,2,61,78,6,0,1,0,59,0,""],[8,":n_chp_priorite_tache","c",3,0,84,104,5,0,2,0,59,105,""],[9,"provenance","f",1,0,112,121,1,1,3,5,122,0,""],[10,"table_reference","f",2,0,130,144,9,1,1,4,145,0,""],[11,"source","f",3,0,156,161,10,1,1,3,162,0,""],[12,"nom_de_la_table","f",4,0,163,177,11,2,1,2,178,0,""],[13,"tbl_taches","c",5,0,179,188,12,0,1,0,0,0,""],[14,"base","f",5,0,192,195,12,1,2,1,196,0,""],[15,"b1","c",6,0,197,198,14,0,1,0,196,199,""],[16,"conditions","f",1,0,220,229,1,1,4,4,230,0,""],[17,"et","f",2,0,238,239,16,2,1,3,240,0,""],[18,"egal","f",3,0,241,244,17,2,1,2,245,0,""],[19,"champ","f",4,0,246,250,18,1,1,1,251,0,""],[20,"chi_id_tache","c",5,2,253,264,19,0,1,0,251,0,""],[21,":c_chi_id_tache","c",4,0,270,284,18,0,2,0,251,285,""],[22,"egal","f",3,0,289,292,17,2,2,2,293,0,""],[23,"champ","f",4,0,294,298,22,1,1,1,299,0,""],[24,"chx_utilisateur_tache","c",5,2,301,321,23,0,1,0,299,0,""],[25,":c_chx_utilisateur_tache","c",4,0,327,350,22,0,2,0,299,351,""]]'),
('23','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_priorite_tache`) , :n_chp_priorite_tache)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(
         ou(est(champ(chp_priorite_tache) , NULL) , egal(champ(chp_priorite_tache) , '''')),
         egal(champ(chx_utilisateur_tache) , :c_chx_utilisateur_tache)
      )
   )
)','
UPDATE b1.tbl_taches SET `chp_priorite_tache` = :n_chp_priorite_tache
WHERE ((chp_priorite_tache IS NULL OR chp_priorite_tache = '''') AND chx_utilisateur_tache = :c_chx_utilisateur_tache) ;','function sql_23($par){
    $texte_sql_23=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_23.=''    `chp_priorite_tache`  = NULL  ''.CRLF;
    }else{
        $texte_sql_23.=''    `chp_priorite_tache`  = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND (chp_priorite_tache IS NULL OR chp_priorite_tache = \''\'')''.CRLF;
    $where0.='' AND chx_utilisateur_tache = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $texte_sql_23.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_23 = <pre>'' . $texte_sql_23 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_23)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_23()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chp_priorite_tache","c",4,2,61,78,6,0,1,0,59,0,""],[8,":n_chp_priorite_tache","c",3,0,84,104,5,0,2,0,59,105,""],[9,"provenance","f",1,0,112,121,1,1,3,5,122,0,""],[10,"table_reference","f",2,0,130,144,9,1,1,4,145,0,""],[11,"source","f",3,0,156,161,10,1,1,3,162,0,""],[12,"nom_de_la_table","f",4,0,163,177,11,2,1,2,178,0,""],[13,"tbl_taches","c",5,0,179,188,12,0,1,0,0,0,""],[14,"base","f",5,0,192,195,12,1,2,1,196,0,""],[15,"b1","c",6,0,197,198,14,0,1,0,196,199,""],[16,"conditions","f",1,0,220,229,1,1,4,5,230,0,""],[17,"et","f",2,0,238,239,16,2,1,4,240,0,""],[18,"ou","f",3,0,251,252,17,2,1,3,253,0,""],[19,"est","f",4,0,254,256,18,2,1,2,257,0,""],[20,"champ","f",5,0,258,262,19,1,1,1,263,0,""],[21,"chp_priorite_tache","c",6,0,264,281,20,0,1,0,263,282,""],[22,"NULL","c",5,0,286,289,19,0,2,0,263,290,""],[23,"egal","f",4,0,294,297,18,2,2,2,298,0,""],[24,"champ","f",5,0,299,303,23,1,1,1,304,0,""],[25,"chp_priorite_tache","c",6,0,305,322,24,0,1,0,304,323,""],[26,"","c",5,1,327,327,23,0,2,0,304,0,""],[27,"egal","f",3,0,342,345,17,2,2,2,346,0,""],[28,"champ","f",4,0,347,351,27,1,1,1,352,0,""],[29,"chx_utilisateur_tache","c",5,0,353,373,28,0,1,0,352,374,""],[30,":c_chx_utilisateur_tache","c",4,0,378,401,27,0,2,0,352,402,""]]'),
('24','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chp_priorite_tache`) , plus(champ(`chp_priorite_tache`) , 1))
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chx_utilisateur_tache`) , :c_chx_utilisateur_tache) , inf(champ(`chp_priorite_tache`) , 50))
   )
)','
UPDATE b1.tbl_taches SET `chp_priorite_tache` = (`chp_priorite_tache`+1)
WHERE (`chx_utilisateur_tache` = :c_chx_utilisateur_tache AND `chp_priorite_tache` < 50) ;','function sql_24($par){
    $texte_sql_24=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    $texte_sql_24.='' `chp_priorite_tache` = (`chp_priorite_tache`+1) ''.CRLF;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $where0.='' AND `chp_priorite_tache` < 50''.CRLF;
    $texte_sql_24.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_24 = <pre>'' . $texte_sql_24 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_24)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_24()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,4,45,0,""],[5,"affecte","f",2,0,53,59,4,2,1,3,60,0,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,0,""],[7,"chp_priorite_tache","c",4,2,68,85,6,0,1,0,66,0,""],[8,"plus","f",3,0,91,94,5,2,2,2,95,0,""],[9,"champ","f",4,0,96,100,8,1,1,1,101,0,""],[10,"chp_priorite_tache","c",5,2,103,120,9,0,1,0,101,0,""],[11,"1","c",4,0,126,126,8,0,2,0,101,127,""],[12,"provenance","f",1,0,139,148,1,1,3,5,149,0,""],[13,"table_reference","f",2,0,157,171,12,1,1,4,172,0,""],[14,"source","f",3,0,183,188,13,1,1,3,189,0,""],[15,"nom_de_la_table","f",4,0,190,204,14,2,1,2,205,0,""],[16,"tbl_taches","c",5,0,206,215,15,0,1,0,0,0,""],[17,"base","f",5,0,219,222,15,1,2,1,223,0,""],[18,"b1","c",6,0,224,225,17,0,1,0,223,226,""],[19,"conditions","f",1,0,247,256,1,1,4,4,257,0,""],[20,"et","f",2,0,265,266,19,2,1,3,267,0,""],[21,"egal","f",3,0,268,271,20,2,1,2,272,0,""],[22,"champ","f",4,0,273,277,21,1,1,1,278,0,""],[23,"chx_utilisateur_tache","c",5,2,280,300,22,0,1,0,278,0,""],[24,":c_chx_utilisateur_tache","c",4,0,306,329,21,0,2,0,278,330,""],[25,"inf","f",3,0,334,336,20,2,2,2,337,0,""],[26,"champ","f",4,0,338,342,25,1,1,1,343,0,""],[27,"chp_priorite_tache","c",5,2,345,362,26,0,1,0,343,0,""],[28,"50","c",4,0,368,369,25,0,2,0,343,370,""]]'),
('25','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chp_priorite_tache`) , moins(champ(`chp_priorite_tache`) , 1))
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         egal(champ(`chx_utilisateur_tache`) , :c_chx_utilisateur_tache),
         inf(champ(`chp_priorite_tache`) , 50),
         sup(champ(`chp_priorite_tache`) , 0)
      )
   )
)','
UPDATE b1.tbl_taches SET `chp_priorite_tache` = (`chp_priorite_tache`-1)
WHERE (/*  */ `chx_utilisateur_tache` = :c_chx_utilisateur_tache AND `chp_priorite_tache` < 50 AND `chp_priorite_tache` > 0) ;','function sql_25($par){
    $texte_sql_25=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    $texte_sql_25.='' `chp_priorite_tache` = (`chp_priorite_tache`-1) ''.CRLF;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $where0.='' AND `chp_priorite_tache` < 50''.CRLF;
    $where0.='' AND `chp_priorite_tache` > 0''.CRLF;
    $texte_sql_25.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_25 = <pre>'' . $texte_sql_25 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_25)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_25()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,4,45,0,""],[5,"affecte","f",2,0,53,59,4,2,1,3,60,0,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,0,""],[7,"chp_priorite_tache","c",4,2,68,85,6,0,1,0,66,0,""],[8,"moins","f",3,0,91,95,5,2,2,2,96,0,""],[9,"champ","f",4,0,97,101,8,1,1,1,102,0,""],[10,"chp_priorite_tache","c",5,2,104,121,9,0,1,0,102,0,""],[11,"1","c",4,0,127,127,8,0,2,0,102,128,""],[12,"provenance","f",1,0,140,149,1,1,3,5,150,0,""],[13,"table_reference","f",2,0,158,172,12,1,1,4,173,0,""],[14,"source","f",3,0,184,189,13,1,1,3,190,0,""],[15,"nom_de_la_table","f",4,0,191,205,14,2,1,2,206,0,""],[16,"tbl_taches","c",5,0,207,216,15,0,1,0,0,0,""],[17,"base","f",5,0,220,223,15,1,2,1,224,0,""],[18,"b1","c",6,0,225,226,17,0,1,0,224,227,""],[19,"conditions","f",1,0,248,257,1,1,4,4,258,0,""],[20,"et","f",2,0,266,267,19,4,1,3,268,0,""],[21,"#","f",3,0,279,279,20,0,1,0,280,281,""],[22,"egal","f",3,0,293,296,20,2,2,2,297,0,""],[23,"champ","f",4,0,298,302,22,1,1,1,303,0,""],[24,"chx_utilisateur_tache","c",5,2,305,325,23,0,1,0,303,0,""],[25,":c_chx_utilisateur_tache","c",4,0,331,354,22,0,2,0,303,355,""],[26,"inf","f",3,0,367,369,20,2,3,2,370,0,""],[27,"champ","f",4,0,371,375,26,1,1,1,376,0,""],[28,"chp_priorite_tache","c",5,2,378,395,27,0,1,0,376,0,""],[29,"50","c",4,0,401,402,26,0,2,0,376,403,""],[30,"sup","f",3,0,415,417,20,2,4,2,418,0,""],[31,"champ","f",4,0,419,423,30,1,1,1,424,0,""],[32,"chp_priorite_tache","c",5,2,426,443,31,0,1,0,424,0,""],[33,"0","c",4,0,449,449,30,0,2,0,424,450,""]]'),
('26','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_basedd`),
      champ(`T0` , `chx_dossier_id_basedd`),
      champ(`T0` , `chx_cible_id_basedd`),
      champ(`T0` , `chp_nom_basedd`),
      champ(`T0` , `chp_rev_basedd`),
      champ(`T0` , `chp_commentaire_basedd`),
      champ(`T0` , `chp_genere_basedd`),
      champ(`T0` , `chp_rev_travail_basedd`),
      champ(`T0` , `chp_fournisseur_basedd`),
      champ(`T1` , `chi_id_dossier`),
      champ(`T1` , `chx_cible_dossier`),
      champ(`T1` , `chp_nom_dossier`),
      champ(`T2` , `chi_id_cible`),
      champ(`T2` , `chp_nom_cible`),
      champ(`T2` , `chp_dossier_cible`),
      champ(`T2` , `chp_commentaire_cible`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , alias(T0) , base(b1)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_dossiers , alias(T1) , base(b1))),
         contrainte(egal(champ(T1 , chi_id_dossier) , champ(T0 , chx_dossier_id_basedd)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_cibles , alias(T2) , base(b1))),
         contrainte(egal(champ(T2 , chi_id_cible) , champ(T0 , chx_cible_id_basedd)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_basedd`) , :T0_chi_id_basedd) , egal(champ(`T0` , `chx_cible_id_basedd`) , :T0_chx_cible_id_basedd))
   )
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
`T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
`T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
`T2`.`chp_commentaire_cible`
 FROM b1.tbl_bdds T0
 LEFT JOIN b1.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

 LEFT JOIN b1.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd

WHERE (`T0`.`chi_id_basedd` = :T0_chi_id_basedd AND `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd);','function sql_26($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
      `T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
      `T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
      `T2`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_basedd`'',$par[''T0_chi_id_basedd'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $errr=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($errr);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chx_dossier_id_basedd'' => $tab0[1],
                ''T0.chx_cible_id_basedd'' => $tab0[2],
                ''T0.chp_nom_basedd'' => $tab0[3],
                ''T0.chp_rev_basedd'' => $tab0[4],
                ''T0.chp_commentaire_basedd'' => $tab0[5],
                ''T0.chp_genere_basedd'' => $tab0[6],
                ''T0.chp_rev_travail_basedd'' => $tab0[7],
                ''T0.chp_fournisseur_basedd'' => $tab0[8],
                ''T1.chi_id_dossier'' => $tab0[9],
                ''T1.chx_cible_dossier'' => $tab0[10],
                ''T1.chp_nom_dossier'' => $tab0[11],
                ''T2.chi_id_cible'' => $tab0[12],
                ''T2.chp_nom_cible'' => $tab0[13],
                ''T2.chp_dossier_cible'' => $tab0[14],
                ''T2.chp_commentaire_cible'' => $tab0[15],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','bases par id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,16,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_basedd","c",3,2,71,83,5,0,2,0,62,0,""],[8,"champ","f",2,0,94,98,4,2,2,1,99,0,""],[9,"T0","c",3,2,101,102,8,0,1,0,99,0,""],[10,"chx_dossier_id_basedd","c",3,2,108,128,8,0,2,0,99,0,""],[11,"champ","f",2,0,139,143,4,2,3,1,144,0,""],[12,"T0","c",3,2,146,147,11,0,1,0,144,0,""],[13,"chx_cible_id_basedd","c",3,2,153,171,11,0,2,0,144,0,""],[14,"champ","f",2,0,182,186,4,2,4,1,187,0,""],[15,"T0","c",3,2,189,190,14,0,1,0,187,0,""],[16,"chp_nom_basedd","c",3,2,196,209,14,0,2,0,187,0,""],[17,"champ","f",2,0,220,224,4,2,5,1,225,0,""],[18,"T0","c",3,2,227,228,17,0,1,0,225,0,""],[19,"chp_rev_basedd","c",3,2,234,247,17,0,2,0,225,0,""],[20,"champ","f",2,0,258,262,4,2,6,1,263,0,""],[21,"T0","c",3,2,265,266,20,0,1,0,263,0,""],[22,"chp_commentaire_basedd","c",3,2,272,293,20,0,2,0,263,0,""],[23,"champ","f",2,0,304,308,4,2,7,1,309,0,""],[24,"T0","c",3,2,311,312,23,0,1,0,309,0,""],[25,"chp_genere_basedd","c",3,2,318,334,23,0,2,0,309,0,""],[26,"champ","f",2,0,345,349,4,2,8,1,350,0,""],[27,"T0","c",3,2,352,353,26,0,1,0,350,0,""],[28,"chp_rev_travail_basedd","c",3,2,359,380,26,0,2,0,350,0,""],[29,"champ","f",2,0,391,395,4,2,9,1,396,0,""],[30,"T0","c",3,2,398,399,29,0,1,0,396,0,""],[31,"chp_fournisseur_basedd","c",3,2,405,426,29,0,2,0,396,0,""],[32,"champ","f",2,0,437,441,4,2,10,1,442,0,""],[33,"T1","c",3,2,444,445,32,0,1,0,442,0,""],[34,"chi_id_dossier","c",3,2,451,464,32,0,2,0,442,0,""],[35,"champ","f",2,0,475,479,4,2,11,1,480,0,""],[36,"T1","c",3,2,482,483,35,0,1,0,480,0,""],[37,"chx_cible_dossier","c",3,2,489,505,35,0,2,0,480,0,""],[38,"champ","f",2,0,516,520,4,2,12,1,521,0,""],[39,"T1","c",3,2,523,524,38,0,1,0,521,0,""],[40,"chp_nom_dossier","c",3,2,530,544,38,0,2,0,521,0,""],[41,"champ","f",2,0,555,559,4,2,13,1,560,0,""],[42,"T2","c",3,2,562,563,41,0,1,0,560,0,""],[43,"chi_id_cible","c",3,2,569,580,41,0,2,0,560,0,""],[44,"champ","f",2,0,591,595,4,2,14,1,596,0,""],[45,"T2","c",3,2,598,599,44,0,1,0,596,0,""],[46,"chp_nom_cible","c",3,2,605,617,44,0,2,0,596,0,""],[47,"champ","f",2,0,628,632,4,2,15,1,633,0,""],[48,"T2","c",3,2,635,636,47,0,1,0,633,0,""],[49,"chp_dossier_cible","c",3,2,642,658,47,0,2,0,633,0,""],[50,"champ","f",2,0,669,673,4,2,16,1,674,0,""],[51,"T2","c",3,2,676,677,50,0,1,0,674,0,""],[52,"chp_commentaire_cible","c",3,2,683,703,50,0,2,0,674,0,""],[53,"provenance","f",1,0,716,725,1,3,3,5,726,0,""],[54,"table_reference","f",2,0,734,748,53,1,1,4,749,0,""],[55,"source","f",3,0,760,765,54,1,1,3,766,0,""],[56,"nom_de_la_table","f",4,0,767,781,55,3,1,2,782,0,""],[57,"tbl_bdds","c",5,0,783,790,56,0,1,0,0,0,""],[58,"alias","f",5,0,794,798,56,1,2,1,799,0,""],[59,"T0","c",6,0,800,801,58,0,1,0,799,802,""],[60,"base","f",5,0,806,809,56,1,3,1,810,0,""],[61,"b1","c",6,0,811,812,60,0,1,0,810,813,""],[62,"jointure_gauche","f",2,0,832,846,53,2,2,4,847,0,""],[63,"source","f",3,0,858,863,62,1,1,3,864,0,""],[64,"nom_de_la_table","f",4,0,865,879,63,3,1,2,880,0,""],[65,"tbl_dossiers","c",5,0,881,892,64,0,1,0,0,0,""],[66,"alias","f",5,0,896,900,64,1,2,1,901,0,""],[67,"T1","c",6,0,902,903,66,0,1,0,901,904,""],[68,"base","f",5,0,908,911,64,1,3,1,912,0,""],[69,"b1","c",6,0,913,914,68,0,1,0,912,915,""],[70,"contrainte","f",3,0,929,938,62,1,2,3,939,0,""],[71,"egal","f",4,0,940,943,70,2,1,2,944,0,""],[72,"champ","f",5,0,945,949,71,2,1,1,950,0,""],[73,"T1","c",6,0,951,952,72,0,1,0,0,0,""],[74,"chi_id_dossier","c",6,0,956,969,72,0,2,0,950,970,""],[75,"champ","f",5,0,974,978,71,2,2,1,979,0,""],[76,"T0","c",6,0,980,981,75,0,1,0,0,0,""],[77,"chx_dossier_id_basedd","c",6,0,985,1005,75,0,2,0,979,1006,""],[78,"jointure_gauche","f",2,0,1025,1039,53,2,3,4,1040,0,""],[79,"source","f",3,0,1051,1056,78,1,1,3,1057,0,""],[80,"nom_de_la_table","f",4,0,1058,1072,79,3,1,2,1073,0,""],[81,"tbl_cibles","c",5,0,1074,1083,80,0,1,0,0,0,""],[82,"alias","f",5,0,1087,1091,80,1,2,1,1092,0,""],[83,"T2","c",6,0,1093,1094,82,0,1,0,1092,1095,""],[84,"base","f",5,0,1099,1102,80,1,3,1,1103,0,""],[85,"b1","c",6,0,1104,1105,84,0,1,0,1103,1106,""],[86,"contrainte","f",3,0,1120,1129,78,1,2,3,1130,0,""],[87,"egal","f",4,0,1131,1134,86,2,1,2,1135,0,""],[88,"champ","f",5,0,1136,1140,87,2,1,1,1141,0,""],[89,"T2","c",6,0,1142,1143,88,0,1,0,0,0,""],[90,"chi_id_cible","c",6,0,1147,1158,88,0,2,0,1141,1159,""],[91,"champ","f",5,0,1163,1167,87,2,2,1,1168,0,""],[92,"T0","c",6,0,1169,1170,91,0,1,0,0,0,""],[93,"chx_cible_id_basedd","c",6,0,1174,1192,91,0,2,0,1168,1193,""],[94,"conditions","f",1,0,1214,1223,1,1,4,4,1224,0,""],[95,"et","f",2,0,1232,1233,94,2,1,3,1234,0,""],[96,"egal","f",3,0,1235,1238,95,2,1,2,1239,0,""],[97,"champ","f",4,0,1240,1244,96,2,1,1,1245,0,""],[98,"T0","c",5,2,1247,1248,97,0,1,0,1245,0,""],[99,"chi_id_basedd","c",5,2,1254,1266,97,0,2,0,1245,0,""],[100,":T0_chi_id_basedd","c",4,0,1272,1288,96,0,2,0,1245,1289,""],[101,"egal","f",3,0,1293,1296,95,2,2,2,1297,0,""],[102,"champ","f",4,0,1298,1302,101,2,1,1,1303,0,""],[103,"T0","c",5,2,1305,1306,102,0,1,0,1303,0,""],[104,"chx_cible_id_basedd","c",5,2,1312,1330,102,0,2,0,1303,0,""],[105,":T0_chx_cible_id_basedd","c",4,0,1336,1358,101,0,2,0,1303,1359,""]]'),
('27','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_basedd`),
      champ(`T0` , `chx_dossier_id_basedd`),
      champ(`T0` , `chx_cible_id_basedd`),
      champ(`T0` , `chp_nom_basedd`),
      champ(`T0` , `chp_rev_basedd`),
      champ(`T0` , `chp_commentaire_basedd`),
      champ(`T0` , `chp_genere_basedd`),
      champ(`T0` , `chp_rev_travail_basedd`),
      champ(`T0` , `chp_fournisseur_basedd`),
      champ(`T1` , `chi_id_dossier`),
      champ(`T1` , `chx_cible_dossier`),
      champ(`T1` , `chp_nom_dossier`),
      champ(`T2` , `chi_id_cible`),
      champ(`T2` , `chp_nom_cible`),
      champ(`T2` , `chp_dossier_cible`),
      champ(`T2` , `chp_commentaire_cible`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , alias(T0) , base(b1)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_dossiers , alias(T1) , base(b1))),
         contrainte(egal(champ(T1 , chi_id_dossier) , champ(T0 , chx_dossier_id_basedd)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_cibles , alias(T2) , base(b1))),
         contrainte(egal(champ(T2 , chi_id_cible) , champ(T0 , chx_cible_id_basedd)))
      )
   ),
   conditions(egal(champ(`T0` , `chx_cible_id_basedd`) , :T0_chx_cible_id_basedd))
)','SELECT 
`T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
`T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
`T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
`T2`.`chp_commentaire_cible`
 FROM b1.tbl_bdds T0
 LEFT JOIN b1.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

 LEFT JOIN b1.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd

WHERE `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd;','function sql_27($par){
    $champs0=''
      `T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
      `T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
      `T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
      `T2`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_basedd'' => $tab0[0],
                ''T0.chx_dossier_id_basedd'' => $tab0[1],
                ''T0.chx_cible_id_basedd'' => $tab0[2],
                ''T0.chp_nom_basedd'' => $tab0[3],
                ''T0.chp_rev_basedd'' => $tab0[4],
                ''T0.chp_commentaire_basedd'' => $tab0[5],
                ''T0.chp_genere_basedd'' => $tab0[6],
                ''T0.chp_rev_travail_basedd'' => $tab0[7],
                ''T0.chp_fournisseur_basedd'' => $tab0[8],
                ''T1.chi_id_dossier'' => $tab0[9],
                ''T1.chx_cible_dossier'' => $tab0[10],
                ''T1.chp_nom_dossier'' => $tab0[11],
                ''T2.chi_id_cible'' => $tab0[12],
                ''T2.chp_nom_cible'' => $tab0[13],
                ''T2.chp_dossier_cible'' => $tab0[14],
                ''T2.chp_commentaire_cible'' => $tab0[15],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','toutes les bases d''une cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,16,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_basedd","c",3,2,71,83,5,0,2,0,62,0,""],[8,"champ","f",2,0,94,98,4,2,2,1,99,0,""],[9,"T0","c",3,2,101,102,8,0,1,0,99,0,""],[10,"chx_dossier_id_basedd","c",3,2,108,128,8,0,2,0,99,0,""],[11,"champ","f",2,0,139,143,4,2,3,1,144,0,""],[12,"T0","c",3,2,146,147,11,0,1,0,144,0,""],[13,"chx_cible_id_basedd","c",3,2,153,171,11,0,2,0,144,0,""],[14,"champ","f",2,0,182,186,4,2,4,1,187,0,""],[15,"T0","c",3,2,189,190,14,0,1,0,187,0,""],[16,"chp_nom_basedd","c",3,2,196,209,14,0,2,0,187,0,""],[17,"champ","f",2,0,220,224,4,2,5,1,225,0,""],[18,"T0","c",3,2,227,228,17,0,1,0,225,0,""],[19,"chp_rev_basedd","c",3,2,234,247,17,0,2,0,225,0,""],[20,"champ","f",2,0,258,262,4,2,6,1,263,0,""],[21,"T0","c",3,2,265,266,20,0,1,0,263,0,""],[22,"chp_commentaire_basedd","c",3,2,272,293,20,0,2,0,263,0,""],[23,"champ","f",2,0,304,308,4,2,7,1,309,0,""],[24,"T0","c",3,2,311,312,23,0,1,0,309,0,""],[25,"chp_genere_basedd","c",3,2,318,334,23,0,2,0,309,0,""],[26,"champ","f",2,0,345,349,4,2,8,1,350,0,""],[27,"T0","c",3,2,352,353,26,0,1,0,350,0,""],[28,"chp_rev_travail_basedd","c",3,2,359,380,26,0,2,0,350,0,""],[29,"champ","f",2,0,391,395,4,2,9,1,396,0,""],[30,"T0","c",3,2,398,399,29,0,1,0,396,0,""],[31,"chp_fournisseur_basedd","c",3,2,405,426,29,0,2,0,396,0,""],[32,"champ","f",2,0,437,441,4,2,10,1,442,0,""],[33,"T1","c",3,2,444,445,32,0,1,0,442,0,""],[34,"chi_id_dossier","c",3,2,451,464,32,0,2,0,442,0,""],[35,"champ","f",2,0,475,479,4,2,11,1,480,0,""],[36,"T1","c",3,2,482,483,35,0,1,0,480,0,""],[37,"chx_cible_dossier","c",3,2,489,505,35,0,2,0,480,0,""],[38,"champ","f",2,0,516,520,4,2,12,1,521,0,""],[39,"T1","c",3,2,523,524,38,0,1,0,521,0,""],[40,"chp_nom_dossier","c",3,2,530,544,38,0,2,0,521,0,""],[41,"champ","f",2,0,555,559,4,2,13,1,560,0,""],[42,"T2","c",3,2,562,563,41,0,1,0,560,0,""],[43,"chi_id_cible","c",3,2,569,580,41,0,2,0,560,0,""],[44,"champ","f",2,0,591,595,4,2,14,1,596,0,""],[45,"T2","c",3,2,598,599,44,0,1,0,596,0,""],[46,"chp_nom_cible","c",3,2,605,617,44,0,2,0,596,0,""],[47,"champ","f",2,0,628,632,4,2,15,1,633,0,""],[48,"T2","c",3,2,635,636,47,0,1,0,633,0,""],[49,"chp_dossier_cible","c",3,2,642,658,47,0,2,0,633,0,""],[50,"champ","f",2,0,669,673,4,2,16,1,674,0,""],[51,"T2","c",3,2,676,677,50,0,1,0,674,0,""],[52,"chp_commentaire_cible","c",3,2,683,703,50,0,2,0,674,0,""],[53,"provenance","f",1,0,716,725,1,3,3,5,726,0,""],[54,"table_reference","f",2,0,734,748,53,1,1,4,749,0,""],[55,"source","f",3,0,760,765,54,1,1,3,766,0,""],[56,"nom_de_la_table","f",4,0,767,781,55,3,1,2,782,0,""],[57,"tbl_bdds","c",5,0,783,790,56,0,1,0,0,0,""],[58,"alias","f",5,0,794,798,56,1,2,1,799,0,""],[59,"T0","c",6,0,800,801,58,0,1,0,799,802,""],[60,"base","f",5,0,806,809,56,1,3,1,810,0,""],[61,"b1","c",6,0,811,812,60,0,1,0,810,813,""],[62,"jointure_gauche","f",2,0,832,846,53,2,2,4,847,0,""],[63,"source","f",3,0,858,863,62,1,1,3,864,0,""],[64,"nom_de_la_table","f",4,0,865,879,63,3,1,2,880,0,""],[65,"tbl_dossiers","c",5,0,881,892,64,0,1,0,0,0,""],[66,"alias","f",5,0,896,900,64,1,2,1,901,0,""],[67,"T1","c",6,0,902,903,66,0,1,0,901,904,""],[68,"base","f",5,0,908,911,64,1,3,1,912,0,""],[69,"b1","c",6,0,913,914,68,0,1,0,912,915,""],[70,"contrainte","f",3,0,929,938,62,1,2,3,939,0,""],[71,"egal","f",4,0,940,943,70,2,1,2,944,0,""],[72,"champ","f",5,0,945,949,71,2,1,1,950,0,""],[73,"T1","c",6,0,951,952,72,0,1,0,0,0,""],[74,"chi_id_dossier","c",6,0,956,969,72,0,2,0,950,970,""],[75,"champ","f",5,0,974,978,71,2,2,1,979,0,""],[76,"T0","c",6,0,980,981,75,0,1,0,0,0,""],[77,"chx_dossier_id_basedd","c",6,0,985,1005,75,0,2,0,979,1006,""],[78,"jointure_gauche","f",2,0,1025,1039,53,2,3,4,1040,0,""],[79,"source","f",3,0,1051,1056,78,1,1,3,1057,0,""],[80,"nom_de_la_table","f",4,0,1058,1072,79,3,1,2,1073,0,""],[81,"tbl_cibles","c",5,0,1074,1083,80,0,1,0,0,0,""],[82,"alias","f",5,0,1087,1091,80,1,2,1,1092,0,""],[83,"T2","c",6,0,1093,1094,82,0,1,0,1092,1095,""],[84,"base","f",5,0,1099,1102,80,1,3,1,1103,0,""],[85,"b1","c",6,0,1104,1105,84,0,1,0,1103,1106,""],[86,"contrainte","f",3,0,1120,1129,78,1,2,3,1130,0,""],[87,"egal","f",4,0,1131,1134,86,2,1,2,1135,0,""],[88,"champ","f",5,0,1136,1140,87,2,1,1,1141,0,""],[89,"T2","c",6,0,1142,1143,88,0,1,0,0,0,""],[90,"chi_id_cible","c",6,0,1147,1158,88,0,2,0,1141,1159,""],[91,"champ","f",5,0,1163,1167,87,2,2,1,1168,0,""],[92,"T0","c",6,0,1169,1170,91,0,1,0,0,0,""],[93,"chx_cible_id_basedd","c",6,0,1174,1192,91,0,2,0,1168,1193,""],[94,"conditions","f",1,0,1214,1223,1,1,4,3,1224,0,""],[95,"egal","f",2,0,1225,1228,94,2,1,2,1229,0,""],[96,"champ","f",3,0,1230,1234,95,2,1,1,1235,0,""],[97,"T0","c",4,2,1237,1238,96,0,1,0,1235,0,""],[98,"chx_cible_id_basedd","c",4,2,1244,1262,96,0,2,0,1235,0,""],[99,":T0_chx_cible_id_basedd","c",3,0,1268,1290,95,0,2,0,1235,1291,""]]'),
('28','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_tache`) , champ(`T0` , `chx_utilisateur_tache`) , champ(`T0` , `chp_texte_tache`) , champ(`T0` , `chp_priorite_tache`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_tache`) , :T0_chi_id_tache) , egal(champ(`T0` , `chx_utilisateur_tache`) , :T0_chx_utilisateur_tache))
   )
)','SELECT 
`T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
 FROM b1.tbl_taches T0
WHERE (`T0`.`chi_id_tache` = :T0_chi_id_tache AND `T0`.`chx_utilisateur_tache` = :T0_chx_utilisateur_tache);','function sql_28($par){
    $champs0=''
      `T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_tache`'',$par[''T0_chi_id_tache'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_utilisateur_tache`'',$par[''T0_chx_utilisateur_tache'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $errr=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($errr);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_tache'' => $tab0[0],
                ''T0.chx_utilisateur_tache'' => $tab0[1],
                ''T0.chp_texte_tache'' => $tab0[2],
                ''T0.chp_priorite_tache'' => $tab0[3],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_tache","c",3,2,64,75,5,0,2,0,55,0,""],[8,"champ","f",2,0,81,85,4,2,2,1,86,0,""],[9,"T0","c",3,2,88,89,8,0,1,0,86,0,""],[10,"chx_utilisateur_tache","c",3,2,95,115,8,0,2,0,86,0,""],[11,"champ","f",2,0,121,125,4,2,3,1,126,0,""],[12,"T0","c",3,2,128,129,11,0,1,0,126,0,""],[13,"chp_texte_tache","c",3,2,135,149,11,0,2,0,126,0,""],[14,"champ","f",2,0,155,159,4,2,4,1,160,0,""],[15,"T0","c",3,2,162,163,14,0,1,0,160,0,""],[16,"chp_priorite_tache","c",3,2,169,186,14,0,2,0,160,0,""],[17,"provenance","f",1,0,195,204,1,1,3,5,205,0,""],[18,"table_reference","f",2,0,213,227,17,1,1,4,228,0,""],[19,"source","f",3,0,239,244,18,1,1,3,245,0,""],[20,"nom_de_la_table","f",4,0,246,260,19,3,1,2,261,0,""],[21,"tbl_taches","c",5,0,262,271,20,0,1,0,0,0,""],[22,"alias","f",5,0,275,279,20,1,2,1,280,0,""],[23,"T0","c",6,0,281,282,22,0,1,0,280,283,""],[24,"base","f",5,0,287,290,20,1,3,1,291,0,""],[25,"b1","c",6,0,292,293,24,0,1,0,291,294,""],[26,"conditions","f",1,0,315,324,1,1,4,4,325,0,""],[27,"et","f",2,0,333,334,26,2,1,3,335,0,""],[28,"egal","f",3,0,336,339,27,2,1,2,340,0,""],[29,"champ","f",4,0,341,345,28,2,1,1,346,0,""],[30,"T0","c",5,2,348,349,29,0,1,0,346,0,""],[31,"chi_id_tache","c",5,2,355,366,29,0,2,0,346,0,""],[32,":T0_chi_id_tache","c",4,0,372,387,28,0,2,0,346,388,""],[33,"egal","f",3,0,392,395,27,2,2,2,396,0,""],[34,"champ","f",4,0,397,401,33,2,1,1,402,0,""],[35,"T0","c",5,2,404,405,34,0,1,0,402,0,""],[36,"chx_utilisateur_tache","c",5,2,411,431,34,0,2,0,402,0,""],[37,":T0_chx_utilisateur_tache","c",4,0,437,461,33,0,2,0,402,462,""]]'),
('29','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_texte_tache`) , :n_chp_texte_tache) , affecte(champ(`chp_priorite_tache`) , :n_chp_priorite_tache)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chx_utilisateur_tache`) , :c_chx_utilisateur_tache) , egal(champ(`chi_id_tache`) , :c_chi_id_tache))
   )
)','
UPDATE b1.tbl_taches SET `chp_texte_tache` = :n_chp_texte_tache , `chp_priorite_tache` = :n_chp_priorite_tache
WHERE (`chx_utilisateur_tache` = :c_chx_utilisateur_tache
   AND `chi_id_tache` = :c_chi_id_tache) ;','function sql_29($par){
    $texte_sql_29=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    $texte_sql_29.=''    `chp_texte_tache`     = \''''.sq0($par[''n_chp_texte_tache'']).''\''     , ''.CRLF;
    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_29.=''    `chp_priorite_tache`  = NULL  ''.CRLF;
    }else{
        $texte_sql_29.=''    `chp_priorite_tache`  = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.CRLF;
    $texte_sql_29.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_29 = <pre>'' . $texte_sql_29 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_29);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_29()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','texte et priorité par id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,2,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chp_texte_tache","c",4,2,61,75,6,0,1,0,59,0,""],[8,":n_chp_texte_tache","c",3,0,81,98,5,0,2,0,59,99,""],[9,"affecte","f",2,0,103,109,4,2,2,2,110,0,""],[10,"champ","f",3,0,111,115,9,1,1,1,116,0,""],[11,"chp_priorite_tache","c",4,2,118,135,10,0,1,0,116,0,""],[12,":n_chp_priorite_tache","c",3,0,141,161,9,0,2,0,116,162,""],[13,"provenance","f",1,0,169,178,1,1,3,5,179,0,""],[14,"table_reference","f",2,0,187,201,13,1,1,4,202,0,""],[15,"source","f",3,0,213,218,14,1,1,3,219,0,""],[16,"nom_de_la_table","f",4,0,220,234,15,2,1,2,235,0,""],[17,"tbl_taches","c",5,0,236,245,16,0,1,0,0,0,""],[18,"base","f",5,0,249,252,16,1,2,1,253,0,""],[19,"b1","c",6,0,254,255,18,0,1,0,253,256,""],[20,"conditions","f",1,0,277,286,1,1,4,4,287,0,""],[21,"et","f",2,0,295,296,20,2,1,3,297,0,""],[22,"egal","f",3,0,298,301,21,2,1,2,302,0,""],[23,"champ","f",4,0,303,307,22,1,1,1,308,0,""],[24,"chx_utilisateur_tache","c",5,2,310,330,23,0,1,0,308,0,""],[25,":c_chx_utilisateur_tache","c",4,0,336,359,22,0,2,0,308,360,""],[26,"egal","f",3,0,364,367,21,2,2,2,368,0,""],[27,"champ","f",4,0,369,373,26,1,1,1,374,0,""],[28,"chi_id_tache","c",5,2,376,387,27,0,1,0,374,0,""],[29,":c_chi_id_tache","c",4,0,393,407,26,0,2,0,374,408,""]]'),
('30','1','insert','insérer(
   base_de_reference(1),
   valeurs(affecte(champ(`chx_utilisateur_tache`) , :chx_utilisateur_tache) , affecte(champ(`chp_texte_tache`) , :chp_texte_tache) , affecte(champ(`chp_priorite_tache`) , :chp_priorite_tache)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   )
)','
INSERT INTO b1.`tbl_taches`(
    `chx_utilisateur_tache` , 
    `chp_texte_tache` , 
    `chp_priorite_tache`
) VALUES (
    :chx_utilisateur_tache , 
    :chp_texte_tache , 
    :chp_priorite_tache
);','function sql_30($par){
    $texte_sql_30=''
      INSERT INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches`(
         `chx_utilisateur_tache` , 
         `chp_texte_tache` , 
         `chp_priorite_tache`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_utilisateur_tache'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_texte_tache'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_priorite_tache'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_30.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_30 = <pre>'' . $texte_sql_30 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_30)){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_30()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,3,2,3,44,0,""],[5,"affecte","f",2,0,45,51,4,2,1,2,52,0,""],[6,"champ","f",3,0,53,57,5,1,1,1,58,0,""],[7,"chx_utilisateur_tache","c",4,2,60,80,6,0,1,0,58,0,""],[8,":chx_utilisateur_tache","c",3,0,86,107,5,0,2,0,58,108,""],[9,"affecte","f",2,0,112,118,4,2,2,2,119,0,""],[10,"champ","f",3,0,120,124,9,1,1,1,125,0,""],[11,"chp_texte_tache","c",4,2,127,141,10,0,1,0,125,0,""],[12,":chp_texte_tache","c",3,0,147,162,9,0,2,0,125,163,""],[13,"affecte","f",2,0,167,173,4,2,3,2,174,0,""],[14,"champ","f",3,0,175,179,13,1,1,1,180,0,""],[15,"chp_priorite_tache","c",4,2,182,199,14,0,1,0,180,0,""],[16,":chp_priorite_tache","c",3,0,205,223,13,0,2,0,180,224,""],[17,"provenance","f",1,0,231,240,1,1,3,5,241,0,""],[18,"table_reference","f",2,0,249,263,17,1,1,4,264,0,""],[19,"source","f",3,0,275,280,18,1,1,3,281,0,""],[20,"nom_de_la_table","f",4,0,282,296,19,2,1,2,297,0,""],[21,"tbl_taches","c",5,0,298,307,20,0,1,0,0,0,""],[22,"base","f",5,0,311,314,20,1,2,1,315,0,""],[23,"b1","c",6,0,316,317,22,0,1,0,315,318,""]]'),
('31','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_tache`) , :chi_id_tache) , egal(champ(`chx_utilisateur_tache`) , :chx_utilisateur_tache))
   )
)','
DELETE FROM b1.tbl_taches
WHERE (`chi_id_tache` = :chi_id_tache
   AND `chx_utilisateur_tache` = :chx_utilisateur_tache) ;','function sql_31($par){
    $texte_sql_31=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches
          WHERE (`chi_id_tache` = ''.sq1($par[''chi_id_tache'']).'' AND `chx_utilisateur_tache` = ''.sq1($par[''chx_utilisateur_tache'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_31 = <pre>'' . $texte_sql_31 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_31);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_31()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','tâche par id et utilisateur','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_taches","c",5,0,106,115,7,0,1,0,0,0,""],[9,"base","f",5,0,119,122,7,1,2,1,123,0,""],[10,"b1","c",6,0,124,125,9,0,1,0,123,126,""],[11,"conditions","f",1,0,147,156,1,1,3,4,157,0,""],[12,"et","f",2,0,165,166,11,2,1,3,167,0,""],[13,"egal","f",3,0,168,171,12,2,1,2,172,0,""],[14,"champ","f",4,0,173,177,13,1,1,1,178,0,""],[15,"chi_id_tache","c",5,2,180,191,14,0,1,0,178,0,""],[16,":chi_id_tache","c",4,0,197,209,13,0,2,0,178,210,""],[17,"egal","f",3,0,214,217,12,2,2,2,218,0,""],[18,"champ","f",4,0,219,223,17,1,1,1,224,0,""],[19,"chx_utilisateur_tache","c",5,2,226,246,18,0,1,0,224,0,""],[20,":chx_utilisateur_tache","c",4,0,252,273,17,0,2,0,224,274,""]]'),
('32','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_requete`),
      champ(`T0` , `chx_cible_requete`),
      champ(`T0` , `chp_type_requete`),
      champ(`T0` , `cht_rev_requete`),
      champ(`T0` , `cht_sql_requete`),
      champ(`T0` , `cht_php_requete`),
      champ(`T0` , `cht_commentaire_requete`),
      champ(`T0` , `cht_matrice_requete`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_requete`) , :T0_chi_id_requete) , egal(champ(`T0` , `chx_cible_requete`) , :T0_chx_cible_requete))
   )
)','SELECT 
`T0`.`chi_id_requete` , `T0`.`chx_cible_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , 
`T0`.`cht_php_requete` , `T0`.`cht_commentaire_requete` , `T0`.`cht_matrice_requete`
 FROM b1.tbl_requetes T0
WHERE (`T0`.`chi_id_requete` = :T0_chi_id_requete AND `T0`.`chx_cible_requete` = :T0_chx_cible_requete);','function sql_32($par){
    $champs0=''
      `T0`.`chi_id_requete` , `T0`.`chx_cible_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , 
      `T0`.`cht_php_requete` , `T0`.`cht_commentaire_requete` , `T0`.`cht_matrice_requete`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_requete`'',$par[''T0_chi_id_requete'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_requete`'',$par[''T0_chx_cible_requete'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $errr=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($errr);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_requete'' => $tab0[0],
                ''T0.chx_cible_requete'' => $tab0[1],
                ''T0.chp_type_requete'' => $tab0[2],
                ''T0.cht_rev_requete'' => $tab0[3],
                ''T0.cht_sql_requete'' => $tab0[4],
                ''T0.cht_php_requete'' => $tab0[5],
                ''T0.cht_commentaire_requete'' => $tab0[6],
                ''T0.cht_matrice_requete'' => $tab0[7],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','requête par id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,8,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_requete","c",3,2,71,84,5,0,2,0,62,0,""],[8,"champ","f",2,0,95,99,4,2,2,1,100,0,""],[9,"T0","c",3,2,102,103,8,0,1,0,100,0,""],[10,"chx_cible_requete","c",3,2,109,125,8,0,2,0,100,0,""],[11,"champ","f",2,0,136,140,4,2,3,1,141,0,""],[12,"T0","c",3,2,143,144,11,0,1,0,141,0,""],[13,"chp_type_requete","c",3,2,150,165,11,0,2,0,141,0,""],[14,"champ","f",2,0,176,180,4,2,4,1,181,0,""],[15,"T0","c",3,2,183,184,14,0,1,0,181,0,""],[16,"cht_rev_requete","c",3,2,190,204,14,0,2,0,181,0,""],[17,"champ","f",2,0,215,219,4,2,5,1,220,0,""],[18,"T0","c",3,2,222,223,17,0,1,0,220,0,""],[19,"cht_sql_requete","c",3,2,229,243,17,0,2,0,220,0,""],[20,"champ","f",2,0,254,258,4,2,6,1,259,0,""],[21,"T0","c",3,2,261,262,20,0,1,0,259,0,""],[22,"cht_php_requete","c",3,2,268,282,20,0,2,0,259,0,""],[23,"champ","f",2,0,293,297,4,2,7,1,298,0,""],[24,"T0","c",3,2,300,301,23,0,1,0,298,0,""],[25,"cht_commentaire_requete","c",3,2,307,329,23,0,2,0,298,0,""],[26,"champ","f",2,0,340,344,4,2,8,1,345,0,""],[27,"T0","c",3,2,347,348,26,0,1,0,345,0,""],[28,"cht_matrice_requete","c",3,2,354,372,26,0,2,0,345,0,""],[29,"provenance","f",1,0,385,394,1,1,3,5,395,0,""],[30,"table_reference","f",2,0,403,417,29,1,1,4,418,0,""],[31,"source","f",3,0,429,434,30,1,1,3,435,0,""],[32,"nom_de_la_table","f",4,0,436,450,31,3,1,2,451,0,""],[33,"tbl_requetes","c",5,0,452,463,32,0,1,0,0,0,""],[34,"alias","f",5,0,467,471,32,1,2,1,472,0,""],[35,"T0","c",6,0,473,474,34,0,1,0,472,475,""],[36,"base","f",5,0,479,482,32,1,3,1,483,0,""],[37,"b1","c",6,0,484,485,36,0,1,0,483,486,""],[38,"conditions","f",1,0,507,516,1,1,4,4,517,0,""],[39,"et","f",2,0,525,526,38,2,1,3,527,0,""],[40,"egal","f",3,0,528,531,39,2,1,2,532,0,""],[41,"champ","f",4,0,533,537,40,2,1,1,538,0,""],[42,"T0","c",5,2,540,541,41,0,1,0,538,0,""],[43,"chi_id_requete","c",5,2,547,560,41,0,2,0,538,0,""],[44,":T0_chi_id_requete","c",4,0,566,583,40,0,2,0,538,584,""],[45,"egal","f",3,0,588,591,39,2,2,2,592,0,""],[46,"champ","f",4,0,593,597,45,2,1,1,598,0,""],[47,"T0","c",5,2,600,601,46,0,1,0,598,0,""],[48,"chx_cible_requete","c",5,2,607,623,46,0,2,0,598,0,""],[49,":T0_chx_cible_requete","c",4,0,629,649,45,0,2,0,598,650,""]]'),
('33','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_cible`) , champ(`T0` , `chp_nom_cible`) , champ(`T0` , `chp_dossier_cible`) , champ(`T0` , `chp_commentaire_cible`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_cibles , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_cible`) , :T0_chi_id_cible) , comme(champ(`T0` , `chp_nom_cible`) , :T0_chp_nom_cible) , comme(champ(`T0` , `chp_dossier_cible`) , :T0_chp_dossier_cible) , comme(champ(`T0` , `chp_commentaire_cible`) , :T0_chp_commentaire_cible))
   ),
   complements(
      trier_par((champ(`T0` , `chi_id_cible`) , croissant())),
      limité_à(quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
 FROM b1.tbl_cibles T0
WHERE (`T0`.`chi_id_cible` = :T0_chi_id_cible
   AND `T0`.`chp_nom_cible` LIKE :T0_chp_nom_cible
   AND `T0`.`chp_dossier_cible` LIKE :T0_chp_dossier_cible
   AND `T0`.`chp_commentaire_cible` LIKE :T0_chp_commentaire_cible) 
ORDER BY `T0`.`chi_id_cible` ASC 
LIMIT:quantitee OFFSET :debut ;','function sql_33($par){
    $champs0=''
      `T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    if(($par[''T0_chi_id_cible''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_cible`'',$par[''T0_chi_id_cible'']);
    }
    if(($par[''T0_chp_nom_cible''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_cible` LIKE ''.sq1($par[''T0_chp_nom_cible'']).''''.CRLF;
    }
    if(($par[''T0_chp_dossier_cible''] !== '''')){
        $where0.='' AND `T0`.`chp_dossier_cible` LIKE ''.sq1($par[''T0_chp_dossier_cible'']).''''.CRLF;
    }
    if(($par[''T0_chp_commentaire_cible''] !== '''')){
        $where0.='' AND `T0`.`chp_commentaire_cible` LIKE ''.sq1($par[''T0_chp_commentaire_cible'']).''''.CRLF;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chi_id_cible` ASC'';
    $sql0.=$order0;
    $plage0=''
       LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_cible'' => $tab0[0],
                ''T0.chp_nom_cible'' => $tab0[1],
                ''T0.chp_dossier_cible'' => $tab0[2],
                ''T0.chp_commentaire_cible'' => $tab0[3],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','cibles','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_cible","c",3,2,64,75,5,0,2,0,55,0,""],[8,"champ","f",2,0,81,85,4,2,2,1,86,0,""],[9,"T0","c",3,2,88,89,8,0,1,0,86,0,""],[10,"chp_nom_cible","c",3,2,95,107,8,0,2,0,86,0,""],[11,"champ","f",2,0,113,117,4,2,3,1,118,0,""],[12,"T0","c",3,2,120,121,11,0,1,0,118,0,""],[13,"chp_dossier_cible","c",3,2,127,143,11,0,2,0,118,0,""],[14,"champ","f",2,0,149,153,4,2,4,1,154,0,""],[15,"T0","c",3,2,156,157,14,0,1,0,154,0,""],[16,"chp_commentaire_cible","c",3,2,163,183,14,0,2,0,154,0,""],[17,"provenance","f",1,0,192,201,1,1,3,5,202,0,""],[18,"table_reference","f",2,0,210,224,17,1,1,4,225,0,""],[19,"source","f",3,0,236,241,18,1,1,3,242,0,""],[20,"nom_de_la_table","f",4,0,243,257,19,3,1,2,258,0,""],[21,"tbl_cibles","c",5,0,259,268,20,0,1,0,0,0,""],[22,"alias","f",5,0,272,276,20,1,2,1,277,0,""],[23,"T0","c",6,0,278,279,22,0,1,0,277,280,""],[24,"base","f",5,0,284,287,20,1,3,1,288,0,""],[25,"b1","c",6,0,289,290,24,0,1,0,288,291,""],[26,"conditions","f",1,0,312,321,1,1,4,4,322,0,""],[27,"et","f",2,0,330,331,26,4,1,3,332,0,""],[28,"egal","f",3,0,333,336,27,2,1,2,337,0,""],[29,"champ","f",4,0,338,342,28,2,1,1,343,0,""],[30,"T0","c",5,2,345,346,29,0,1,0,343,0,""],[31,"chi_id_cible","c",5,2,352,363,29,0,2,0,343,0,""],[32,":T0_chi_id_cible","c",4,0,369,384,28,0,2,0,343,385,""],[33,"comme","f",3,0,389,393,27,2,2,2,394,0,""],[34,"champ","f",4,0,395,399,33,2,1,1,400,0,""],[35,"T0","c",5,2,402,403,34,0,1,0,400,0,""],[36,"chp_nom_cible","c",5,2,409,421,34,0,2,0,400,0,""],[37,":T0_chp_nom_cible","c",4,0,427,443,33,0,2,0,400,444,""],[38,"comme","f",3,0,448,452,27,2,3,2,453,0,""],[39,"champ","f",4,0,454,458,38,2,1,1,459,0,""],[40,"T0","c",5,2,461,462,39,0,1,0,459,0,""],[41,"chp_dossier_cible","c",5,2,468,484,39,0,2,0,459,0,""],[42,":T0_chp_dossier_cible","c",4,0,490,510,38,0,2,0,459,511,""],[43,"comme","f",3,0,515,519,27,2,4,2,520,0,""],[44,"champ","f",4,0,521,525,43,2,1,1,526,0,""],[45,"T0","c",5,2,528,529,44,0,1,0,526,0,""],[46,"chp_commentaire_cible","c",5,2,535,555,44,0,2,0,526,0,""],[47,":T0_chp_commentaire_cible","c",4,0,561,585,43,0,2,0,526,586,""],[48,"complements","f",1,0,598,608,1,2,5,4,609,0,""],[49,"trier_par","f",2,0,617,625,48,1,1,3,626,0,""],[50,"","f",3,0,617,625,49,2,1,2,627,0,""],[51,"champ","f",4,0,628,632,50,2,1,1,633,0,""],[52,"T0","c",5,2,635,636,51,0,1,0,633,0,""],[53,"chi_id_cible","c",5,2,642,653,51,0,2,0,633,0,""],[54,"croissant","f",4,0,659,667,50,0,2,0,668,0,""],[55,"limit\u00e9_\u00e0","f",2,0,680,687,48,2,2,2,688,0,""],[56,"quantit\u00e9","f",3,0,689,696,55,1,1,1,697,0,""],[57,":quantitee","c",4,0,698,707,56,0,1,0,697,708,""],[58,"d\u00e9but","f",3,0,712,716,55,1,2,1,717,0,""],[59,":debut","c",4,0,718,723,58,0,1,0,717,724,""]]'),
('34','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_cible`) , champ(`T0` , `chp_nom_cible`) , champ(`T0` , `chp_dossier_cible`) , champ(`T0` , `chp_commentaire_cible`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_cibles , alias(T0) , base(b1)))
      )
   ),
   conditions(egal(champ(`T0` , `chi_id_cible`) , :T0_chi_id_cible))
)','SELECT 
`T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
 FROM b1.tbl_cibles T0
WHERE `T0`.`chi_id_cible` = :T0_chi_id_cible;','function sql_34($par){
    $champs0=''
      `T0`.`chi_id_cible` , `T0`.`chp_nom_cible` , `T0`.`chp_dossier_cible` , `T0`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_cible`'',$par[''T0_chi_id_cible'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $errr=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($errr);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_cible'' => $tab0[0],
                ''T0.chp_nom_cible'' => $tab0[1],
                ''T0.chp_dossier_cible'' => $tab0[2],
                ''T0.chp_commentaire_cible'' => $tab0[3],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','cible par id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_cible","c",3,2,64,75,5,0,2,0,55,0,""],[8,"champ","f",2,0,81,85,4,2,2,1,86,0,""],[9,"T0","c",3,2,88,89,8,0,1,0,86,0,""],[10,"chp_nom_cible","c",3,2,95,107,8,0,2,0,86,0,""],[11,"champ","f",2,0,113,117,4,2,3,1,118,0,""],[12,"T0","c",3,2,120,121,11,0,1,0,118,0,""],[13,"chp_dossier_cible","c",3,2,127,143,11,0,2,0,118,0,""],[14,"champ","f",2,0,149,153,4,2,4,1,154,0,""],[15,"T0","c",3,2,156,157,14,0,1,0,154,0,""],[16,"chp_commentaire_cible","c",3,2,163,183,14,0,2,0,154,0,""],[17,"provenance","f",1,0,192,201,1,1,3,5,202,0,""],[18,"table_reference","f",2,0,210,224,17,1,1,4,225,0,""],[19,"source","f",3,0,236,241,18,1,1,3,242,0,""],[20,"nom_de_la_table","f",4,0,243,257,19,3,1,2,258,0,""],[21,"tbl_cibles","c",5,0,259,268,20,0,1,0,0,0,""],[22,"alias","f",5,0,272,276,20,1,2,1,277,0,""],[23,"T0","c",6,0,278,279,22,0,1,0,277,280,""],[24,"base","f",5,0,284,287,20,1,3,1,288,0,""],[25,"b1","c",6,0,289,290,24,0,1,0,288,291,""],[26,"conditions","f",1,0,312,321,1,1,4,3,322,0,""],[27,"egal","f",2,0,323,326,26,2,1,2,327,0,""],[28,"champ","f",3,0,328,332,27,2,1,1,333,0,""],[29,"T0","c",4,2,335,336,28,0,1,0,333,0,""],[30,"chi_id_cible","c",4,2,342,353,28,0,2,0,333,0,""],[31,":T0_chi_id_cible","c",3,0,359,374,27,0,2,0,333,375,""]]'),
('35','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`cht_php_requete`) , :n_cht_php_requete)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_requete`) , :c_chi_id_requete) , egal(champ(`chx_cible_requete`) , :c_chx_cible_requete))
   )
)','
UPDATE b1.tbl_requetes SET `cht_php_requete` = :n_cht_php_requete
WHERE (`chi_id_requete` = :c_chi_id_requete AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_35($par){
    $texte_sql_35=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.CRLF;
    if($par[''n_cht_php_requete'']==='''' || $par[''n_cht_php_requete'']===NULL ){
        $texte_sql_35.=''    `cht_php_requete`  = NULL  ''.CRLF;
    }else{
        $texte_sql_35.=''    `cht_php_requete`  = \''''.sq0($par[''n_cht_php_requete'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.CRLF;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.CRLF;
    $texte_sql_35.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_35 = <pre>'' . $texte_sql_35 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_35)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_35()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','modifier le php d''une requete après création','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"cht_php_requete","c",4,2,61,75,6,0,1,0,59,0,""],[8,":n_cht_php_requete","c",3,0,81,98,5,0,2,0,59,99,""],[9,"provenance","f",1,0,106,115,1,1,3,5,116,0,""],[10,"table_reference","f",2,0,124,138,9,1,1,4,139,0,""],[11,"source","f",3,0,150,155,10,1,1,3,156,0,""],[12,"nom_de_la_table","f",4,0,157,171,11,2,1,2,172,0,""],[13,"tbl_requetes","c",5,0,173,184,12,0,1,0,0,0,""],[14,"base","f",5,0,188,191,12,1,2,1,192,0,""],[15,"b1","c",6,0,193,194,14,0,1,0,192,195,""],[16,"conditions","f",1,0,216,225,1,1,4,4,226,0,""],[17,"et","f",2,0,234,235,16,2,1,3,236,0,""],[18,"egal","f",3,0,237,240,17,2,1,2,241,0,""],[19,"champ","f",4,0,242,246,18,1,1,1,247,0,""],[20,"chi_id_requete","c",5,2,249,262,19,0,1,0,247,0,""],[21,":c_chi_id_requete","c",4,0,268,284,18,0,2,0,247,285,""],[22,"egal","f",3,0,289,292,17,2,2,2,293,0,""],[23,"champ","f",4,0,294,298,22,1,1,1,299,0,""],[24,"chx_cible_requete","c",5,2,301,317,23,0,1,0,299,0,""],[25,":c_chx_cible_requete","c",4,0,323,342,22,0,2,0,299,343,""]]'),
('36','1','insert','insérer(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_nom_cible`) , :chp_nom_cible) , affecte(champ(`chp_dossier_cible`) , :chp_dossier_cible) , affecte(champ(`chp_commentaire_cible`) , :chp_commentaire_cible)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_cibles , base(b1)))
      )
   )
)','
INSERT INTO b1.`tbl_cibles`(
    `chp_nom_cible` , 
    `chp_dossier_cible` , 
    `chp_commentaire_cible`
) VALUES (
    :chp_nom_cible , 
    :chp_dossier_cible , 
    :chp_commentaire_cible
);','function sql_36($par){
    $texte_sql_36=''
      INSERT INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_cibles`(
         `chp_nom_cible` , 
         `chp_dossier_cible` , 
         `chp_commentaire_cible`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_cible'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_dossier_cible'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_cible'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_36.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_36 = <pre>'' . $texte_sql_36 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_36)){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_36()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,3,2,3,44,0,""],[5,"affecte","f",2,0,45,51,4,2,1,2,52,0,""],[6,"champ","f",3,0,53,57,5,1,1,1,58,0,""],[7,"chp_nom_cible","c",4,2,60,72,6,0,1,0,58,0,""],[8,":chp_nom_cible","c",3,0,78,91,5,0,2,0,58,92,""],[9,"affecte","f",2,0,96,102,4,2,2,2,103,0,""],[10,"champ","f",3,0,104,108,9,1,1,1,109,0,""],[11,"chp_dossier_cible","c",4,2,111,127,10,0,1,0,109,0,""],[12,":chp_dossier_cible","c",3,0,133,150,9,0,2,0,109,151,""],[13,"affecte","f",2,0,155,161,4,2,3,2,162,0,""],[14,"champ","f",3,0,163,167,13,1,1,1,168,0,""],[15,"chp_commentaire_cible","c",4,2,170,190,14,0,1,0,168,0,""],[16,":chp_commentaire_cible","c",3,0,196,217,13,0,2,0,168,218,""],[17,"provenance","f",1,0,225,234,1,1,3,5,235,0,""],[18,"table_reference","f",2,0,243,257,17,1,1,4,258,0,""],[19,"source","f",3,0,269,274,18,1,1,3,275,0,""],[20,"nom_de_la_table","f",4,0,276,290,19,2,1,2,291,0,""],[21,"tbl_cibles","c",5,0,292,301,20,0,1,0,0,0,""],[22,"base","f",5,0,305,308,20,1,2,1,309,0,""],[23,"b1","c",6,0,310,311,22,0,1,0,309,312,""]]'),
('37','1','insert','insérer(
   base_de_reference(1),
   valeurs(affecte(champ(`chx_cible_dossier`) , :chx_cible_dossier) , affecte(champ(`chp_nom_dossier`) , :chp_nom_dossier)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , base(b1)))
      )
   )
)','
INSERT INTO b1.`tbl_dossiers`(
    `chx_cible_dossier` , 
    `chp_nom_dossier`
) VALUES (
    :chx_cible_dossier , 
    :chp_nom_dossier
);','function sql_37($par){
    $texte_sql_37=''
      INSERT INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_dossiers`(
         `chx_cible_dossier` , 
         `chp_nom_dossier`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_dossier'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_dossier'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_37.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_37 = <pre>'' . $texte_sql_37 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_37)){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_37()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,2,2,3,44,0,""],[5,"affecte","f",2,0,45,51,4,2,1,2,52,0,""],[6,"champ","f",3,0,53,57,5,1,1,1,58,0,""],[7,"chx_cible_dossier","c",4,2,60,76,6,0,1,0,58,0,""],[8,":chx_cible_dossier","c",3,0,82,99,5,0,2,0,58,100,""],[9,"affecte","f",2,0,104,110,4,2,2,2,111,0,""],[10,"champ","f",3,0,112,116,9,1,1,1,117,0,""],[11,"chp_nom_dossier","c",4,2,119,133,10,0,1,0,117,0,""],[12,":chp_nom_dossier","c",3,0,139,154,9,0,2,0,117,155,""],[13,"provenance","f",1,0,162,171,1,1,3,5,172,0,""],[14,"table_reference","f",2,0,180,194,13,1,1,4,195,0,""],[15,"source","f",3,0,206,211,14,1,1,3,212,0,""],[16,"nom_de_la_table","f",4,0,213,227,15,2,1,2,228,0,""],[17,"tbl_dossiers","c",5,0,229,240,16,0,1,0,0,0,""],[18,"base","f",5,0,244,247,16,1,2,1,248,0,""],[19,"b1","c",6,0,249,250,18,0,1,0,248,251,""]]'),
('38','1','requete_manuelle','requete_manuelle(
   base_de_reference(1)
   transaction()
)','
BEGIN TRANSACTION;
','function sql_38($par){
    $texte_sql_38=''
      
      BEGIN TRANSACTION;
      
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_38 = <pre>'' . $texte_sql_38 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_38)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_38()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"requete_manuelle","f",0,0,0,15,0,2,1,2,16,0,""],[2,"base_de_reference","f",1,0,21,37,1,1,1,1,38,0,""],[3,"1","c",2,0,39,39,2,0,1,0,38,40,""],[4,"transaction","f",1,0,45,55,1,0,2,0,56,0,""]]'),
('39','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_source`) , :chi_id_source) , egal(champ(`chx_cible_id_source`) , :chx_cible_id_source))
   )
)','
DELETE FROM b1.tbl_sources
WHERE (`chi_id_source` = :chi_id_source
   AND `chx_cible_id_source` = :chx_cible_id_source) ;','function sql_39($par){
    $texte_sql_39=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources
          WHERE (`chi_id_source` = ''.sq1($par[''chi_id_source'']).'' AND `chx_cible_id_source` = ''.sq1($par[''chx_cible_id_source'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_39 = <pre>'' . $texte_sql_39 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_39);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_39()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','source par id et cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_sources","c",5,0,106,116,7,0,1,0,0,0,""],[9,"base","f",5,0,120,123,7,1,2,1,124,0,""],[10,"b1","c",6,0,125,126,9,0,1,0,124,127,""],[11,"conditions","f",1,0,148,157,1,1,3,4,158,0,""],[12,"et","f",2,0,166,167,11,2,1,3,168,0,""],[13,"egal","f",3,0,169,172,12,2,1,2,173,0,""],[14,"champ","f",4,0,174,178,13,1,1,1,179,0,""],[15,"chi_id_source","c",5,2,181,193,14,0,1,0,179,0,""],[16,":chi_id_source","c",4,0,199,212,13,0,2,0,179,213,""],[17,"egal","f",3,0,217,220,12,2,2,2,221,0,""],[18,"champ","f",4,0,222,226,17,1,1,1,227,0,""],[19,"chx_cible_id_source","c",5,2,229,247,18,0,1,0,227,0,""],[20,":chx_cible_id_source","c",4,0,253,272,17,0,2,0,227,273,""]]'),
('40','1','requete_manuelle','requete_manuelle(
   #(),
   base_de_reference(1),
   rollback()
)','
ROLLBACK;','function sql_40($par){
    $texte_sql_40=''
      
      ROLLBACK;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_40 = <pre>'' . $texte_sql_40 . ''</pre>'' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_40)){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_40()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"requete_manuelle","f",0,0,0,15,0,3,1,2,16,0,""],[2,"#","f",1,0,21,21,1,0,1,0,22,23,""],[3,"base_de_reference","f",1,0,29,45,1,1,2,1,46,0,""],[4,"1","c",2,0,47,47,3,0,1,0,46,48,""],[5,"rollback","f",1,0,54,61,1,0,3,0,62,0,""]]'),
('41','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , base(b1)))
      )
   ),
   conditions(egal(champ(`chx_cible_id_source`) , :chx_cible_id_source))
)','
DELETE FROM b1.tbl_sources
WHERE `chx_cible_id_source` = :chx_cible_id_source ;','function sql_41($par){
    $texte_sql_41=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources
          WHERE `chx_cible_id_source` = ''.sq1($par[''chx_cible_id_source'']).'' ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_41 = <pre>'' . $texte_sql_41 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_41);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_41()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','sources par cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_sources","c",5,0,106,116,7,0,1,0,0,0,""],[9,"base","f",5,0,120,123,7,1,2,1,124,0,""],[10,"b1","c",6,0,125,126,9,0,1,0,124,127,""],[11,"conditions","f",1,0,148,157,1,1,3,3,158,0,""],[12,"egal","f",2,0,159,162,11,2,1,2,163,0,""],[13,"champ","f",3,0,164,168,12,1,1,1,169,0,""],[14,"chx_cible_id_source","c",4,2,171,189,13,0,1,0,169,0,""],[15,":chx_cible_id_source","c",3,0,195,214,12,0,2,0,169,215,""]]'),
('42','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chx_cible_requete`) , :chx_cible_requete))
   )
)','
DELETE FROM b1.tbl_requetes
WHERE (`chx_cible_requete` = :chx_cible_requete) ;','function sql_42($par){
    $texte_sql_42=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_requetes
          WHERE (`chx_cible_requete` = ''.sq1($par[''chx_cible_requete'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_42 = <pre>'' . $texte_sql_42 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_42);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_42()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','requêtes par cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_requetes","c",5,0,106,117,7,0,1,0,0,0,""],[9,"base","f",5,0,121,124,7,1,2,1,125,0,""],[10,"b1","c",6,0,126,127,9,0,1,0,125,128,""],[11,"conditions","f",1,0,149,158,1,1,3,4,159,0,""],[12,"et","f",2,0,167,168,11,1,1,3,169,0,""],[13,"egal","f",3,0,170,173,12,2,1,2,174,0,""],[14,"champ","f",4,0,175,179,13,1,1,1,180,0,""],[15,"chx_cible_requete","c",5,2,182,198,14,0,1,0,180,0,""],[16,":chx_cible_requete","c",4,0,204,221,13,0,2,0,180,222,""]]'),
('43','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chx_cible_id_basedd`) , :chx_cible_id_basedd))
   )
)','
DELETE FROM b1.tbl_bdds
WHERE (`chx_cible_id_basedd` = :chx_cible_id_basedd) ;','function sql_43($par){
    $texte_sql_43=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds
          WHERE (`chx_cible_id_basedd` = ''.sq1($par[''chx_cible_id_basedd'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_43 = <pre>'' . $texte_sql_43 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_43);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_43()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','bases par cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_bdds","c",5,0,106,113,7,0,1,0,0,0,""],[9,"base","f",5,0,117,120,7,1,2,1,121,0,""],[10,"b1","c",6,0,122,123,9,0,1,0,121,124,""],[11,"conditions","f",1,0,145,154,1,1,3,4,155,0,""],[12,"et","f",2,0,163,164,11,1,1,3,165,0,""],[13,"egal","f",3,0,166,169,12,2,1,2,170,0,""],[14,"champ","f",4,0,171,175,13,1,1,1,176,0,""],[15,"chx_cible_id_basedd","c",5,2,178,196,14,0,1,0,176,0,""],[16,":chx_cible_id_basedd","c",4,0,202,221,13,0,2,0,176,222,""]]'),
('44','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chx_cible_dossier`) , :chx_cible_dossier))
   )
)','
DELETE FROM b1.tbl_dossiers
WHERE (`chx_cible_dossier` = :chx_cible_dossier) ;','function sql_44($par){
    $texte_sql_44=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers
          WHERE (`chx_cible_dossier` = ''.sq1($par[''chx_cible_dossier'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_44 = <pre>'' . $texte_sql_44 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_44);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_44()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','dossiers d''une cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_dossiers","c",5,0,106,117,7,0,1,0,0,0,""],[9,"base","f",5,0,121,124,7,1,2,1,125,0,""],[10,"b1","c",6,0,126,127,9,0,1,0,125,128,""],[11,"conditions","f",1,0,149,158,1,1,3,4,159,0,""],[12,"et","f",2,0,167,168,11,1,1,3,169,0,""],[13,"egal","f",3,0,170,173,12,2,1,2,174,0,""],[14,"champ","f",4,0,175,179,13,1,1,1,180,0,""],[15,"chx_cible_dossier","c",5,2,182,198,14,0,1,0,180,0,""],[16,":chx_cible_dossier","c",4,0,204,221,13,0,2,0,180,222,""]]'),
('45','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_cibles , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_cible`) , :chi_id_cible))
   )
)','
DELETE FROM b1.tbl_cibles
WHERE (`chi_id_cible` = :chi_id_cible) ;','function sql_45($par){
    $texte_sql_45=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles
          WHERE (`chi_id_cible` = ''.sq1($par[''chi_id_cible'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_45 = <pre>'' . $texte_sql_45 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_45);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_45()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','cible par id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_cibles","c",5,0,106,115,7,0,1,0,0,0,""],[9,"base","f",5,0,119,122,7,1,2,1,123,0,""],[10,"b1","c",6,0,124,125,9,0,1,0,123,126,""],[11,"conditions","f",1,0,147,156,1,1,3,4,157,0,""],[12,"et","f",2,0,165,166,11,1,1,3,167,0,""],[13,"egal","f",3,0,168,171,12,2,1,2,172,0,""],[14,"champ","f",4,0,173,177,13,1,1,1,178,0,""],[15,"chi_id_cible","c",5,2,180,191,14,0,1,0,178,0,""],[16,":chi_id_cible","c",4,0,197,209,13,0,2,0,178,210,""]]'),
('46','1','requete_manuelle','requete_manuelle(base_de_reference(1) , commit())','
COMMIT;','function sql_46($par,$db){
    $texte_sql_46=''
      
      COMMIT;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_46 = <pre>'' . $texte_sql_46 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$db->exec($texte_sql_46);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $db->lastErrorCode() ,__xme => ''erreur sql_46()''.'' ''.$db->lastErrorMsg()));
    }else{
        return(array( __xst => true ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"requete_manuelle","f",0,0,0,15,0,2,1,2,16,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"commit","f",1,0,40,45,1,0,2,0,46,0,""]]'),
('47','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_commentaire_cible`) , :n_chp_commentaire_cible)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_cibles , base(b1)))
      )
   ),
   conditions(egal(champ(`chi_id_cible`) , 1))
)','
UPDATE b1.tbl_cibles SET `chp_commentaire_cible` = :n_chp_commentaire_cible
WHERE `chi_id_cible` = 1 ;','function sql_47($par){
    $texte_sql_47=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_cibles` SET ''.CRLF;
    if($par[''n_chp_commentaire_cible'']==='''' || $par[''n_chp_commentaire_cible'']===NULL ){
        $texte_sql_47.=''    `chp_commentaire_cible`  = NULL  ''.CRLF;
    }else{
        $texte_sql_47.=''    `chp_commentaire_cible`  = \''''.sq0($par[''n_chp_commentaire_cible'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_cible` = 1''.CRLF;
    $texte_sql_47.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_47 = <pre>'' . $texte_sql_47 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_47);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_47()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chp_commentaire_cible","c",4,2,61,81,6,0,1,0,59,0,""],[8,":n_chp_commentaire_cible","c",3,0,87,110,5,0,2,0,59,111,""],[9,"provenance","f",1,0,118,127,1,1,3,5,128,0,""],[10,"table_reference","f",2,0,136,150,9,1,1,4,151,0,""],[11,"source","f",3,0,162,167,10,1,1,3,168,0,""],[12,"nom_de_la_table","f",4,0,169,183,11,2,1,2,184,0,""],[13,"tbl_cibles","c",5,0,185,194,12,0,1,0,0,0,""],[14,"base","f",5,0,198,201,12,1,2,1,202,0,""],[15,"b1","c",6,0,203,204,14,0,1,0,202,205,""],[16,"conditions","f",1,0,226,235,1,1,4,3,236,0,""],[17,"egal","f",2,0,237,240,16,2,1,2,241,0,""],[18,"champ","f",3,0,242,246,17,1,1,1,247,0,""],[19,"chi_id_cible","c",4,2,249,260,18,0,1,0,247,0,""],[20,"1","c",3,0,266,266,17,0,2,0,247,267,""]]'),
('48','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_nom_cible`) , :n_chp_nom_cible) , affecte(champ(`chp_dossier_cible`) , :n_chp_dossier_cible) , affecte(champ(`chp_commentaire_cible`) , :n_chp_commentaire_cible)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_cibles , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_cible`) , :c_chi_id_cible))
   )
)','
UPDATE b1.tbl_cibles SET `chp_nom_cible` = :n_chp_nom_cible , `chp_dossier_cible` = :n_chp_dossier_cible , `chp_commentaire_cible` = :n_chp_commentaire_cible
WHERE (`chi_id_cible` = :c_chi_id_cible) ;','function sql_48($par){
    $texte_sql_48=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_cibles` SET ''.CRLF;
    $texte_sql_48.=''    `chp_nom_cible`          = \''''.sq0($par[''n_chp_nom_cible'']).''\''          , ''.CRLF;
    if($par[''n_chp_dossier_cible'']==='''' || $par[''n_chp_dossier_cible'']===NULL ){
        $texte_sql_48.=''    `chp_dossier_cible`      = NULL      , ''.CRLF;
    }else{
        $texte_sql_48.=''    `chp_dossier_cible`      = \''''.sq0($par[''n_chp_dossier_cible'']).''\'' , ''.CRLF;
    }
    if($par[''n_chp_commentaire_cible'']==='''' || $par[''n_chp_commentaire_cible'']===NULL ){
        $texte_sql_48.=''    `chp_commentaire_cible`  = NULL  ''.CRLF;
    }else{
        $texte_sql_48.=''    `chp_commentaire_cible`  = \''''.sq0($par[''n_chp_commentaire_cible'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_cible` = ''.sq1($par[''c_chi_id_cible'']).''''.CRLF;
    $texte_sql_48.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_48 = <pre>'' . $texte_sql_48 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_48);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_48()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,3,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chp_nom_cible","c",4,2,61,73,6,0,1,0,59,0,""],[8,":n_chp_nom_cible","c",3,0,79,94,5,0,2,0,59,95,""],[9,"affecte","f",2,0,99,105,4,2,2,2,106,0,""],[10,"champ","f",3,0,107,111,9,1,1,1,112,0,""],[11,"chp_dossier_cible","c",4,2,114,130,10,0,1,0,112,0,""],[12,":n_chp_dossier_cible","c",3,0,136,155,9,0,2,0,112,156,""],[13,"affecte","f",2,0,160,166,4,2,3,2,167,0,""],[14,"champ","f",3,0,168,172,13,1,1,1,173,0,""],[15,"chp_commentaire_cible","c",4,2,175,195,14,0,1,0,173,0,""],[16,":n_chp_commentaire_cible","c",3,0,201,224,13,0,2,0,173,225,""],[17,"provenance","f",1,0,232,241,1,1,3,5,242,0,""],[18,"table_reference","f",2,0,250,264,17,1,1,4,265,0,""],[19,"source","f",3,0,276,281,18,1,1,3,282,0,""],[20,"nom_de_la_table","f",4,0,283,297,19,2,1,2,298,0,""],[21,"tbl_cibles","c",5,0,299,308,20,0,1,0,0,0,""],[22,"base","f",5,0,312,315,20,1,2,1,316,0,""],[23,"b1","c",6,0,317,318,22,0,1,0,316,319,""],[24,"conditions","f",1,0,340,349,1,1,4,4,350,0,""],[25,"et","f",2,0,358,359,24,1,1,3,360,0,""],[26,"egal","f",3,0,361,364,25,2,1,2,365,0,""],[27,"champ","f",4,0,366,370,26,1,1,1,371,0,""],[28,"chi_id_cible","c",5,2,373,384,27,0,1,0,371,0,""],[29,":c_chi_id_cible","c",4,0,390,404,26,0,2,0,371,405,""]]'),
('49','1','select','sélectionner(
   base_de_reference(1),
   valeurs(compter(tous_les_champs())),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_basedd`) , :T0_chi_id_basedd) , egal(champ(`T0` , `chx_cible_id_basedd`) , :T0_chx_cible_id_basedd))
   )
)','SELECT 
count(*)
 FROM b1.tbl_bdds T0
WHERE (`T0`.`chi_id_basedd` = :T0_chi_id_basedd AND `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd);','function sql_49($par){
    $champs0=''
      count(*)
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_basedd`'',$par[''T0_chi_id_basedd'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''0'' => $tab0[0],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','comptage des bases d''un correspondants à des id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,1,2,2,49,0,""],[5,"compter","f",2,0,50,56,4,1,1,1,57,0,""],[6,"tous_les_champs","f",3,0,58,72,5,0,1,0,73,0,""],[7,"provenance","f",1,0,82,91,1,1,3,5,92,0,""],[8,"table_reference","f",2,0,100,114,7,1,1,4,115,0,""],[9,"source","f",3,0,126,131,8,1,1,3,132,0,""],[10,"nom_de_la_table","f",4,0,133,147,9,3,1,2,148,0,""],[11,"tbl_bdds","c",5,0,149,156,10,0,1,0,0,0,""],[12,"alias","f",5,0,160,164,10,1,2,1,165,0,""],[13,"T0","c",6,0,166,167,12,0,1,0,165,168,""],[14,"base","f",5,0,172,175,10,1,3,1,176,0,""],[15,"b1","c",6,0,177,178,14,0,1,0,176,179,""],[16,"conditions","f",1,0,200,209,1,1,4,4,210,0,""],[17,"et","f",2,0,218,219,16,2,1,3,220,0,""],[18,"egal","f",3,0,221,224,17,2,1,2,225,0,""],[19,"champ","f",4,0,226,230,18,2,1,1,231,0,""],[20,"T0","c",5,2,233,234,19,0,1,0,231,0,""],[21,"chi_id_basedd","c",5,2,240,252,19,0,2,0,231,0,""],[22,":T0_chi_id_basedd","c",4,0,258,274,18,0,2,0,231,275,""],[23,"egal","f",3,0,279,282,17,2,2,2,283,0,""],[24,"champ","f",4,0,284,288,23,2,1,1,289,0,""],[25,"T0","c",5,2,291,292,24,0,1,0,289,0,""],[26,"chx_cible_id_basedd","c",5,2,298,316,24,0,2,0,289,0,""],[27,":T0_chx_cible_id_basedd","c",4,0,322,344,23,0,2,0,289,345,""]]'),
('50','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_dossier`),
      champ(`T0` , `chx_cible_dossier`),
      champ(`T0` , `chp_nom_dossier`),
      champ(`T1` , `chi_id_cible`),
      champ(`T1` , `chp_nom_cible`),
      champ(`T1` , `chp_dossier_cible`),
      champ(`T1` , `chp_commentaire_cible`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , alias(T0) , base(b1)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_cibles , alias(T1) , base(b1))),
         contrainte(egal(champ(T1 , chi_id_cible) , champ(T0 , chx_cible_dossier)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_dossier`) , :T0_chi_id_dossier) , egal(champ(`T0` , `chx_cible_dossier`) , :T0_chx_cible_dossier))
   )
)','SELECT 
`T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
`T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible`
 FROM b1.tbl_dossiers T0
 LEFT JOIN b1.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_dossier

WHERE (`T0`.`chi_id_dossier` = :T0_chi_id_dossier AND `T0`.`chx_cible_dossier` = :T0_chx_cible_dossier);','function sql_50($par){
    $champs0=''
      `T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
      `T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_dossier
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_dossier`'',$par[''T0_chi_id_dossier'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_dossier'' => $tab0[0],
                ''T0.chx_cible_dossier'' => $tab0[1],
                ''T0.chp_nom_dossier'' => $tab0[2],
                ''T1.chi_id_cible'' => $tab0[3],
                ''T1.chp_nom_cible'' => $tab0[4],
                ''T1.chp_dossier_cible'' => $tab0[5],
                ''T1.chp_commentaire_cible'' => $tab0[6],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','dossier par id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,7,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_dossier","c",3,2,71,84,5,0,2,0,62,0,""],[8,"champ","f",2,0,95,99,4,2,2,1,100,0,""],[9,"T0","c",3,2,102,103,8,0,1,0,100,0,""],[10,"chx_cible_dossier","c",3,2,109,125,8,0,2,0,100,0,""],[11,"champ","f",2,0,136,140,4,2,3,1,141,0,""],[12,"T0","c",3,2,143,144,11,0,1,0,141,0,""],[13,"chp_nom_dossier","c",3,2,150,164,11,0,2,0,141,0,""],[14,"champ","f",2,0,175,179,4,2,4,1,180,0,""],[15,"T1","c",3,2,182,183,14,0,1,0,180,0,""],[16,"chi_id_cible","c",3,2,189,200,14,0,2,0,180,0,""],[17,"champ","f",2,0,211,215,4,2,5,1,216,0,""],[18,"T1","c",3,2,218,219,17,0,1,0,216,0,""],[19,"chp_nom_cible","c",3,2,225,237,17,0,2,0,216,0,""],[20,"champ","f",2,0,248,252,4,2,6,1,253,0,""],[21,"T1","c",3,2,255,256,20,0,1,0,253,0,""],[22,"chp_dossier_cible","c",3,2,262,278,20,0,2,0,253,0,""],[23,"champ","f",2,0,289,293,4,2,7,1,294,0,""],[24,"T1","c",3,2,296,297,23,0,1,0,294,0,""],[25,"chp_commentaire_cible","c",3,2,303,323,23,0,2,0,294,0,""],[26,"provenance","f",1,0,336,345,1,2,3,5,346,0,""],[27,"table_reference","f",2,0,354,368,26,1,1,4,369,0,""],[28,"source","f",3,0,380,385,27,1,1,3,386,0,""],[29,"nom_de_la_table","f",4,0,387,401,28,3,1,2,402,0,""],[30,"tbl_dossiers","c",5,0,403,414,29,0,1,0,0,0,""],[31,"alias","f",5,0,418,422,29,1,2,1,423,0,""],[32,"T0","c",6,0,424,425,31,0,1,0,423,426,""],[33,"base","f",5,0,430,433,29,1,3,1,434,0,""],[34,"b1","c",6,0,435,436,33,0,1,0,434,437,""],[35,"jointure_gauche","f",2,0,456,470,26,2,2,4,471,0,""],[36,"source","f",3,0,482,487,35,1,1,3,488,0,""],[37,"nom_de_la_table","f",4,0,489,503,36,3,1,2,504,0,""],[38,"tbl_cibles","c",5,0,505,514,37,0,1,0,0,0,""],[39,"alias","f",5,0,518,522,37,1,2,1,523,0,""],[40,"T1","c",6,0,524,525,39,0,1,0,523,526,""],[41,"base","f",5,0,530,533,37,1,3,1,534,0,""],[42,"b1","c",6,0,535,536,41,0,1,0,534,537,""],[43,"contrainte","f",3,0,551,560,35,1,2,3,561,0,""],[44,"egal","f",4,0,562,565,43,2,1,2,566,0,""],[45,"champ","f",5,0,567,571,44,2,1,1,572,0,""],[46,"T1","c",6,0,573,574,45,0,1,0,0,0,""],[47,"chi_id_cible","c",6,0,578,589,45,0,2,0,572,590,""],[48,"champ","f",5,0,594,598,44,2,2,1,599,0,""],[49,"T0","c",6,0,600,601,48,0,1,0,0,0,""],[50,"chx_cible_dossier","c",6,0,605,621,48,0,2,0,599,622,""],[51,"conditions","f",1,0,643,652,1,1,4,4,653,0,""],[52,"et","f",2,0,661,662,51,2,1,3,663,0,""],[53,"egal","f",3,0,664,667,52,2,1,2,668,0,""],[54,"champ","f",4,0,669,673,53,2,1,1,674,0,""],[55,"T0","c",5,2,676,677,54,0,1,0,674,0,""],[56,"chi_id_dossier","c",5,2,683,696,54,0,2,0,674,0,""],[57,":T0_chi_id_dossier","c",4,0,702,719,53,0,2,0,674,720,""],[58,"egal","f",3,0,724,727,52,2,2,2,728,0,""],[59,"champ","f",4,0,729,733,58,2,1,1,734,0,""],[60,"T0","c",5,2,736,737,59,0,1,0,734,0,""],[61,"chx_cible_dossier","c",5,2,743,759,59,0,2,0,734,0,""],[62,":T0_chx_cible_dossier","c",4,0,765,785,58,0,2,0,734,786,""]]'),
('51','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_dossier`) , champ(`T0` , `chx_cible_dossier`) , champ(`T0` , `chp_nom_dossier`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chx_cible_dossier`) , :T0_chx_cible_dossier))
   )
)','SELECT 
`T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier`
 FROM b1.tbl_dossiers T0
WHERE (`T0`.`chx_cible_dossier` = :T0_chx_cible_dossier);','function sql_51($par){
    $champs0=''
      `T0`.`chi_id_dossier` , `T0`.`chx_cible_dossier` , `T0`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_dossier'' => $tab0[0],
                ''T0.chx_cible_dossier'' => $tab0[1],
                ''T0.chp_nom_dossier'' => $tab0[2],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','tous les dossiers d''une cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,3,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_dossier","c",3,2,64,77,5,0,2,0,55,0,""],[8,"champ","f",2,0,83,87,4,2,2,1,88,0,""],[9,"T0","c",3,2,90,91,8,0,1,0,88,0,""],[10,"chx_cible_dossier","c",3,2,97,113,8,0,2,0,88,0,""],[11,"champ","f",2,0,119,123,4,2,3,1,124,0,""],[12,"T0","c",3,2,126,127,11,0,1,0,124,0,""],[13,"chp_nom_dossier","c",3,2,133,147,11,0,2,0,124,0,""],[14,"provenance","f",1,0,156,165,1,1,3,5,166,0,""],[15,"table_reference","f",2,0,174,188,14,1,1,4,189,0,""],[16,"source","f",3,0,200,205,15,1,1,3,206,0,""],[17,"nom_de_la_table","f",4,0,207,221,16,3,1,2,222,0,""],[18,"tbl_dossiers","c",5,0,223,234,17,0,1,0,0,0,""],[19,"alias","f",5,0,238,242,17,1,2,1,243,0,""],[20,"T0","c",6,0,244,245,19,0,1,0,243,246,""],[21,"base","f",5,0,250,253,17,1,3,1,254,0,""],[22,"b1","c",6,0,255,256,21,0,1,0,254,257,""],[23,"conditions","f",1,0,278,287,1,1,4,4,288,0,""],[24,"et","f",2,0,296,297,23,1,1,3,298,0,""],[25,"egal","f",3,0,299,302,24,2,1,2,303,0,""],[26,"champ","f",4,0,304,308,25,2,1,1,309,0,""],[27,"T0","c",5,2,311,312,26,0,1,0,309,0,""],[28,"chx_cible_dossier","c",5,2,318,334,26,0,2,0,309,0,""],[29,":T0_chx_cible_dossier","c",4,0,340,360,25,0,2,0,309,361,""]]'),
('52','1','insert','insérer(
   base_de_reference(1),
   valeurs(affecte(champ(`chx_cible_dossier`) , :chx_cible_dossier) , affecte(champ(`chp_nom_dossier`) , :chp_nom_dossier)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , base(b1)))
      )
   ),
   complements(ignorer())
)','
INSERT  OR IGNORE INTO b1.`tbl_dossiers`(
    `chx_cible_dossier` , 
    `chp_nom_dossier`
) VALUES (
    :chx_cible_dossier , 
    :chp_nom_dossier
);','function sql_52($par){
    $texte_sql_52=''
      INSERT  OR IGNORE  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_dossiers`(
         `chx_cible_dossier` , 
         `chp_nom_dossier`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_dossier'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_dossier'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_52.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_52 = <pre>'' . $texte_sql_52 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_52);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_52()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,4,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,2,2,3,44,0,""],[5,"affecte","f",2,0,45,51,4,2,1,2,52,0,""],[6,"champ","f",3,0,53,57,5,1,1,1,58,0,""],[7,"chx_cible_dossier","c",4,2,60,76,6,0,1,0,58,0,""],[8,":chx_cible_dossier","c",3,0,82,99,5,0,2,0,58,100,""],[9,"affecte","f",2,0,104,110,4,2,2,2,111,0,""],[10,"champ","f",3,0,112,116,9,1,1,1,117,0,""],[11,"chp_nom_dossier","c",4,2,119,133,10,0,1,0,117,0,""],[12,":chp_nom_dossier","c",3,0,139,154,9,0,2,0,117,155,""],[13,"provenance","f",1,0,162,171,1,1,3,5,172,0,""],[14,"table_reference","f",2,0,180,194,13,1,1,4,195,0,""],[15,"source","f",3,0,206,211,14,1,1,3,212,0,""],[16,"nom_de_la_table","f",4,0,213,227,15,2,1,2,228,0,""],[17,"tbl_dossiers","c",5,0,229,240,16,0,1,0,0,0,""],[18,"base","f",5,0,244,247,16,1,2,1,248,0,""],[19,"b1","c",6,0,249,250,18,0,1,0,248,251,""],[20,"complements","f",1,0,272,282,1,1,4,1,283,0,""],[21,"ignorer","f",2,0,284,290,20,0,1,0,291,0,""]]'),
('53','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_dossier`) , champ(`T0` , `chp_nom_dossier`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_dossier`) , :T0_chi_id_dossier) , egal(champ(`T0` , `chx_cible_dossier`) , :T0_chx_cible_dossier) , comme(champ(`T0` , `chp_nom_dossier`) , :T0_chp_nom_dossier))
   ),
   complements(
      trier_par((champ(`T0` , `chp_nom_dossier`) , croissant()) , (champ(`T0` , `chi_id_dossier`) , décroissant())),
      limité_à(quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_dossier` , `T0`.`chp_nom_dossier`
 FROM b1.tbl_dossiers T0
WHERE (`T0`.`chi_id_dossier` = :T0_chi_id_dossier
   AND `T0`.`chx_cible_dossier` = :T0_chx_cible_dossier
   AND `T0`.`chp_nom_dossier` LIKE :T0_chp_nom_dossier) 
ORDER BY `T0`.`chp_nom_dossier` ASC, `T0`.`chi_id_dossier` DESC 
LIMIT:quantitee OFFSET :debut ;','function sql_53($par){
    $champs0=''
      `T0`.`chi_id_dossier` , `T0`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    if(($par[''T0_chi_id_dossier''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_dossier`'',$par[''T0_chi_id_dossier'']);
    }
    if(($par[''T0_chx_cible_dossier''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    }
    if(($par[''T0_chp_nom_dossier''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_dossier` LIKE ''.sq1($par[''T0_chp_nom_dossier'']).''''.CRLF;
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_nom_dossier` ASC, `T0`.`chi_id_dossier` DESC'';
    $sql0.=$order0;
    $plage0=''
       LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_dossier'' => $tab0[0],
                ''T0.chp_nom_dossier'' => $tab0[1],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','dossiers','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,2,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_dossier","c",3,2,64,77,5,0,2,0,55,0,""],[8,"champ","f",2,0,83,87,4,2,2,1,88,0,""],[9,"T0","c",3,2,90,91,8,0,1,0,88,0,""],[10,"chp_nom_dossier","c",3,2,97,111,8,0,2,0,88,0,""],[11,"provenance","f",1,0,120,129,1,1,3,5,130,0,""],[12,"table_reference","f",2,0,138,152,11,1,1,4,153,0,""],[13,"source","f",3,0,164,169,12,1,1,3,170,0,""],[14,"nom_de_la_table","f",4,0,171,185,13,3,1,2,186,0,""],[15,"tbl_dossiers","c",5,0,187,198,14,0,1,0,0,0,""],[16,"alias","f",5,0,202,206,14,1,2,1,207,0,""],[17,"T0","c",6,0,208,209,16,0,1,0,207,210,""],[18,"base","f",5,0,214,217,14,1,3,1,218,0,""],[19,"b1","c",6,0,219,220,18,0,1,0,218,221,""],[20,"conditions","f",1,0,242,251,1,1,4,4,252,0,""],[21,"et","f",2,0,260,261,20,3,1,3,262,0,""],[22,"egal","f",3,0,263,266,21,2,1,2,267,0,""],[23,"champ","f",4,0,268,272,22,2,1,1,273,0,""],[24,"T0","c",5,2,275,276,23,0,1,0,273,0,""],[25,"chi_id_dossier","c",5,2,282,295,23,0,2,0,273,0,""],[26,":T0_chi_id_dossier","c",4,0,301,318,22,0,2,0,273,319,""],[27,"egal","f",3,0,323,326,21,2,2,2,327,0,""],[28,"champ","f",4,0,328,332,27,2,1,1,333,0,""],[29,"T0","c",5,2,335,336,28,0,1,0,333,0,""],[30,"chx_cible_dossier","c",5,2,342,358,28,0,2,0,333,0,""],[31,":T0_chx_cible_dossier","c",4,0,364,384,27,0,2,0,333,385,""],[32,"comme","f",3,0,389,393,21,2,3,2,394,0,""],[33,"champ","f",4,0,395,399,32,2,1,1,400,0,""],[34,"T0","c",5,2,402,403,33,0,1,0,400,0,""],[35,"chp_nom_dossier","c",5,2,409,423,33,0,2,0,400,0,""],[36,":T0_chp_nom_dossier","c",4,0,429,447,32,0,2,0,400,448,""],[37,"complements","f",1,0,460,470,1,2,5,4,471,0,""],[38,"trier_par","f",2,0,479,487,37,2,1,3,488,0,""],[39,"","f",3,0,479,487,38,2,1,2,489,0,""],[40,"champ","f",4,0,490,494,39,2,1,1,495,0,""],[41,"T0","c",5,2,497,498,40,0,1,0,495,0,""],[42,"chp_nom_dossier","c",5,2,504,518,40,0,2,0,495,0,""],[43,"croissant","f",4,0,524,532,39,0,2,0,533,0,""],[44,"","f",3,0,524,532,38,2,2,2,539,0,""],[45,"champ","f",4,0,540,544,44,2,1,1,545,0,""],[46,"T0","c",5,2,547,548,45,0,1,0,545,0,""],[47,"chi_id_dossier","c",5,2,554,567,45,0,2,0,545,0,""],[48,"d\u00e9croissant","f",4,0,573,583,44,0,2,0,584,0,""],[49,"limit\u00e9_\u00e0","f",2,0,596,603,37,2,2,2,604,0,""],[50,"quantit\u00e9","f",3,0,605,612,49,1,1,1,613,0,""],[51,":quantitee","c",4,0,614,623,50,0,1,0,613,624,""],[52,"d\u00e9but","f",3,0,628,632,49,1,2,1,633,0,""],[53,":debut","c",4,0,634,639,52,0,1,0,633,640,""]]'),
('54','1','insert','insérer(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chx_cible_id_source`) , :chx_cible_id_source),
      affecte(champ(`chp_nom_source`) , :chp_nom_source),
      affecte(champ(`chp_commentaire_source`) , :chp_commentaire_source),
      affecte(champ(`chx_dossier_id_source`) , :chx_dossier_id_source),
      affecte(champ(`chp_rev_source`) , :chp_rev_source),
      affecte(champ(`chp_genere_source`) , :chp_genere_source),
      affecte(champ(`chp_type_source`) , :chp_type_source)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , base(b1)))
      )
   )
)','
INSERT INTO b1.`tbl_sources`(
    `chx_cible_id_source` , 
    `chp_nom_source` , 
    `chp_commentaire_source` , 
    `chx_dossier_id_source` , 
    `chp_rev_source` , 
    `chp_genere_source` , 
    `chp_type_source`
) VALUES (
    :chx_cible_id_source , 
    :chp_nom_source , 
    :chp_commentaire_source , 
    :chx_dossier_id_source , 
    :chp_rev_source , 
    :chp_genere_source , 
    :chp_type_source
);','function sql_54($par){
    $texte_sql_54=''
      INSERT  INTO `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_sources`(
         `chx_cible_id_source` , 
         `chp_nom_source` , 
         `chp_commentaire_source` , 
         `chx_dossier_id_source` , 
         `chp_rev_source` , 
         `chp_genere_source` , 
         `chp_type_source`
      ) VALUES 
    '';
    $liste_des_valeurs='''';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''''){
            $liste_des_valeurs.='','';
        }
        $liste_des_valeurs.=''('';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_cible_id_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_nom_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_commentaire_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chx_dossier_id_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_rev_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_genere_source'']).'','';
        $liste_des_valeurs.=CRLF.''      ''.sq1($par[$i][''chp_type_source'']).'''';
        $liste_des_valeurs.='')'';
    }
    $texte_sql_54.=$liste_des_valeurs;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_54 = <pre>'' . $texte_sql_54 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_54);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => false, 
            ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => ''erreur sql_54()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            ''nouvel_id''   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"ins\u00e9rer","f",0,0,0,6,0,3,1,6,7,0,""],[2,"base_de_reference","f",1,0,12,28,1,1,1,1,29,0,""],[3,"1","c",2,0,30,30,2,0,1,0,29,31,""],[4,"valeurs","f",1,0,37,43,1,7,2,3,44,0,""],[5,"affecte","f",2,0,52,58,4,2,1,2,59,0,""],[6,"champ","f",3,0,60,64,5,1,1,1,65,0,""],[7,"chx_cible_id_source","c",4,2,67,85,6,0,1,0,65,0,""],[8,":chx_cible_id_source","c",3,0,91,110,5,0,2,0,65,111,""],[9,"affecte","f",2,0,120,126,4,2,2,2,127,0,""],[10,"champ","f",3,0,128,132,9,1,1,1,133,0,""],[11,"chp_nom_source","c",4,2,135,148,10,0,1,0,133,0,""],[12,":chp_nom_source","c",3,0,154,168,9,0,2,0,133,169,""],[13,"affecte","f",2,0,178,184,4,2,3,2,185,0,""],[14,"champ","f",3,0,186,190,13,1,1,1,191,0,""],[15,"chp_commentaire_source","c",4,2,193,214,14,0,1,0,191,0,""],[16,":chp_commentaire_source","c",3,0,220,242,13,0,2,0,191,243,""],[17,"affecte","f",2,0,252,258,4,2,4,2,259,0,""],[18,"champ","f",3,0,260,264,17,1,1,1,265,0,""],[19,"chx_dossier_id_source","c",4,2,267,287,18,0,1,0,265,0,""],[20,":chx_dossier_id_source","c",3,0,293,314,17,0,2,0,265,315,""],[21,"affecte","f",2,0,324,330,4,2,5,2,331,0,""],[22,"champ","f",3,0,332,336,21,1,1,1,337,0,""],[23,"chp_rev_source","c",4,2,339,352,22,0,1,0,337,0,""],[24,":chp_rev_source","c",3,0,358,372,21,0,2,0,337,373,""],[25,"affecte","f",2,0,382,388,4,2,6,2,389,0,""],[26,"champ","f",3,0,390,394,25,1,1,1,395,0,""],[27,"chp_genere_source","c",4,2,397,413,26,0,1,0,395,0,""],[28,":chp_genere_source","c",3,0,419,436,25,0,2,0,395,437,""],[29,"affecte","f",2,0,446,452,4,2,7,2,453,0,""],[30,"champ","f",3,0,454,458,29,1,1,1,459,0,""],[31,"chp_type_source","c",4,2,461,475,30,0,1,0,459,0,""],[32,":chp_type_source","c",3,0,481,496,29,0,2,0,459,497,""],[33,"provenance","f",1,0,508,517,1,1,3,5,518,0,""],[34,"table_reference","f",2,0,526,540,33,1,1,4,541,0,""],[35,"source","f",3,0,552,557,34,1,1,3,558,0,""],[36,"nom_de_la_table","f",4,0,559,573,35,2,1,2,574,0,""],[37,"tbl_sources","c",5,0,575,585,36,0,1,0,0,0,""],[38,"base","f",5,0,589,592,36,1,2,1,593,0,""],[39,"b1","c",6,0,594,595,38,0,1,0,593,596,""]]'),
('55','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chx_cible_dossier`) , :n_chx_cible_dossier) , affecte(champ(`chp_nom_dossier`) , :n_chp_nom_dossier)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_dossier`) , :c_chi_id_dossier) , egal(champ(`chx_cible_dossier`) , :c_chx_cible_dossier))
   )
)','
UPDATE b1.tbl_dossiers SET `chx_cible_dossier` = :n_chx_cible_dossier , `chp_nom_dossier` = :n_chp_nom_dossier
WHERE (`chi_id_dossier` = :c_chi_id_dossier AND `chx_cible_dossier` = :c_chx_cible_dossier) ;','function sql_55($par){
    $texte_sql_55=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_dossiers` SET ''.CRLF;
    $texte_sql_55.=''    `chx_cible_dossier`  = ''.sq0($par[''n_chx_cible_dossier'']).''  , ''.CRLF;
    if($par[''n_chp_nom_dossier'']==='''' || $par[''n_chp_nom_dossier'']===NULL ){
        $texte_sql_55.=''    `chp_nom_dossier`    = NULL    ''.CRLF;
    }else{
        $texte_sql_55.=''    `chp_nom_dossier`    = \''''.sq0($par[''n_chp_nom_dossier'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_dossier` = ''.sq1($par[''c_chi_id_dossier'']).''''.CRLF;
    $where0.='' AND `chx_cible_dossier` = ''.sq1($par[''c_chx_cible_dossier'']).''''.CRLF;
    $texte_sql_55.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_55 = <pre>'' . $texte_sql_55 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_55);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_55()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,2,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chx_cible_dossier","c",4,2,61,77,6,0,1,0,59,0,""],[8,":n_chx_cible_dossier","c",3,0,83,102,5,0,2,0,59,103,""],[9,"affecte","f",2,0,107,113,4,2,2,2,114,0,""],[10,"champ","f",3,0,115,119,9,1,1,1,120,0,""],[11,"chp_nom_dossier","c",4,2,122,136,10,0,1,0,120,0,""],[12,":n_chp_nom_dossier","c",3,0,142,159,9,0,2,0,120,160,""],[13,"provenance","f",1,0,167,176,1,1,3,5,177,0,""],[14,"table_reference","f",2,0,185,199,13,1,1,4,200,0,""],[15,"source","f",3,0,211,216,14,1,1,3,217,0,""],[16,"nom_de_la_table","f",4,0,218,232,15,2,1,2,233,0,""],[17,"tbl_dossiers","c",5,0,234,245,16,0,1,0,0,0,""],[18,"base","f",5,0,249,252,16,1,2,1,253,0,""],[19,"b1","c",6,0,254,255,18,0,1,0,253,256,""],[20,"conditions","f",1,0,277,286,1,1,4,4,287,0,""],[21,"et","f",2,0,295,296,20,2,1,3,297,0,""],[22,"egal","f",3,0,298,301,21,2,1,2,302,0,""],[23,"champ","f",4,0,303,307,22,1,1,1,308,0,""],[24,"chi_id_dossier","c",5,2,310,323,23,0,1,0,308,0,""],[25,":c_chi_id_dossier","c",4,0,329,345,22,0,2,0,308,346,""],[26,"egal","f",3,0,350,353,21,2,2,2,354,0,""],[27,"champ","f",4,0,355,359,26,1,1,1,360,0,""],[28,"chx_cible_dossier","c",5,2,362,378,27,0,1,0,360,0,""],[29,":c_chx_cible_dossier","c",4,0,384,403,26,0,2,0,360,404,""]]'),
('56','1','select','sélectionner(
   base_de_reference(1),
   valeurs(compter(tous_les_champs())),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chx_cible_id_source`) , :T0_chx_cible_id_source) , egal(champ(`T0` , `chx_dossier_id_source`) , :T0_chx_dossier_id_source))
   )
)','SELECT 
count(*)
 FROM b1.tbl_sources T0
WHERE (`T0`.`chx_cible_id_source` = :T0_chx_cible_id_source AND `T0`.`chx_dossier_id_source` = :T0_chx_dossier_id_source);','function sql_56($par){
    $champs0=''
      count(*)
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_source`'',$par[''T0_chx_dossier_id_source'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''0'' => $tab0[0],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','comptage des sources d''un dossier','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,1,2,2,49,0,""],[5,"compter","f",2,0,50,56,4,1,1,1,57,0,""],[6,"tous_les_champs","f",3,0,58,72,5,0,1,0,73,0,""],[7,"provenance","f",1,0,82,91,1,1,3,5,92,0,""],[8,"table_reference","f",2,0,100,114,7,1,1,4,115,0,""],[9,"source","f",3,0,126,131,8,1,1,3,132,0,""],[10,"nom_de_la_table","f",4,0,133,147,9,3,1,2,148,0,""],[11,"tbl_sources","c",5,0,149,159,10,0,1,0,0,0,""],[12,"alias","f",5,0,163,167,10,1,2,1,168,0,""],[13,"T0","c",6,0,169,170,12,0,1,0,168,171,""],[14,"base","f",5,0,175,178,10,1,3,1,179,0,""],[15,"b1","c",6,0,180,181,14,0,1,0,179,182,""],[16,"conditions","f",1,0,203,212,1,1,4,4,213,0,""],[17,"et","f",2,0,221,222,16,2,1,3,223,0,""],[18,"egal","f",3,0,224,227,17,2,1,2,228,0,""],[19,"champ","f",4,0,229,233,18,2,1,1,234,0,""],[20,"T0","c",5,2,236,237,19,0,1,0,234,0,""],[21,"chx_cible_id_source","c",5,2,243,261,19,0,2,0,234,0,""],[22,":T0_chx_cible_id_source","c",4,0,267,289,18,0,2,0,234,290,""],[23,"egal","f",3,0,294,297,17,2,2,2,298,0,""],[24,"champ","f",4,0,299,303,23,2,1,1,304,0,""],[25,"T0","c",5,2,306,307,24,0,1,0,304,0,""],[26,"chx_dossier_id_source","c",5,2,313,333,24,0,2,0,304,0,""],[27,":T0_chx_dossier_id_source","c",4,0,339,363,23,0,2,0,304,364,""]]'),
('57','1','select','sélectionner(
   base_de_reference(1),
   valeurs(compter(tous_les_champs())),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_bdds , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chx_dossier_id_basedd`) , :T0_chx_dossier_id_basedd) , egal(champ(`T0` , `chx_cible_id_basedd`) , :T0_chx_cible_id_basedd))
   )
)','SELECT 
count(*)
 FROM b1.tbl_bdds T0
WHERE (`T0`.`chx_dossier_id_basedd` = :T0_chx_dossier_id_basedd AND `T0`.`chx_cible_id_basedd` = :T0_chx_cible_id_basedd);','function sql_57($par){
    $champs0=''
      count(*)
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_bdds T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_basedd`'',$par[''T0_chx_dossier_id_basedd'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_basedd`'',$par[''T0_chx_cible_id_basedd'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''0'' => $tab0[0],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','comptage des bases rattachées à un dossier','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,1,2,2,49,0,""],[5,"compter","f",2,0,50,56,4,1,1,1,57,0,""],[6,"tous_les_champs","f",3,0,58,72,5,0,1,0,73,0,""],[7,"provenance","f",1,0,82,91,1,1,3,5,92,0,""],[8,"table_reference","f",2,0,100,114,7,1,1,4,115,0,""],[9,"source","f",3,0,126,131,8,1,1,3,132,0,""],[10,"nom_de_la_table","f",4,0,133,147,9,3,1,2,148,0,""],[11,"tbl_bdds","c",5,0,149,156,10,0,1,0,0,0,""],[12,"alias","f",5,0,160,164,10,1,2,1,165,0,""],[13,"T0","c",6,0,166,167,12,0,1,0,165,168,""],[14,"base","f",5,0,172,175,10,1,3,1,176,0,""],[15,"b1","c",6,0,177,178,14,0,1,0,176,179,""],[16,"conditions","f",1,0,200,209,1,1,4,4,210,0,""],[17,"et","f",2,0,218,219,16,2,1,3,220,0,""],[18,"egal","f",3,0,221,224,17,2,1,2,225,0,""],[19,"champ","f",4,0,226,230,18,2,1,1,231,0,""],[20,"T0","c",5,2,233,234,19,0,1,0,231,0,""],[21,"chx_dossier_id_basedd","c",5,2,240,260,19,0,2,0,231,0,""],[22,":T0_chx_dossier_id_basedd","c",4,0,266,290,18,0,2,0,231,291,""],[23,"egal","f",3,0,295,298,17,2,2,2,299,0,""],[24,"champ","f",4,0,300,304,23,2,1,1,305,0,""],[25,"T0","c",5,2,307,308,24,0,1,0,305,0,""],[26,"chx_cible_id_basedd","c",5,2,314,332,24,0,2,0,305,0,""],[27,":T0_chx_cible_id_basedd","c",4,0,338,360,23,0,2,0,305,361,""]]'),
('58','1','delete','supprimer(
   base_de_reference(1),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_dossier`) , :chi_id_dossier) , egal(champ(`chx_cible_dossier`) , :chx_cible_dossier))
   )
)','
DELETE FROM b1.tbl_dossiers
WHERE (`chi_id_dossier` = :chi_id_dossier
   AND `chx_cible_dossier` = :chx_cible_dossier) ;','function sql_58($par){
    $texte_sql_58=''
      
      DELETE FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers
          WHERE (`chi_id_dossier` = ''.sq1($par[''chi_id_dossier'']).'' AND `chx_cible_dossier` = ''.sq1($par[''chx_cible_dossier'']).'') ;
    '';
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_58 = <pre>'' . $texte_sql_58 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_58);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_58()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','dossier par id et cible','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"supprimer","f",0,0,0,8,0,3,1,6,9,0,""],[2,"base_de_reference","f",1,0,14,30,1,1,1,1,31,0,""],[3,"1","c",2,0,32,32,2,0,1,0,31,33,""],[4,"provenance","f",1,0,39,48,1,1,2,5,49,0,""],[5,"table_reference","f",2,0,57,71,4,1,1,4,72,0,""],[6,"source","f",3,0,83,88,5,1,1,3,89,0,""],[7,"nom_de_la_table","f",4,0,90,104,6,2,1,2,105,0,""],[8,"tbl_dossiers","c",5,0,106,117,7,0,1,0,0,0,""],[9,"base","f",5,0,121,124,7,1,2,1,125,0,""],[10,"b1","c",6,0,126,127,9,0,1,0,125,128,""],[11,"conditions","f",1,0,149,158,1,1,3,4,159,0,""],[12,"et","f",2,0,167,168,11,2,1,3,169,0,""],[13,"egal","f",3,0,170,173,12,2,1,2,174,0,""],[14,"champ","f",4,0,175,179,13,1,1,1,180,0,""],[15,"chi_id_dossier","c",5,2,182,195,14,0,1,0,180,0,""],[16,":chi_id_dossier","c",4,0,201,215,13,0,2,0,180,216,""],[17,"egal","f",3,0,220,223,12,2,2,2,224,0,""],[18,"champ","f",4,0,225,229,17,1,1,1,230,0,""],[19,"chx_cible_dossier","c",5,2,232,248,18,0,1,0,230,0,""],[20,":chx_cible_dossier","c",4,0,254,271,17,0,2,0,230,272,""]]'),
('59','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chp_nom_source`) , champ(`T0` , `chi_id_source`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         dans(champ(`T0` , `chp_nom_source`) , (:T0_chp_nom_source)),
         egal(champ(`T0` , `chx_cible_id_source`) , :T0_chx_cible_id_source),
         egal(champ(`T0` , `chx_dossier_id_source`) , :T0_chx_dossier_id_source)
      )
   )
)','SELECT 
`T0`.`chp_nom_source` , `T0`.`chi_id_source`
 FROM b1.tbl_sources T0
WHERE (/*  */ `T0`.`chp_nom_source` IN (:T0_chp_nom_source) AND `T0`.`chx_cible_id_source` = :T0_chx_cible_id_source AND `T0`.`chx_dossier_id_source` = :T0_chx_dossier_id_source);','function sql_59($par){
    $champs0=''
      `T0`.`chp_nom_source` , `T0`.`chi_id_source`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `T0`.`chp_nom_source` IN (''.sq0($par[''T0_chp_nom_source'']).'')''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_source`'',$par[''T0_chx_dossier_id_source'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chp_nom_source'' => $tab0[0],
                ''T0.chi_id_source'' => $tab0[1],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','sources d''un dossier par liste de nom','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,2,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chp_nom_source","c",3,2,64,77,5,0,2,0,55,0,""],[8,"champ","f",2,0,83,87,4,2,2,1,88,0,""],[9,"T0","c",3,2,90,91,8,0,1,0,88,0,""],[10,"chi_id_source","c",3,2,97,109,8,0,2,0,88,0,""],[11,"provenance","f",1,0,118,127,1,1,3,5,128,0,""],[12,"table_reference","f",2,0,136,150,11,1,1,4,151,0,""],[13,"source","f",3,0,162,167,12,1,1,3,168,0,""],[14,"nom_de_la_table","f",4,0,169,183,13,3,1,2,184,0,""],[15,"tbl_sources","c",5,0,185,195,14,0,1,0,0,0,""],[16,"alias","f",5,0,199,203,14,1,2,1,204,0,""],[17,"T0","c",6,0,205,206,16,0,1,0,204,207,""],[18,"base","f",5,0,211,214,14,1,3,1,215,0,""],[19,"b1","c",6,0,216,217,18,0,1,0,215,218,""],[20,"conditions","f",1,0,239,248,1,1,4,4,249,0,""],[21,"et","f",2,0,257,258,20,4,1,3,259,0,""],[22,"#","f",3,0,270,270,21,0,1,0,271,272,""],[23,"dans","f",3,0,284,287,21,2,2,2,288,0,""],[24,"champ","f",4,0,289,293,23,2,1,1,294,0,""],[25,"T0","c",5,2,296,297,24,0,1,0,294,0,""],[26,"chp_nom_source","c",5,2,303,316,24,0,2,0,294,0,""],[27,"","f",4,0,303,316,23,1,2,1,322,0,""],[28,":T0_chp_nom_source","c",5,0,323,340,27,0,1,0,322,341,""],[29,"egal","f",3,0,354,357,21,2,3,2,358,0,""],[30,"champ","f",4,0,359,363,29,2,1,1,364,0,""],[31,"T0","c",5,2,366,367,30,0,1,0,364,0,""],[32,"chx_cible_id_source","c",5,2,373,391,30,0,2,0,364,0,""],[33,":T0_chx_cible_id_source","c",4,0,397,419,29,0,2,0,364,420,""],[34,"egal","f",3,0,432,435,21,2,4,2,436,0,""],[35,"champ","f",4,0,437,441,34,2,1,1,442,0,""],[36,"T0","c",5,2,444,445,35,0,1,0,442,0,""],[37,"chx_dossier_id_source","c",5,2,451,471,35,0,2,0,442,0,""],[38,":T0_chx_dossier_id_source","c",4,0,477,501,34,0,2,0,442,502,""]]'),
('60','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chp_nom_dossier`) , champ(`T0` , `chi_id_dossier`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_dossiers , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(
         #(),
         dans(champ(`T0` , `chp_nom_dossier`) , (:T0_chp_nom_dossier)),
         egal(champ(`T0` , `chx_cible_dossier`) , :T0_chx_cible_dossier)
      )
   )
)','SELECT 
`T0`.`chp_nom_dossier` , `T0`.`chi_id_dossier`
 FROM b1.tbl_dossiers T0
WHERE (/*  */ `T0`.`chp_nom_dossier` IN (:T0_chp_nom_dossier) AND `T0`.`chx_cible_dossier` = :T0_chx_cible_dossier);','function sql_60($par){
    $champs0=''
      `T0`.`chp_nom_dossier` , `T0`.`chi_id_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `T0`.`chp_nom_dossier` IN (''.sq0($par[''T0_chp_nom_dossier'']).'')''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_dossier`'',$par[''T0_chx_cible_dossier'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chp_nom_dossier'' => $tab0[0],
                ''T0.chi_id_dossier'' => $tab0[1],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','dossiers pas liste de noms','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,2,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chp_nom_dossier","c",3,2,64,78,5,0,2,0,55,0,""],[8,"champ","f",2,0,84,88,4,2,2,1,89,0,""],[9,"T0","c",3,2,91,92,8,0,1,0,89,0,""],[10,"chi_id_dossier","c",3,2,98,111,8,0,2,0,89,0,""],[11,"provenance","f",1,0,120,129,1,1,3,5,130,0,""],[12,"table_reference","f",2,0,138,152,11,1,1,4,153,0,""],[13,"source","f",3,0,164,169,12,1,1,3,170,0,""],[14,"nom_de_la_table","f",4,0,171,185,13,3,1,2,186,0,""],[15,"tbl_dossiers","c",5,0,187,198,14,0,1,0,0,0,""],[16,"alias","f",5,0,202,206,14,1,2,1,207,0,""],[17,"T0","c",6,0,208,209,16,0,1,0,207,210,""],[18,"base","f",5,0,214,217,14,1,3,1,218,0,""],[19,"b1","c",6,0,219,220,18,0,1,0,218,221,""],[20,"conditions","f",1,0,242,251,1,1,4,4,252,0,""],[21,"et","f",2,0,260,261,20,3,1,3,262,0,""],[22,"#","f",3,0,273,273,21,0,1,0,274,275,""],[23,"dans","f",3,0,287,290,21,2,2,2,291,0,""],[24,"champ","f",4,0,292,296,23,2,1,1,297,0,""],[25,"T0","c",5,2,299,300,24,0,1,0,297,0,""],[26,"chp_nom_dossier","c",5,2,306,320,24,0,2,0,297,0,""],[27,"","f",4,0,306,320,23,1,2,1,326,0,""],[28,":T0_chp_nom_dossier","c",5,0,327,345,27,0,1,0,326,346,""],[29,"egal","f",3,0,359,362,21,2,3,2,363,0,""],[30,"champ","f",4,0,364,368,29,2,1,1,369,0,""],[31,"T0","c",5,2,371,372,30,0,1,0,369,0,""],[32,"chx_cible_dossier","c",5,2,378,394,30,0,2,0,369,0,""],[33,":T0_chx_cible_dossier","c",4,0,400,420,29,0,2,0,369,421,""]]'),
('61','1','select_liste','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_source`),
      champ(`T0` , `chx_cible_id_source`),
      champ(`T0` , `chp_nom_source`),
      champ(`T0` , `chp_commentaire_source`),
      champ(`T0` , `chx_dossier_id_source`),
      champ(`T0` , `chp_rev_source`),
      champ(`T0` , `chp_genere_source`),
      champ(`T0` , `chp_type_source`),
      champ(`T1` , `chi_id_cible`),
      champ(`T1` , `chp_nom_cible`),
      champ(`T1` , `chp_dossier_cible`),
      champ(`T1` , `chp_commentaire_cible`),
      champ(`T2` , `chi_id_dossier`),
      champ(`T2` , `chx_cible_dossier`),
      champ(`T2` , `chp_nom_dossier`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , alias(T0) , base(b1)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_cibles , alias(T1) , base(b1))),
         contrainte(egal(champ(T1 , chi_id_cible) , champ(T0 , chx_cible_id_source)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_dossiers , alias(T2) , base(b1))),
         contrainte(egal(champ(T2 , chi_id_dossier) , champ(T0 , chx_dossier_id_source)))
      )
   ),
   conditions(
      et(
         egal(champ(`T0` , `chx_cible_id_source`) , :T0_chx_cible_id_source),
         egal(champ(`T0` , `chi_id_source`) , :T0_chi_id_source),
         comme(champ(`T0` , `chp_nom_source`) , :T0_chp_nom_source),
         comme(champ(`T0` , `chp_type_source`) , :T0_chp_type_source),
         comme(champ(`T2` , `chp_nom_dossier`) , :T2_chp_nom_dossier),
         egal(champ(`T0` , `chx_dossier_id_source`) , :T0_chx_dossier_id_source)
      )
   ),
   complements(
      trier_par((champ(`T0` , `chp_nom_source`) , croissant())),
      limité_à(quantité(:quantitee) , début(:debut))
   )
)','SELECT 
`T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
`T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
`T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
 FROM b1.tbl_sources T0
 LEFT JOIN b1.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

 LEFT JOIN b1.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source

WHERE (`T0`.`chx_cible_id_source` = :T0_chx_cible_id_source
   AND `T0`.`chi_id_source` = :T0_chi_id_source
   AND `T0`.`chp_nom_source` LIKE :T0_chp_nom_source
   AND `T0`.`chp_type_source` LIKE :T0_chp_type_source
   AND `T2`.`chp_nom_dossier` LIKE :T2_chp_nom_dossier
   AND `T0`.`chx_dossier_id_source` = :T0_chx_dossier_id_source) 
ORDER BY `T0`.`chp_nom_source` ASC  
LIMIT :quantitee OFFSET :debut ;','function sql_61($par){
    $champs0=''
      `T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
      `T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
      `T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    if(($par[''T0_chx_cible_id_source''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    }
    if(($par[''T0_chi_id_source''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_source`'',$par[''T0_chi_id_source'']);
    }
    if(($par[''T0_chp_nom_source''] !== '''')){
        $where0.='' AND `T0`.`chp_nom_source` LIKE ''.sq1($par[''T0_chp_nom_source'']).''''.CRLF;
    }
    if(($par[''T0_chp_type_source''] !== '''')){
        $where0.='' AND `T0`.`chp_type_source` LIKE ''.sq1($par[''T0_chp_type_source'']).''''.CRLF;
    }
    if(($par[''T2_chp_nom_dossier''] !== '''')){
        $where0.='' AND `T2`.`chp_nom_dossier` LIKE ''.sq1($par[''T2_chp_nom_dossier'']).''''.CRLF;
    }
    if(($par[''T0_chx_dossier_id_source''] !== '''')){
        $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_dossier_id_source`'',$par[''T0_chx_dossier_id_source'']);
    }
    $sql0.=$where0;
    $order0=''
       ORDER BY  `T0`.`chp_nom_source` ASC'';
    $sql0.=$order0;
    $plage0=''
        LIMIT ''.sq1($par[''quantitee'']).'' OFFSET ''.sq1($par[''debut'']).'' '';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' . $sql0 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_source'' => $tab0[0],
                ''T0.chx_cible_id_source'' => $tab0[1],
                ''T0.chp_nom_source'' => $tab0[2],
                ''T0.chp_commentaire_source'' => $tab0[3],
                ''T0.chx_dossier_id_source'' => $tab0[4],
                ''T0.chp_rev_source'' => $tab0[5],
                ''T0.chp_genere_source'' => $tab0[6],
                ''T0.chp_type_source'' => $tab0[7],
                ''T1.chi_id_cible'' => $tab0[8],
                ''T1.chp_nom_cible'' => $tab0[9],
                ''T1.chp_dossier_cible'' => $tab0[10],
                ''T1.chp_commentaire_cible'' => $tab0[11],
                ''T2.chi_id_dossier'' => $tab0[12],
                ''T2.chx_cible_dossier'' => $tab0[13],
                ''T2.chp_nom_dossier'' => $tab0[14],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par[''quantitee''] || $_SESSION[APP_KEY][''__filtres''][$par[''page_courante'']][''champs''][''__xpage''] > 0)){
            $sql1=''SELECT COUNT(*) ''.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''nombre''  => $__nbEnregs ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         ''sql0''    => $sql0,
         ''where0''  => $where0     ,
        );
    }
}
','sources','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,15,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_source","c",3,2,71,83,5,0,2,0,62,0,""],[8,"champ","f",2,0,94,98,4,2,2,1,99,0,""],[9,"T0","c",3,2,101,102,8,0,1,0,99,0,""],[10,"chx_cible_id_source","c",3,2,108,126,8,0,2,0,99,0,""],[11,"champ","f",2,0,137,141,4,2,3,1,142,0,""],[12,"T0","c",3,2,144,145,11,0,1,0,142,0,""],[13,"chp_nom_source","c",3,2,151,164,11,0,2,0,142,0,""],[14,"champ","f",2,0,175,179,4,2,4,1,180,0,""],[15,"T0","c",3,2,182,183,14,0,1,0,180,0,""],[16,"chp_commentaire_source","c",3,2,189,210,14,0,2,0,180,0,""],[17,"champ","f",2,0,221,225,4,2,5,1,226,0,""],[18,"T0","c",3,2,228,229,17,0,1,0,226,0,""],[19,"chx_dossier_id_source","c",3,2,235,255,17,0,2,0,226,0,""],[20,"champ","f",2,0,266,270,4,2,6,1,271,0,""],[21,"T0","c",3,2,273,274,20,0,1,0,271,0,""],[22,"chp_rev_source","c",3,2,280,293,20,0,2,0,271,0,""],[23,"champ","f",2,0,304,308,4,2,7,1,309,0,""],[24,"T0","c",3,2,311,312,23,0,1,0,309,0,""],[25,"chp_genere_source","c",3,2,318,334,23,0,2,0,309,0,""],[26,"champ","f",2,0,345,349,4,2,8,1,350,0,""],[27,"T0","c",3,2,352,353,26,0,1,0,350,0,""],[28,"chp_type_source","c",3,2,359,373,26,0,2,0,350,0,""],[29,"champ","f",2,0,384,388,4,2,9,1,389,0,""],[30,"T1","c",3,2,391,392,29,0,1,0,389,0,""],[31,"chi_id_cible","c",3,2,398,409,29,0,2,0,389,0,""],[32,"champ","f",2,0,420,424,4,2,10,1,425,0,""],[33,"T1","c",3,2,427,428,32,0,1,0,425,0,""],[34,"chp_nom_cible","c",3,2,434,446,32,0,2,0,425,0,""],[35,"champ","f",2,0,457,461,4,2,11,1,462,0,""],[36,"T1","c",3,2,464,465,35,0,1,0,462,0,""],[37,"chp_dossier_cible","c",3,2,471,487,35,0,2,0,462,0,""],[38,"champ","f",2,0,498,502,4,2,12,1,503,0,""],[39,"T1","c",3,2,505,506,38,0,1,0,503,0,""],[40,"chp_commentaire_cible","c",3,2,512,532,38,0,2,0,503,0,""],[41,"champ","f",2,0,543,547,4,2,13,1,548,0,""],[42,"T2","c",3,2,550,551,41,0,1,0,548,0,""],[43,"chi_id_dossier","c",3,2,557,570,41,0,2,0,548,0,""],[44,"champ","f",2,0,581,585,4,2,14,1,586,0,""],[45,"T2","c",3,2,588,589,44,0,1,0,586,0,""],[46,"chx_cible_dossier","c",3,2,595,611,44,0,2,0,586,0,""],[47,"champ","f",2,0,622,626,4,2,15,1,627,0,""],[48,"T2","c",3,2,629,630,47,0,1,0,627,0,""],[49,"chp_nom_dossier","c",3,2,636,650,47,0,2,0,627,0,""],[50,"provenance","f",1,0,663,672,1,3,3,5,673,0,""],[51,"table_reference","f",2,0,681,695,50,1,1,4,696,0,""],[52,"source","f",3,0,707,712,51,1,1,3,713,0,""],[53,"nom_de_la_table","f",4,0,714,728,52,3,1,2,729,0,""],[54,"tbl_sources","c",5,0,730,740,53,0,1,0,0,0,""],[55,"alias","f",5,0,744,748,53,1,2,1,749,0,""],[56,"T0","c",6,0,750,751,55,0,1,0,749,752,""],[57,"base","f",5,0,756,759,53,1,3,1,760,0,""],[58,"b1","c",6,0,761,762,57,0,1,0,760,763,""],[59,"jointure_gauche","f",2,0,782,796,50,2,2,4,797,0,""],[60,"source","f",3,0,808,813,59,1,1,3,814,0,""],[61,"nom_de_la_table","f",4,0,815,829,60,3,1,2,830,0,""],[62,"tbl_cibles","c",5,0,831,840,61,0,1,0,0,0,""],[63,"alias","f",5,0,844,848,61,1,2,1,849,0,""],[64,"T1","c",6,0,850,851,63,0,1,0,849,852,""],[65,"base","f",5,0,856,859,61,1,3,1,860,0,""],[66,"b1","c",6,0,861,862,65,0,1,0,860,863,""],[67,"contrainte","f",3,0,877,886,59,1,2,3,887,0,""],[68,"egal","f",4,0,888,891,67,2,1,2,892,0,""],[69,"champ","f",5,0,893,897,68,2,1,1,898,0,""],[70,"T1","c",6,0,899,900,69,0,1,0,0,0,""],[71,"chi_id_cible","c",6,0,904,915,69,0,2,0,898,916,""],[72,"champ","f",5,0,920,924,68,2,2,1,925,0,""],[73,"T0","c",6,0,926,927,72,0,1,0,0,0,""],[74,"chx_cible_id_source","c",6,0,931,949,72,0,2,0,925,950,""],[75,"jointure_gauche","f",2,0,969,983,50,2,3,4,984,0,""],[76,"source","f",3,0,995,1000,75,1,1,3,1001,0,""],[77,"nom_de_la_table","f",4,0,1002,1016,76,3,1,2,1017,0,""],[78,"tbl_dossiers","c",5,0,1018,1029,77,0,1,0,0,0,""],[79,"alias","f",5,0,1033,1037,77,1,2,1,1038,0,""],[80,"T2","c",6,0,1039,1040,79,0,1,0,1038,1041,""],[81,"base","f",5,0,1045,1048,77,1,3,1,1049,0,""],[82,"b1","c",6,0,1050,1051,81,0,1,0,1049,1052,""],[83,"contrainte","f",3,0,1066,1075,75,1,2,3,1076,0,""],[84,"egal","f",4,0,1077,1080,83,2,1,2,1081,0,""],[85,"champ","f",5,0,1082,1086,84,2,1,1,1087,0,""],[86,"T2","c",6,0,1088,1089,85,0,1,0,0,0,""],[87,"chi_id_dossier","c",6,0,1093,1106,85,0,2,0,1087,1107,""],[88,"champ","f",5,0,1111,1115,84,2,2,1,1116,0,""],[89,"T0","c",6,0,1117,1118,88,0,1,0,0,0,""],[90,"chx_dossier_id_source","c",6,0,1122,1142,88,0,2,0,1116,1143,""],[91,"conditions","f",1,0,1164,1173,1,1,4,4,1174,0,""],[92,"et","f",2,0,1182,1183,91,6,1,3,1184,0,""],[93,"egal","f",3,0,1195,1198,92,2,1,2,1199,0,""],[94,"champ","f",4,0,1200,1204,93,2,1,1,1205,0,""],[95,"T0","c",5,2,1207,1208,94,0,1,0,1205,0,""],[96,"chx_cible_id_source","c",5,2,1214,1232,94,0,2,0,1205,0,""],[97,":T0_chx_cible_id_source","c",4,0,1238,1260,93,0,2,0,1205,1261,""],[98,"egal","f",3,0,1273,1276,92,2,2,2,1277,0,""],[99,"champ","f",4,0,1278,1282,98,2,1,1,1283,0,""],[100,"T0","c",5,2,1285,1286,99,0,1,0,1283,0,""],[101,"chi_id_source","c",5,2,1292,1304,99,0,2,0,1283,0,""],[102,":T0_chi_id_source","c",4,0,1310,1326,98,0,2,0,1283,1327,""],[103,"comme","f",3,0,1339,1343,92,2,3,2,1344,0,""],[104,"champ","f",4,0,1345,1349,103,2,1,1,1350,0,""],[105,"T0","c",5,2,1352,1353,104,0,1,0,1350,0,""],[106,"chp_nom_source","c",5,2,1359,1372,104,0,2,0,1350,0,""],[107,":T0_chp_nom_source","c",4,0,1378,1395,103,0,2,0,1350,1396,""],[108,"comme","f",3,0,1408,1412,92,2,4,2,1413,0,""],[109,"champ","f",4,0,1414,1418,108,2,1,1,1419,0,""],[110,"T0","c",5,2,1421,1422,109,0,1,0,1419,0,""],[111,"chp_type_source","c",5,2,1428,1442,109,0,2,0,1419,0,""],[112,":T0_chp_type_source","c",4,0,1448,1466,108,0,2,0,1419,1467,""],[113,"comme","f",3,0,1479,1483,92,2,5,2,1484,0,""],[114,"champ","f",4,0,1485,1489,113,2,1,1,1490,0,""],[115,"T2","c",5,2,1492,1493,114,0,1,0,1490,0,""],[116,"chp_nom_dossier","c",5,2,1499,1513,114,0,2,0,1490,0,""],[117,":T2_chp_nom_dossier","c",4,0,1519,1537,113,0,2,0,1490,1538,""],[118,"egal","f",3,0,1550,1553,92,2,6,2,1554,0,""],[119,"champ","f",4,0,1555,1559,118,2,1,1,1560,0,""],[120,"T0","c",5,2,1562,1563,119,0,1,0,1560,0,""],[121,"chx_dossier_id_source","c",5,2,1569,1589,119,0,2,0,1560,0,""],[122,":T0_chx_dossier_id_source","c",4,0,1595,1619,118,0,2,0,1560,1620,""],[123,"complements","f",1,0,1639,1649,1,2,5,4,1650,0,""],[124,"trier_par","f",2,0,1658,1666,123,1,1,3,1667,0,""],[125,"","f",3,0,1658,1666,124,2,1,2,1668,0,""],[126,"champ","f",4,0,1669,1673,125,2,1,1,1674,0,""],[127,"T0","c",5,2,1676,1677,126,0,1,0,1674,0,""],[128,"chp_nom_source","c",5,2,1683,1696,126,0,2,0,1674,0,""],[129,"croissant","f",4,0,1702,1710,125,0,2,0,1711,0,""],[130,"limit\u00e9_\u00e0","f",2,0,1723,1730,123,2,2,2,1731,0,""],[131,"quantit\u00e9","f",3,0,1732,1739,130,1,1,1,1740,0,""],[132,":quantitee","c",4,0,1741,1750,131,0,1,0,1740,1751,""],[133,"d\u00e9but","f",3,0,1755,1759,130,1,2,1,1760,0,""],[134,":debut","c",4,0,1761,1766,133,0,1,0,1760,1767,""]]'),
('62','1','select','sélectionner(
   base_de_reference(1),
   valeurs(
      champ(`T0` , `chi_id_source`),
      champ(`T0` , `chx_cible_id_source`),
      champ(`T0` , `chp_nom_source`),
      champ(`T0` , `chp_commentaire_source`),
      champ(`T0` , `chx_dossier_id_source`),
      champ(`T0` , `chp_rev_source`),
      champ(`T0` , `chp_genere_source`),
      champ(`T0` , `chp_type_source`),
      champ(`T1` , `chi_id_cible`),
      champ(`T1` , `chp_nom_cible`),
      champ(`T1` , `chp_dossier_cible`),
      champ(`T1` , `chp_commentaire_cible`),
      champ(`T2` , `chi_id_dossier`),
      champ(`T2` , `chx_cible_dossier`),
      champ(`T2` , `chp_nom_dossier`)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , alias(T0) , base(b1)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_cibles , alias(T1) , base(b1))),
         contrainte(egal(champ(T1 , chi_id_cible) , champ(T0 , chx_cible_id_source)))
      ),
      jointure_gauche(
         source(nom_de_la_table(tbl_dossiers , alias(T2) , base(b1))),
         contrainte(egal(champ(T2 , chi_id_dossier) , champ(T0 , chx_dossier_id_source)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chi_id_source`) , :T0_chi_id_source) , egal(champ(`T0` , `chx_cible_id_source`) , :T0_chx_cible_id_source))
   )
)','SELECT 
`T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
`T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
`T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
 FROM b1.tbl_sources T0
 LEFT JOIN b1.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

 LEFT JOIN b1.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source

WHERE (`T0`.`chi_id_source` = :T0_chi_id_source AND `T0`.`chx_cible_id_source` = :T0_chx_cible_id_source);','function sql_62($par){
    $champs0=''
      `T0`.`chi_id_source` , `T0`.`chx_cible_id_source` , `T0`.`chp_nom_source` , `T0`.`chp_commentaire_source` , `T0`.`chx_dossier_id_source` , 
      `T0`.`chp_rev_source` , `T0`.`chp_genere_source` , `T0`.`chp_type_source` , `T1`.`chi_id_cible` , `T1`.`chp_nom_cible` , 
      `T1`.`chp_dossier_cible` , `T1`.`chp_commentaire_cible` , `T2`.`chi_id_dossier` , `T2`.`chx_cible_dossier` , `T2`.`chp_nom_dossier`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_sources T0
       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_cibles T1 ON T1.chi_id_cible = T0.chx_cible_id_source

       LEFT JOIN `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_dossiers T2 ON T2.chi_id_dossier = T0.chx_dossier_id_source
    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chi_id_source`'',$par[''T0_chi_id_source'']);
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_cible_id_source`'',$par[''T0_chx_cible_id_source'']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_source'' => $tab0[0],
                ''T0.chx_cible_id_source'' => $tab0[1],
                ''T0.chp_nom_source'' => $tab0[2],
                ''T0.chp_commentaire_source'' => $tab0[3],
                ''T0.chx_dossier_id_source'' => $tab0[4],
                ''T0.chp_rev_source'' => $tab0[5],
                ''T0.chp_genere_source'' => $tab0[6],
                ''T0.chp_type_source'' => $tab0[7],
                ''T1.chi_id_cible'' => $tab0[8],
                ''T1.chp_nom_cible'' => $tab0[9],
                ''T1.chp_dossier_cible'' => $tab0[10],
                ''T1.chp_commentaire_cible'' => $tab0[11],
                ''T2.chi_id_dossier'' => $tab0[12],
                ''T2.chx_cible_dossier'' => $tab0[13],
                ''T2.chp_nom_dossier'' => $tab0[14],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,4,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,15,2,2,49,0,""],[5,"champ","f",2,0,57,61,4,2,1,1,62,0,""],[6,"T0","c",3,2,64,65,5,0,1,0,62,0,""],[7,"chi_id_source","c",3,2,71,83,5,0,2,0,62,0,""],[8,"champ","f",2,0,94,98,4,2,2,1,99,0,""],[9,"T0","c",3,2,101,102,8,0,1,0,99,0,""],[10,"chx_cible_id_source","c",3,2,108,126,8,0,2,0,99,0,""],[11,"champ","f",2,0,137,141,4,2,3,1,142,0,""],[12,"T0","c",3,2,144,145,11,0,1,0,142,0,""],[13,"chp_nom_source","c",3,2,151,164,11,0,2,0,142,0,""],[14,"champ","f",2,0,175,179,4,2,4,1,180,0,""],[15,"T0","c",3,2,182,183,14,0,1,0,180,0,""],[16,"chp_commentaire_source","c",3,2,189,210,14,0,2,0,180,0,""],[17,"champ","f",2,0,221,225,4,2,5,1,226,0,""],[18,"T0","c",3,2,228,229,17,0,1,0,226,0,""],[19,"chx_dossier_id_source","c",3,2,235,255,17,0,2,0,226,0,""],[20,"champ","f",2,0,266,270,4,2,6,1,271,0,""],[21,"T0","c",3,2,273,274,20,0,1,0,271,0,""],[22,"chp_rev_source","c",3,2,280,293,20,0,2,0,271,0,""],[23,"champ","f",2,0,304,308,4,2,7,1,309,0,""],[24,"T0","c",3,2,311,312,23,0,1,0,309,0,""],[25,"chp_genere_source","c",3,2,318,334,23,0,2,0,309,0,""],[26,"champ","f",2,0,345,349,4,2,8,1,350,0,""],[27,"T0","c",3,2,352,353,26,0,1,0,350,0,""],[28,"chp_type_source","c",3,2,359,373,26,0,2,0,350,0,""],[29,"champ","f",2,0,384,388,4,2,9,1,389,0,""],[30,"T1","c",3,2,391,392,29,0,1,0,389,0,""],[31,"chi_id_cible","c",3,2,398,409,29,0,2,0,389,0,""],[32,"champ","f",2,0,420,424,4,2,10,1,425,0,""],[33,"T1","c",3,2,427,428,32,0,1,0,425,0,""],[34,"chp_nom_cible","c",3,2,434,446,32,0,2,0,425,0,""],[35,"champ","f",2,0,457,461,4,2,11,1,462,0,""],[36,"T1","c",3,2,464,465,35,0,1,0,462,0,""],[37,"chp_dossier_cible","c",3,2,471,487,35,0,2,0,462,0,""],[38,"champ","f",2,0,498,502,4,2,12,1,503,0,""],[39,"T1","c",3,2,505,506,38,0,1,0,503,0,""],[40,"chp_commentaire_cible","c",3,2,512,532,38,0,2,0,503,0,""],[41,"champ","f",2,0,543,547,4,2,13,1,548,0,""],[42,"T2","c",3,2,550,551,41,0,1,0,548,0,""],[43,"chi_id_dossier","c",3,2,557,570,41,0,2,0,548,0,""],[44,"champ","f",2,0,581,585,4,2,14,1,586,0,""],[45,"T2","c",3,2,588,589,44,0,1,0,586,0,""],[46,"chx_cible_dossier","c",3,2,595,611,44,0,2,0,586,0,""],[47,"champ","f",2,0,622,626,4,2,15,1,627,0,""],[48,"T2","c",3,2,629,630,47,0,1,0,627,0,""],[49,"chp_nom_dossier","c",3,2,636,650,47,0,2,0,627,0,""],[50,"provenance","f",1,0,663,672,1,3,3,5,673,0,""],[51,"table_reference","f",2,0,681,695,50,1,1,4,696,0,""],[52,"source","f",3,0,707,712,51,1,1,3,713,0,""],[53,"nom_de_la_table","f",4,0,714,728,52,3,1,2,729,0,""],[54,"tbl_sources","c",5,0,730,740,53,0,1,0,0,0,""],[55,"alias","f",5,0,744,748,53,1,2,1,749,0,""],[56,"T0","c",6,0,750,751,55,0,1,0,749,752,""],[57,"base","f",5,0,756,759,53,1,3,1,760,0,""],[58,"b1","c",6,0,761,762,57,0,1,0,760,763,""],[59,"jointure_gauche","f",2,0,782,796,50,2,2,4,797,0,""],[60,"source","f",3,0,808,813,59,1,1,3,814,0,""],[61,"nom_de_la_table","f",4,0,815,829,60,3,1,2,830,0,""],[62,"tbl_cibles","c",5,0,831,840,61,0,1,0,0,0,""],[63,"alias","f",5,0,844,848,61,1,2,1,849,0,""],[64,"T1","c",6,0,850,851,63,0,1,0,849,852,""],[65,"base","f",5,0,856,859,61,1,3,1,860,0,""],[66,"b1","c",6,0,861,862,65,0,1,0,860,863,""],[67,"contrainte","f",3,0,877,886,59,1,2,3,887,0,""],[68,"egal","f",4,0,888,891,67,2,1,2,892,0,""],[69,"champ","f",5,0,893,897,68,2,1,1,898,0,""],[70,"T1","c",6,0,899,900,69,0,1,0,0,0,""],[71,"chi_id_cible","c",6,0,904,915,69,0,2,0,898,916,""],[72,"champ","f",5,0,920,924,68,2,2,1,925,0,""],[73,"T0","c",6,0,926,927,72,0,1,0,0,0,""],[74,"chx_cible_id_source","c",6,0,931,949,72,0,2,0,925,950,""],[75,"jointure_gauche","f",2,0,969,983,50,2,3,4,984,0,""],[76,"source","f",3,0,995,1000,75,1,1,3,1001,0,""],[77,"nom_de_la_table","f",4,0,1002,1016,76,3,1,2,1017,0,""],[78,"tbl_dossiers","c",5,0,1018,1029,77,0,1,0,0,0,""],[79,"alias","f",5,0,1033,1037,77,1,2,1,1038,0,""],[80,"T2","c",6,0,1039,1040,79,0,1,0,1038,1041,""],[81,"base","f",5,0,1045,1048,77,1,3,1,1049,0,""],[82,"b1","c",6,0,1050,1051,81,0,1,0,1049,1052,""],[83,"contrainte","f",3,0,1066,1075,75,1,2,3,1076,0,""],[84,"egal","f",4,0,1077,1080,83,2,1,2,1081,0,""],[85,"champ","f",5,0,1082,1086,84,2,1,1,1087,0,""],[86,"T2","c",6,0,1088,1089,85,0,1,0,0,0,""],[87,"chi_id_dossier","c",6,0,1093,1106,85,0,2,0,1087,1107,""],[88,"champ","f",5,0,1111,1115,84,2,2,1,1116,0,""],[89,"T0","c",6,0,1117,1118,88,0,1,0,0,0,""],[90,"chx_dossier_id_source","c",6,0,1122,1142,88,0,2,0,1116,1143,""],[91,"conditions","f",1,0,1164,1173,1,1,4,4,1174,0,""],[92,"et","f",2,0,1182,1183,91,2,1,3,1184,0,""],[93,"egal","f",3,0,1185,1188,92,2,1,2,1189,0,""],[94,"champ","f",4,0,1190,1194,93,2,1,1,1195,0,""],[95,"T0","c",5,2,1197,1198,94,0,1,0,1195,0,""],[96,"chi_id_source","c",5,2,1204,1216,94,0,2,0,1195,0,""],[97,":T0_chi_id_source","c",4,0,1222,1238,93,0,2,0,1195,1239,""],[98,"egal","f",3,0,1243,1246,92,2,2,2,1247,0,""],[99,"champ","f",4,0,1248,1252,98,2,1,1,1253,0,""],[100,"T0","c",5,2,1255,1256,99,0,1,0,1253,0,""],[101,"chx_cible_id_source","c",5,2,1262,1280,99,0,2,0,1253,0,""],[102,":T0_chx_cible_id_source","c",4,0,1286,1308,98,0,2,0,1253,1309,""]]'),
('63','1','update','modifier(
   base_de_reference(1),
   valeurs(
      affecte(champ(`chp_nom_source`) , :n_chp_nom_source),
      affecte(champ(`chp_commentaire_source`) , :n_chp_commentaire_source),
      affecte(champ(`chx_dossier_id_source`) , :n_chx_dossier_id_source),
      affecte(champ(`chp_rev_source`) , :n_chp_rev_source),
      affecte(champ(`chp_genere_source`) , :n_chp_genere_source),
      affecte(champ(`chp_type_source`) , :n_chp_type_source)
   ),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_sources , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_source`) , :c_chi_id_source) , egal(champ(`chx_cible_id_source`) , :c_chx_cible_id_source))
   )
)','
UPDATE b1.tbl_sources SET `chp_nom_source` = :n_chp_nom_source , `chp_commentaire_source` = :n_chp_commentaire_source , `chx_dossier_id_source` = :n_chx_dossier_id_source , `chp_rev_source` = :n_chp_rev_source , `chp_genere_source` = :n_chp_genere_source , `chp_type_source` = :n_chp_type_source
WHERE (`chi_id_source` = :c_chi_id_source AND `chx_cible_id_source` = :c_chx_cible_id_source) ;','function sql_63($par){
    $texte_sql_63=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_sources` SET ''.CRLF;
    $texte_sql_63.=''    `chp_nom_source`          = \''''.sq0($par[''n_chp_nom_source'']).''\''          , ''.CRLF;
    if($par[''n_chp_commentaire_source'']==='''' || $par[''n_chp_commentaire_source'']===NULL ){
        $texte_sql_63.=''    `chp_commentaire_source`  = NULL  , ''.CRLF;
    }else{
        $texte_sql_63.=''    `chp_commentaire_source`  = \''''.sq0($par[''n_chp_commentaire_source'']).''\'' , ''.CRLF;
    }
    if($par[''n_chx_dossier_id_source'']==='''' || $par[''n_chx_dossier_id_source'']===NULL ){
        $texte_sql_63.=''    `chx_dossier_id_source`   = NULL   , ''.CRLF;
    }else{
        $texte_sql_63.=''    `chx_dossier_id_source`   = ''.sq0($par[''n_chx_dossier_id_source'']).'' , ''.CRLF;
    }
    if($par[''n_chp_rev_source'']==='''' || $par[''n_chp_rev_source'']===NULL ){
        $texte_sql_63.=''    `chp_rev_source`          = NULL          , ''.CRLF;
    }else{
        $texte_sql_63.=''    `chp_rev_source`          = \''''.sq0($par[''n_chp_rev_source'']).''\'' , ''.CRLF;
    }
    if($par[''n_chp_genere_source'']==='''' || $par[''n_chp_genere_source'']===NULL ){
        $texte_sql_63.=''    `chp_genere_source`       = NULL       , ''.CRLF;
    }else{
        $texte_sql_63.=''    `chp_genere_source`       = \''''.sq0($par[''n_chp_genere_source'']).''\'' , ''.CRLF;
    }
    $texte_sql_63.=''    `chp_type_source`         = \''''.sq0($par[''n_chp_type_source'']).''\''         ''.CRLF;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_source` = ''.sq1($par[''c_chi_id_source'']).''''.CRLF;
    $where0.='' AND `chx_cible_id_source` = ''.sq1($par[''c_chx_cible_id_source'']).''''.CRLF;
    $texte_sql_63.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_63 = <pre>'' . $texte_sql_63 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_63);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_63()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
',NULL,'[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,6,2,3,45,0,""],[5,"affecte","f",2,0,53,59,4,2,1,2,60,0,""],[6,"champ","f",3,0,61,65,5,1,1,1,66,0,""],[7,"chp_nom_source","c",4,2,68,81,6,0,1,0,66,0,""],[8,":n_chp_nom_source","c",3,0,87,103,5,0,2,0,66,104,""],[9,"affecte","f",2,0,113,119,4,2,2,2,120,0,""],[10,"champ","f",3,0,121,125,9,1,1,1,126,0,""],[11,"chp_commentaire_source","c",4,2,128,149,10,0,1,0,126,0,""],[12,":n_chp_commentaire_source","c",3,0,155,179,9,0,2,0,126,180,""],[13,"affecte","f",2,0,189,195,4,2,3,2,196,0,""],[14,"champ","f",3,0,197,201,13,1,1,1,202,0,""],[15,"chx_dossier_id_source","c",4,2,204,224,14,0,1,0,202,0,""],[16,":n_chx_dossier_id_source","c",3,0,230,253,13,0,2,0,202,254,""],[17,"affecte","f",2,0,263,269,4,2,4,2,270,0,""],[18,"champ","f",3,0,271,275,17,1,1,1,276,0,""],[19,"chp_rev_source","c",4,2,278,291,18,0,1,0,276,0,""],[20,":n_chp_rev_source","c",3,0,297,313,17,0,2,0,276,314,""],[21,"affecte","f",2,0,323,329,4,2,5,2,330,0,""],[22,"champ","f",3,0,331,335,21,1,1,1,336,0,""],[23,"chp_genere_source","c",4,2,338,354,22,0,1,0,336,0,""],[24,":n_chp_genere_source","c",3,0,360,379,21,0,2,0,336,380,""],[25,"affecte","f",2,0,389,395,4,2,6,2,396,0,""],[26,"champ","f",3,0,397,401,25,1,1,1,402,0,""],[27,"chp_type_source","c",4,2,404,418,26,0,1,0,402,0,""],[28,":n_chp_type_source","c",3,0,424,441,25,0,2,0,402,442,""],[29,"provenance","f",1,0,453,462,1,1,3,5,463,0,""],[30,"table_reference","f",2,0,471,485,29,1,1,4,486,0,""],[31,"source","f",3,0,497,502,30,1,1,3,503,0,""],[32,"nom_de_la_table","f",4,0,504,518,31,2,1,2,519,0,""],[33,"tbl_sources","c",5,0,520,530,32,0,1,0,0,0,""],[34,"base","f",5,0,534,537,32,1,2,1,538,0,""],[35,"b1","c",6,0,539,540,34,0,1,0,538,541,""],[36,"conditions","f",1,0,562,571,1,1,4,4,572,0,""],[37,"et","f",2,0,580,581,36,2,1,3,582,0,""],[38,"egal","f",3,0,583,586,37,2,1,2,587,0,""],[39,"champ","f",4,0,588,592,38,1,1,1,593,0,""],[40,"chi_id_source","c",5,2,595,607,39,0,1,0,593,0,""],[41,":c_chi_id_source","c",4,0,613,628,38,0,2,0,593,629,""],[42,"egal","f",3,0,633,636,37,2,2,2,637,0,""],[43,"champ","f",4,0,638,642,42,1,1,1,643,0,""],[44,"chx_cible_id_source","c",5,2,645,663,43,0,1,0,643,0,""],[45,":c_chx_cible_id_source","c",4,0,669,690,42,0,2,0,643,691,""]]'),
('64','1','select','sélectionner(
   base_de_reference(1),
   valeurs(champ(`T0` , `chi_id_tache`) , champ(`T0` , `chx_utilisateur_tache`) , champ(`T0` , `chp_texte_tache`) , champ(`T0` , `chp_priorite_tache`)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , alias(T0) , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`T0` , `chx_utilisateur_tache`) , :T0_chx_utilisateur_tache) , inf(champ(`T0` , `chp_priorite_tache`) , :T0_chp_priorite_tache))
   ),
   complements(
      trier_par((champ(`T0` , `chp_priorite_tache`) , croissant()))
   )
)','SELECT 
`T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
 FROM b1.tbl_taches T0
WHERE (`T0`.`chx_utilisateur_tache` = :T0_chx_utilisateur_tache
   AND `T0`.`chp_priorite_tache` < :T0_chp_priorite_tache);','function sql_64($par){
    $champs0=''
      `T0`.`chi_id_tache` , `T0`.`chx_utilisateur_tache` , `T0`.`chp_texte_tache` , `T0`.`chp_priorite_tache`
    '';
    $sql0=''SELECT ''.$champs0;
    $from0=''
      FROM `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.tbl_taches T0    '';
    $sql0.=$from0;
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id(''`T0`.`chx_utilisateur_tache`'',$par[''T0_chx_utilisateur_tache'']);
    $where0.='' AND `T0`.`chp_priorite_tache` < ''.sq1($par[''T0_chp_priorite_tache'']).''''.CRLF;
    $sql0.=$where0;
    $order0='''';
    $sql0.=$order0;
    /* ATTENTION : pas de limites */
    $plage0='''';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . '' '' . __LINE__ . '' $sql0 = <pre>'' .  $sql0  . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                ''T0.chi_id_tache'' => $tab0[0],
                ''T0.chx_utilisateur_tache'' => $tab0[1],
                ''T0.chp_texte_tache'' => $tab0[2],
                ''T0.chp_priorite_tache'' => $tab0[3],
            );
        }
        return array(
           __xst  => true       ,
           ''valeur''  => $donnees0   ,
           ''sql0''    => $sql0          ,
           ''where0''  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           ''sql0''    => $sql0,
           ''where0''  => $where0     ,
        );
    }
}
','priorité tache < ?','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"s\u00e9lectionner","f",0,0,0,11,0,5,1,6,12,0,""],[2,"base_de_reference","f",1,0,17,33,1,1,1,1,34,0,""],[3,"1","c",2,0,35,35,2,0,1,0,34,36,""],[4,"valeurs","f",1,0,42,48,1,4,2,2,49,0,""],[5,"champ","f",2,0,50,54,4,2,1,1,55,0,""],[6,"T0","c",3,2,57,58,5,0,1,0,55,0,""],[7,"chi_id_tache","c",3,2,64,75,5,0,2,0,55,0,""],[8,"champ","f",2,0,81,85,4,2,2,1,86,0,""],[9,"T0","c",3,2,88,89,8,0,1,0,86,0,""],[10,"chx_utilisateur_tache","c",3,2,95,115,8,0,2,0,86,0,""],[11,"champ","f",2,0,121,125,4,2,3,1,126,0,""],[12,"T0","c",3,2,128,129,11,0,1,0,126,0,""],[13,"chp_texte_tache","c",3,2,135,149,11,0,2,0,126,0,""],[14,"champ","f",2,0,155,159,4,2,4,1,160,0,""],[15,"T0","c",3,2,162,163,14,0,1,0,160,0,""],[16,"chp_priorite_tache","c",3,2,169,186,14,0,2,0,160,0,""],[17,"provenance","f",1,0,195,204,1,1,3,5,205,0,""],[18,"table_reference","f",2,0,213,227,17,1,1,4,228,0,""],[19,"source","f",3,0,239,244,18,1,1,3,245,0,""],[20,"nom_de_la_table","f",4,0,246,260,19,3,1,2,261,0,""],[21,"tbl_taches","c",5,0,262,271,20,0,1,0,0,0,""],[22,"alias","f",5,0,275,279,20,1,2,1,280,0,""],[23,"T0","c",6,0,281,282,22,0,1,0,280,283,""],[24,"base","f",5,0,287,290,20,1,3,1,291,0,""],[25,"b1","c",6,0,292,293,24,0,1,0,291,294,""],[26,"conditions","f",1,0,315,324,1,1,4,4,325,0,""],[27,"et","f",2,0,333,334,26,2,1,3,335,0,""],[28,"egal","f",3,0,336,339,27,2,1,2,340,0,""],[29,"champ","f",4,0,341,345,28,2,1,1,346,0,""],[30,"T0","c",5,2,348,349,29,0,1,0,346,0,""],[31,"chx_utilisateur_tache","c",5,2,355,375,29,0,2,0,346,0,""],[32,":T0_chx_utilisateur_tache","c",4,0,381,405,28,0,2,0,346,406,""],[33,"inf","f",3,0,410,412,27,2,2,2,413,0,""],[34,"champ","f",4,0,414,418,33,2,1,1,419,0,""],[35,"T0","c",5,2,421,422,34,0,1,0,419,0,""],[36,"chp_priorite_tache","c",5,2,428,445,34,0,2,0,419,0,""],[37,":T0_chp_priorite_tache","c",4,0,451,472,33,0,2,0,419,473,""],[38,"complements","f",1,0,485,495,1,1,5,4,496,0,""],[39,"trier_par","f",2,0,504,512,38,1,1,3,513,0,""],[40,"","f",3,0,504,512,39,2,1,2,514,0,""],[41,"champ","f",4,0,515,519,40,2,1,1,520,0,""],[42,"T0","c",5,2,522,523,41,0,1,0,520,0,""],[43,"chp_priorite_tache","c",5,2,529,546,41,0,2,0,520,0,""],[44,"croissant","f",4,0,552,560,40,0,2,0,561,0,""]]'),
('65','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`chp_priorite_tache`) , :n_chp_priorite_tache)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_taches , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_tache`) , :c_chi_id_tache) , egal(champ(`chx_utilisateur_tache`) , :c_chx_utilisateur_tache))
   )
)','
UPDATE b1.tbl_taches SET `chp_priorite_tache` = :n_chp_priorite_tache
WHERE (`chi_id_tache` = :c_chi_id_tache
   AND `chx_utilisateur_tache` = :c_chx_utilisateur_tache) ;','function sql_65($par){
    $texte_sql_65=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_taches` SET ''.CRLF;
    if($par[''n_chp_priorite_tache'']==='''' || $par[''n_chp_priorite_tache'']===NULL ){
        $texte_sql_65.=''    `chp_priorite_tache`  = NULL  ''.CRLF;
    }else{
        $texte_sql_65.=''    `chp_priorite_tache`  = ''.sq0($par[''n_chp_priorite_tache'']).'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_tache` = ''.sq1($par[''c_chi_id_tache'']).''''.CRLF;
    $where0.='' AND `chx_utilisateur_tache` = ''.sq1($par[''c_chx_utilisateur_tache'']).''''.CRLF;
    $texte_sql_65.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_65 = <pre>'' . $texte_sql_65 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_65);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_65()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','priorité tâche par id','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,1,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"chp_priorite_tache","c",4,2,61,78,6,0,1,0,59,0,""],[8,":n_chp_priorite_tache","c",3,0,84,104,5,0,2,0,59,105,""],[9,"provenance","f",1,0,112,121,1,1,3,5,122,0,""],[10,"table_reference","f",2,0,130,144,9,1,1,4,145,0,""],[11,"source","f",3,0,156,161,10,1,1,3,162,0,""],[12,"nom_de_la_table","f",4,0,163,177,11,2,1,2,178,0,""],[13,"tbl_taches","c",5,0,179,188,12,0,1,0,0,0,""],[14,"base","f",5,0,192,195,12,1,2,1,196,0,""],[15,"b1","c",6,0,197,198,14,0,1,0,196,199,""],[16,"conditions","f",1,0,220,229,1,1,4,4,230,0,""],[17,"et","f",2,0,238,239,16,2,1,3,240,0,""],[18,"egal","f",3,0,241,244,17,2,1,2,245,0,""],[19,"champ","f",4,0,246,250,18,1,1,1,251,0,""],[20,"chi_id_tache","c",5,2,253,264,19,0,1,0,251,0,""],[21,":c_chi_id_tache","c",4,0,270,284,18,0,2,0,251,285,""],[22,"egal","f",3,0,289,292,17,2,2,2,293,0,""],[23,"champ","f",4,0,294,298,22,1,1,1,299,0,""],[24,"chx_utilisateur_tache","c",5,2,301,321,23,0,1,0,299,0,""],[25,":c_chx_utilisateur_tache","c",4,0,327,350,22,0,2,0,299,351,""]]'),
('66','1','update','modifier(
   base_de_reference(1),
   valeurs(affecte(champ(`cht_rev_requete`) , :n_cht_rev_requete) , affecte(champ(`cht_sql_requete`) , :n_cht_sql_requete) , affecte(champ(`cht_php_requete`) , :n_cht_php_requete)),
   provenance(
      table_reference(
         source(nom_de_la_table(tbl_requetes , base(b1)))
      )
   ),
   conditions(
      et(egal(champ(`chi_id_requete`) , :c_chi_id_requete) , egal(champ(`chx_cible_requete`) , :c_chx_cible_requete))
   )
)','
UPDATE b1.tbl_requetes SET `cht_rev_requete` = :n_cht_rev_requete , `cht_sql_requete` = :n_cht_sql_requete , `cht_php_requete` = :n_cht_php_requete
WHERE (`chi_id_requete` = :c_chi_id_requete
   AND `chx_cible_requete` = :c_chx_cible_requete) ;','function sql_66($par){
    $texte_sql_66=''UPDATE `''.$GLOBALS[BDD][BDD_1][''nom_bdd''].''`.`tbl_requetes` SET ''.CRLF;
    if($par[''n_cht_rev_requete'']==='''' || $par[''n_cht_rev_requete'']===NULL ){
        $texte_sql_66.=''    `cht_rev_requete`  = NULL  , ''.CRLF;
    }else{
        $texte_sql_66.=''    `cht_rev_requete`  = \''''.sq0($par[''n_cht_rev_requete'']).''\'' , ''.CRLF;
    }
    if($par[''n_cht_sql_requete'']==='''' || $par[''n_cht_sql_requete'']===NULL ){
        $texte_sql_66.=''    `cht_sql_requete`  = NULL  , ''.CRLF;
    }else{
        $texte_sql_66.=''    `cht_sql_requete`  = \''''.sq0($par[''n_cht_sql_requete'']).''\'' , ''.CRLF;
    }
    if($par[''n_cht_php_requete'']==='''' || $par[''n_cht_php_requete'']===NULL ){
        $texte_sql_66.=''    `cht_php_requete`  = NULL  ''.CRLF;
    }else{
        $texte_sql_66.=''    `cht_php_requete`  = \''''.sq0($par[''n_cht_php_requete'']).''\'' ''.CRLF;
    }
    $where0='' WHERE 1=1 ''.CRLF;
    $where0.='' AND `chi_id_requete` = ''.sq1($par[''c_chi_id_requete'']).''''.CRLF;
    $where0.='' AND `chx_cible_requete` = ''.sq1($par[''c_chx_cible_requete'']).''''.CRLF;
    $texte_sql_66.=$where0;
    // echo __FILE__ . '' '' . __LINE__ . '' $texte_sql_66 = <pre>'' . $texte_sql_66 . ''</pre>'' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_66);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, ''code_erreur'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => ''erreur sql_66()''.'' ''.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, ''changements'' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
','requetes pour rev,sql et php','[[0,"","INIT",-1,0,0,0,0,1,0,0,0,0,""],[1,"modifier","f",0,0,0,7,0,4,1,6,8,0,""],[2,"base_de_reference","f",1,0,13,29,1,1,1,1,30,0,""],[3,"1","c",2,0,31,31,2,0,1,0,30,32,""],[4,"valeurs","f",1,0,38,44,1,3,2,3,45,0,""],[5,"affecte","f",2,0,46,52,4,2,1,2,53,0,""],[6,"champ","f",3,0,54,58,5,1,1,1,59,0,""],[7,"cht_rev_requete","c",4,2,61,75,6,0,1,0,59,0,""],[8,":n_cht_rev_requete","c",3,0,81,98,5,0,2,0,59,99,""],[9,"affecte","f",2,0,103,109,4,2,2,2,110,0,""],[10,"champ","f",3,0,111,115,9,1,1,1,116,0,""],[11,"cht_sql_requete","c",4,2,118,132,10,0,1,0,116,0,""],[12,":n_cht_sql_requete","c",3,0,138,155,9,0,2,0,116,156,""],[13,"affecte","f",2,0,160,166,4,2,3,2,167,0,""],[14,"champ","f",3,0,168,172,13,1,1,1,173,0,""],[15,"cht_php_requete","c",4,2,175,189,14,0,1,0,173,0,""],[16,":n_cht_php_requete","c",3,0,195,212,13,0,2,0,173,213,""],[17,"provenance","f",1,0,220,229,1,1,3,5,230,0,""],[18,"table_reference","f",2,0,238,252,17,1,1,4,253,0,""],[19,"source","f",3,0,264,269,18,1,1,3,270,0,""],[20,"nom_de_la_table","f",4,0,271,285,19,2,1,2,286,0,""],[21,"tbl_requetes","c",5,0,287,298,20,0,1,0,0,0,""],[22,"base","f",5,0,302,305,20,1,2,1,306,0,""],[23,"b1","c",6,0,307,308,22,0,1,0,306,309,""],[24,"conditions","f",1,0,330,339,1,1,4,4,340,0,""],[25,"et","f",2,0,348,349,24,2,1,3,350,0,""],[26,"egal","f",3,0,351,354,25,2,1,2,355,0,""],[27,"champ","f",4,0,356,360,26,1,1,1,361,0,""],[28,"chi_id_requete","c",5,2,363,376,27,0,1,0,361,0,""],[29,":c_chi_id_requete","c",4,0,382,398,26,0,2,0,361,399,""],[30,"egal","f",3,0,403,406,25,2,2,2,407,0,""],[31,"champ","f",4,0,408,412,30,1,1,1,413,0,""],[32,"chx_cible_requete","c",5,2,415,431,31,0,1,0,413,0,""],[33,":c_chx_cible_requete","c",4,0,437,456,30,0,2,0,413,457,""]]');
/*



  =========================================================================
  Pour la table tbl_tests il n'y a aucune donnée à insérer
  =========================================================================
*/
