<?php
function sql_15($par){
    $champs0='
      `T0`.`chi_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_commentaire_basedd`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_bdds T0    ';
    $sql0.=$from0;
    $where0=' WHERE 1=1 '.CRLF;
    if(($par['T0_chx_cible_id_basedd'] !== '')){
        $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chx_cible_id_basedd`',$par['T0_chx_cible_id_basedd']);
    }
    if(($par['T0_chi_id_basedd'] !== '')){
        $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chi_id_basedd`',$par['T0_chi_id_basedd']);
    }
    if(($par['T0_chp_nom_basedd'] !== '')){
        $where0.=' AND `T0`.`chp_nom_basedd` LIKE '.sq1($par['T0_chp_nom_basedd']).''.CRLF;
    }
    $sql0.=$where0;
    $order0='
       ORDER BY  `T0`.`chi_id_basedd` ASC';
    $sql0.=$order0;
    $plage0='
       LIMIT '.sq1($par['quantitee']).' OFFSET '.sq1($par['debut']).' ';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' . $sql0 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                'T0.chi_id_basedd' => $tab0[0],
                'T0.chp_nom_basedd' => $tab0[1],
                'T0.chp_commentaire_basedd' => $tab0[2],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par['quantitee'] || $_SESSION[APP_KEY]['__filtres'][$par['page_courante']]['champs']['__xpage'] > 0)){
            $sql1='SELECT COUNT(*) '.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           __xst  => true       ,
           __xva  => $donnees0   ,
           'nombre'  => $__nbEnregs ,
           'sql0'    => $sql0          ,
           'where0'  => $where0     ,
        );
    }else{
        return array(
         __xst  => false ,
         __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         'sql0'    => $sql0,
         'where0'  => $where0     ,
        );
    }
}
