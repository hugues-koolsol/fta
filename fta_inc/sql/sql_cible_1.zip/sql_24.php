<?php
function sql_24($par){
    $texte_sql_24='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_taches` SET '.CRLF;
    $texte_sql_24.=' `chp_priorite_tache` = (`chp_priorite_tache`+1) '.CRLF;
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chx_utilisateur_tache` = '.sq1($par['c_chx_utilisateur_tache']).''.CRLF;
    $where0.=' AND `chp_priorite_tache` < 50'.CRLF;
    $texte_sql_24.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_24 = <pre>' . $texte_sql_24 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_24)){
        return(array( __xst => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => 'erreur sql_24()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
