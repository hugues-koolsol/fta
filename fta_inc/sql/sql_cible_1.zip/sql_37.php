<?php
function sql_37($par){
    $texte_sql_37='
      INSERT INTO `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_dossiers`(
         `chx_cible_dossier` , 
         `chp_nom_dossier`
      ) VALUES 
    ';
    $liste_des_valeurs='';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''){
            $liste_des_valeurs.=',';
        }
        $liste_des_valeurs.='(';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_cible_dossier']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_nom_dossier']).'';
        $liste_des_valeurs.=')';
    }
    $texte_sql_37.=$liste_des_valeurs;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_37 = <pre>' . $texte_sql_37 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_37)){
        return(array(
            __xst      => false, 
            'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => 'erreur sql_37()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            'nouvel_id'   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
