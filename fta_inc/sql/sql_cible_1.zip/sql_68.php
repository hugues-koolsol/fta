<?php
function sql_68($par){
    $champs0='
      `T0`.`chi_id_test`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_tests T0    ';
    $sql0.=$from0;
    /* ATTENTION : pas de condition dans cette liste */
    $where0=' WHERE 1 ';
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' .  $sql0  . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                'T0.chi_id_test' => $tab0[0],
            );
        }
        return array(
           __xst  => true       ,
           __xva  => $donnees0   ,
           'sql0'    => $sql0          ,
           'where0'  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           'sql0'    => $sql0,
           'where0'  => $where0     ,
        );
    }
}
