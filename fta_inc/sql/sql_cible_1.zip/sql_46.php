<?php
function sql_46($par,$db){
    $texte_sql_46='
      
      COMMIT;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_46 = <pre>' . $texte_sql_46 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$db->exec($texte_sql_46);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, 'code_erreur' => $db->lastErrorCode() ,__xme => 'erreur sql_46()'.' '.$db->lastErrorMsg()));
    }else{
        return(array( __xst => true ));
    }
}
