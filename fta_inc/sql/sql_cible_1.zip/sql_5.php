<?php
function sql_5($par){
    $texte_sql_5='
      
      DELETE FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_revs
          WHERE (`chx_cible_rev` = '.sq1($par['chx_cible_rev']).' AND `chp_provenance_rev` = '.sq1($par['chp_provenance_rev']).' AND `chx_source_rev` = '.sq1($par['chx_source_rev']).') ;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_5 = <pre>' . $texte_sql_5 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_5);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => 'erreur sql_5()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
