<?php
function sql_54($par){
    $texte_sql_54='
      INSERT  INTO `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_sources`(
         `chx_cible_id_source` , 
         `chp_nom_source` , 
         `chp_commentaire_source` , 
         `chx_dossier_id_source` , 
         `chp_rev_source` , 
         `chp_genere_source` , 
         `chp_type_source`
      ) VALUES 
    ';
    $liste_des_valeurs='';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''){
            $liste_des_valeurs.=',';
        }
        $liste_des_valeurs.='(';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_cible_id_source']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_nom_source']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_commentaire_source']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_dossier_id_source']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_rev_source']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_genere_source']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_type_source']).'';
        $liste_des_valeurs.=')';
    }
    $texte_sql_54.=$liste_des_valeurs;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_54 = <pre>' . $texte_sql_54 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_54);
    error_reporting($err);
    if(false === $ret){
        return(array(
            __xst      => false, 
            'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => 'erreur sql_54()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            'nouvel_id'   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
