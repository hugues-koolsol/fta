<?php
function sql_67($par){
    $champs0='
      `T0`.`chi_id_test` , `T0`.`chp_nom_test` , `T0`.`chp_texte1_test` , `T0`.`chx_test_parent_test`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_tests T0    ';
    $sql0.=$from0;
    $where0=' WHERE 1=1 '.PHP_EOL;
    $where0.=PHP_EOL.construction_where_sql_sur_id('`T0`.`chi_id_test`',$par['T0_chi_id_test']);
    $sql0.=$where0;
    $order0='
       ORDER BY  `T0`.`chi_id_test` LIMIT '.sq1($par['quantitee']).' OFFSET '.sq1($par['debut']).'  DESC';
    $sql0.=$order0;
    $plage0='
        LIMIT '.sq1($par['quantitee']).' OFFSET '.sq1($par['debut']).' ';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' .  $sql0  . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                'T0.chi_id_test' => $tab0[0],
                'T0.chp_nom_test' => $tab0[1],
                'T0.chp_texte1_test' => $tab0[2],
                'T0.chx_test_parent_test' => $tab0[3],
            );
        }
        return array(
           __xst  => true       ,
           __xva  => $donnees0   ,
           'sql0'    => $sql0          ,
           'where0'  => $where0     ,
        );
    }else{
        return array(
           __xst  => false ,
           __xme => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           'sql0'    => $sql0,
           'where0'  => $where0     ,
        );
    }
}
