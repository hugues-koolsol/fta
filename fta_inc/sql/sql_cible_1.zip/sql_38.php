<?php
function sql_38($par){
    $texte_sql_38='
      
      BEGIN TRANSACTION;
      
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_38 = <pre>' . $texte_sql_38 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_38)){
        return(array( __xst => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => 'erreur sql_38()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true ));
    }
}
