<?php
function sql_48($par){
    $texte_sql_48='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_cibles` SET '.CRLF;
    $texte_sql_48.='    `chp_nom_cible`          = \''.sq0($par['n_chp_nom_cible']).'\'          , '.CRLF;
    if($par['n_chp_dossier_cible']==='' || $par['n_chp_dossier_cible']===NULL ){
        $texte_sql_48.='    `chp_dossier_cible`      = NULL      , '.CRLF;
    }else{
        $texte_sql_48.='    `chp_dossier_cible`      = \''.sq0($par['n_chp_dossier_cible']).'\' , '.CRLF;
    }
    if($par['n_chp_commentaire_cible']==='' || $par['n_chp_commentaire_cible']===NULL ){
        $texte_sql_48.='    `chp_commentaire_cible`  = NULL  '.CRLF;
    }else{
        $texte_sql_48.='    `chp_commentaire_cible`  = \''.sq0($par['n_chp_commentaire_cible']).'\' '.CRLF;
    }
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_cible` = '.sq1($par['c_chi_id_cible']).''.CRLF;
    $texte_sql_48.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_48 = <pre>' . $texte_sql_48 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_48);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => 'erreur sql_48()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
