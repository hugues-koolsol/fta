<?php
function sql_12($par){
    $texte_sql_12='
      INSERT INTO `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_revs`(
         `chx_cible_rev` , 
         `chp_provenance_rev` , 
         `chx_source_rev` , 
         `chp_id_rev` , 
         `chp_valeur_rev` , 
         `chp_type_rev` , 
         `chp_niveau_rev` , 
         `chp_quotee_rev` , 
         `chp_pos_premier_rev` , 
         `chp_pos_dernier_rev` , 
         `chp_parent_rev` , 
         `chp_nbr_enfants_rev` , 
         `chp_num_enfant_rev` , 
         `chp_profondeur_rev` , 
         `chp_pos_ouver_parenthese_rev` , 
         `chp_pos_fermer_parenthese_rev` , 
         `chp_commentaire_rev`
      ) VALUES 
    ';
    $liste_des_valeurs='';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''){
            $liste_des_valeurs.=',';
        }
        $liste_des_valeurs.='(';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_cible_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_provenance_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_source_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_id_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_valeur_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_type_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_niveau_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_quotee_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_pos_premier_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_pos_dernier_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_parent_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_nbr_enfants_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_num_enfant_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_profondeur_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_pos_ouver_parenthese_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_pos_fermer_parenthese_rev']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_commentaire_rev']).'';
        $liste_des_valeurs.=')';
    }
    $texte_sql_12.=$liste_des_valeurs;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_12 = <pre>' . $texte_sql_12 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_12)){
        return(array(
            __xst      => false, 
            'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            __xme => 'erreur sql_12()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            __xst      => true,
            'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            'nouvel_id'   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
