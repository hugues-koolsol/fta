<?php
function sql_10($par){
    $texte_sql_10='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_bdds` SET '.CRLF;
    if($par['n_chp_rev_travail_basedd']==='' || $par['n_chp_rev_travail_basedd']===NULL ){
        $texte_sql_10.='    `chp_rev_travail_basedd`  = NULL  '.CRLF;
    }else{
        $texte_sql_10.='    `chp_rev_travail_basedd`  = \''.sq0($par['n_chp_rev_travail_basedd']).'\' '.CRLF;
    }
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_basedd` = '.sq1($par['c_chi_id_basedd']).''.CRLF;
    $where0.=' AND `chx_cible_id_basedd` = '.sq1($par['c_chx_cible_id_basedd']).''.CRLF;
    $texte_sql_10.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_10 = <pre>' . $texte_sql_10 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_10)){
        return(array( __xst => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => 'erreur sql_10()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
