<?php
function sql_4($par){
    $texte_sql_4='
      
      DELETE FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_requetes
          WHERE (`chi_id_requete` = '.sq1($par['chi_id_requete']).' AND `chx_cible_requete` = '.sq1($par['chx_cible_requete']).') ;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_4 = <pre>' . $texte_sql_4 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_4)){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_4()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
