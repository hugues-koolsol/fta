<?php
function sql_21($par){
    $texte_sql_21='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_taches` SET '.CRLF;
    $texte_sql_21.=' `chp_priorite_tache` = (`chp_priorite_tache`+1) '.CRLF;
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_tache` = '.sq1($par['c_chi_id_tache']).''.CRLF;
    $where0.=' AND `chx_utilisateur_tache` = '.sq1($par['c_chx_utilisateur_tache']).''.CRLF;
    $where0.=' AND `chp_priorite_tache` < 50'.CRLF;
    $texte_sql_21.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_21 = <pre>' . $texte_sql_21 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_21)){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_21()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
