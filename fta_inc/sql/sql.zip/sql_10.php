<?php
function sql_10($par){
    $texte_sql_10='
      
      UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_bdds SET 
            `chp_rev_travail_basedd` = '.sq1($par['n_chp_rev_travail_basedd']).'
          WHERE `chi_id_basedd` = '.sq1($par['c_chi_id_basedd']).' ;
    ';
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_10)){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_10()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
