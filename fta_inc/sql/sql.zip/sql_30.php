<?php
function sql_30($par){
    $texte_sql_30='
      INSERT INTO `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_taches`(
         `chx_utilisateur_tache` , 
         `chp_texte_tache` , 
         `chp_priorite_tache`
      ) VALUES 
    ';
    $liste_des_valeurs='';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''){
            $liste_des_valeurs.=',';
        }
        $liste_des_valeurs.='(';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_utilisateur_tache']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_texte_tache']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_priorite_tache']).'';
        $liste_des_valeurs.=')';
    }
    $texte_sql_30.=$liste_des_valeurs;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_30 = <pre>' . $texte_sql_30 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_30)){
        return(array(
            'statut'      => false, 
            'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            'message' => 'erreur sql_30()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            'statut'      => true,
            'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            'nouvel_id'   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
