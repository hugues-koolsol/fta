<?php
function sql_16($par){
    $texte_sql_16='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_bdds` SET '.CRLF;
    if($par['n_chx_dossier_id_basedd']==='' || $par['n_chx_dossier_id_basedd']===NULL ){
        $texte_sql_16.='    `chx_dossier_id_basedd`   = NULL   , '.CRLF;
    }else{
        $texte_sql_16.='    `chx_dossier_id_basedd`   = '.sq0($par['n_chx_dossier_id_basedd']).' , '.CRLF;
    }
    $texte_sql_16.='    `chp_nom_basedd`          = \''.sq0($par['n_chp_nom_basedd']).'\'          , '.CRLF;
    if($par['n_chp_rev_basedd']==='' || $par['n_chp_rev_basedd']===NULL ){
        $texte_sql_16.='    `chp_rev_basedd`          = NULL          , '.CRLF;
    }else{
        $texte_sql_16.='    `chp_rev_basedd`          = \''.sq0($par['n_chp_rev_basedd']).'\' , '.CRLF;
    }
    if($par['n_chp_commentaire_basedd']==='' || $par['n_chp_commentaire_basedd']===NULL ){
        $texte_sql_16.='    `chp_commentaire_basedd`  = NULL  , '.CRLF;
    }else{
        $texte_sql_16.='    `chp_commentaire_basedd`  = \''.sq0($par['n_chp_commentaire_basedd']).'\' , '.CRLF;
    }
    if($par['n_chp_genere_basedd']==='' || $par['n_chp_genere_basedd']===NULL ){
        $texte_sql_16.='    `chp_genere_basedd`       = NULL       , '.CRLF;
    }else{
        $texte_sql_16.='    `chp_genere_basedd`       = \''.sq0($par['n_chp_genere_basedd']).'\' , '.CRLF;
    }
    if($par['n_chp_rev_travail_basedd']==='' || $par['n_chp_rev_travail_basedd']===NULL ){
        $texte_sql_16.='    `chp_rev_travail_basedd`  = NULL  , '.CRLF;
    }else{
        $texte_sql_16.='    `chp_rev_travail_basedd`  = \''.sq0($par['n_chp_rev_travail_basedd']).'\' , '.CRLF;
    }
    if($par['n_chp_fournisseur_basedd']==='' || $par['n_chp_fournisseur_basedd']===NULL ){
        $texte_sql_16.='    `chp_fournisseur_basedd`  = NULL  '.CRLF;
    }else{
        $texte_sql_16.='    `chp_fournisseur_basedd`  = \''.sq0($par['n_chp_fournisseur_basedd']).'\' '.CRLF;
    }
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_basedd` = '.sq1($par['c_chi_id_basedd']).''.CRLF;
    $where0.=' AND `chx_cible_id_basedd` = '.sq1($par['c_chx_cible_id_basedd']).''.CRLF;
    $texte_sql_16.=$where0;
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_16)){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_16()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
