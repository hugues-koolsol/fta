<?php
function sql_55($par){
    $texte_sql_55='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_dossiers` SET '.CRLF;
    $texte_sql_55.='    `chx_cible_dossier`  = '.sq0($par['n_chx_cible_dossier']).'  , '.CRLF;
    if($par['n_chp_nom_dossier']==='' || $par['n_chp_nom_dossier']===NULL ){
        $texte_sql_55.='    `chp_nom_dossier`    = NULL    '.CRLF;
    }else{
        $texte_sql_55.='    `chp_nom_dossier`    = \''.sq0($par['n_chp_nom_dossier']).'\' '.CRLF;
    }
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_dossier` = '.sq1($par['c_chi_id_dossier']).''.CRLF;
    $where0.=' AND `chx_cible_dossier` = '.sq1($par['c_chx_cible_dossier']).''.CRLF;
    $texte_sql_55.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_55 = <pre>' . $texte_sql_55 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_55);
    error_reporting($err);
    if(false === $ret){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_55()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
