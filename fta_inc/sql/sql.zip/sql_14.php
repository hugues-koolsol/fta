<?php
function sql_14($par){
    $texte_sql_14='
      
      DELETE FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_revs
          WHERE `chx_cible_rev` = '.sq1($par['chx_cible_rev']).' ;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_14 = <pre>' . $texte_sql_14 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_14);
    error_reporting($err);
    if(false === $ret){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_14()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
