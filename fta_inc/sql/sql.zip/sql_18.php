<?php
function sql_18($par){
    $texte_sql_18='
      
      DELETE FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_bdds
          WHERE (`chi_id_basedd` = '.sq1($par['chi_id_basedd']).' AND `chx_cible_id_basedd` = '.sq1($par['chx_cible_id_basedd']).') ;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_18 = <pre>' . $texte_sql_18 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_18);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => 'erreur sql_18()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
