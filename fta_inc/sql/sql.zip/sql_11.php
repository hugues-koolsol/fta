<?php
function sql_11($par){
    $champs0='
      `T0`.`chi_id_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_nom_basedd`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_bdds T0    ';
    $sql0.=$from0;
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chi_id_basedd`',$par['les_id_des_bases']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' . var_export( $sql0 , true ) . '</pre>' ; exit(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                'T0.chi_id_basedd' => $tab0[0],
                'T0.chp_rev_travail_basedd' => $tab0[1],
                'T0.chp_nom_basedd' => $tab0[2],
            );
        }
        return array(
           'statut'  => true       ,
           'valeur' => $donnees0  ,
           'sql' => $sql0          ,
        );
    }else{
        return array(
         'statut'  => false ,
         'message' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         'sql' => $sql0,
        );
    }
}
