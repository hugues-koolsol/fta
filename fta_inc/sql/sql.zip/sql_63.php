<?php
function sql_63($par){
    $texte_sql_63='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_sources` SET '.CRLF;
    $texte_sql_63.='    `chp_nom_source`          = \''.sq0($par['n_chp_nom_source']).'\'          , '.CRLF;
    if($par['n_chp_commentaire_source']==='' || $par['n_chp_commentaire_source']===NULL ){
        $texte_sql_63.='    `chp_commentaire_source`  = NULL  , '.CRLF;
    }else{
        $texte_sql_63.='    `chp_commentaire_source`  = \''.sq0($par['n_chp_commentaire_source']).'\' , '.CRLF;
    }
    if($par['n_chx_dossier_id_source']==='' || $par['n_chx_dossier_id_source']===NULL ){
        $texte_sql_63.='    `chx_dossier_id_source`   = NULL   , '.CRLF;
    }else{
        $texte_sql_63.='    `chx_dossier_id_source`   = '.sq0($par['n_chx_dossier_id_source']).' , '.CRLF;
    }
    if($par['n_chp_rev_source']==='' || $par['n_chp_rev_source']===NULL ){
        $texte_sql_63.='    `chp_rev_source`          = NULL          , '.CRLF;
    }else{
        $texte_sql_63.='    `chp_rev_source`          = \''.sq0($par['n_chp_rev_source']).'\' , '.CRLF;
    }
    if($par['n_chp_genere_source']==='' || $par['n_chp_genere_source']===NULL ){
        $texte_sql_63.='    `chp_genere_source`       = NULL       , '.CRLF;
    }else{
        $texte_sql_63.='    `chp_genere_source`       = \''.sq0($par['n_chp_genere_source']).'\' , '.CRLF;
    }
    $texte_sql_63.='    `chp_type_source`         = \''.sq0($par['n_chp_type_source']).'\'         '.CRLF;
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_source` = '.sq1($par['c_chi_id_source']).''.CRLF;
    $where0.=' AND `chx_cible_id_source` = '.sq1($par['c_chx_cible_id_source']).''.CRLF;
    $texte_sql_63.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_63 = <pre>' . $texte_sql_63 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_63);
    error_reporting($err);
    if(false === $ret){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_63()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
