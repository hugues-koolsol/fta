<?php
function sql_58($par){
    $texte_sql_58='
      
      DELETE FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_dossiers
          WHERE (`chi_id_dossier` = '.sq1($par['chi_id_dossier']).' AND `chx_cible_dossier` = '.sq1($par['chx_cible_dossier']).') ;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_58 = <pre>' . $texte_sql_58 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_58);
    error_reporting($err);
    if(false === $ret){
        return(array( __xst => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,__xme => 'erreur sql_58()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( __xst => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
