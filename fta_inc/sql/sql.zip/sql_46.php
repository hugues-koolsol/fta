<?php
function sql_46($par){
    $texte_sql_46='
      
      COMMIT;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_46 = <pre>' . $texte_sql_46 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_46);
    error_reporting($err);
    if(false === $ret){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_46()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true ));
    }
}
