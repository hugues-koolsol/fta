<?php
function sql_26($par){
    $champs0='
      `T0`.`chi_id_basedd` , `T0`.`chx_dossier_id_basedd` , `T0`.`chx_cible_id_basedd` , `T0`.`chp_nom_basedd` , `T0`.`chp_rev_basedd` , 
      `T0`.`chp_commentaire_basedd` , `T0`.`chp_genere_basedd` , `T0`.`chp_rev_travail_basedd` , `T0`.`chp_fournisseur_basedd` , `T1`.`chi_id_dossier` , 
      `T1`.`chx_cible_dossier` , `T1`.`chp_nom_dossier` , `T2`.`chi_id_cible` , `T2`.`chp_nom_cible` , `T2`.`chp_dossier_cible` , 
      `T2`.`chp_commentaire_cible`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_bdds T0
       LEFT JOIN `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_dossiers T1 ON T1.chi_id_dossier = T0.chx_dossier_id_basedd

       LEFT JOIN `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_cibles T2 ON T2.chi_id_cible = T0.chx_cible_id_basedd
    ';
    $sql0.=$from0;
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chi_id_basedd`',$par['T0_chi_id_basedd']);
    $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chx_cible_id_basedd`',$par['T0_chx_cible_id_basedd']);
    $sql0.=$where0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' .  $sql0  . '</pre>' ; exit(0);
    $errr=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($errr);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                'T0.chi_id_basedd' => $tab0[0],
                'T0.chx_dossier_id_basedd' => $tab0[1],
                'T0.chx_cible_id_basedd' => $tab0[2],
                'T0.chp_nom_basedd' => $tab0[3],
                'T0.chp_rev_basedd' => $tab0[4],
                'T0.chp_commentaire_basedd' => $tab0[5],
                'T0.chp_genere_basedd' => $tab0[6],
                'T0.chp_rev_travail_basedd' => $tab0[7],
                'T0.chp_fournisseur_basedd' => $tab0[8],
                'T1.chi_id_dossier' => $tab0[9],
                'T1.chx_cible_dossier' => $tab0[10],
                'T1.chp_nom_dossier' => $tab0[11],
                'T2.chi_id_cible' => $tab0[12],
                'T2.chp_nom_cible' => $tab0[13],
                'T2.chp_dossier_cible' => $tab0[14],
                'T2.chp_commentaire_cible' => $tab0[15],
            );
        }
        return array(
           'statut'  => true       ,
           'valeur'  => $donnees0   ,
           'sql0'    => $sql0          ,
           'where0'  => $where0     ,
        );
    }else{
        return array(
           'statut'  => false ,
           'message' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           'sql0'    => $sql0,
           'where0'  => $where0     ,
        );
    }
}
