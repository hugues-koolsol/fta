<?php
function sql_40($par){
    $texte_sql_40='
      
      ROLLBACK;
    ';
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_40 = <pre>' . $texte_sql_40 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_40)){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_40()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true ));
    }
}
