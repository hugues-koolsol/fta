<?php
function sql_8($par){
    $texte_sql_8='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_revs` SET '.CRLF;
    if($par['n_chx_source_rev']==='' || $par['n_chx_source_rev']===NULL ){
        $texte_sql_8.='    `chx_source_rev`  = NULL  '.CRLF;
    }else{
        $texte_sql_8.='    `chx_source_rev`  = '.sq0($par['n_chx_source_rev']).' '.CRLF;
    }
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chx_cible_rev` = '.sq1($par['c_chx_cible_rev']).''.CRLF;
    $where0.=' AND `chp_provenance_rev` = '.sq1($par['c_chp_provenance_rev']).''.CRLF;
    $where0.=' AND `chx_source_rev` = '.sq1($par['c_chx_source_rev']).''.CRLF;
    $texte_sql_8.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_8 = <pre>' . $texte_sql_8 . '</pre>' ; exit(0);
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_8)){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_8()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
