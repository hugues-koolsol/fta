<?php
function sql_7($par){
    $texte_sql_7='
      INSERT INTO `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_requetes`(
         `chx_cible_requete` , 
         `chp_type_requete` , 
         `cht_rev_requete` , 
         `cht_sql_requete` , 
         `cht_php_requete`
      ) VALUES 
    ';
    $liste_des_valeurs='';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''){
            $liste_des_valeurs.=',';
        }
        $liste_des_valeurs.='(';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_cible_requete']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_type_requete']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['cht_rev_requete']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['cht_sql_requete']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['cht_php_requete']).'';
        $liste_des_valeurs.=')';
    }
    $texte_sql_7.=$liste_des_valeurs;
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_7)){
        return(array(
            'statut'      => false, 
            'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            'message' => 'erreur sql_7()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            'statut'      => true,
            'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            'nouvel_id'   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
