<?php
function sql_3($par){
    $texte_sql_3='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_requetes` SET '.CRLF;
    if($par['n_chi_id_requete']==='' || $par['n_chi_id_requete']===NULL ){
        $texte_sql_3.='    `chi_id_requete`  = NULL  '.CRLF;
    }else{
        $texte_sql_3.='    `chi_id_requete`  = '.sq0($par['n_chi_id_requete']).' '.CRLF;
    }
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_requete` = '.sq1($par['c_chi_id_requete']).''.CRLF;
    $texte_sql_3.=$where0;
    if(false === $GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_3)){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_3()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
