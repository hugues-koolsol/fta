<?php
function sql_65($par){
    $texte_sql_65='UPDATE `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_taches` SET '.CRLF;
    if($par['n_chp_priorite_tache']==='' || $par['n_chp_priorite_tache']===NULL ){
        $texte_sql_65.='    `chp_priorite_tache`  = NULL  '.CRLF;
    }else{
        $texte_sql_65.='    `chp_priorite_tache`  = '.sq0($par['n_chp_priorite_tache']).' '.CRLF;
    }
    $where0=' WHERE 1=1 '.CRLF;
    $where0.=' AND `chi_id_tache` = '.sq1($par['c_chi_id_tache']).''.CRLF;
    $where0.=' AND `chx_utilisateur_tache` = '.sq1($par['c_chx_utilisateur_tache']).''.CRLF;
    $texte_sql_65.=$where0;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_65 = <pre>' . $texte_sql_65 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_65);
    error_reporting($err);
    if(false === $ret){
        return(array( 'statut' => false, 'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode() ,'message' => 'erreur sql_65()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }else{
        return(array( 'statut' => true, 'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes()));
    }
}
