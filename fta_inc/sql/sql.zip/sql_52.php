<?php
function sql_52($par){
    $texte_sql_52='
      INSERT  OR IGNORE  INTO `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.`tbl_dossiers`(
         `chx_cible_dossier` , 
         `chp_nom_dossier`
      ) VALUES 
    ';
    $liste_des_valeurs='';
    for($i=0;($i < count($par));$i++){
        if($liste_des_valeurs != ''){
            $liste_des_valeurs.=',';
        }
        $liste_des_valeurs.='(';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chx_cible_dossier']).',';
        $liste_des_valeurs.=CRLF.'      '.sq1($par[$i]['chp_nom_dossier']).'';
        $liste_des_valeurs.=')';
    }
    $texte_sql_52.=$liste_des_valeurs;
    // echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_52 = <pre>' . $texte_sql_52 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $ret=$GLOBALS[BDD][BDD_1][LIEN_BDD]->exec($texte_sql_52);
    error_reporting($err);
    if(false === $ret){
        return(array(
            'statut'      => false, 
            'code_erreur' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorCode(), 
            'message' => 'erreur sql_52()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()
        ));
    }else{
        return(array( 
            'statut'      => true,
            'changements' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->changes(),
            'nouvel_id'   => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastInsertRowID(),
        ));
    }
}
