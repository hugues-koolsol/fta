<?php
function sql_13($par){
    $champs0='
      `T0`.`chi_id_rev` , `T0`.`chp_provenance_rev` , `T0`.`chx_source_rev` , `T1`.`chp_nom_source` , `T0`.`chp_valeur_rev` , 
      `T0`.`chp_type_rev` , `T0`.`chp_niveau_rev` , `T0`.`chp_pos_premier_rev` , `T0`.`chp_commentaire_rev`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_revs T0
       LEFT JOIN `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_sources T1 ON T1.chi_id_source = T0.chx_source_rev
    ';
    $sql0.=$from0;
    $where0=' WHERE 1=1 '.CRLF;
    if(($par['T0_chx_cible_rev'] !== '')){
        $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chx_cible_rev`',$par['T0_chx_cible_rev']);
    }
    if(($par['T0_chp_provenance_rev'] !== '')){
        $where0.=' AND `T0`.`chp_provenance_rev` LIKE '.sq1($par['T0_chp_provenance_rev']).''.CRLF;
    }
    if(($par['T0_chx_source_rev'] !== '')){
        $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chx_source_rev`',$par['T0_chx_source_rev']);
    }
    if(($par['T1_chp_nom_source1'] !== '')){
        $where0.=' AND `T1`.`chp_nom_source` LIKE '.sq1($par['T1_chp_nom_source1']).''.CRLF;
    }
    if(($par['T1_chp_nom_source2'] !== '')){
        $where0.=' AND `T1`.`chp_nom_source` NOT LIKE '.sq1($par['T1_chp_nom_source2']).''.CRLF;
    }
    if(($par['T0_chp_valeur_rev'] !== '')){
        $where0.=' AND `T0`.`chp_valeur_rev` LIKE '.sq1($par['T0_chp_valeur_rev']).''.CRLF;
    }
    if(($par['T0_chp_commentaire_rev'] !== '')){
        $where0.=' AND `T0`.`chp_commentaire_rev` LIKE '.sq1($par['T0_chp_commentaire_rev']).''.CRLF;
    }
    if(($par['T0_chi_id_rev'] !== '')){
        $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chi_id_rev`',$par['T0_chi_id_rev']);
    }
    $sql0.=$where0;
    $order0='
       ORDER BY  `T0`.`chp_provenance_rev` ASC, `T0`.`chx_source_rev` ASC';
    $sql0.=$order0;
    $plage0='
       LIMIT '.sq1($par['quantitee']).' OFFSET '.sq1($par['debut']).' ';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' . $sql0 . '</pre>' ; exit(0);
    $err=error_reporting(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    error_reporting($err);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                'T0.chi_id_rev' => $tab0[0],
                'T0.chp_provenance_rev' => $tab0[1],
                'T0.chx_source_rev' => $tab0[2],
                'T1.chp_nom_source' => $tab0[3],
                'T0.chp_valeur_rev' => $tab0[4],
                'T0.chp_type_rev' => $tab0[5],
                'T0.chp_niveau_rev' => $tab0[6],
                'T0.chp_pos_premier_rev' => $tab0[7],
                'T0.chp_commentaire_rev' => $tab0[8],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par['quantitee'] || $_SESSION[APP_KEY]['__filtres'][$par['page_courante']]['champs']['__xpage'] > 0)){
            $sql1='SELECT COUNT(*) '.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           'statut'  => true       ,
           'valeur'  => $donnees0   ,
           'nombre'  => $__nbEnregs ,
           'sql0'    => $sql0          ,
           'where0'  => $where0     ,
        );
    }else{
        return array(
         'statut'  => false ,
         'message' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         'sql0'    => $sql0,
         'where0'  => $where0     ,
        );
    }
}
