<?php
function sql_6($par){
    $champs0='
      `T0`.`chi_id_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_requetes T0    ';
    $sql0.=$from0;
    /* ATTENTION : pas de condition dans cette liste */
    $where0=' WHERE 1 ';
    $sql0.=$where0;
    $order0='
       ORDER BY  `T0`.`chi_id_requete`  ASC';
    $sql0.=$order0;
    /* ATTENTION : pas de limites */
    $plage0='';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' . var_export( $sql0 , true ) . '</pre>' ; exit(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
                'T0.chi_id_requete' => $tab0[0],
                'T0.cht_sql_requete' => $tab0[1],
                'T0.cht_php_requete' => $tab0[2],
            );
        }
        return array(
           'statut'  => true       ,
           'valeur' => $donnees0   ,
           'sql' => $sql0          ,
           'where0' => $where0     ,
        );
    }else{
        return array(
           'statut'  => false ,
           'message' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
           'sql' => $sql0,
           'where0' => $where0     ,
        );
    }
}
