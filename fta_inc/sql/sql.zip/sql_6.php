<?php
function sql_6($par){
    $champs0='
      `T0`.`chi_id_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , 
      `T0`.`cht_commentaire_requete`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_requetes T0    ';
    $sql0.=$from0;
    $where0=' WHERE 1=1 '.CRLF;
    if(($par['T0_chx_cible_requete'] !== '')){
        $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chx_cible_requete`',$par['T0_chx_cible_requete']);
    }
    if(($par['T0_chi_id_requete'] !== '')){
        $where0.=CRLF.construction_where_sql_sur_id('`T0`.`chi_id_requete`',$par['T0_chi_id_requete']);
    }
    if(($par['T0_chp_type_requete'] !== '')){
        $where0+=' AND `T0`.`chp_type_requete` LIKE '.sq1($par['T0_chp_type_requete']).''.CRLF;
    }
    if(($par['T0_cht_rev_requete'] !== '')){
        $where0+=' AND `T0`.`cht_rev_requete` LIKE '.sq1($par['T0_cht_rev_requete']).''.CRLF;
    }
    $sql0.=$where0;
    $order0='
       ORDER BY  `T0`.`chi_id_requete` DESC';
    $sql0.=$order0;
    $plage0='
       LIMIT '.sq1($par['quantitee']).' OFFSET '.sq1($par['debut']).' ';
    $sql0.=$plage0;
    $donnees0=array();
    //echo __FILE__ . ' ' . __LINE__ . ' $sql0 = <pre>' . var_export( $sql0 , true ) . '</pre>' ; exit(0);
    $stmt0=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($sql0);
    if(($stmt0 !== false)){
        $res0=$stmt0->execute();
        while(($tab0=$res0->fetchArray(SQLITE3_NUM))){
            $donnees0[]=array(
            'T0.chi_id_requete' => $tab0[0],
            'T0.chp_type_requete' => $tab0[1],
            'T0.cht_rev_requete' => $tab0[2],
            'T0.cht_sql_requete' => $tab0[3],
            'T0.cht_php_requete' => $tab0[4],
            'T0.cht_commentaire_requete' => $tab0[5],
            );
        }
        $stmt0->close();
        $__nbEnregs=count($donnees0);
        if(($__nbEnregs >= $par['quantitee'] || $_SESSION[APP_KEY]['__filtres'][$par['page_courante']]['champs']['__xpage'] > 0)){
            $sql1='SELECT COUNT(*) '.$from0.$where0;
            $__nbEnregs=$GLOBALS[BDD][BDD_1][LIEN_BDD]->querySingle($sql1);
        }
        return array(
           'statut'  => true       ,
           'valeurs' => $donnees0  ,
           'nombre' => $__nbEnregs ,
           'sql' => $sql0          ,
        );
    }else{
        return array(
         'statut'  => false ,
         'message' => $GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg(),
         'sql' => $sql0,
        );
    }
}
