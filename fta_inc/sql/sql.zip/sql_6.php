<?php
function sql_6($par){
    $texte_sql_6='
      SELECT 
      `T0`.`chi_id_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete`
            FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_requetes T0 ORDER BY  `T0`.`chi_id_requete`  ASC;
    ';
    $stmt=$GLOBALS[BDD][BDD_1][LIEN_BDD]->prepare($texte_sql_6);
    /* echo __FILE__ . ' ' . __LINE__ . ' $texte_sql_6 = <pre>' . $texte_sql_6 . '</pre>' ; exit(0); */
    if($stmt !== false){
        $result=$stmt->execute();
        $donnees=array();
        $arr=$result->fetchArray(SQLITE3_NUM);
        while($arr !== false){
            $donnees[]=array(
                'T0.chi_id_requete' => $arr[0],
                'T0.cht_sql_requete' => $arr[1],
                'T0.cht_php_requete' => $arr[2],
            );
            $arr=$result->fetchArray(SQLITE3_NUM);
        }
        $stmt->close();
        return(array( 'statut' => true, 'valeur' => $donnees));
    }else{
        return(array( 'statut' => false, 'message' => 'erreur sql_6()'.' '.$GLOBALS[BDD][BDD_1][LIEN_BDD]->lastErrorMsg()));
    }
}
