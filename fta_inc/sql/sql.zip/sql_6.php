<?php
function sql_6($par){
    $champs0='
      `T0`.`chi_id_requete` , `T0`.`chp_type_requete` , `T0`.`cht_rev_requete` , `T0`.`cht_sql_requete` , `T0`.`cht_php_requete` , 
      `T0`.`cht_commentaire_requete` , `T2`.`cht_commentaire_requete`
    ';
    $sql0='SELECT '.$champs0;
    $from0='
      FROM `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_requetes T0      , 
           `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_requetes T1
       LEFT JOIN `'.$GLOBALS[BDD][BDD_1]['nom_bdd'].'`.tbl_requetes T2 ON T2.chi_id_requete = T1.chi_id_requete
    ';
    $sql0.=$from0;
}
